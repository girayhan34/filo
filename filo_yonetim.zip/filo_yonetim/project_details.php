<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$project_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($project_id === 0) {
    header("Location: projects.php");
    exit();
}

// Proje detaylarını çek
$stmt = $pdo->prepare("
    SELECT p.*, c.name as customer_name 
    FROM projects p 
    LEFT JOIN customers c ON p.customer_id = c.id 
    WHERE p.id = ?
");
$stmt->execute([$project_id]);
$project = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$project) {
    header("Location: projects.php");
    exit();
}

// Projeye ait görevleri çek
$task_stmt = $pdo->prepare("
    SELECT t.*, u.name as assigned_to_name 
    FROM tasks t 
    LEFT JOIN users u ON t.assigned_to = u.id 
    WHERE t.project_id = ? 
    ORDER BY t.status, t.due_date ASC
");
$task_stmt->execute([$project_id]);
$tasks = $task_stmt->fetchAll(PDO::FETCH_ASSOC);

// Projeye ait finansal verileri çek
$financial_stmt = $pdo->prepare("SELECT 
    SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
    SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expense
FROM income_expense 
WHERE project_id = ?");
$financial_stmt->execute([$project_id]);
$financial_data = $financial_stmt->fetch(PDO::FETCH_ASSOC);

$page_title = 'Proje Detayı: ' . htmlspecialchars($project['project_name']);
$page_subtitle = 'Proje detaylarını ve ilişkili görevleri görüntüleyin.';
include 'includes/header.php';
?>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Proje Bilgileri</h5>
            </div>
            <div class="card-body">
                <p><strong>Müşteri:</strong> <?= htmlspecialchars($project['customer_name'] ?? 'Belirtilmemiş') ?></p>
                <p><strong>Açıklama:</strong> <?= nl2br(htmlspecialchars($project['description'] ?? 'Açıklama yok.')) ?></p>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Projeye Atanmış Görevler</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Görev Başlığı</th>
                                <th>Atanan</th>
                                <th>Bitiş Tarihi</th>
                                <th>Durum</th>
                                <th>Öncelik</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tasks)): ?>
                                <tr><td colspan="5" class="text-center text-muted">Bu projeye atanmış görev bulunmuyor.</td></tr>
                            <?php else: ?>
                                <?php foreach ($tasks as $task): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($task['title']) ?></td>
                                        <td><?= htmlspecialchars($task['assigned_to_name'] ?? 'Atanmamış') ?></td>
                                        <td><?= $task['due_date'] ? date('d.m.Y', strtotime($task['due_date'])) : '-' ?></td>
                                        <td>
                                            <?php 
                                            $status_map = [
                                                'todo' => ['text' => 'Yapılacak', 'class' => 'secondary'],
                                                'inprogress' => ['text' => 'Devam Ediyor', 'class' => 'primary'],
                                                'done' => ['text' => 'Tamamlandı', 'class' => 'success'],
                                                'archived' => ['text' => 'Arşivlendi', 'class' => 'dark'],
                                                'cancelled' => ['text' => 'İptal Edildi', 'class' => 'danger']
                                            ];
                                            $status_info = $status_map[$task['status']] ?? ['text' => $task['status'], 'class' => 'light'];
                                            ?>
                                            <span class="badge bg-<?= $status_info['class'] ?>"><?= $status_info['text'] ?></span>
                                        </td>
                                        <td>
                                            <?php 
                                            $priority_map = [
                                                'low' => ['text' => 'Düşük', 'class' => 'success'],
                                                'medium' => ['text' => 'Orta', 'class' => 'warning'],
                                                'high' => ['text' => 'Yüksek', 'class' => 'danger'],
                                                'urgent' => ['text' => 'Acil', 'class' => 'danger fw-bold']
                                            ];
                                            $priority_info = $priority_map[$task['priority']] ?? ['text' => $task['priority'], 'class' => 'secondary'];
                                            ?>
                                            <span class="badge border border-<?= $priority_info['class'] ?> text-<?= $priority_info['class'] ?>"><?= $priority_info['text'] ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h5 class="card-title">Proje Özeti</h5>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>Başlangıç:</strong> <?= $project['start_date'] ? date('d.m.Y', strtotime($project['start_date'])) : '-' ?></li>
                    <li class="list-group-item"><strong>Bitiş:</strong> <?= $project['end_date'] ? date('d.m.Y', strtotime($project['end_date'])) : '-' ?></li>
                    <li class="list-group-item"><strong>Bütçe:</strong> <?= $project['budget'] ? number_format($project['budget'], 2, ',', '.') . ' ₺' : '-' ?></li>
                    <li class="list-group-item"><strong>Durum:</strong> <span class="badge bg-primary"><?= htmlspecialchars($project['status']) ?></span></li>
                </ul>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Finansal Özet</h5>
                <?php 
                    $total_income = $financial_data['total_income'] ?? 0;
                    $total_expense = $financial_data['total_expense'] ?? 0;
                    $profit = $total_income - $total_expense;
                    $profit_class = $profit >= 0 ? 'text-success' : 'text-danger';
                ?>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Toplam Gelir
                        <span class="badge bg-success rounded-pill"><?= number_format($total_income, 2, ',', '.') ?> ₺</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Toplam Gider
                        <span class="badge bg-danger rounded-pill"><?= number_format($total_expense, 2, ',', '.') ?> ₺</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center fw-bold">
                        Net Kar/Zarar
                        <span class="badge bg-primary rounded-pill <?= $profit_class ?>"><?= number_format($profit, 2, ',', '.') ?> ₺</span>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
$task_stmt = $pdo->prepare("
    SELECT t.*, u.name as assigned_to_name 
    FROM tasks t 
    LEFT JOIN users u ON t.assigned_to = u.id 
    WHERE t.project_id = ? 
    ORDER BY t.status, t.due_date ASC
");
$task_stmt->execute([$project_id]);
$tasks = $task_stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Proje Detayı: ' . htmlspecialchars($project['project_name']);
$page_subtitle = 'Proje detaylarını ve ilişkili görevleri görüntüleyin.';
include 'includes/header.php';
?>

<div class="row">
    <div class="col-md-8">
        <div class="card shadow-sm mb-4">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i>Proje Bilgileri</h5>
            </div>
            <div class="card-body">
                <p><strong>Müşteri:</strong> <?= htmlspecialchars($project['customer_name'] ?? 'Belirtilmemiş') ?></p>
                <p><strong>Açıklama:</strong> <?= nl2br(htmlspecialchars($project['description'] ?? 'Açıklama yok.')) ?></p>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-header">
                <h5 class="mb-0"><i class="fas fa-tasks me-2"></i>Projeye Atanmış Görevler</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Görev Başlığı</th>
                                <th>Atanan</th>
                                <th>Bitiş Tarihi</th>
                                <th>Durum</th>
                                <th>Öncelik</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($tasks)): ?>
                                <tr><td colspan="5" class="text-center text-muted">Bu projeye atanmış görev bulunmuyor.</td></tr>
                            <?php else: ?>
                                <?php foreach ($tasks as $task): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($task['title']) ?></td>
                                        <td><?= htmlspecialchars($task['assigned_to_name'] ?? 'Atanmamış') ?></td>
                                        <td><?= $task['due_date'] ? date('d.m.Y', strtotime($task['due_date'])) : '-' ?></td>
                                        <td>
                                            <?php 
                                            $status_map = [
                                                'todo' => ['text' => 'Yapılacak', 'class' => 'secondary'],
                                                'inprogress' => ['text' => 'Devam Ediyor', 'class' => 'primary'],
                                                'done' => ['text' => 'Tamamlandı', 'class' => 'success'],
                                                'archived' => ['text' => 'Arşivlendi', 'class' => 'dark'],
                                                'cancelled' => ['text' => 'İptal Edildi', 'class' => 'danger']
                                            ];
                                            $status_info = $status_map[$task['status']] ?? ['text' => $task['status'], 'class' => 'light'];
                                            ?>
                                            <span class="badge bg-<?= $status_info['class'] ?>"><?= $status_info['text'] ?></span>
                                        </td>
                                        <td>
                                            <?php 
                                            $priority_map = [
                                                'low' => ['text' => 'Düşük', 'class' => 'success'],
                                                'medium' => ['text' => 'Orta', 'class' => 'warning'],
                                                'high' => ['text' => 'Yüksek', 'class' => 'danger'],
                                                'urgent' => ['text' => 'Acil', 'class' => 'danger fw-bold']
                                            ];
                                            $priority_info = $priority_map[$task['priority']] ?? ['text' => $task['priority'], 'class' => 'secondary'];
                                            ?>
                                            <span class="badge border border-<?= $priority_info['class'] ?> text-<?= $priority_info['class'] ?>"><?= $priority_info['text'] ?></span>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <h5 class="card-title">Proje Özeti</h5>
                <ul class="list-group list-group-flush">
                    <li class="list-group-item"><strong>Başlangıç:</strong> <?= $project['start_date'] ? date('d.m.Y', strtotime($project['start_date'])) : '-' ?></li>
                    <li class="list-group-item"><strong>Bitiş:</strong> <?= $project['end_date'] ? date('d.m.Y', strtotime($project['end_date'])) : '-' ?></li>
                    <li class="list-group-item"><strong>Bütçe:</strong> <?= $project['budget'] ? number_format($project['budget'], 2, ',', '.') . ' ₺' : '-' ?></li>
                    <li class="list-group-item"><strong>Durum:</strong> <span class="badge bg-primary"><?= htmlspecialchars($project['status']) ?></span></li>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>