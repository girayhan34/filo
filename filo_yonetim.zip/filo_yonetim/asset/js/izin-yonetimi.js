/**
 * İzin Yönetimi JavaScript Dosyası
 * Bu dosya, izin yönetimi modülünün tüm istemci tarafı işlevselliğini içerir.
 */

$(document).ready(function() {
    // Global değişkenler
    let izinTablosu;
    let seciliIzinId = 0;
    
    // Tarih seçicileri başlat
    $('.datepicker').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
        autoUpdateInput: true,
        locale: {
            format: 'DD.MM.YYYY',
            applyLabel: 'Tamam',
            cancelLabel: 'İptal',
            daysOfWeek: ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'],
            monthNames: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
            firstDay: 1
        }
    });
    
    // Tarih aralığı seçici
    $('.date-range-picker').daterangepicker({
        autoUpdateInput: false,
        locale: {
            format: 'DD.MM.YYYY',
            applyLabel: 'Uygula',
            cancelLabel: 'Temizle',
            fromLabel: 'Başlangıç',
            toLabel: 'Bitiş',
            customRangeLabel: 'Özel',
            daysOfWeek: ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'],
            monthNames: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
            firstDay: 1
        },
        ranges: {
           'Bugün': [moment(), moment()],
           'Dün': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Bu Hafta': [moment().startOf('week'), moment().endOf('week')],
           'Bu Ay': [moment().startOf('month'), moment().endOf('month')],
           'Geçen Ay': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    });
    
    // Tarih aralığı seçildiğinde
    $('.date-range-picker').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
        izinTablosu.ajax.reload();
    });
    
    // Tarih aralığı temizlendiğinde
    $('.date-range-picker').on('cancel.daterangepicker', function(ev, picker) {
        $(this).val('');
        izinTablosu.ajax.reload();
    });
    
    // İzin tablosunu başlat
    function initIzinTablosu() {
        izinTablosu = $('#izinTablosu').DataTable({
            processing: true,
            serverSide: true,
            ajax: {
                url: 'api/izin_listesi.php',
                type: 'POST',
                data: function(d) {
                    d.personel_id = $('#personelFiltre').val();
                    d.izin_tipi = $('#izinTipiFiltre').val();
                    d.durum = $('#durumFiltre').val();
                    
                    // Tarih aralığını ayrıştır
                    const tarihAraligi = $('#tarihAraligiFiltre').val().split(' - ');
                    if (tarihAraligi.length === 2) {
                        d.tarih_baslangic = moment(tarihAraligi[0], 'DD.MM.YYYY').format('YYYY-MM-DD');
                        d.tarih_bitis = moment(tarihAraligi[1], 'DD.MM.YYYY').format('YYYY-MM-DD');
                    }
                }
            },
            columns: [
                { data: 'personel_adi' },
                { 
                    data: 'izin_tipi_adi',
                    render: function(data, type, row) {
                        return `<span class="badge" style="background-color: ${row.izin_tipi_renk || '#6c757d'}">${data}</span>`;
                    }
                },
                { 
                    data: 'baslangic_tarihi',
                    render: function(data) {
                        return data ? moment(data).format('DD.MM.YYYY') : '-';
                    }
                },
                { 
                    data: 'bitis_tarihi',
                    render: function(data) {
                        return data ? moment(data).format('DD.MM.YYYY') : '-';
                    }
                },
                { data: 'toplam_gun' },
                { 
                    data: 'durum',
                    render: function(data) {
                        let badgeClass = 'secondary';
                        if (data === 'Onaylandı') badgeClass = 'success';
                        else if (data === 'Reddedildi') badgeClass = 'danger';
                        else if (data === 'Onay Bekliyor') badgeClass = 'warning';
                        
                        return `<span class="badge bg-${badgeClass}">${data}</span>`;
                    }
                },
                { 
                    data: 'olusturma_tarihi',
                    render: function(data) {
                        return data ? moment(data).format('DD.MM.YYYY HH:mm') : '-';
                    }
                },
                {
                    data: null,
                    orderable: false,
                    render: function(data, type, row) {
                        let buttons = '';
                        
                        // Detay butonu (her zaman göster)
                        buttons += `<button class="btn btn-sm btn-info btn-detail me-1" data-id="${row.id}" title="Detay Görüntüle">
                            <i class="fas fa-eye"></i>
                        </button>`;
                        
                        // Düzenle butonu (sadece onay bekliyorsa ve yetkiliyse)
                        if (row.durum === 'Onay Bekliyor' && (row.personel_id === ${$('#currentUserId').val() || 0} || ${$('#isAdmin').val() === '1' ? 'true' : 'false'})) {
                            buttons += `<button class="btn btn-sm btn-warning btn-edit me-1" data-id="${row.id}" title="Düzenle">
                                <i class="fas fa-edit"></i>
                            </button>`;
                        }
                        
                        // Sil butonu (sadece onay bekliyorsa ve yetkiliyse)
                        if (row.durum === 'Onay Bekliyor' && (row.personel_id === ${$('#currentUserId').val() || 0} || ${$('#isAdmin').val() === '1' ? 'true' : 'false'})) {
                            buttons += `<button class="btn btn-sm btn-danger btn-delete" data-id="${row.id}" title="Sil">
                                <i class="fas fa-trash"></i>
                            </button>`;
                        }
                        
                        return buttons;
                    }
                }
            ],
            language: {
                url: '//cdn.datatables.net/plug-ins/1.13.7/i18n/tr.json'
            },
            dom: "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
                 "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            buttons: [
                {
                    extend: 'excel',
                    text: '<i class="fas fa-file-excel"></i> Excel',
                    className: 'btn btn-success btn-sm',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6]
                    }
                },
                {
                    extend: 'pdf',
                    text: '<i class="fas fa-file-pdf"></i> PDF',
                    className: 'btn btn-danger btn-sm',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6]
                    }
                },
                {
                    extend: 'print',
                    text: '<i class="fas fa-print"></i> Yazdır',
                    className: 'btn btn-info btn-sm',
                    exportOptions: {
                        columns: [0, 1, 2, 3, 4, 5, 6]
                    }
                }
            ],
            order: [[2, 'desc']],
            pageLength: 25,
            responsive: true,
            drawCallback: function() {
                // Tooltip'leri etkinleştir
                $('[data-bs-toggle="tooltip"]').tooltip();
            }
        });
    }
    
    // İstatistikleri yükle
    function yukleIzinIstatistikleri() {
        const baslangicTarihi = moment().startOf('month').format('YYYY-MM-DD');
        const bitisTarihi = moment().endOf('month').format('YYYY-MM-DD');
        
        $.ajax({
            url: 'api/izin_istatistikleri.php',
            type: 'GET',
            data: {
                tarih_baslangic: baslangicTarihi,
                tarih_bitis: bitisTarihi
            },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    // Toplam izin
                    $('#toplamIzin').text(response.toplam_izin);
                    
                    // Onay bekleyen
                    $('#onayBekleyenIzin').text(response.onay_bekleyen);
                    
                    // Onaylanan
                    $('#onaylananIzin').text(response.onaylanan);
                    
                    // Reddedilen
                    $('#reddedilenIzin').text(response.reddedilen);
                    
                    // İzin dağılımı grafiğini güncelle
                    guncelleIzinDagilimGrafik(response.izin_dagilim);
                } else {
                    toastr.error('İstatistikler yüklenirken bir hata oluştu: ' + (response.message || 'Bilinmeyen hata'));
                }
            },
            error: function(xhr, status, error) {
                console.error('İstatistik yükleme hatası:', error);
                toastr.error('İstatistikler yüklenirken bir hata oluştu.');
            }
        });
    }
    
    // İzin dağılım grafiğini güncelle
    function guncelleIzinDagilimGrafik(veriler) {
        // Grafik verilerini hazırla
        const labels = veriler.map(item => item.izin_tipi);
        const data = veriler.map(item => item.adet);
        const backgroundColors = [
            '#4e73df', '#1cc88a', '#36b9cc', '#f6c23e', '#e74a3b',
            '#5a5c69', '#858796', '#3a3b45', '#f8f9fc', '#5a5c69'
        ];
        
        // Graği oluştur veya güncelle
        const ctx = document.getElementById('izinDagilimGrafik').getContext('2d');
        
        if (window.izinDagilimGrafik) {
            // Grafik zaten varsa güncelle
            window.izinDagilimGrafik.data.labels = labels;
            window.izinDagilimGrafik.data.datasets[0].data = data;
            window.izinDagilimGrafik.update();
        } else {
            // Yeni grafik oluştur
            window.izinDagilimGrafik = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: labels,
                    datasets: [{
                        data: data,
                        backgroundColor: backgroundColors,
                        hoverBackgroundColor: backgroundColors.map(c => Chart.helpers.color(c).darken(0.2).rgbString()),
                        hoverBorderColor: 'rgba(234, 236, 244, 1)',
                    }]
                },
                options: {
                    maintainAspectRatio: false,
                    plugins: {
                        tooltip: {
                            backgroundColor: 'rgb(255,255,255)',
                            bodyColor: '#858796',
                            borderColor: '#dddfeb',
                            borderWidth: 1,
                            xPadding: 15,
                            yPadding: 15,
                            displayColors: false,
                            caretPadding: 10,
                            callbacks: {
                                label: function(context) {
                                    const label = context.label || '';
                                    const value = context.raw || 0;
                                    const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                    const percentage = Math.round((value / total) * 100);
                                    return `${label}: ${value} (${percentage}%)`;
                                }
                            }
                        },
                        legend: {
                            position: 'right',
                            labels: {
                                usePointStyle: true,
                                padding: 20
                            }
                        }
                    },
                    cutout: '65%'
                }
            });
        }
    }
    
    // İzin ekleme formunu göster
    function showIzinEkleForm() {
        // Formu sıfırla
        $('#izinEkleForm')[0].reset();
        
        // Varsayılan değerleri ayarla
        const today = moment().format('DD.MM.YYYY');
        $('#baslangicTarihi').val(today);
        $('#bitisTarihi').val(today);
        $('#toplamGun').val('1');
        
        // Personel seçeneklerini yükle (eğer admin ise)
        if ($('#isAdmin').val() === '1') {
            $.ajax({
                url: 'api/personel_listesi.php',
                type: 'GET',
                dataType: 'json',
                success: function(response) {
                    if (response.status === 'success') {
                        const select = $('#personelId');
                        select.empty();
                        
                        response.data.forEach(function(personel) {
                            select.append(new Option(`${personel.ad} ${personel.soyad} (${personel.departman})`, personel.id));
                        });
                    }
                }
            });
        } else {
            // Kullanıcı kendisi için izin ekliyorsa, sadece kendi adını göster
            $('#personelId').empty().append(
                `<option value="${$('#currentUserId').val()}">${$('#currentUserName').val()}</option>`
            );
        }
        
        // İzin tiplerini yükle
        $.ajax({
            url: 'api/izin_tipleri.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    const select = $('#izinTipiId');
                    select.empty();
                    
                    response.data.forEach(function(tip) {
                        select.append(new Option(tip.adi, tip.id));
                    });
                }
            }
        });
        
        // Modalı göster
        $('#izinEkleModal').modal('show');
    }
    
    // Tarih değiştiğinde toplam günü hesapla
    function hesaplaToplamGun() {
        const baslangic = moment($('#baslangicTarihi').val(), 'DD.MM.YYYY');
        const bitis = moment($('#bitisTarihi').val(), 'DD.MM.YYYY');
        
        if (baslangic.isValid() && bitis.isValid() && bitis.isSameOrAfter(baslangic)) {
            // Hafta sonlarını saymamak için özel hesaplama
            let toplamGun = 0;
            let currentDate = moment(baslangic);
            
            while (currentDate.isSameOrBefore(bitis)) {
                // Hafta içi ise (1-5 arası, Pazartesi=1, Pazar=0)
                if (currentDate.day() !== 0 && currentDate.day() !== 6) {
                    toplamGun++;
                }
                currentDate.add(1, 'days');
            }
            
            // Eğer 0 gün çıkarsa en az 1 gün yap
            $('#toplamGun').val(Math.max(1, toplamGun));
        } else {
            $('#toplamGun').val('1');
        }
    }
    
    // İzin ekleme formunu gönderme
    function submitIzinEkleForm() {
        // Form doğrulama
        if (!$('#izinEkleForm')[0].checkValidity()) {
            $('#izinEkleForm').find(':submit').click();
            return;
        }
        
        // Form verilerini topla
        const formData = {
            personel_id: $('#personelId').val(),
            izin_tipi_id: $('#izinTipiId').val(),
            baslangic_tarihi: $('#baslangicTarihi').val(),
            bitis_tarihi: $('#bitisTarihi').val(),
            toplam_gun: $('#toplamGun').val(),
            aciklama: $('#aciklama').val()
        };
        
        // Yükleme göster
        const submitBtn = $('#izinEkleForm').find('button[type="submit"]');
        const originalBtnText = submitBtn.html();
        submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> İşleniyor...');
        
        // API'ye gönder
        $.ajax({
            url: 'api/izin_ekle.php',
            type: 'POST',
            data: formData,
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    toastr.success('İzin talebiniz başarıyla oluşturuldu.');
                    $('#izinEkleModal').modal('hide');
                    izinTablosu.ajax.reload();
                    yukleIzinIstatistikleri();
                } else {
                    toastr.error(response.message || 'İzin talebi oluşturulurken bir hata oluştu!');
                }
            },
            error: function(xhr, status, error) {
                console.error('İzin ekleme hatası:', error);
                toastr.error('İzin talebi oluşturulurken bir hata oluştu!');
            },
            complete: function() {
                submitBtn.prop('disabled', false).html(originalBtnText);
            }
        });
    }
    
    // İzin detaylarını göster
    function showIzinDetay(izinId) {
        if (!izinId) return;
        
        // Detayları yükle
        $.ajax({
            url: 'api/izin_detay.php',
            type: 'GET',
            data: { id: izinId },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    const izin = response.data.temel_bilgiler;
                    
                    // Temel bilgileri doldur
                    $('#detailPersonelAdi').text(izin.personel_adi);
                    $('#detailDepartman').text(izin.departman || '-');
                    $('#detailUnvan').text(izin.unvan || '-');
                    $('#detailIzinTipi').html(`<span class="badge" style="background-color: ${izin.izin_tipi_renk || '#6c757d'}">${izin.izin_tipi_adi}</span>`);
                    $('#detailBaslangicTarihi').text(moment(izin.baslangic_tarihi).format('DD.MM.YYYY'));
                    $('#detailBitisTarihi').text(moment(izin.bitis_tarihi).format('DD.MM.YYYY'));
                    $('#detailToplamGun').text(izin.toplam_gun);
                    
                    // Durum
                    let durumBadge = '';
                    if (izin.durum === 'Onaylandı') {
                        durumBadge = '<span class="badge bg-success">Onaylandı</span>';
                    } else if (izin.durum === 'Reddedildi') {
                        durumBadge = '<span class="badge bg-danger">Reddedildi</span>';
                    } else {
                        durumBadge = '<span class="badge bg-warning">Onay Bekliyor</span>';
                    }
                    $('#detailDurum').html(durumBadge);
                    
                    // Açıklama
                    $('#detailAciklama').text(izin.aciklama || '-');
                    
                    // Onay/Red bilgisi
                    if (izin.durum !== 'Onay Bekliyor') {
                        const islemYapan = izin.islem_yapan ? izin.islem_yapan : 'Bilinmiyor';
                        const islemTarihi = izin.son_islem_tarihi ? moment(izin.son_islem_tarihi).format('DD.MM.YYYY HH:mm') : '-';
                        const aciklama = izin.onay_red_aciklama ? ` (${izin.onay_red_aciklama})` : '';
                        
                        $('#detailIslemBilgisi').html(`
                            <strong>${izin.durum}:</strong> ${islemYapan} - ${islemTarihi} ${aciklama}
                        `).removeClass('d-none');
                    } else {
                        $('#detailIslemBilgisi').addClass('d-none');
                    }
                    
                    // İşlem butonlarını ayarla
                    const islemButonlari = $('#detailIslemButonlari');
                    islemButonlari.empty();
                    
                    // Sadece onay bekleyen izinler için onay/red butonlarını göster
                    if (izin.durum === 'Onay Bekliyor' && ($('#isAdmin').val() === '1' || $('#isYonetici').val() === '1')) {
                        islemButonlari.append(`
                            <button class="btn btn-success btn-sm me-2" id="btnIzinOnayla" data-id="${izin.id}">
                                <i class="fas fa-check"></i> Onayla
                            </button>
                            <button class="btn btn-danger btn-sm" id="btnIzinReddet" data-id="${izin.id}">
                                <i class="fas fa-times"></i> Reddet
                            </button>
                        `);
                    }
                    
                    // Dokümanları yükle
                    const dokumanlarListesi = $('#detailDokumanlar');
                    dokumanlarListesi.empty();
                    
                    if (response.data.dokumanlar && response.data.dokumanlar.length > 0) {
                        response.data.dokumanlar.forEach(function(dokuman) {
                            dokumanlarListesi.append(`
                                <div class="d-flex justify-content-between align-items-center border-bottom py-2">
                                    <div>
                                        <i class="fas fa-file-pdf text-danger me-2"></i>
                                        <a href="${dokuman.dosya_yolu}" target="_blank">${dokuman.dosya_adi}</a>
                                        ${dokuman.aciklama ? `<small class="text-muted d-block">${dokuman.aciklama}</small>` : ''}
                                    </div>
                                    <small class="text-muted">${moment(dokuman.olusturma_tarihi).format('DD.MM.YYYY')}</small>
                                </div>
                            `);
                        });
                    } else {
                        dokumanlarListesi.append('<div class="text-muted">Eklenmiş doküman bulunamadı.</div>');
                    }
                    
                    // İşlem geçmişini yükle
                    const islemGecmisiListesi = $('#detailIslemGecmisi');
                    islemGecmisiListesi.empty();
                    
                    if (response.data.islem_gecmisi && response.data.islem_gecmisi.length > 0) {
                        response.data.islem_gecmisi.forEach(function(kayit) {
                            let islemIkon = '';
                            let islemMetin = kayit.islem_turu;
                            
                            if (kayit.islem_turu === 'OLUSTURMA') {
                                islemIkon = '<i class="fas fa-plus-circle text-primary me-2"></i>';
                                islemMetin = 'Oluşturuldu';
                            } else if (kayit.islem_turu === 'GUNCELLEME') {
                                islemIkon = '<i class="fas fa-edit text-warning me-2"></i>';
                                islemMetin = 'Güncellendi';
                            } else if (kayit.islem_turu === 'ONAY') {
                                islemIkon = '<i class="fas fa-check-circle text-success me-2"></i>';
                                islemMetin = 'Onaylandı';
                            } else if (kayit.islem_turu === 'RED') {
                                islemIkon = '<i class="fas fa-times-circle text-danger me-2"></i>';
                                islemMetin = 'Reddedildi';
                            } else if (kayit.islem_turu === 'SILME') {
                                islemIkon = '<i class="fas fa-trash-alt text-danger me-2"></i>';
                                islemMetin = 'Silindi';
                            }
                            
                            islemGecmisiListesi.append(`
                                <div class="timeline-item">
                                    <div class="timeline-marker"></div>
                                    <div class="timeline-content">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <h6 class="mb-0">${islemIkon} ${islemMetin}</h6>
                                            <small class="text-muted">${moment(kayit.islem_tarihi).format('DD.MM.YYYY HH:mm')}</small>
                                        </div>
                                        <div class="small text-muted">
                                            ${kayit.islem_yapan || 'Sistem'}
                                            ${kayit.aciklama ? `- ${kayit.aciklama}` : ''}
                                        </div>
                                    </div>
                                </div>
                            `);
                        });
                    } else {
                        islemGecmisiListesi.append('<div class="text-muted">İşlem geçmişi bulunamadı.</div>');
                    }
                    
                    // İstatistikleri göster
                    const istatistikler = response.data.istatistikler || [];
                    const istatistikContainer = $('#izinIstatistikleri');
                    istatistikContainer.empty();
                    
                    if (istatistikler.length > 0) {
                        let istatistikHTML = '<div class="row g-3">';
                        
                        istatistikler.forEach(function(istatistik) {
                            const yuzde = istatistik.toplam_talep > 0 
                                ? Math.round((istatistik.onaylanan / istatistik.toplam_talep) * 100) 
                                : 0;
                            
                            istatistikHTML += `
                                <div class="col-md-6">
                                    <div class="card h-100">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-center mb-2">
                                                <h6 class="mb-0">${istatistik.izin_tipi}</h6>
                                                <span class="badge bg-primary">${istatistik.toplam_talep} Talep</span>
                                            </div>
                                            <div class="progress mb-2" style="height: 10px;">
                                                <div class="progress-bar bg-success" role="progressbar" 
                                                     style="width: ${yuzde}%" 
                                                     aria-valuenow="${yuzde}" 
                                                     aria-valuemin="0" 
                                                     aria-valuemax="100">
                                                </div>
                                            </div>
                                            <div class="row text-center small">
                                                <div class="col-4">
                                                    <div>Onaylanan</div>
                                                    <strong>${istatistik.onaylanan || 0}</strong>
                                                </div>
                                                <div class="col-4">
                                                    <div>Reddedilen</div>
                                                    <strong>${istatistik.reddedilen || 0}</strong>
                                                </div>
                                                <div class="col-4">
                                                    <div>Toplam Gün</div>
                                                    <strong>${istatistik.toplam_gun || 0}</strong>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            `;
                        });
                        
                        istatistikHTML += '</div>';
                        istatistikContainer.html(istatistikHTML);
                    } else {
                        istatistikContainer.html('<div class="alert alert-info">İstatistik bilgisi bulunamadı.</div>');
                    }
                    
                    // Modalı göster
                    $('#izinDetayModal').modal('show');
                } else {
                    toastr.error(response.message || 'İzin detayları yüklenirken bir hata oluştu!');
                }
            },
            error: function(xhr, status, error) {
                console.error('İzin detay yükleme hatası:', error);
                toastr.error('İzin detayları yüklenirken bir hata oluştu!');
            }
        });
    }
    
    // İzin onaylama işlemi
    function onaylaIzin(izinId) {
        if (!izinId) return;
        
        Swal.fire({
            title: 'İzni Onayla',
            text: 'Bu izin talebini onaylamak istediğinize emin misiniz?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonText: 'Evet, Onayla',
            cancelButtonText: 'İptal',
            confirmButtonColor: '#28a745',
            cancelButtonColor: '#6c757d',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                const btn = $(`#btnIzinOnayla[data-id="${izinId}"]`);
                const originalBtnText = btn.html();
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> İşleniyor...');
                
                $.ajax({
                    url: 'api/izin_onayla.php',
                    type: 'POST',
                    data: { 
                        id: izinId,
                        aciklama: $('#onayAciklama').val()
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            toastr.success('İzin başarıyla onaylandı.');
                            $('#izinDetayModal').modal('hide');
                            izinTablosu.ajax.reload();
                            yukleIzinIstatistikleri();
                        } else {
                            toastr.error(response.message || 'İzin onaylanırken bir hata oluştu!');
                            btn.prop('disabled', false).html(originalBtnText);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('İzin onaylama hatası:', error);
                        toastr.error('İzin onaylanırken bir hata oluştu!');
                        btn.prop('disabled', false).html(originalBtnText);
                    }
                });
            }
        });
    }
    
    // İzin reddetme işlemi
    function reddetIzin(izinId) {
        if (!izinId) return;
        
        Swal.fire({
            title: 'İzni Reddet',
            html: `
                <div class="mb-3">
                    <label for="redNedeni" class="form-label">Red Nedeni <span class="text-danger">*</span></label>
                    <select class="form-select" id="redNedeni" required>
                        <option value="">Seçiniz</option>
                        <option value="Yetersiz Personel">Yetersiz Personel</option>
                        <option value="İş Yoğunluğu">İş Yoğunluğu</option>
                        <option value="Planlama Uyumsuzluğu">Planlama Uyumsuzluğu</option>
                        <option value="Diğer">Diğer</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="redAciklama" class="form-label">Açıklama</label>
                    <textarea class="form-control" id="redAciklama" rows="3"></textarea>
                </div>
            `,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Reddet',
            cancelButtonText: 'İptal',
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            reverseButtons: true,
            focusConfirm: false,
            preConfirm: () => {
                const redNedeni = document.getElementById('redNedeni').value;
                if (!redNedeni) {
                    Swal.showValidationMessage('Lütfen bir red nedeni seçiniz');
                    return false;
                }
                return {
                    red_nedeni: redNedeni,
                    ek_aciklama: document.getElementById('redAciklama').value
                };
            }
        }).then((result) => {
            if (result.isConfirmed && result.value) {
                const btn = $(`#btnIzinReddet[data-id="${izinId}"]`);
                const originalBtnText = btn.html();
                btn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> İşleniyor...');
                
                $.ajax({
                    url: 'api/izin_reddet.php',
                    type: 'POST',
                    data: { 
                        id: izinId,
                        red_nedeni: result.value.red_nedeni,
                        ek_aciklama: result.value.ek_aciklama
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            toastr.success('İzin başarıyla reddedildi.');
                            $('#izinDetayModal').modal('hide');
                            izinTablosu.ajax.reload();
                            yukleIzinIstatistikleri();
                        } else {
                            toastr.error(response.message || 'İzin reddedilirken bir hata oluştu!');
                            btn.prop('disabled', false).html(originalBtnText);
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('İzin reddetme hatası:', error);
                        toastr.error('İzin reddedilirken bir hata oluştu!');
                        btn.prop('disabled', false).html(originalBtnText);
                    }
                });
            }
        });
    }
    
    // İzin silme işlemi
    function silIzin(izinId) {
        if (!izinId) return;
        
        Swal.fire({
            title: 'İzni Sil',
            text: 'Bu izin kaydını silmek istediğinize emin misiniz? Bu işlem geri alınamaz!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Evet, Sil',
            cancelButtonText: 'İptal',
            confirmButtonColor: '#dc3545',
            cancelButtonColor: '#6c757d',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Silme işlemi burada yapılacak
                // Örnek bir AJAX isteği:
                /*
                $.ajax({
                    url: 'api/izin_sil.php',
                    type: 'POST',
                    data: { id: izinId },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status === 'success') {
                            toastr.success('İzin başarıyla silindi.');
                            izinTablosu.ajax.reload();
                            yukleIzinIstatistikleri();
                        } else {
                            toastr.error(response.message || 'İzin silinirken bir hata oluştu!');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('İzin silme hatası:', error);
                        toastr.error('İzin silinirken bir hata oluştu!');
                    }
                });
                */
                
                // Şimdilik sadece bildirim göster
                toastr.info('Bu özellik şu anda aktif değil. Lütfen daha sonra tekrar deneyiniz.');
            }
        });
    }
    
    // Event Delegation ile dinamik olarak oluşturulan elementlere tıklama olayı ekleme
    $(document).on('click', '.btn-detail', function() {
        const izinId = $(this).data('id');
        showIzinDetay(izinId);
    });
    
    $(document).on('click', '.btn-edit', function() {
        const izinId = $(this).data('id');
        // Düzenleme işlemi burada yapılacak
        toastr.info('Bu özellik şu anda aktif değil. Lütfen daha sonra tekrar deneyiniz.');
    });
    
    $(document).on('click', '.btn-delete', function() {
        const izinId = $(this).data('id');
        silIzin(izinId);
    });
    
    // Detay modalı içindeki butonlar için event delegation
    $(document).on('click', '#btnIzinOnayla', function() {
        const izinId = $(this).data('id');
        onaylaIzin(izinId);
    });
    
    $(document).on('click', '#btnIzinReddet', function() {
        const izinId = $(this).data('id');
        reddetIzin(izinId);
    });
    
    // Tarih değişikliklerini dinle
    $('#baslangicTarihi, #bitisTarihi').on('apply.daterangepicker', function() {
        hesaplaToplamGun();
    });
    
    // Filtreleme butonları
    $('.filter-btn').on('click', function() {
        const filterType = $(this).data('filter');
        
        switch(filterType) {
            case 'onay_bekleyen':
                $('#durumFiltre').val('Onay Bekliyor');
                break;
            case 'onaylanan':
                $('#durumFiltre').val('Onaylandı');
                break;
            case 'reddedilen':
                $('#durumFiltre').val('Reddedildi');
                break;
            case 'bugun':
                $('#tarihAraligiFiltre').val(moment().format('DD.MM.YYYY') + ' - ' + moment().format('DD.MM.YYYY'));
                break;
            case 'bu_hafta':
                $('#tarihAraligiFiltre').val(moment().startOf('week').format('DD.MM.YYYY') + ' - ' + moment().endOf('week').format('DD.MM.YYYY'));
                break;
            case 'bu_ay':
                $('#tarihAraligiFiltre').val(moment().startOf('month').format('DD.MM.YYYY') + ' - ' + moment().endOf('month').format('DD.MM.YYYY'));
                break;
        }
        
        izinTablosu.ajax.reload();
    });
    
    // Filtreleri temizle
    $('#temizleFiltreler').on('click', function() {
        $('#izinFiltreForm')[0].reset();
        $('.date-range-picker').data('daterangepicker').setStartDate(moment().startOf('month'));
        $('.date-range-picker').data('daterangepicker').setEndDate(moment().endOf('month'));
        izinTablosu.ajax.reload();
    });
    
    // İzin ekleme formu gönderimi
    $('#izinEkleForm').on('submit', function(e) {
        e.preventDefault();
        submitIzinEkleForm();
    });
    
    // Sayfa yüklendiğinde başlangıç işlemleri
    function init() {
        initIzinTablosu();
        yukleIzinIstatistikleri();
        
        // Tarih aralığı için başlangıç değerlerini ayarla (bu ay)
        $('.date-range-picker').data('daterangepicker').setStartDate(moment().startOf('month'));
        $('.date-range-picker').data('daterangepicker').setEndDate(moment().endOf('month'));
    }
    
    // Sayfa yüklendiğinde çalıştır
    init();
});
