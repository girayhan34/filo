class InvoiceManager {
    constructor() {
        this.invoiceData = [];
        this.vehicleData = [];
        this.personnelData = [];
        this.customerData = [];
        this.currentInvoiceId = null;
        this.currentInvoiceData = null;
        
        this.initializeEventListeners();
        this.initializeDataTables();
        this.loadInitialData();
    }

    initializeEventListeners() {
        // Form submission
        document.getElementById('invoiceForm')?.addEventListener('submit', (e) => this.handleFormSubmit(e));
        
        // Filter form
        document.getElementById('filterForm')?.addEventListener('submit', (e) => {
            e.preventDefault();
            this.applyFilters();
        });
        
        // Reset filters
        document.getElementById('resetFilters')?.addEventListener('click', () => this.resetFilters());
        
        // Add item row
        document.getElementById('addItemBtn')?.addEventListener('click', () => this.addItemRow());
    }

    initializeDataTables() {
        if ($.fn.DataTable.isDataTable('#invoicesTable')) {
            $('#invoicesTable').DataTable().destroy();
        }
        
        this.invoiceTable = $('#invoicesTable').DataTable({
            responsive: true,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.25/i18n/Turkish.json'
            },
            order: [[0, 'desc']],
            pageLength: 25,
            dom: '<"top"f>rt<"bottom"lip><"clear">',
            initComplete: function() {
                $('.dataTables_filter input').addClass('form-control form-control-sm');
                $('.dataTables_length select').addClass('form-select form-select-sm');
            }
        });
    }

    async loadInitialData() {
        try {
            await Promise.all([
                this.loadInvoices(),
                this.loadCustomers(),
                this.loadVehicles(),
                this.loadPersonnel()
            ]);
            
            this.initializeCustomerSearch();
            this.loadNextReceiptNo();
        } catch (error) {
            this.showError('Veriler yüklenirken bir hata oluştu: ' + error.message);
        }
    }

    async loadInvoices() {
        try {
            const response = await fetch('api/get_invoices.php');
            if (!response.ok) throw new Error('Faturalar yüklenirken hata oluştu');
            
            this.invoiceData = await response.json();
            this.updateInvoiceTable();
        } catch (error) {
            this.showError('Faturalar yüklenirken hata oluştu: ' + error.message);
        }
    }

    async loadCustomers() {
        try {
            const response = await fetch('api/get_customers.php');
            if (!response.ok) throw new Error('Müşteriler yüklenirken hata oluştu');
            
            this.customerData = await response.json();
        } catch (error) {
            this.showError('Müşteriler yüklenirken hata oluştu: ' + error.message);
        }
    }

    async loadVehicles() {
        try {
            const response = await fetch('api/get_vehicles.php');
            if (!response.ok) throw new Error('Araçlar yüklenirken hata oluştu');
            
            this.vehicleData = await response.json();
            this.populateVehicleSelect();
        } catch (error) {
            this.showError('Araçlar yüklenirken hata oluştu: ' + error.message);
        }
    }

    async loadPersonnel() {
        try {
            const response = await fetch('api/get_personnel.php');
            if (!response.ok) throw new Error('Personel yüklenirken hata oluştu');
            
            this.personnelData = await response.json();
            this.populatePersonnelSelect();
        } catch (error) {
            this.showError('Personel yüklenirken hata oluştu: ' + error.message);
        }
    }

    initializeCustomerSearch() {
        const customerInput = document.getElementById('customerSearch');
        const suggestions = document.getElementById('customerSuggestions');

        if (!customerInput) return;

        customerInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase();
            suggestions.innerHTML = '';
            
            if (query.length < 2) {
                suggestions.style.display = 'none';
                return;
            }

            const filtered = this.customerData.filter(customer => 
                customer.name.toLowerCase().includes(query) || 
                (customer.company_name && customer.company_name.toLowerCase().includes(query))
            );

            if (filtered.length > 0) {
                filtered.forEach(customer => {
                    const div = document.createElement('div');
                    div.className = 'list-group-item list-group-item-action';
                    div.textContent = customer.company_name || customer.name;
                    div.onclick = () => this.selectCustomer(customer);
                    suggestions.appendChild(div);
                });
                suggestions.style.display = 'block';
            } else {
                suggestions.style.display = 'none';
            }
        });

        // Hide suggestions when clicking outside
        document.addEventListener('click', (e) => {
            if (e.target !== customerInput) {
                suggestions.style.display = 'none';
            }
        });
    }

    selectCustomer(customer) {
        const customerInput = document.getElementById('customerSearch');
        const customerIdInput = document.getElementById('customer_id');
        
        customerInput.value = customer.company_name || customer.name;
        customerIdInput.value = customer.id;
        
        document.getElementById('customerSuggestions').style.display = 'none';
    }

    populateVehicleSelect() {
        const select = document.getElementById('vehicle_id');
        if (!select) return;
        
        select.innerHTML = '<option value="">Araç Seçiniz</option>';
        
        this.vehicleData.forEach(vehicle => {
            const option = document.createElement('option');
            option.value = vehicle.id;
            option.textContent = `${vehicle.plate} - ${vehicle.brand} ${vehicle.model}`;
            select.appendChild(option);
        });
    }

    populatePersonnelSelect() {
        const select = document.getElementById('driver_id');
        if (!select) return;
        
        select.innerHTML = '<option value="">Şoför Seçiniz</option>';
        
        this.personnelData.forEach(person => {
            const option = document.createElement('option');
            option.value = person.id;
            option.textContent = person.name;
            select.appendChild(option);
        });
    }

    addItemRow() {
        const itemsContainer = document.getElementById('invoiceItems');
        const itemTemplate = document.getElementById('itemTemplate');
        const newItem = itemTemplate.content.cloneNode(true);
        
        const itemCount = document.querySelectorAll('.invoice-item').length;
        newItem.querySelectorAll('input, select').forEach(input => {
            input.name = input.name.replace('[0]', `[${itemCount}]`);
            input.id = input.id.replace('0', itemCount);
        });
        
        itemsContainer.appendChild(newItem);
        this.calculateRowTotal(itemCount);
    }

    calculateRowTotal(rowIndex) {
        const quantity = parseFloat(document.getElementById(`items_${rowIndex}_quantity`).value) || 0;
        const unitPrice = parseFloat(document.getElementById(`items_${rowIndex}_unit_price`).value) || 0;
        const taxRate = parseFloat(document.getElementById(`items_${rowIndex}_tax_rate`).value) || 0;
        
        const subtotal = quantity * unitPrice;
        const taxAmount = subtotal * (taxRate / 100);
        const total = subtotal + taxAmount;
        
        document.getElementById(`items_${rowIndex}_subtotal`).value = subtotal.toFixed(2);
        document.getElementById(`items_${rowIndex}_tax_amount`).value = taxAmount.toFixed(2);
        document.getElementById(`items_${rowIndex}_total`).value = total.toFixed(2);
        
        this.calculateInvoiceTotal();
    }

    calculateInvoiceTotal() {
        let subtotal = 0;
        let totalTax = 0;
        let total = 0;
        
        document.querySelectorAll('.invoice-item').forEach((row, index) => {
            subtotal += parseFloat(document.getElementById(`items_${index}_subtotal`).value) || 0;
            totalTax += parseFloat(document.getElementById(`items_${index}_tax_amount`).value) || 0;
        });
        
        total = subtotal + totalTax;
        
        document.getElementById('subtotal').value = subtotal.toFixed(2);
        document.getElementById('tax_total').value = totalTax.toFixed(2);
        document.getElementById('total_amount').value = total.toFixed(2);
    }

    async handleFormSubmit(e) {
        e.preventDefault();
        
        const form = e.target;
        const formData = new FormData(form);
        const action = this.currentInvoiceId ? 'update_invoice' : 'create_invoice';
        
        if (this.currentInvoiceId) {
            formData.append('invoice_id', this.currentInvoiceId);
        }
        
        formData.append('action', action);
        
        try {
            const response = await fetch('api/invoice_operations.php', {
                method: 'POST',
                body: formData
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                $('#invoiceModal').modal('hide');
                this.loadInvoices();
            } else {
                throw new Error(result.message || 'İşlem başarısız oldu');
            }
        } catch (error) {
            this.showError('İşlem sırasında bir hata oluştu: ' + error.message);
        }
    }

    applyFilters() {
        const form = document.getElementById('filterForm');
        const formData = new FormData(form);
        const params = new URLSearchParams();
        
        for (const [key, value] of formData.entries()) {
            if (value) {
                params.append(key, value);
            }
        }
        
        window.location.href = `invoices.php?${params.toString()}`;
    }

    resetFilters() {
        window.location.href = 'invoices.php';
    }

    async viewInvoice(id) {
        try {
            const response = await fetch(`api/get_invoice.php?id=${id}`);
            if (!response.ok) throw new Error('Fatura bilgileri alınamadı');
            
            const data = await response.json();
            this.displayInvoiceDetails(data);
            $('#invoiceDetailsModal').modal('show');
        } catch (error) {
            this.showError('Fatura bilgileri yüklenirken hata oluştu: ' + error.message);
        }
    }

    async editInvoice(id) {
        try {
            this.currentInvoiceId = id;
            
            const response = await fetch(`api/get_invoice.php?id=${id}&edit=true`);
            if (!response.ok) throw new Error('Fatura bilgileri alınamadı');
            
            const data = await response.json();
            this.populateInvoiceForm(data);
            $('#invoiceModal').modal('show');
        } catch (error) {
            this.showError('Fatura düzenleme sırasında hata oluştu: ' + error.message);
        }
    }

    async deleteInvoice(id) {
        if (!confirm('Bu faturayı silmek istediğinize emin misiniz? Bu işlem geri alınamaz.')) {
            return;
        }
        
        try {
            const response = await fetch('api/invoice_operations.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `action=delete_invoice&invoice_id=${id}`
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
                this.loadInvoices();
            } else {
                throw new Error(result.message || 'Fatura silinirken bir hata oluştu');
            }
        } catch (error) {
            this.showError('Fatura silinirken bir hata oluştu: ' + error.message);
        }
    }

    async printInvoice(id) {
        try {
            const response = await fetch(`api/print_invoice.php?id=${id}`);
            if (!response.ok) throw new Error('Yazdırma işlemi başarısız oldu');
            
            const blob = await response.blob();
            const url = window.URL.createObjectURL(blob);
            
            const printWindow = window.open(url, '_blank');
            printWindow.onload = function() {
                printWindow.print();
            };
        } catch (error) {
            this.showError('Yazdırma işlemi sırasında hata oluştu: ' + error.message);
        }
    }

    async sendInvoiceEmail(id) {
        if (!confirm('Faturayı e-posta ile göndermek istediğinize emin misiniz?')) {
            return;
        }
        
        try {
            const response = await fetch('api/send_invoice_email.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `invoice_id=${id}`
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.showSuccess(result.message);
            } else {
                throw new Error(result.message || 'E-posta gönderilirken bir hata oluştu');
            }
        } catch (error) {
            this.showError('E-posta gönderilirken bir hata oluştu: ' + error.message);
        }
    }

    populateInvoiceForm(data) {
        const form = document.getElementById('invoiceForm');
        
        // Reset form
        form.reset();
        
        // Populate basic fields
        Object.keys(data).forEach(key => {
            const input = form.querySelector(`[name="${key}"]`);
            if (input) {
                if (input.type === 'checkbox') {
                    input.checked = Boolean(data[key]);
                } else {
                    input.value = data[key] || '';
                }
            }
        });
        
        // Populate customer
        if (data.customer) {
            document.getElementById('customerSearch').value = data.customer.company_name || data.customer.name;
            document.getElementById('customer_id').value = data.customer.id;
        }
        
        // Clear existing items
        const itemsContainer = document.getElementById('invoiceItems');
        itemsContainer.innerHTML = '';
        
        // Add items
        if (data.items && data.items.length > 0) {
            data.items.forEach((item, index) => {
                this.addItemRow();
                
                document.getElementById(`items_${index}_description`).value = item.description || '';
                document.getElementById(`items_${index}_quantity`).value = item.quantity || '';
                document.getElementById(`items_${index}_unit`).value = item.unit || 'adet';
                document.getElementById(`items_${index}_unit_price`).value = item.unit_price || '';
                document.getElementById(`items_${index}_tax_rate`).value = item.tax_rate || '18';
                
                this.calculateRowTotal(index);
            });
        } else {
            // Add one empty row if no items
            this.addItemRow();
        }
        
        // Calculate totals
        this.calculateInvoiceTotal();
    }

    displayInvoiceDetails(data) {
        const container = document.getElementById('invoiceDetailsContent');
        if (!container) return;
        
        const invoice = data.invoice;
        const payments = data.payments || [];
        const totalPaid = data.total_paid || 0;
        const remainingAmount = data.remaining_amount || 0;
        
        // Format dates
        const formatDate = (dateString) => {
            if (!dateString) return '';
            const date = new Date(dateString);
            return date.toLocaleDateString('tr-TR');
        };
        
        // Format currency
        const formatCurrency = (amount) => {
            return new Intl.NumberFormat('tr-TR', { 
                style: 'currency', 
                currency: 'TRY',
                minimumFractionDigits: 2
            }).format(amount);
        };
        
        // Generate payment rows
        const paymentRows = payments.map(payment => `
            <tr>
                <td>${formatDate(payment.payment_date)}</td>
                <td>${payment.payment_method}</td>
                <td>${payment.receipt_no || '-'}</td>
                <td class="text-end">${formatCurrency(payment.amount)}</td>
                <td class="text-center">
                    <button class="btn btn-sm btn-outline-primary" onclick="printReceipt(${payment.id})">
                        <i class="fas fa-print"></i>
                    </button>
                </td>
            </tr>
        `).join('');
        
        // Generate items rows
        const itemRows = (invoice.items || []).map(item => `
            <tr>
                <td>${item.description || ''}</td>
                <td class="text-end">${item.quantity || '0'}</td>
                <td>${item.unit || 'adet'}</td>
                <td class="text-end">${formatCurrency(item.unit_price || 0)}</td>
                <td class="text-end">${item.tax_rate || '0'}%</td>
                <td class="text-end">${formatCurrency((item.quantity || 0) * (item.unit_price || 0))}</td>
            </tr>
        `).join('');
        
        // Set HTML content
        container.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <h6><i class="fas fa-file-invoice"></i> Fatura Bilgileri</h6>
                    <table class="table table-sm">
                        <tr>
                            <th width="40%">Fatura No:</th>
                            <td>${invoice.invoice_no || ''}</td>
                        </tr>
                        <tr>
                            <th>Fatura Tarihi:</th>
                            <td>${formatDate(invoice.invoice_date)}</td>
                        </tr>
                        <tr>
                            <th>Vade Tarihi:</th>
                            <td>${formatDate(invoice.due_date)}</td>
                        </tr>
                        <tr>
                            <th>Durum:</th>
                            <td>
                                <span class="badge ${this.getStatusBadgeClass(invoice.status)}">
                                    ${this.getStatusText(invoice.status)}
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <th>Toplam Tutar:</th>
                            <td class="fw-bold">${formatCurrency(invoice.total_amount || 0)}</td>
                        </tr>
                        <tr>
                            <th>Ödenen Tutar:</th>
                            <td class="text-success fw-bold">${formatCurrency(totalPaid)}</td>
                        </tr>
                        <tr>
                            <th>Kalan Tutar:</th>
                            <td class="text-danger fw-bold">${formatCurrency(remainingAmount)}</td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-6">
                    <h6><i class="fas fa-users"></i> Müşteri Bilgileri</h6>
                    <table class="table table-sm">
                        <tr>
                            <th width="40%">Müşteri:</th>
                            <td>${invoice.customer?.company_name || invoice.customer?.name || ''}</td>
                        </tr>
                        <tr>
                            <th>Yetkili:</th>
                            <td>${invoice.customer_contact || ''}</td>
                        </tr>
                        <tr>
                            <th>Telefon:</th>
                            <td>${invoice.customer_phone || ''}</td>
                        </tr>
                        <tr>
                            <th>E-posta:</th>
                            <td>${invoice.customer_email || ''}</td>
                        </tr>
                        <tr>
                            <th>Adres:</th>
                            <td>${invoice.customer_address || ''}</td>
                        </tr>
                        <tr>
                            <th>Vergi Dairesi:</th>
                            <td>${invoice.tax_office || ''}</td>
                        </tr>
                        <tr>
                            <th>Vergi No/TCKN:</th>
                            <td>${invoice.tax_number || ''}</td>
                        </tr>
                    </table>
                </div>
            </div>
            
            <div class="row mt-4">
                <div class="col-12">
                    <h6><i class="fas fa-list"></i> Fatura Kalemleri</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th>Açıklama</th>
                                    <th class="text-end">Miktar</th>
                                    <th>Birim</th>
                                    <th class="text-end">Birim Fiyat</th>
                                    <th class="text-end">KDV</th>
                                    <th class="text-end">Tutar</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${itemRows}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th colspan="5" class="text-end">Ara Toplam:</th>
                                    <th class="text-end">${formatCurrency(invoice.subtotal || 0)}</th>
                                </tr>
                                <tr>
                                    <th colspan="5" class="text-end">KDV Toplam:</th>
                                    <th class="text-end">${formatCurrency(invoice.tax_total || 0)}</th>
                                </tr>
                                <tr class="table-active">
                                    <th colspan="5" class="text-end">Genel Toplam:</th>
                                    <th class="text-end">${formatCurrency(invoice.total_amount || 0)}</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            
            ${payments.length > 0 ? `
            <div class="row mt-4">
                <div class="col-12">
                    <h6><i class="fas fa-credit-card"></i> Ödemeler</h6>
                    <div class="table-responsive">
                        <table class="table table-bordered table-sm">
                            <thead class="table-light">
                                <tr>
                                    <th>Tarih</th>
                                    <th>Ödeme Yöntemi</th>
                                    <th>Fiş No</th>
                                    <th class="text-end">Tutar</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                ${paymentRows}
                            </tbody>
                            <tfoot>
                                <tr class="table-active">
                                    <th colspan="3" class="text-end">Toplam Ödenen:</th>
                                    <th class="text-end">${formatCurrency(totalPaid)}</th>
                                    <th></th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            ` : ''}
            
            ${invoice.notes ? `
            <div class="row mt-4">
                <div class="col-12">
                    <h6><i class="fas fa-sticky-note"></i> Notlar</h6>
                    <div class="card">
                        <div class="card-body">
                            ${invoice.notes.replace(/\n/g, '<br>')}
                        </div>
                    </div>
                </div>
            </div>
            ` : ''}
        `;
    }

    getStatusBadgeClass(status) {
        const classes = {
            'draft': 'bg-secondary',
            'sent': 'bg-info',
            'paid': 'bg-success',
            'overdue': 'bg-danger',
            'cancelled': 'bg-dark',
            'refunded': 'bg-warning',
            'partial': 'bg-primary'
        };
        
        return classes[status] || 'bg-secondary';
    }

    getStatusText(status) {
        const statusTexts = {
            'draft': 'Taslak',
            'sent': 'Gönderildi',
            'paid': 'Ödendi',
            'overdue': 'Gecikmiş',
            'cancelled': 'İptal Edildi',
            'refunded': 'İade Edildi',
            'partial': 'Kısmi Ödeme'
        };
        
        return statusTexts[status] || status;
    }

    showSuccess(message) {
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-success border-0 position-fixed bottom-0 end-0 m-3';
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-check-circle me-2"></i> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Kapat"></button>
            </div>
        `;
        
        document.body.appendChild(toast);
        const toastInstance = new bootstrap.Toast(toast);
        toastInstance.show();
        
        // Remove toast after hiding
        toast.addEventListener('hidden.bs.toast', () => {
            document.body.removeChild(toast);
        });
    }

    showError(message) {
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-danger border-0 position-fixed bottom-0 end-0 m-3';
        toast.setAttribute('role', 'alert');
        toast.setAttribute('aria-live', 'assertive');
        toast.setAttribute('aria-atomic', 'true');
        
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    <i class="fas fa-exclamation-circle me-2"></i> ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Kapat"></button>
            </div>
        `;
        
        document.body.appendChild(toast);
        const toastInstance = new bootstrap.Toast(toast);
        toastInstance.show();
        
        // Remove toast after hiding
        toast.addEventListener('hidden.bs.toast', () => {
            document.body.removeChild(toast);
        });
    }

    async loadNextReceiptNo() {
        try {
            const response = await fetch('api/get_next_receipt_no.php');
            if (!response.ok) throw new Error('Fiş numarası alınamadı');
            
            const data = await response.json();
            
            const receiptNoInput = document.getElementById('receipt_no');
            if (receiptNoInput && data.next_receipt_no) {
                receiptNoInput.value = data.next_receipt_no;
            }
        } catch (error) {
            console.error('Fiş numarası yüklenirken hata oluştu:', error);
        }
    }
}

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    window.invoiceManager = new InvoiceManager();
});

// Global functions for HTML onclick handlers
function viewInvoice(id) {
    if (window.invoiceManager) {
        window.invoiceManager.viewInvoice(id);
    }
}

function editInvoice(id) {
    if (window.invoiceManager) {
        window.invoiceManager.editInvoice(id);
    }
}

function deleteInvoice(id) {
    if (window.invoiceManager) {
        window.invoiceManager.deleteInvoice(id);
    }
}

function printInvoice(id) {
    if (window.invoiceManager) {
        window.invoiceManager.printInvoice(id);
    }
}

function sendInvoiceEmail(id) {
    if (window.invoiceManager) {
        window.invoiceManager.sendInvoiceEmail(id);
    }
}

function printReceipt(id) {
    // Implementation for printing receipt
    console.log('Printing receipt:', id);
    // Add your print receipt logic here
}
