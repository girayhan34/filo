// Modern Fleet Management System JavaScript
// Uygulama durumu yönetimi
const FleetApp = {
    state: {
        currentSection: 'dashboard',
        sidebarCollapsed: false,
        darkMode: false,
        notifications: [],
        activeModals: []
    },

    // Başlatma fonksiyonu
    init() {
        this.initEventListeners();
        this.initAnimations();
        this.initNotifications();
        this.loadUserPreferences();
        console.log('Fleet Management System initialized');
    },

    // Event listener'ları başlat
    initEventListeners() {
        // Sidebar navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', this.handleNavigation.bind(this));
        });

        // Responsive kontrolü
        window.addEventListener('resize', this.handleResize.bind(this));
        this.handleResize();

        // Form validasyonu
        document.querySelectorAll('.needs-validation').forEach(form => {
            form.addEventListener('submit', this.handleFormValidation.bind(this));
        });

        // Modal event listeners
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('show.bs.modal', this.handleModalShow.bind(this));
            modal.addEventListener('hide.bs.modal', this.handleModalHide.bind(this));
        });

        // Stat card hover effects
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', this.animateStatCard);
            card.addEventListener('mouseleave', this.resetStatCard);
        });
    },

    // Animasyonları başlat
    initAnimations() {
        // Sayfa yüklenme animasyonu
        document.body.classList.add('loaded');
        
        // Stat card'lar için staggered animation
        const statCards = document.querySelectorAll('.stat-card');
        statCards.forEach((card, index) => {
            card.style.animationDelay = `${index * 0.1}s`;
            card.classList.add('fade-in-up');
        });

        // Sidebar animasyonu
        const navItems = document.querySelectorAll('.nav-item');
        navItems.forEach((item, index) => {
            item.style.animationDelay = `${index * 0.05}s`;
            item.classList.add('slide-in-left');
        });
    },

    // Bildirim sistemi
    initNotifications() {
        // Gerçek zamanlı bildirimler için WebSocket bağlantısı
        // Bu örnekte localStorage kullanıyoruz
        this.checkNotifications();
        setInterval(() => this.checkNotifications(), 30000); // 30 saniyede bir kontrol
    },

    // Navigasyon işleme
    handleNavigation(e) {
        const link = e.currentTarget;
        const href = link.getAttribute('href');
        
        // Eğer link personel.php veya personnel.php ise normal davranışa izin ver
        if (href && (href.includes('personel.php') || href.includes('personnel.php'))) {
            // Eski personnel.php linklerini yeniye yönlendir
            if (href.includes('personnel.php')) {
                e.preventDefault();
                window.location.href = href.replace('personnel.php', 'personel.php');
                return false;
            }
            return true;
        }
        
        e.preventDefault();
        
        // Aktif link'i güncelle
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        link.classList.add('active');
        
        // Sayfa geçiş animasyonu
        this.animatePageTransition();
        
        // AJAX ile içerik yükleme
        if (href) {
            console.log('Navigating to:', href);
            window.location.href = href;
        }
    },

    // Responsive işleme
    handleResize() {
        const isMobile = window.innerWidth < 768;
        const isTablet = window.innerWidth < 992;
        
        document.body.classList.toggle('mobile-view', isMobile);
        document.body.classList.toggle('tablet-view', isTablet);
        
        // Sidebar'ı mobilde otomatik kapat
        if (isMobile && !this.state.sidebarCollapsed) {
            this.toggleSidebar();
        }
    },

    // Form validasyonu
    handleFormValidation(e) {
        const form = e.target;
        if (!form.checkValidity()) {
            e.preventDefault();
            e.stopPropagation();
            this.showValidationErrors(form);
        } else {
            this.showSuccessMessage('Form başarıyla gönderildi!');
        }
        form.classList.add('was-validated');
    },

    // Modal işlemleri
    handleModalShow(e) {
        const modal = e.target;
        this.state.activeModals.push(modal.id);
        modal.classList.add('modal-fade-in');
    },

    handleModalHide(e) {
        const modal = e.target;
        this.state.activeModals = this.state.activeModals.filter(id => id !== modal.id);
        modal.classList.remove('modal-fade-in');
        
        // Modal form'unu temizle
        const form = modal.querySelector('form');
        if (form) {
            form.reset();
            form.classList.remove('was-validated');
        }
    },

    // Stat card animasyonları
    animateStatCard(e) {
        const card = e.currentTarget;
        card.style.transform = 'translateY(-8px) scale(1.02)';
        card.style.boxShadow = '0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)';
    },

    resetStatCard(e) {
        const card = e.currentTarget;
        card.style.transform = 'translateY(0) scale(1)';
        card.style.boxShadow = '';
    },

    // Sayfa geçiş animasyonu
    animatePageTransition() {
        const content = document.querySelector('.content-body');
        if (content) {
            content.style.opacity = '0.7';
            content.style.transform = 'translateY(10px)';
            
            setTimeout(() => {
                content.style.transform = 'translateY(0)';
            }, 150);
        }
    },

    // Mifty Sidebar toggle
    toggleSidebar() {
        const sidebar = document.querySelector('.sidebar');
        const mainContent = document.querySelector('.main-content');
        
        if (sidebar && mainContent) {
            if (window.innerWidth <= 768) {
                // Mobile: Show/hide sidebar
                sidebar.classList.toggle('show');
            } else {
                // Desktop: Collapse/expand sidebar
                sidebar.classList.toggle('collapsed');
                mainContent.classList.toggle('expanded');
                
                // Store preference
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            }
        }
    },

    // Bildirim kontrolü
    checkNotifications() {
        // Örnek bildirimler - gerçek uygulamada API'den gelecek
        const notifications = [
            { id: 1, type: 'warning', message: 'Araç bakım zamanı yaklaştı', time: new Date() },
            { id: 2, type: 'info', message: 'Yeni fatura oluşturuldu', time: new Date() },
            { id: 3, type: 'success', message: 'Ödeme alındı', time: new Date() }
        ];
        
        this.updateNotificationBadge(notifications.length);
    },

    // Bildirim badge'ini güncelle
    updateNotificationBadge(count) {
        const badges = document.querySelectorAll('.notification-badge');
        badges.forEach(badge => {
            if (badge) {
                badge.textContent = count;
                badge.style.display = count > 0 ? 'block' : 'none';
            }
        });
    },

    // Kullanıcı tercihlerini yükle
    loadUserPreferences() {
        const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
        if (sidebarCollapsed) {
            this.toggleSidebar();
        }

        const darkMode = localStorage.getItem('darkMode') === 'true';
        if (darkMode) {
            this.toggleDarkMode();
        }
    },

    // Dark mode toggle
    toggleDarkMode() {
        this.state.darkMode = !this.state.darkMode;
        document.body.classList.toggle('dark-mode', this.state.darkMode);
        localStorage.setItem('darkMode', this.state.darkMode);
    },

    // Başarı mesajı göster
    showSuccessMessage(message) {
        this.showToast(message, 'success');
    },

    // Hata mesajı göster
    showErrorMessage(message) {
        this.showToast(message, 'error');
    },

    // Toast bildirimi göster
    showToast(message, type = 'info') {
        const toast = document.createElement('div');
        toast.className = `toast toast-${type}`;
        toast.innerHTML = `
            <div class="toast-content">
                <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(toast);
        
        // Animasyon
        setTimeout(() => toast.classList.add('show'), 100);
        setTimeout(() => {
            toast.classList.remove('show');
            setTimeout(() => document.body.removeChild(toast), 300);
        }, 3000);
    },

    // Validasyon hatalarını göster
    showValidationErrors(form) {
        const invalidFields = form.querySelectorAll(':invalid');
        invalidFields.forEach(field => {
            const feedback = field.nextElementSibling;
            if (feedback && feedback.classList.contains('invalid-feedback')) {
                feedback.style.display = 'block';
            }
        });
    }
};

// Sayfa yüklendiğinde uygulamayı başlat
document.addEventListener('DOMContentLoaded', () => {
    FleetApp.init();
});

// Global fonksiyonlar (geriye dönük uyumluluk için)
window.FleetApp = FleetApp;