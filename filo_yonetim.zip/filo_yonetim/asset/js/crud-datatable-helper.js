/**
 * Filo Yönetim Sistemi - CRUD & DataTable Yardımcı Fonksiyonları
 * Bu dosya, DataTables ve modal işlemleri için genel yardımcı fonksiyonları içerir.
 */

/**
 * Genel bir AJAX isteği gönderir ve yanıtı işler.
 * @param {object} options - AJAX ayarları (url, type, data, etc.).
 * @param {jQuery} submitButton - İşlemi tetikleyen buton (isteğe bağlı).
 * @returns {Promise} - AJAX isteğinin sonucunu içeren bir Promise nesnesi.
 */
function sendAjaxRequest(options, submitButton = null) {
    const originalButtonHtml = submitButton ? submitButton.html() : '';
    const loadingHtml = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> İşleniyor...';

    return new Promise((resolve, reject) => {
        $.ajax({
            ...options,
            dataType: 'json',
            beforeSend: function() {
                if (submitButton) {
                    submitButton.prop('disabled', true).html(loadingHtml);
                }
            },
            success: function(response) {
                if (response.status === 'success') {
                    toastr.success(response.message || 'İşlem başarıyla tamamlandı.');
                    resolve(response);
                } else {
                    toastr.error(response.message || 'Bir hata oluştu!');
                    reject(response);
                }
            },
            error: function(xhr) {
                const errorMessage = xhr.responseJSON?.message || xhr.statusText || 'Bilinmeyen bir sunucu hatası oluştu.';
                toastr.error(`Hata: ${errorMessage}`);
                console.error('AJAX Error:', xhr);
                reject(xhr);
            },
            complete: function() {
                if (submitButton) {
                    submitButton.prop('disabled', false).html(originalButtonHtml);
                }
            }
        });
    });
}

/**
 * Genel bir silme işlemi için SweetAlert onayı gösterir ve AJAX isteği gönderir.
 * @param {string} url - Silme API'sinin URL'si.
 * @param {number} id - Silinecek kaydın ID'si.
 * @param {object} table - Yeniden yüklenecek DataTable nesnesi.
 * @param {string} [title='Emin misiniz?'] - Onay penceresi başlığı.
 * @param {string} [text='Bu işlem geri alınamaz!'] - Onay penceresi metni.
 */
function handleDelete(url, id, table, title = 'Emin misiniz?', text = 'Bu kaydı silmek istediğinize emin misiniz? Bu işlem geri alınamaz!') {
    Swal.fire({
        title: title,
        text: text,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Evet, sil!',
        cancelButtonText: 'İptal'
    }).then((result) => {
        if (result.isConfirmed) {
            sendAjaxRequest({
                url: url,
                type: 'POST',
                data: { id: id }
            }).then(() => {
                table.ajax.reload(); // Tabloyu yenile
                // Gerekirse diğer istatistikleri de yenile
                if (typeof yukleIzinIstatistikleri === 'function') {
                    yukleIzinIstatistikleri();
                }
            }).catch(() => {
                // Hata zaten toastr ile gösterildi.
            });
        }
    });
}

/**
 * DataTables için varsayılan dil ayarlarını döndürür.
 * @returns {object}
 */
function getDataTablesLanguage() {
    return {
        url: '//cdn.datatables.net/plug-ins/1.11.5/i18n/tr.json'
    };
}

/**
 * DataTables için varsayılan dışa aktarma butonlarını döndürür.
 * @param {Array<number>} exportColumns - Dışa aktarılacak sütunların indeksleri.
 * @returns {Array<object>}
 */
function getDataTablesButtons(exportColumns) {
    return [
        {
            extend: 'excel',
            text: '<i class="fas fa-file-excel"></i> Excel',
            className: 'btn btn-success btn-sm',
            exportOptions: { columns: exportColumns }
        },
        {
            extend: 'pdf',
            text: '<i class="fas fa-file-pdf"></i> PDF',
            className: 'btn btn-danger btn-sm',
            exportOptions: { columns: exportColumns }
        },
        {
            extend: 'print',
            text: '<i class="fas fa-print"></i> Yazdır',
            className: 'btn btn-secondary btn-sm',
            exportOptions: { columns: exportColumns }
        }
    ];
}