<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Set page variables for header
$page_title = 'Dashboard';
$page_subtitle = 'Filo yönetim sistemine genel bakış';

// Dashboard istatistiklerini hesapla
try {
    // Fatura istatistikleri
    $stmt = $pdo->query("SELECT 
        COUNT(*) as total_invoices,
        SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid_invoices,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_invoices,
        SUM(CASE WHEN status = 'overdue' THEN 1 ELSE 0 END) as overdue_invoices,
        SUM(total_amount) as total_amount,
        SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END) as paid_amount,
        SUM(CASE WHEN status != 'paid' THEN total_amount ELSE 0 END) as pending_amount
    FROM invoices");
    $invoice_stats = $stmt->fetch();

    // Araç sayısı
    $stmt = $pdo->query("SELECT COUNT(*) as total_vehicles FROM vehicles WHERE status = 'active'");
    $vehicle_count = $stmt->fetchColumn();

    // Müşteri sayısı
    $stmt = $pdo->query("SELECT COUNT(*) as total_customers FROM customers WHERE status = 'active'");
    $customer_count = $stmt->fetchColumn();

    // Personel sayısı
    $stmt = $pdo->query("SELECT COUNT(*) as total_personnel FROM personnel WHERE status = 'active'");
    $personnel_count = $stmt->fetchColumn();

    // Bu ayki gelir-gider
    $stmt = $pdo->query("SELECT 
        SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as monthly_income,
        SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as monthly_expense
    FROM income_expense 
    WHERE MONTH(date) = MONTH(CURRENT_DATE()) AND YEAR(date) = YEAR(CURRENT_DATE())");
    $monthly_stats = $stmt->fetch();

    // Son faturalar
    $stmt = $pdo->query("SELECT i.*, c.name as customer_name, v.plate as vehicle_plate 
    FROM invoices i 
    LEFT JOIN customers c ON i.customer_id = c.id 
    LEFT JOIN vehicles v ON i.vehicle_id = v.id 
    ORDER BY i.created_at DESC LIMIT 5");
    $recent_invoices = $stmt->fetchAll();

    // Yaklaşan vadeler
    $stmt = $pdo->query("SELECT i.*, c.name as customer_name 
    FROM invoices i 
    LEFT JOIN customers c ON i.customer_id = c.id 
    WHERE i.status != 'paid' AND i.due_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    ORDER BY i.due_date ASC LIMIT 5");
    $upcoming_dues = $stmt->fetchAll();

    // En çok masraf yapan araçlar (son 30 gün)
    $stmt = $pdo->query("
        SELECT 
            v.plate,
            (COALESCE(SUM(vf.cost), 0) + COALESCE(SUM(vm.cost), 0)) as total_cost
        FROM vehicles v
        LEFT JOIN vehicle_fuel vf ON v.id = vf.vehicle_id AND vf.fuel_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        LEFT JOIN vehicle_maintenance vm ON v.id = vm.vehicle_id AND vm.maintenance_date >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
        WHERE v.status = 'active'
        GROUP BY v.id, v.plate
        HAVING total_cost > 0
        ORDER BY total_cost DESC
        LIMIT 5
    ");
    $top_expense_vehicles = $stmt->fetchAll();

    // Aylık masraf dökümü (son 6 ay)
    $stmt = $pdo->query("
        SELECT 
            DATE_FORMAT(expense_date, '%Y-%m') as month,
            SUM(CASE WHEN expense_type = 'fuel' THEN cost ELSE 0 END) as total_fuel,
            SUM(CASE WHEN expense_type = 'maintenance' THEN cost ELSE 0 END) as total_maintenance
        FROM (
            SELECT cost, fuel_date as expense_date, 'fuel' as expense_type FROM vehicle_fuel
            UNION ALL
            SELECT cost, maintenance_date as expense_date, 'maintenance' as expense_type FROM vehicle_maintenance
        ) as expenses
        WHERE expense_date >= DATE_SUB(CURDATE(), INTERVAL 6 MONTH)
        GROUP BY DATE_FORMAT(expense_date, '%Y-%m')
        ORDER BY month ASC
    ");
    $monthly_costs = $stmt->fetchAll();
} catch (Exception $e) {
    // Hata durumunda varsayılan değerler
    $invoice_stats = [
        'total_invoices' => 0, 'paid_invoices' => 0, 'pending_invoices' => 0, 
        'overdue_invoices' => 0, 'total_amount' => 0, 'paid_amount' => 0, 'pending_amount' => 0
    ];
    $vehicle_count = 0;
    $customer_count = 0;
    $personnel_count = 0;
    $monthly_stats = ['monthly_income' => 0, 'monthly_expense' => 0];
    $recent_invoices = [];
    $upcoming_dues = [];
    $top_expense_vehicles = [];
    $monthly_costs = [];
}

// Include modern header
include 'includes/header.php';
?>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <a href="invoices.php?action=create" class="btn btn-primary w-100 quick-action-btn">
                            <i class="fas fa-plus-circle mb-1"></i>
                            <small>Yeni Fatura</small>
                        </a>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <a href="collections.php?action=create" class="btn btn-success w-100 quick-action-btn">
                            <i class="fas fa-cash-register mb-1"></i>
                            <small>Yeni Tahsilat</small>
                        </a>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <a href="maintenance.php?action=create" class="btn btn-info w-100 quick-action-btn">
                            <i class="fas fa-tools mb-1"></i>
                            <small>Bakım Kaydı</small>
                        </a>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <a href="reportsk Rapor</small>
                        </a>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <a href="reports_z.php?type=monthly" cla
                            <small>Aylık Rapor</small>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <a href="vehicles.php?action=create" class="btn btn-secondary w-100 quick-action-btn">
                            <i class="fas fa-truck mb-1"></i>
                            <small>Araç Ekle</small>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Yaklaşan Bakımlar Bildirimi -->
<?php if ($notification_count > 0): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <h5 class="alert-heading"><i class="fas fa-exclamation-triangle me-2"></i>Yaklaşan Bakımlar</h5>
    <p>Aşağıdaki araçların bakımları önümüzdeki <strong><?= $upcoming_maintenance_days ?> gün</strong> içinde yapılmalıdır:</p>
    <ul>
        <?php foreach (array_slice($maintenance_notifications, 0, 3) as $notification): // Sadece ilk 3 tanesini gösterelim ?>
            <li>
                <strong><?= htmlspecialchars($notification['plate']) ?></strong> - Son Tarih: <strong><?= date('d.m.Y', strtotime($notification['next_maintenance_date'])) ?></strong>
            </li>
        <?php endforeach; ?>
    </ul>
    <?php if ($notification_count > 3): ?>
        <p class="mb-0">...ve <?= $notification_count - 3 ?> diğer araç.</p>
    <?php endif; ?>
    <hr>
    <a href="maintenance.php" class="btn btn-sm btn-warning">Tüm Bakım Kayıtlarını Görüntüle</a>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
</div>
<?php endif; ?>

<!-- Ornek.html Stats Cards -->
<div class="row mb-4">
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card stats-card">
            <i class="fas fa-money-bill-wave"></i>
            <h2><?= number_format($monthly_stats['monthly_income'] ?? 0, 0, ',', '.') ?>₺</h2>
            <p>Aylık Gelir</p>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card stats-card">
            <i class="fas fa-credit-card"></i>
            <h2><?= number_format($monthly_stats['monthly_expense'] ?? 0, 0, ',', '.') ?>₺</h2>
            <p>Aylık Gider</p>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card stats-card">
            <i class="fas fa-file-invoice"></i>
            <h2><?= $invoice_stats['pending_invoices'] + $invoice_stats['overdue_invoices'] ?></h2>
            <p>Bekleyen Faturalar</p>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card stats-card">
            <i class="fas fa-cash-register"></i>
            <h2><?= number_format($invoice_stats['paid_amount'] ?? 0, 0, ',', '.') ?>₺</h2>
            <p>Toplam Tahsilat</p>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card stats-card">
            <i class="fas fa-users"></i>
            <h2><?= $customer_count ?></h2>
            <p>Aktif Müşteriler</p>
        </div>
    </div>
    
    <div class="col-xl-2 col-md-4 col-sm-6">
        <div class="card stats-card">
            <i class="fas fa-truck"></i>
            <h2><?= $vehicle_count ?></h2>
            <p>Aktif Araçlar</p>
        </div>
    </div>
</div>

<!-- Secondary Stats Row -->
<div class="row g-3 mb-4">
    <div class="col-xl-4 col-lg-6">
        <div class="card border-0">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h6 class="card-title mb-0">Toplam Tahsilat</h6>
                    <div class="stat-icon bg-success" style="width: 32px; height: 32px; font-size: 0.875rem;">
                        <i class="fas fa-cash-register"></i>
                    </div>
                </div>
                <h4 class="mb-1"><?= number_format($invoice_stats['paid_amount'] ?? 0, 0, ',', '.') ?>₺</h4>
                <small class="text-success"><i class="fas fa-arrow-up me-1"></i>Bu ay +15.3%</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-4 col-lg-6">
        <div class="card border-0">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h6 class="card-title mb-0">Aktif Personel</h6>
                    <div class="stat-icon bg-primary" style="width: 32px; height: 32px; font-size: 0.875rem;">
                        <i class="fas fa-users"></i>
                    </div>
                </div>
                <h4 class="mb-1"><?= $personnel_count ?></h4>
                <small class="text-muted">Toplam personel sayısı</small>
            </div>
        </div>
    </div>
    
    <div class="col-xl-4 col-lg-6">
        <div class="card border-0">
            <div class="card-body p-3">
                <div class="d-flex align-items-center justify-content-between mb-2">
                    <h6 class="card-title mb-0">Net Kar</h6>
                    <div class="stat-icon bg-success" style="width: 32px; height: 32px; font-size: 0.875rem;">
                        <i class="fas fa-chart-line"></i>
                    </div>
                </div>
                <h4 class="mb-1"><?= number_format(($monthly_stats['monthly_income'] ?? 0) - ($monthly_stats['monthly_expense'] ?? 0), 0, ',', '.') ?>₺</h4>
                <small class="text-success"><i class="fas fa-arrow-up me-1"></i>Aylık kar</small>
            </div>
        </div>
    </div>
    <div class="col-xl-4">
        <div class="card border-0">
            <div class="card-header bg-transparent border-0 pb-0">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="card-title mb-0">En Çok Masraf Yapan Araçlar (Son 30 Gün)</h6>
                    <a href="reports_z.php" class="btn btn-sm btn-outline-primary">Detaylı Rapor</a>
                </div>
            </div>
            <div class="card-body">
                <div style="height: 250px;">
                    <canvas id="topExpenseVehiclesChart"></canvas>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-8">
        <div class="card border-0">
            <div class="card-header bg-transparent border-0 pb-0">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="card-title mb-0">Aylık Masraf Dağılımı (Yakıt vs. Bakım)</h6>
                    <a href="reports_z.php" class="btn btn-sm btn-outline-primary">Detaylı Rapor</a>
                </div>
            </div>
            <div class="card-body">
                <div style="height: 250px;">
                    <canvas id="monthlyCostsChart"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Mifty Recent Transactions -->
<div class="row g-3">
    <div class="col-xl-8">
        <div class="card border-0">
            <div class="card-header bg-transparent border-0 pb-0">
                <div class="d-flex justify-content-between align-items-center">
                    <h6 class="card-title mb-0">Son Faturalar</h6>
                    <a href="invoices.php" class="btn btn-sm btn-outline-primary">Tümünü Gör</a>
                </div>
            </div>
            <div class="card-body pt-2">
                <div class="table-responsive">
                    <table class="table table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th class="border-0 fw-medium">Fatura No</th>
                                <th class="border-0 fw-medium">Müşteri</th>
                                <th class="border-0 fw-medium">Tarih</th>
                                <th class="border-0 fw-medium">Tutar</th>
                                <th class="border-0 fw-medium">Durum</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_invoices)): ?>
                                <tr>
                                    <td colspan="5" class="text-center text-muted py-4">
                                        <i class="fas fa-file-invoice fa-2x mb-2 d-block opacity-50"></i>
                                        Henüz fatura kaydı bulunmuyor
                                    </td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($recent_invoices as $invoice): ?>
                                <tr>
                                    <td class="fw-medium">#<?= $invoice['receipt_no'] ?></td>
                                    <td><?= htmlspecialchars($invoice['customer_name'] ?? 'Bilinmeyen') ?></td>
                                    <td class="text-muted"><?= date('d.m.Y', strtotime($invoice['created_at'])) ?></td>
                                    <td class="fw-medium"><?= number_format($invoice['total_amount'], 2, ',', '.') ?>₺</td>
                                    <td>
                                        <?php
                                        $badge_class = 'badge bg-secondary';
                                        $status_text = 'Bilinmeyen';
                                        switch ($invoice['status']) {
                                            case 'paid':
                                                $badge_class = 'badge bg-success';
                                                $status_text = 'Ödendi';
                                                break;
                                            case 'pending':
                                                $badge_class = 'badge bg-warning text-dark';
                                                $status_text = 'Beklemede';
                                                break;
                                            case 'overdue':
                                                $badge_class = 'badge bg-danger';
                                                $status_text = 'Gecikmiş';
                                                break;
                                        }
                                        ?>
                                        <span class="badge <?= $badge_class ?>"><?= $status_text ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-xl-4 col-lg-5">
        <!-- Hızlı Bilgiler Widget -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0">Bugünkü Özet</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Günlük Gelir</span>
                    <strong class="text-success">₺12,450</strong>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Günlük Gider</span>
                    <strong class="text-danger">₺3,200</strong>
                </div>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <span class="text-muted">Net Kar</span>
                    <strong class="text-primary">₺9,250</strong>
                </div>
                <hr>
                <div class="d-flex justify-content-between align-items-center">
                    <span class="text-muted">Aktif Seferler</span>
                    <span class="badge bg-info">8</span>
                </div>
            </div>
        </div>
        
        <!-- Yaklaşan Ödemeler -->
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">Yaklaşan Ödemeler</h5>
                <a href="payments.php" class="btn btn-sm btn-outline-primary">Tümü</a>
            </div>
            <div class="card-body">
                <?php if (!empty($upcoming_dues)): ?>
                    <?php foreach (array_slice($upcoming_dues, 0, 4) as $due): ?>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <div>
                            <div class="fw-medium"><?= htmlspecialchars($due['customer_name']) ?></div>
                            <small class="text-muted"><?= date('d.m.Y', strtotime($due['due_date'])) ?></small>
                        </div>
                        <span class="badge bg-warning"><?= number_format($due['amount'], 0, ',', '.') ?>₺</span>
                    </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="text-center text-muted py-3">
                        <i class="fas fa-calendar-check fa-2x mb-2"></i><br>
                        Yaklaşan ödeme bulunmuyor
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>


<script>
document.addEventListener('DOMContentLoaded', function() {
    // En Çok Masraf Yapan Araçlar Grafiği
    const topExpenseCtx = document.getElementById('topExpenseVehiclesChart');
    if (topExpenseCtx) {
        new Chart(topExpenseCtx, {
            type: 'bar',
            data: {
                labels: [<?php echo "'" . implode("','", array_column($top_expense_vehicles, 'plate')) . "'"; ?>],
                datasets: [{
                    label: 'Toplam Masraf (₺)',
                    data: [<?php echo implode(',', array_column($top_expense_vehicles, 'total_cost')); ?>],
                    backgroundColor: 'rgba(231, 74, 59, 0.6)',
                    borderColor: 'rgba(231, 74, 59, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                indexAxis: 'y', // Yatay çubuk grafik için
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: { x: { beginAtZero: true, ticks: { callback: value => '₺' + value.toLocaleString() } } }
            }
        });
    }

    // Aylık Masraf Dağılımı Grafiği
    const monthlyCostsCtx = document.getElementById('monthlyCostsChart');
    if (monthlyCostsCtx) {
        new Chart(monthlyCostsCtx, {
            type: 'bar',
            data: {
                labels: [<?php echo "'" . implode("','", array_column($monthly_costs, 'month')) . "'"; ?>],
                datasets: [
                    {
                        label: 'Yakıt Masrafı (₺)',
                        data: [<?php echo implode(',', array_column($monthly_costs, 'total_fuel')); ?>],
                        backgroundColor: 'rgba(54, 162, 235, 0.6)', // Mavi
                        borderColor: 'rgba(54, 162, 235, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Bakım Masrafı (₺)',
                        data: [<?php echo implode(',', array_column($monthly_costs, 'total_maintenance')); ?>],
                        backgroundColor: 'rgba(255, 159, 64, 0.6)', // Turuncu
                        borderColor: 'rgba(255, 159, 64, 1)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: { x: { stacked: true }, y: { stacked: true, beginAtZero: true, ticks: { callback: value => '₺' + value.toLocaleString() } } }
            }
        });
    }
});
</script>
<?php include 'includes/footer.php'; ?>