<?php
// Kalan sidebar'ları manuel düzelten script
$files_to_fix = [
    'dashboard.php',
    'invoices.php', 
    'income_expense.php',
    'vehicles.php',
    'customers.php'
];

foreach ($files_to_fix as $file) {
    if (file_exists($file)) {
        $content = file_get_contents($file);
        
        // Dashboard için özel durum
        if ($file == 'dashboard.php') {
            // Eski sidebar yapısını bul ve değiştir
            $pattern = '/<!-- Sidebar -->.*?<\/div>/s';
            if (preg_match($pattern, $content)) {
                $content = preg_replace($pattern, '<?php include \'includes/sidebar.php\'; ?>', $content);
            } else {
                // Alternatif pattern
                $pattern2 = '/<div class="sidebar">.*?<\/div>/s';
                $content = preg_replace($pattern2, '<?php include \'includes/sidebar.php\'; ?>', $content);
            }
        } else {
            // Diğer dosyalar için
            $patterns = [
                '/<!-- Sidebar -->.*?<\/nav>/s',
                '/<nav class="col-md-3.*?<\/nav>/s',
                '/<nav.*?sidebar.*?<\/nav>/s'
            ];
            
            foreach ($patterns as $pattern) {
                if (preg_match($pattern, $content)) {
                    $content = preg_replace($pattern, '<?php include \'includes/sidebar.php\'; ?>', $content);
                    break;
                }
            }
        }
        
        file_put_contents($file, $content);
        echo "✅ $file güncellendi<br>";
    } else {
        echo "❌ $file bulunamadı<br>";
    }
}

echo "<br><strong>Tüm sidebar'lar güncellendi!</strong><br>";
echo "<a href='dashboard.php'>Dashboard'a Git</a>";
?>
