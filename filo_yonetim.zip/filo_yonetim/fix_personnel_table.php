<?php
require_once 'includes/config.php';

try {
    // Check if personnel table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'personnel'");
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        die("Personel tablosu bulunamadı!");
    }
    
    // Add missing columns
    $alterQueries = [
        "ALTER TABLE `personnel` 
         ADD COLUMN IF NOT EXISTS `surname` VARCHAR(100) DEFAULT NULL AFTER `name`,
         ADD COLUMN IF NOT EXISTS `phone` VARCHAR(20) DEFAULT NULL AFTER `email`,
         ADD COLUMN IF NOT EXISTS `hire_date` DATE DEFAULT NULL AFTER `department`,
         ADD COLUMN IF NOT EXISTS `status` ENUM('active', 'on_leave', 'inactive', 'deleted') DEFAULT 'active' AFTER `hire_date`,
         ADD COLUMN IF NOT EXISTS `created_by` INT DEFAULT NULL AFTER `status`,
         ADD COLUMN IF NOT EXISTS `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
         ADD COLUMN IF NOT EXISTS `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"
    ];
    
    echo "<h2>Tablo Yapısı Güncelleniyor</h2>";
    
    foreach ($alterQueries as $query) {
        echo "<p>Çalıştırılıyor: <code>" . htmlspecialchars($query) . "</code></p>";
        try {
            $pdo->exec($query);
            echo "<p style='color: green;'>Başarılı!</p>";
        } catch (PDOException $e) {
            echo "<p style='color: red;'>Hata: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }
    
    echo "<h2>Güncel Tablo Yapısı</h2>";
    
    // Show updated table structure
    $stmt = $pdo->query("DESCRIBE personnel");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($column['Extra'] ?? '') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
} catch (PDOException $e) {
    die("<p style='color: red;'>Hata oluştu: " . htmlspecialchars($e->getMessage()) . "</p>");
}
?>
