<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Tahsilatlar';
$page_subtitle = 'Müşteri tahsilatlarını yönetin';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0"><i class="fas fa-cash-register me-2"></i>Tahsilatlar</h5>
        </div>
        <div class="card-body">
            <div class="alert alert-info">
                <i class="fas fa-info-circle me-2"></i>
                Bu modül geliştirme aşamasındadır. Yakında kullanıma sunulacaktır.
            </div>
            <div class="text-center py-5">
                <i class="fas fa-tools fa-3x text-muted mb-3"></i>
                <h4>Tahsilat Modülü</h4>
                <p class="text-muted">Bu sayfa şu anda geliştirme aşamasındadır.</p>
                <a href="dashboard.php" class="btn btn-primary">
                    <i class="fas fa-tachometer-alt me-2"></i>Dashboard'a Dön
                </a>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>