<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Sayfa değişkenleri
$page_title = 'Personel Yönetimi';
$page_subtitle = 'Personel kayıtlarını yönetin';

// İstatistikleri çek
$stats_query = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN status = 'active' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN status = 'on_leave' THEN 1 ELSE 0 END) as on_leave,
    SUM(CASE WHEN status = 'inactive' THEN 1 ELSE 0 END) as inactive
FROM personnel");

$stats = $stats_query->fetch(PDO::FETCH_ASSOC);
$total_personnel = $stats['total'] ?? 0;
$active_personnel = $stats['active'] ?? 0;
$on_leave = $stats['on_leave'] ?? 0;
$inactive = $stats['inactive'] ?? 0;

// Departman listesini al (Bu tablo şemada yok, geçici olarak kapatıldı)
// $departmanlar = $pdo->query("SELECT id, departman_adi FROM departmanlar WHERE durum = 1 ORDER BY departman_adi ASC")->fetchAll();
$departmanlar = []; // Geçici olarak boş dizi atıyoruz

// Header'ı dahil et
include 'includes/header.php';
?>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#yeniPersonelModal">
                            <i class="fas fa-user-plus mb-1"></i>
                            <small>Yeni Personel</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-success w-100 quick-action-btn" onclick="filterPersonnel('Aktif')">
                            <i class="fas fa-user-check mb-1"></i>
                            <small>Aktifler</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-warning w-100 quick-action-btn" onclick="filterPersonnel('İzinli')">
                            <i class="fas fa-umbrella-beach mb-1"></i>
                            <small>İzinliler</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-danger w-100 quick-action-btn" onclick="filterPersonnel('İşten Ayrıldı')">
                            <i class="fas fa-user-times mb-1"></i>
                            <small>Ayrılanlar</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-info w-100 quick-action-btn" onclick="exportPersonnel()">
                            <i class="fas fa-download mb-1"></i>
                            <small>Dışa Aktar</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-secondary w-100 quick-action-btn" onclick="printPersonnel()">
                            <i class="fas fa-print mb-1"></i>
                            <small>Yazdır</small>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- İstatistik Kartları -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Toplam Personel</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($total_personnel) ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Aktif Personel</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($active_personnel) ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-check fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">İzinli</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($on_leave) ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-umbrella-beach fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-danger h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Ayrılanlar</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?= number_format($inactive) ?></div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-user-times fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Personel Listesi -->
<div class="card shadow mb-4">
    <div class="card-header py-3 d-flex justify-content-between align-items-center">
        <h6 class="m-0 font-weight-bold text-primary">Personel Listesi</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="personelTable" width="100%" cellspacing="0">
                <thead class="table-light">
                    <tr>
                        <th width="40">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="selectAll">
                            </div>
                        </th>
                        <th>Personel</th>
                        <th>Pozisyon</th>
                        <th>Departman</th>
                        <th>İletişim</th>
                        <th>İşe Giriş</th>
                        <th>Durum</th>
                        <th width="120">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından sunucu taraflı olarak doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Toplu İşlemler Toolbar -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div class="toast align-items-center text-white bg-primary border-0" role="alert" aria-live="assertive" aria-atomic="true" id="toastTopluIslem">
        <div class="d-flex">
            <div class="toast-body">
                <i class="fas fa-users me-2"></i>
                <span id="selectedCount">0</span> personel seçildi
            </div>
            <div class="btn-group btn-group-sm me-2 my-auto">
                <button type="button" class="btn btn-light" onclick="sendBulkAction('email')" title="E-posta Gönder">
                    <i class="fas fa-envelope text-primary"></i>
                </button>
                <button type="button" class="btn btn-light" onclick="sendBulkAction('sms')" title="SMS Gönder">
                    <i class="fas fa-sms text-primary"></i>
                </button>
                <button type="button" class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false" title="Durum Değiştir">
                    <i class="fas fa-exchange-alt text-primary"></i>
                </button>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a class="dropdown-item" href="#" onclick="changeBulkStatus('Aktif')">Aktif Yap</a></li>
                    <li><a class="dropdown-item" href="#" onclick="changeBulkStatus('İzinli')">İzinli Yap</a></li>
                    <li><a class="dropdown-item" href="#" onclick="changeBulkStatus('İşten Ayrıldı')">İşten Ayrıldı Yap</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item text-danger" href="#" onclick="deleteBulkPersonnel()">Seçilenleri Sil</a></li>
                </ul>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Kapat"></button>
        </div>
    </div>
</div>

<!-- Yeni Personel Ekleme Modal -->
<div class="modal fade" id="yeniPersonelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yeni Personel Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="personelForm" action="api/personel_ekle.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <ul class="nav nav-tabs" id="personelTabs" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active" id="genel-bilgiler-tab" data-bs-toggle="tab" data-bs-target="#genel-bilgiler" type="button" role="tab">Genel Bilgiler</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="iletisim-bilgileri-tab" data-bs-toggle="tab" data-bs-target="#iletisim-bilgileri" type="button" role="tab">İletişim Bilgileri</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="is-bilgileri-tab" data-bs-toggle="tab" data-bs-target="#is-bilgileri" type="button" role="tab">İş Bilgileri</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link" id="banka-bilgileri-tab" data-bs-toggle="tab" data-bs-target="#banka-bilgileri" type="button" role="tab">Banka Bilgileri</button>
                        </li>
                    </ul>
                    <div class="tab-content p-3 border border-top-0 rounded-bottom" id="personelTabsContent">
                        <div class="tab-pane fade show active" id="genel-bilgiler" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="ad" class="form-label">Adı <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="ad" name="ad" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="soyad" class="form-label">Soyadı <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="soyad" name="soyad" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="tc_kimlik" class="form-label">TC Kimlik No</label>
                                    <input type="text" class="form-control" id="tc_kimlik" name="tc_kimlik">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="dogum_tarihi" class="form-label">Doğum Tarihi</label>
                                    <input type="date" class="form-control" id="dogum_tarihi" name="dogum_tarihi">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="cinsiyet" class="form-label">Cinsiyet</label>
                                    <select class="form-select" id="cinsiyet" name="cinsiyet">
                                        <option value="">Seçiniz</option>
                                        <option value="Erkek">Erkek</option>
                                        <option value="Kadın">Kadın</option>
                                        <option value="Diğer">Diğer</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="kan_grubu" class="form-label">Kan Grubu</label>
                                    <select class="form-select" id="kan_grubu" name="kan_grubu">
                                        <option value="">Bilinmiyor</option>
                                        <option value="A Rh+">A Rh+</option>
                                        <option value="A Rh-">A Rh-</option>
                                        <option value="B Rh+">B Rh+</option>
                                        <option value="B Rh-">B Rh-</option>
                                        <option value="AB Rh+">AB Rh+</option>
                                        <option value="AB Rh-">AB Rh-</option>
                                        <option value="0 Rh+">0 Rh+</option>
                                        <option value="0 Rh-">0 Rh-</option>
                                    </select>
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="fotograf" class="form-label">Fotoğraf</label>
                                    <input class="form-control" type="file" id="fotograf" name="fotograf" accept="image/*">
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="iletisim-bilgileri" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="telefon" class="form-label">Telefon</label>
                                    <input type="tel" class="form-control" id="telefon" name="telefon">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label">E-posta</label>
                                    <input type="email" class="form-control" id="email" name="email">
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="adres" class="form-label">Adres</label>
                                    <textarea class="form-control" id="adres" name="adres" rows="2"></textarea>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="il" class="form-label">İl</label>
                                    <input type="text" class="form-control" id="il" name="il">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="ilce" class="form-label">İlçe</label>
                                    <input type="text" class="form-control" id="ilce" name="ilce">
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="posta_kodu" class="form-label">Posta Kodu</label>
                                    <input type="text" class="form-control" id="posta_kodu" name="posta_kodu">
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="is-bilgileri" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="personel_no" class="form-label">Sicil No <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="personel_no" name="personel_no" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="departman_id" class="form-label">Departman</label>
                                    <select class="form-select" id="departman_id" name="departman_id">
                                        <option value="">Seçiniz...</option>
                                        <?php foreach ($departmanlar as $departman): ?>
                                            <option value="<?= $departman['id'] ?>"><?= htmlspecialchars($departman['departman_adi']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="pozisyon" class="form-label">Pozisyon</label>
                                    <input type="text" class="form-control" id="pozisyon" name="pozisyon">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="ise_giris_tarihi" class="form-label">İşe Giriş Tarihi</label>
                                    <input type="date" class="form-control" id="ise_giris_tarihi" name="ise_giris_tarihi">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="calisma_sekli" class="form-label">Çalışma Şekli</label>
                                    <select class="form-select" id="calisma_sekli" name="calisma_sekli">
                                        <option value="Tam Zamanlı">Tam Zamanlı</option>
                                        <option value="Yarı Zamanlı">Yarı Zamanlı</option>
                                        <option value="Stajyer">Stajyer</option>
                                        <option value="Dönemsel">Dönemsel</option>
                                    </select>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="durum" class="form-label">Durum</label>
                                    <select class="form-select" id="durum" name="durum">
                                        <option value="Aktif">Aktif</option>
                                        <option value="İzinli">İzinli</option>
                                        <option value="İşten Ayrıldı">İşten Ayrıldı</option>
                                        <option value="İşten Çıkarıldı">İşten Çıkarıldı</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="banka-bilgileri" role="tabpanel">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="banka_adi" class="form-label">Banka Adı</label>
                                    <input type="text" class="form-control" id="banka_adi" name="banka_adi">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="sube_adi" class="form-label">Şube Adı</label>
                                    <input type="text" class="form-control" id="sube_adi" name="sube_adi">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="sube_kodu" class="form-label">Şube Kodu</label>
                                    <input type="text" class="form-control" id="sube_kodu" name="sube_kodu">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="hesap_no" class="form-label">Hesap No</label>
                                    <input type="text" class="form-control" id="hesap_no" name="hesap_no">
                                </div>
                                <div class="col-12 mb-3">
                                    <label for="iban" class="form-label">IBAN</label>
                                    <div class="input-group">
                                        <span class="input-group-text">TR</span>
                                        <input type="text" class="form-control" id="iban" name="iban" placeholder="00 0000 0000 0000 0000 0000 00">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Personel Detay Modal -->
<div class="modal fade" id="personelDetayModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Personel Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body" id="personelDetayIcerik">
                <!-- Dinamik içerik JavaScript ile yüklenecek -->
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Yükleniyor...</span>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                <button type="button" class="btn btn-primary" id="editPersonelBtn">Düzenle</button>
            </div>
        </div>
    </div>
</div>

<!-- Silme Onay Modal -->
<div class="modal fade" id="silmeOnayModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Silme Onayı</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body">
                <p>Bu personel kaydını silmek istediğinize emin misiniz? Bu işlem geri alınamaz!</p>
                <p class="fw-bold" id="silinecekPersonel"></p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                <button type="button" class="btn btn-danger" id="confirmDeleteBtn">Sil</button>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.bootstrap5.min.css">

<!-- JavaScript -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
// Sayfa yüklendiğinde çalışacak kodlar
$(document).ready(function() {
    // Tab geçişlerini etkinleştir
    var tabElms = [].slice.call(document.querySelectorAll('button[data-bs-toggle="tab"]'));
    tabElms.forEach(function (tabEl) {
        new bootstrap.Tab(tabEl);
    });

    // Tümünü seç
    $('#selectAll').change(function() {
        $('.select-person').prop('checked', $(this).prop('checked'));
        updateSelectedCount();
    });

    // Bireysel seçimlerde tümünü seç durumunu güncelle
    $(document).on('change', '.select-person', function() {
        var allChecked = $('.select-person:checked').length === $('.select-person').length;
        $('#selectAll').prop('checked', allChecked);
        updateSelectedCount();
    });

    // DataTable başlatma
    var table = $('#personelTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/personel_api.php?action=list',
            type: 'POST'
        },
        columns: [
            { 
                data: 'id',
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="form-check"><input class="form-check-input select-person" type="checkbox" value="${data}"></div>`;
                }
            },
            { 
                data: 'ad',
                render: function(data, type, row) {
                    const avatar = row.fotograf ? `<img src="${row.fotograf}" class="rounded-circle" width="40" height="40">` : `<div class="avatar-sm rounded-circle bg-primary text-white d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">${(row.ad || '?').charAt(0)}${(row.soyad || '?').charAt(0)}</div>`;
                    return `<div class="d-flex align-items-center"><div class="me-2">${avatar}</div><div><div class="fw-bold">${row.ad || ''} ${row.soyad || ''}</div><small class="text-muted">${row.personel_no || ''}</small></div></div>`;
                }
            },
            { data: 'pozisyon' },
            { data: 'departman_adi' },
            { 
                data: 'telefon',
                render: function(data, type, row) {
                    return `<div><i class="fas fa-phone-alt me-2 text-muted"></i> ${row.telefon || '-'}</div><div><i class="fas fa-envelope me-2 text-muted"></i> ${row.email || '-'}</div>`;
                }
            },
            { 
                data: 'ise_giris_tarihi',
                render: function(data, type, row) {
                    return data ? moment(data).format('DD.MM.YYYY') : '-';
                }
            },
            { 
                data: 'durum',
                render: function(data, type, row) {
                    const durum_class = data === 'Aktif' ? 'success' : (data === 'İzinli' ? 'warning' : 'danger');
                    return `<span class="badge bg-${durum_class}">${data}</span>`;
                }
            },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="btn-group btn-group-sm">
                                <button type="button" class="btn btn-info" onclick="viewPersonnel(${row.id})" title="Görüntüle"><i class="fas fa-eye"></i></button>
                                <button type="button" class="btn btn-primary" onclick="editPersonnel(${row.id})" title="Düzenle"><i class="fas fa-edit"></i></button>
                                <button type="button" class="btn btn-danger" onclick="deletePersonnel(${row.id}, '${(row.ad + ' ' + row.soyad).replace(/'/g, "\\'")}')" title="Sil"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[1, 'asc']],
        language: getDataTablesLanguage(),
        dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>rt<"row"<"col-sm-12 col-md-5"i><"col-sm-12 col-md-7"p>>',
        responsive: true,
        columnDefs: [
            { "targets": [0, 7], "searchable": false }
        ]
    });
    
    // Form gönderimini yönet
    $('#personelForm').on('submit', function(e) {
        e.preventDefault();
        
        // Form verilerini topla
        var formData = new FormData(this);
        
        // AJAX ile gönder
        $.ajax({
            url: 'api/personel_ekle.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: 'Personel başarıyla eklendi.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'Bir hata oluştu.'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Hata!',
                    text: 'İşlem sırasında bir hata oluştu.'
                });
            }
        });
    });
});

// Seçili personel sayısını güncelle
function updateSelectedCount() {
    var selectedCount = $('.select-person:checked').length;
    
    if (selectedCount > 0) {
        $('#selectedCount').text(selectedCount);
        var toast = new bootstrap.Toast(document.getElementById('toastTopluIslem'));
        toast.show();
    } else {
        var toast = bootstrap.Toast.getInstance(document.getElementById('toastTopluIslem'));
        if (toast) {
            toast.hide();
        }
    }
}

// Personel filtreleme
function filterPersonnel(status) {
    var url = 'personel3.php';
    var params = [];
    
    if (status) {
        params.push('durum=' + encodeURIComponent(status));
    }
    
    if (params.length > 0) {
        url += '?' + params.join('&');
    }
    
    window.location.href = url;
}

// Personel görüntüle
function viewPersonnel(id) {
    $('#personelDetayModal').modal('show');
    
    // Detayları yükle
    $.get('api/personel_detay.php', { id: id }, function(response) {
        if (response.success) {
            var personel = response.data;
            var html = `
                <div class="row">
                    <div class="col-md-4 text-center mb-4">
                        ${personel.fotograf ? 
                            `<img src="${personel.fotograf}" class="img-fluid rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">` : 
                            `<div class="avatar-lg rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3" style="width: 150px; height: 150px; font-size: 3rem;">
                                ${personel.ad ? personel.ad.charAt(0) : ''}${personel.soyad ? personel.soyad.charAt(0) : ''}
                            </div>`
                        }
                        <h4 class="mb-1">${personel.ad} ${personel.soyad}</h4>
                        <p class="text-muted mb-2">${personel.pozisyon || 'Pozisyon Belirtilmemiş'}</p>
                        <span class="badge bg-${getStatusClass(personel.durum)}">${personel.durum}</span>
                    </div>
                    <div class="col-md-8">
                        <ul class="nav nav-tabs" id="personelDetayTabs" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="genel-tab" data-bs-toggle="tab" data-bs-target="#genel" type="button" role="tab">Genel Bilgiler</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="iletisim-tab" data-bs-toggle="tab" data-bs-target="#iletisim" type="button" role="tab">İletişim</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="is-tab" data-bs-toggle="tab" data-bs-target="#is" type="button" role="tab">İş Bilgileri</button>
                            </li>
                        </ul>
                        <div class="tab-content p-3 border border-top-0 rounded-bottom">
                            <div class="tab-pane fade show active" id="genel" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6 mb-2"><strong>TC Kimlik No:</strong> ${personel.tc_kimlik || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Doğum Tarihi:</strong> ${personel.dogum_tarihi ? formatDate(personel.dogum_tarihi) : '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Cinsiyet:</strong> ${personel.cinsiyet || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Kan Grubu:</strong> ${personel.kan_grubu || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Medeni Durum:</strong> ${personel.medeni_durum || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Çocuk Sayısı:</strong> ${personel.cocuk_sayisi || '0'}</div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="iletisim" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6 mb-2"><strong>Telefon:</strong> ${personel.telefon || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>E-posta:</strong> ${personel.email || '-'}</div>
                                    <div class="col-12 mb-2"><strong>Adres:</strong> ${personel.adres || '-'}</div>
                                    <div class="col-md-4 mb-2"><strong>İl:</strong> ${personel.il || '-'}</div>
                                    <div class="col-md-4 mb-2"><strong>İlçe:</strong> ${personel.ilce || '-'}</div>
                                    <div class="col-md-4 mb-2"><strong>Posta Kodu:</strong> ${personel.posta_kodu || '-'}</div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="is" role="tabpanel">
                                <div class="row">
                                    <div class="col-md-6 mb-2"><strong>Sicil No:</strong> ${personel.personel_no || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Departman:</strong> ${personel.departman_adi || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Pozisyon:</strong> ${personel.pozisyon || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>İşe Giriş Tarihi:</strong> ${personel.ise_giris_tarihi ? formatDate(personel.ise_giris_tarihi) : '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Çalışma Şekli:</strong> ${personel.calisma_sekli || '-'}</div>
                                    <div class="col-md-6 mb-2"><strong>Durum:</strong> ${personel.durum || '-'}</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            $('#personelDetayIcerik').html(html);
            
            // Düzenle butonuna tıklama olayını ekle
            $('#editPersonelBtn').off('click').on('click', function() {
                editPersonnel(id);
            });
        } else {
            $('#personelDetayIcerik').html('<div class="alert alert-danger">Personel bilgileri yüklenirken bir hata oluştu.</div>');
        }
    }, 'json').fail(function() {
        $('#personelDetayIcerik').html('<div class="alert alert-danger">Sunucu hatası. Lütfen daha sonra tekrar deneyin.</div>');
    });
}

// Personel düzenle
function editPersonnel(id) {
    // Personel düzenleme sayfasına yönlendir
    window.location.href = 'personel_duzenle.php?id=' + id;
}

// Personel silme işlemi
function deletePersonnel(id, name) {
    if (id) {
        // Silme onayı için modal göster
        $('#silinecekPersonel').text(name || 'Seçilen personel');
        
        // Onay butonuna tıklama olayını ekle
        $('#confirmDeleteBtn').off('click').on('click', function() {
            // AJAX ile silme işlemi
            $.post('api/personel_sil.php', { id: id }, function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: 'Personel başarıyla silindi.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'Silme işlemi sırasında bir hata oluştu.'
                    });
                }
            }, 'json');
            
            // Modalı kapat
            var modal = bootstrap.Modal.getInstance(document.getElementById('silmeOnayModal'));
            modal.hide();
        });
        
        // Modalı göster
        var myModal = new bootstrap.Modal(document.getElementById('silmeOnayModal'));
        myModal.show();
    }
}

// Toplu işlemler
function sendBulkAction(action) {
    var selectedIds = [];
    $('.select-person:checked').each(function() {
        selectedIds.push($(this).val());
    });
    
    if (selectedIds.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'Uyarı!',
            text: 'Lütfen en az bir personel seçin.'
        });
        return;
    }
    
    var actionText = '';
    var url = '';
    
    switch(action) {
        case 'email':
            actionText = 'e-posta gönderilecek';
            url = 'toplu_eposta_gonder.php';
            break;
        case 'sms':
            actionText = 'SMS gönderilecek';
            url = 'toplu_sms_gonder.php';
            break;
        default:
            return;
    }
    
    Swal.fire({
        title: 'Emin misiniz?',
        text: selectedIds.length + ' personele ' + actionText + '. Devam etmek istiyor musunuz?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Evet, Devam Et',
        cancelButtonText: 'İptal'
    }).then((result) => {
        if (result.isConfirmed) {
            // AJAX ile toplu işlemi gerçekleştir
            $.post(url, { personel_ids: selectedIds }, function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: response.message || 'İşlem başarıyla tamamlandı.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Sayfayı yenile
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'İşlem sırasında bir hata oluştu.'
                    });
                }
            }, 'json');
        }
    });
}

// Toplu durum değiştirme
function changeBulkStatus(newStatus) {
    var selectedIds = [];
    $('.select-person:checked').each(function() {
        selectedIds.push($(this).val());
    });
    
    if (selectedIds.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'Uyarı!',
            text: 'Lütfen en az bir personel seçin.'
        });
        return;
    }
    
    Swal.fire({
        title: 'Emin misiniz?',
        text: selectedIds.length + ' personelin durumu "' + newStatus + '" olarak güncellenecek. Devam etmek istiyor musunuz?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Evet, Güncelle',
        cancelButtonText: 'İptal'
    }).then((result) => {
        if (result.isConfirmed) {
            // AJAX ile durum güncelleme
            $.post('api/toplu_durum_guncelle.php', { 
                personel_ids: selectedIds, 
                yeni_durum: newStatus 
            }, function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: response.message || 'Personel durumları başarıyla güncellendi.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Sayfayı yenile
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'Durum güncelleme sırasında bir hata oluştu.'
                    });
                }
            }, 'json');
        }
    });
}

// Toplu silme
function deleteBulkPersonnel() {
    var selectedIds = [];
    $('.select-person:checked').each(function() {
        selectedIds.push($(this).val());
    });
    
    if (selectedIds.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'Uyarı!',
            text: 'Lütfen en az bir personel seçin.'
        });
        return;
    }
    
    Swal.fire({
        title: 'Emin misiniz?',
        text: 'Seçili ' + selectedIds.length + ' personel kalıcı olarak silinecek. Bu işlem geri alınamaz!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, Sil',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#dc3545'
    }).then((result) => {
        if (result.isConfirmed) {
            // AJAX ile toplu silme
            $.post('api/toplu_personel_sil.php', { 
                personel_ids: selectedIds
            }, function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: response.message || 'Seçili personeller başarıyla silindi.',
                        timer: 2000,
                        showConfirmButton: false
                    }).then(() => {
                        // Sayfayı yenile
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'Silme işlemi sırasında bir hata oluştu.'
                    });
                }
            }, 'json');
        }
    });
}

// Yardımcı fonksiyonlar
function getStatusClass(status) {
    switch(status) {
        case 'Aktif': return 'success';
        case 'İzinli': return 'warning';
        case 'İşten Ayrıldı':
        case 'İşten Çıkarıldı': return 'danger';
        default: return 'secondary';
    }
}

function formatDate(dateString) {
    if (!dateString) return '-';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('tr-TR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

// Dışa aktar
function exportPersonnel() {
    // Mevcut filtreleri al
    var params = [];
    
    if ('<?= $filter_department ?>') {
        params.push('departman=' + <?= $filter_department ?>);
    }
    
    if ('<?= $filter_status ?>') {
        params.push('durum=<?= urlencode($filter_status) ?>');
    }
    
    if ('<?= $search ?>') {
        params.push('ara=<?= urlencode($search) ?>');
    }
    
    // Yeni sekmede PDF oluştur
    window.open('raporlar/personel_listesi_pdf.php' + (params.length ? '?' + params.join('&') : ''), '_blank');
}

// Yazdır
function printPersonnel() {
    // Mevcut filtreleri al
    var params = [];
    
    if ('<?= $filter_department ?>') {
        params.push('departman=' + <?= $filter_department ?>);
    }
    
    if ('<?= $filter_status ?>') {
        params.push('durum=<?= urlencode($filter_status) ?>');
    }
    
    if ('<?= $search ?>') {
        params.push('ara=<?= urlencode($search) ?>');
    }
    
    // Yeni sekmede yazdırma sayfasını aç
    var printWindow = window.open('personel_yazdir.php' + (params.length ? '?' + params.join('&') : ''), '_blank');
    
    // Yazdırma işlemi tamamlandığında pencereyi kapat
    printWindow.onload = function() {
        printWindow.print();
    };
}
</script>
