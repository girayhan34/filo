<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Araç Bakım';
$page_subtitle = 'Araç bakım kayıtlarını yönetin';
include 'includes/header.php';

// Araçları çek (form için)
$vehicles = $pdo->query("SELECT id, plate, brand, model FROM vehicles WHERE status = 'active' ORDER BY plate ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <!-- Başlıklar header.php'den geliyor -->
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#maintenanceModal" onclick="prepareAddMaintenance()">
        <i class="fas fa-plus me-2"></i>Yeni Bakım Kaydı Ekle
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-tools me-2"></i>Bakım Geçmişi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="maintenanceTable">
                <thead class="table-light">
                    <tr>
                        <th>Araç</th>
                        <th>Bakım Tarihi</th>
                        <th>Bakım Türü</th>
                        <th>Maliyet</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Bakım Ekleme Modal -->
<div class="modal fade" id="maintenanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="maintenanceModalLabel">Bakım Kaydı</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="maintenanceForm">
                <input type="hidden" id="maintenanceId" name="id">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Araç</label>
                            <select class="form-select" id="vehicleId" name="vehicle_id" required>
                                <option value="">Seçiniz...</option>
                                <?php foreach ($vehicles as $vehicle): ?>
                                    <option value="<?= $vehicle['id'] ?>"><?= htmlspecialchars($vehicle['plate'] . ' - ' . $vehicle['brand']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Bakım Tarihi</label>
                            <input type="date" class="form-control" id="maintenanceDate" name="maintenance_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Bakım Türü</label>
                            <input type="text" class="form-control" id="maintenanceType" name="maintenance_type" placeholder="Örn: Periyodik Bakım, Yağ Değişimi" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Maliyet (₺)</label>
                            <input type="number" class="form-control" id="cost" name="cost" step="0.01" placeholder="0.00">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Durum</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="completed">Tamamlandı</option>
                                <option value="scheduled">Planlandı</option>
                                <option value="overdue">Gecikmiş</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Sonraki Bakım Tarihi</label>
                            <input type="date" class="form-control" id="nextMaintenanceDate" name="next_maintenance_date">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Açıklama</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
let maintenanceTable;

$(document).ready(function() {
    maintenanceTable = $('#maintenanceTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/maintenance_api.php?action=list',
            type: 'POST'
        },
        columns: [
            { data: 'plate', render: function(data, type, row) {
                return `<strong>${data}</strong><br><small class="text-muted">${row.brand} ${row.model}</small>`;
            }},
            { data: 'maintenance_date', render: function(data) { return moment(data).format('DD.MM.YYYY'); }},
            { data: 'maintenance_type' },
            { data: 'cost', render: function(data) { return data ? parseFloat(data).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' }) : '-'; }},
            { data: 'status', render: function(data) {
                const statuses = {
                    'completed': { text: 'Tamamlandı', class: 'success' },
                    'scheduled': { text: 'Planlandı', class: 'info' },
                    'overdue': { text: 'Gecikmiş', class: 'danger' }
                };
                const statusInfo = statuses[data] || { text: data, class: 'secondary' };
                return `<span class="badge bg-${statusInfo.class}">${statusInfo.text}</span>`;
            }},
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="btn-group btn-group-sm">
                                <button class="btn btn-warning" onclick="editMaintenance(${row.id})"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" onclick="deleteMaintenance(${row.id})"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[1, 'desc']], // Tarihe göre tersten sırala
        language: getDataTablesLanguage()
    });

    $('#maintenanceForm').on('submit', function(e) {
        e.preventDefault();
        const id = $('#maintenanceId').val();
        const url = id ? `../api/maintenance_api.php?action=update` : `../api/maintenance_api.php?action=create`;
        
        sendAjaxRequest({
            url: url,
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#maintenanceModal').modal('hide');
            maintenanceTable.ajax.reload(null, false);
        });
    });
});

function prepareAddMaintenance() {
    $('#maintenanceForm')[0].reset();
    $('#maintenanceId').val('');
    $('#maintenanceModalLabel').text('Yeni Bakım Kaydı Ekle');
}

function editMaintenance(id) {
    $.get(`../api/maintenance_api.php?action=get_maintenance&id=${id}`, function(response) {
        if (response.status === 'success') {
            const data = response.data;
            Object.keys(data).forEach(key => {
                $(`#maintenanceForm [name="${key}"]`).val(data[key]);
            });
            $('#maintenanceId').val(data.id);
            $('#maintenanceModalLabel').text('Bakım Kaydını Düzenle');
            $('#maintenanceModal').modal('show');
        }
    });
}

function deleteMaintenance(id) {
    handleDelete('../api/maintenance_api.php?action=delete', id, maintenanceTable);
}
</script>