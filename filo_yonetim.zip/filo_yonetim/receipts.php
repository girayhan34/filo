<?php
session_start();
require_once 'includes/auth.php'; // auth.php'den önce session_start() olmalı
require_once 'includes/config.php';
require_once 'includes/functions.php';

$page_title = 'Fiş Yönetimi';
$page_subtitle = 'Araçların iş fişlerini yönetin.';
include 'includes/header.php';

// Form için araçları ve bir sonraki fiş numarasını çek
$vehicles = $pdo->query("SELECT id, plate as plate_number, brand, model FROM vehicles WHERE status = 'active' ORDER BY plate ASC")->fetchAll(PDO::FETCH_ASSOC);
$lastReceiptNo = $pdo->query("SELECT receipt_no FROM receipts ORDER BY id DESC LIMIT 1")->fetchColumn();
$nextReceiptNo = 'FIS-' . str_pad((int)substr($lastReceiptNo, 4) + 1, 6, '0', STR_PAD_LEFT);
?>

<div class="card shadow-sm mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-plus-circle me-2"></i>Yeni Fiş Oluştur</h5>
    </div>
    <div class="card-body">
        <form id="addReceiptForm">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="receipt_no" class="form-label">Fiş No</label>
                    <input type="text" class="form-control" id="receipt_no" name="receipt_no" value="<?= $nextReceiptNo ?>" required>
                </div>
                <div class="col-md-3">
                    <label for="receipt_date" class="form-label">Fiş Tarihi</label>
                    <input type="date" class="form-control" id="receipt_date" name="receipt_date" value="<?= date('Y-m-d') ?>" required>
                </div>
                <div class="col-md-6">
                    <label for="vehicle_id" class="form-label">Araç</label>
                    <select class="form-select" id="vehicle_id" name="vehicle_id" required>
                        <option value="">Seçiniz...</option>
                        <?php foreach ($vehicles as $vehicle): ?>
                            <option value="<?= $vehicle['id'] ?>"><?= htmlspecialchars($vehicle['plate_number'] . ' - ' . $vehicle['brand']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-12">
                    <label for="customer_name" class="form-label">Müşteri Adı</label>
                    <input type="text" class="form-control" id="customer_name" name="customer_name" required>
                </div>
                <div class="col-md-12">
                    <label for="description" class="form-label">Açıklama</label>
                    <textarea class="form-control" id="description" name="description" rows="2"></textarea>
                </div>
                <div class="col-md-4">
                    <label for="working_hours" class="form-label">Çalışma Saati</label>
                    <input type="number" class="form-control" id="working_hours" name="working_hours" step="0.01" required>
                </div>
                <div class="col-md-4">
                    <label for="unit_price" class="form-label">Birim Ücret (Saatlik)</label>
                    <input type="number" class="form-control" id="unit_price" name="unit_price" step="0.01" required>
                </div>
                <div class="col-md-4">
                    <label for="total_amount" class="form-label">Toplam Tutar</label>
                    <input type="text" class="form-control" id="total_amount" name="total_amount" readonly>
                </div>
                <div class="col-12 text-end">
                    <button type="submit" class="btn btn-primary">Fişi Kaydet</button>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-list me-2"></i>Oluşturulan Fişler</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="receiptsTable">
                <thead class="table-light">
                    <tr>
                        <th>Fiş No</th>
                        <th>Araç</th>
                        <th>Müşteri</th>
                        <th>Tarih</th>
                        <th>Tutar</th>
                        <th>Oluşturan</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
$(document).ready(function() {
    // Toplam tutarı otomatik hesapla
    $('#working_hours, #unit_price').on('input', function() {
        const hours = parseFloat($('#working_hours').val()) || 0;
        const price = parseFloat($('#unit_price').val()) || 0;
        const total = hours * price;
        $('#total_amount').val(total.toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' }));
    });

    // DataTables başlatma
    var table = $('#receiptsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/receipts_api.php?action=list',
            type: 'POST'
        },
        columns: [
            { data: 'receipt_no' },
            { data: 'plate_number', render: function(data, type, row) { return `${data} (${row.brand})`; } },
            { data: 'customer_name' },
            { data: 'receipt_date', render: function(data) { return moment(data).format('DD.MM.YYYY'); } },
            { data: 'total_amount', render: function(data) { return parseFloat(data).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' }); } },
            { data: 'created_by_name' },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="btn-group btn-group-sm">
                                <button class="btn btn-warning" onclick="editReceipt(${row.id})" title="Düzenle"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" onclick="deleteReceipt(${row.id})" title="Sil"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[3, 'desc']],
        language: getDataTablesLanguage()
    });

    // Fiş ekleme formu
    $('#addReceiptForm').on('submit', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/receipts_api.php?action=create',
            type: 'POST',
            data: $(this).serialize()
        }, submitButton).then(() => {
            table.ajax.reload();
            this.reset();
            $('#total_amount').val('');
            // Bir sonraki fiş numarasını güncellemek için sayfa yenilenebilir veya yeni bir API çağrısı yapılabilir.
            location.reload(); 
        });
    });
});

function deleteReceipt(id) {
    handleDelete('../api/receipts_api.php?action=delete', id, $('#receiptsTable').DataTable());
}

function editReceipt(id) {
    $.ajax({
        url: `../api/receipts_api.php?action=get_receipt&id=${id}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                const receipt = response.data;
                $('#edit_receipt_id').val(receipt.id);
                $('#edit_receipt_no').val(receipt.receipt_no);
                $('#edit_receipt_date').val(receipt.receipt_date);
                $('#edit_vehicle_id').val(receipt.vehicle_id);
                $('#edit_customer_name').val(receipt.customer_name);
                $('#edit_description').val(receipt.description);
                $('#edit_working_hours').val(receipt.working_hours);
                $('#edit_unit_price').val(receipt.unit_price);
                $('#edit_total_amount').val(parseFloat(receipt.total_amount).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' }));
                
                $('#editReceiptModal').modal('show');
            } else {
                showToast('error', response.message);
            }
        }
    });
}
</script>
                    </div>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>