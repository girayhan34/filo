<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Sadece yöneticiler bu işlemi yapabilir
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    die('Bu işlem için yetkiniz yok!');
}

try {
    // 1. Vardiya Tablosu
    $pdo->exec("CREATE TABLE IF NOT EXISTS personel_vardiyalari (
        id INT AUTO_INCREMENT PRIMARY KEY,
        personel_id INT NOT NULL,
        vardiya_tipi ENUM('Sabah', 'Öğle', 'Akşam', 'Gece') NOT NULL,
        baslangic_tarihi DATETIME NOT NULL,
        bitis_tarihi DATETIME NOT NULL,
        aciklama TEXT,
        durum ENUM('Planlandı', 'Devam Ediyor', 'Tamamlandı', 'İptal Edildi') DEFAULT 'Planlandı',
        arac_id INT,
        proje_id INT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (personel_id) REFERENCES personel(id) ON DELETE CASCADE,
        FOREIGN KEY (arac_id) REFERENCES vehicles(id) ON DELETE SET NULL,
        FOREIGN KEY (proje_id) REFERENCES projects(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 2. İzinler Tablosu
    $pdo->exec("CREATE TABLE IF NOT EXISTS personel_izinleri (
        id INT AUTO_INCREMENT PRIMARY KEY,
        personel_id INT NOT NULL,
        izin_tipi ENUM('Yıllık İzin', 'Hastalık İzni', 'Doğum İzni', 'Babalık İzni', 'Ücretsiz İzin', 'Diğer') NOT NULL,
        baslangic_tarihi DATE NOT NULL,
        bitis_tarihi DATE NOT NULL,
        toplam_gun INT NOT NULL,
        aciklama TEXT,
        durum ENUM('Beklemede', 'Onaylandı', 'Reddedildi', 'İptal Edildi') DEFAULT 'Beklemede',
        onaylayan_id INT,
        onay_tarihi DATETIME,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (personel_id) REFERENCES personel(id) ON DELETE CASCADE,
        FOREIGN KEY (onaylayan_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 3. Performans Değerlendirmeleri Tablosu
    $pdo->exec("CREATE TABLE IF NOT EXISTS personel_performanslari (
        id INT AUTO_INCREMENT PRIMARY KEY,
        personel_id INT NOT NULL,
        degerlendiren_id INT NOT NULL,
        degerlendirme_tarihi DATE NOT NULL,
        donem_baslangic DATE NOT NULL,
        donem_bitis DATE NOT NULL,
        puan_toplam DECIMAL(5,2) NOT NULL,
        puan_verimlilik DECIMAL(3,1) NOT NULL,
        puan_iletisim DECIMAL(3,1) NOT NULL,
        puan_uzmanlik DECIMAL(3,1) NOT NULL,
        puan_guvenlik DECIMAL(3,1) NOT NULL,
        puan_takim_calismasi DECIMAL(3,1) NOT NULL,
        guclu_yonler TEXT,
        gelistirilecek_alanlar TEXT,
        hedefler TEXT,
        yonetici_yorumu TEXT,
        durum ENUM('Taslak', 'Onaylandı', 'Reddedildi') DEFAULT 'Taslak',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (personel_id) REFERENCES personel(id) ON DELETE CASCADE,
        FOREIGN KEY (degerlendiren_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 4. Dokümanlar Tablosu
    $pdo->exec("CREATE TABLE IF NOT EXISTS personel_dokumanlari (
        id INT AUTO_INCREMENT PRIMARY KEY,
        personel_id INT NOT NULL,
        dokuman_tipi ENUM('Kimlik Fotokopisi', 'Diploma', 'Sürücü Belgesi', 'Sağlık Raporu', 'Sözleşme', 'Diğer') NOT NULL,
        baslik VARCHAR(255) NOT NULL,
        dosya_yolu VARCHAR(512) NOT NULL,
        dosya_tipi VARCHAR(100) NOT NULL,
        dosya_boyutu INT NOT NULL,
        gecerlilik_baslangic DATE,
        gecerlilik_bitis DATE,
        aciklama TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (personel_id) REFERENCES personel(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 5. Maaş Bordroları Tablosu
    $pdo->exec("CREATE TABLE IF NOT EXISTS personel_maaslari (
        id INT AUTO_INCREMENT PRIMARY KEY,
        personel_id INT NOT NULL,
        donem_ay TINYINT NOT NULL,
        donem_yil SMALLINT NOT NULL,
        brut_ucret DECIMAL(10,2) NOT NULL,
        sgk_kesintisi DECIMAL(10,2) NOT NULL,
        issizlik_kesintisi DECIMAL(10,2) NOT NULL,
        gelir_vergisi DECIMAL(10,2) NOT NULL,
        damga_vergisi DECIMAL(10,2) NOT NULL,
        kesintiler_toplami DECIMAL(10,2) NOT NULL,
        net_ucret DECIMAL(10,2) NOT NULL,
        avans DECIMAL(10,2) DEFAULT 0.00,
        kalan_ucret DECIMAL(10,2) NOT NULL,
        odeme_durumu ENUM('Beklemede', 'Ödendi', 'Gecikmiş') DEFAULT 'Beklemede',
        odeme_tarihi DATE,
        aciklama TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        created_by INT,
        FOREIGN KEY (personel_id) REFERENCES personel(id) ON DELETE CASCADE,
        UNIQUE KEY unique_maas (personel_id, donem_ay, donem_yil)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 6. Roller ve İzinler Tabloları
    $pdo->exec("CREATE TABLE IF NOT EXISTS roller (
        id INT AUTO_INCREMENT PRIMARY KEY,
        rol_adi VARCHAR(50) NOT NULL UNIQUE,
        aciklama TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS izinler (
        id INT AUTO_INCREMENT PRIMARY KEY,
        izin_adi VARCHAR(100) NOT NULL UNIQUE,
        aciklama TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS rol_izinleri (
        rol_id INT NOT NULL,
        izin_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (rol_id, izin_id),
        FOREIGN KEY (rol_id) REFERENCES roller(id) ON DELETE CASCADE,
        FOREIGN KEY (izin_id) REFERENCES izinler(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    $pdo->exec("CREATE TABLE IF NOT EXISTS kullanici_rolleri (
        user_id INT NOT NULL,
        rol_id INT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, rol_id),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (rol_id) REFERENCES roller(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // 7. Sistem Logları Tablosu
    $pdo->exec("CREATE TABLE IF NOT EXISTS sistem_loglari (
        id BIGINT AUTO_INCREMENT PRIMARY KEY,
        kullanici_id INT,
        islem_tipi VARCHAR(50) NOT NULL,
        tablo_adi VARCHAR(50),
        kayit_id INT,
        eski_deger TEXT,
        yeni_deger TEXT,
        ip_adresi VARCHAR(45),
        user_agent TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (kullanici_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Varsayılan verileri ekle
    // Roller
    $pdo->exec("INSERT IGNORE INTO roller (id, rol_adi, aciklama) VALUES 
        (1, 'Sistem Yöneticisi', 'Sistemin tüm özelliklerine tam erişim'),
        (2, 'İK Yöneticisi', 'İnsan kaynakları yönetimi ve personel işlemleri'),
        (3, 'Muhasebe', 'Maaş ve ödemeler yönetimi'),
        (4, 'Operasyon Yöneticisi', 'Vardiya ve operasyon yönetimi'),
        (5, 'Personel', 'Temel kullanıcı izinleri')");

    // Temel İzinler
    $pdo->exec("INSERT IGNORE INTO izinler (izin_adi, aciklama) VALUES 
        ('personel_goruntule', 'Personel bilgilerini görüntüleme'),
        ('personel_ekle', 'Yeni personel ekleme'),
        ('personel_duzenle', 'Personel bilgilerini düzenleme'),
        ('personel_sil', 'Personel silme'),
        ('vardiya_goruntule', 'Vardiyaları görüntüleme'),
        ('vardiya_olustur', 'Vardiya oluşturma'),
        ('vardiya_duzenle', 'Vardiya düzenleme'),
        ('vardiya_sil', 'Vardiya silme'),
        ('izin_goruntule', 'İzinleri görüntüleme'),
        ('izin_olustur', 'İzin oluşturma'),
        ('izin_onayla', 'İzin onaylama/reddetme'),
        ('performans_goruntule', 'Performans değerlendirmelerini görüntüleme'),
        ('performans_olustur', 'Performans değerlendirmesi oluşturma'),
        ('dokuman_goruntule', 'Dokümanları görüntüleme'),
        ('dokuman_yukle', 'Doküman yükleme'),
        ('dokuman_sil', 'Doküman silme'),
        ('maas_goruntule', 'Maaş bilgilerini görüntüleme'),
        ('maas_olustur', 'Maaş bordrosu oluşturma'),
        ('maas_duzenle', 'Maaş bilgilerini düzenleme'),
        ('rapor_goruntule', 'Raporları görüntüleme'),
        ('rapor_olustur', 'Rapor oluşturma'),
        ('ayarlar_duzenle', 'Sistem ayarlarını düzenleme')");

    // Varsayılan roller için izinler
    $pdo->exec("INSERT IGNORE INTO rol_izinleri (rol_id, izin_id) 
        SELECT 1, id FROM izinler"); // Sistem Yöneticisi

    $pdo->exec("INSERT IGNORE INTO rol_izinleri (rol_id, izin_id) 
        SELECT 2, id FROM izinlerss WHERE izin_adi NOT IN ('ayarlar_duzenle')"); // İK Yöneticisi

    $pdo->exec("INSERT IGNORE INTO rol_izinleri (rol_id, izin_id) 
        SELECT 3, id FROM izinler WHERE izin_adi IN ('personel_goruntule', 'maas_goruntule', 'maas_olustur', 'maas_duzenle', 'rapor_goruntule')"); // Muhasebe

    $pdo->exec("INSERT IGNORE INTO rol_izinleri (rol_id, izin_id) 
        SELECT 4, id FROM izinler WHERE izin_adi IN ('personel_goruntule', 'vardiya_goruntule', 'vardiya_olustur', 'vardiya_duzenle', 'vardiya_sil', 'izin_goruntule', 'izin_onayla')"); // Operasyon Yöneticisi

    $pdo->exec("INSERT IGNORE INTO rol_izinleri (rol_id, izin_id) 
        SELECT 5, id FROM izinler WHERE izin_adi IN ('personel_goruntule', 'izin_goruntule', 'izin_olustur', 'dokuman_goruntule')"); // Personel

    // Varsayılan kullanıcıya Sistem Yöneticisi rolünü ata
    $pdo->exec("INSERT IGNORE INTO kullanici_rolleri (user_id, rol_id) VALUES (1, 1)");

    echo "<h3>Personel modülleri başarıyla kuruldu!</h3>";
    echo "<p>Oluşturulan tablolar:</p>";
    echo "<ul>";
    echo "<li>personel_vardiyalari</li>";
    echo "<li>personel_izinleri</li>";
    echo "<li>personel_performanslari</li>";
    echo "<li>personel_dokumanlari</li>";
    echo "<li>personel_maaslari</li>";
    echo "<li>roller, izinler, rol_izinleri, kullanici_rolleri</li>";
    echo "<li>sistem_loglari</li>";
    echo "</ul>";
    echo "<p><a href='personel3.php'>Personel Yönetimine Git</a></p>";

} catch (PDOException $e) {
    die("<div style='color:red;'>Hata oluştu: " . $e->getMessage() . "</div>");
}
?>
