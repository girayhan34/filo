<?php
require_once 'includes/config.php';

try {
    // Check if personnel table exists
    $stmt = $pdo->query("SHOW TABLES LIKE 'personnel'");
    $tableExists = $stmt->rowCount() > 0;
    
    if (!$tableExists) {
        die("Personel tablosu bulunamadı!");
    }
    
    // Get table structure
    $stmt = $pdo->query("DESCRIBE personnel");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<h2>Personel Tablosu Yapısı</h2>";
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th><th>Extra</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($column['Extra'] ?? '') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    // Check required columns
    $requiredColumns = ['id', 'name', 'surname', 'position', 'department', 'hire_date', 'status'];
    $missingColumns = [];
    $existingColumns = array_column($columns, 'Field');
    
    foreach ($requiredColumns as $column) {
        if (!in_array($column, $existingColumns)) {
            $missingColumns[] = $column;
        }
    }
    
    if (!empty($missingColumns)) {
        echo "<h3>Eksik Sütunlar:</h3>";
        echo "<ul>";
        foreach ($missingColumns as $column) {
            echo "<li>$column</li>";
        }
        echo "</ul>";
        
        echo "<h3>Eksik sütunları eklemek için aşağıdaki SQL'i çalıştırın:</h3>";
        echo "<pre>\n";
        foreach ($missingColumns as $column) {
            $sql = "ALTER TABLE personnel ADD COLUMN ";
            switch ($column) {
                case 'id':
                    $sql .= "id INT AUTO_INCREMENT PRIMARY KEY";
                    break;
                case 'name':
                    $sql .= "name VARCHAR(100) NOT NULL";
                    break;
                case 'surname':
                    $sql .= "surname VARCHAR(100) NOT NULL";
                    break;
                case 'position':
                    $sql .= "position VARCHAR(100) DEFAULT NULL";
                    break;
                case 'department':
                    $sql .= "department VARCHAR(100) DEFAULT NULL";
                    break;
                case 'hire_date':
                    $sql .= "hire_date DATE DEFAULT NULL";
                    break;
                case 'status':
                    $sql .= "status ENUM('active', 'on_leave', 'inactive', 'deleted') DEFAULT 'active'";
                    break;
            }
            $sql .= ";\n";
            echo htmlspecialchars($sql);
        }
        echo "</pre>";
    } else {
        echo "<p style='color: green;'>Tüm gerekli sütunlar mevcut.</p>";
    }
    
} catch (PDOException $e) {
    echo "Hata oluştu: " . $e->getMessage();
}
?>
