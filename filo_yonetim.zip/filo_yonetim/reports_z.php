<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Tarih aralığı parametreleri
$start_date = $_GET['start_date'] ?? date('Y-m-01');
$end_date = $_GET['end_date'] ?? date('Y-m-t');
$report_type = $_GET['report_type'] ?? 'financial';

// Finansal rapor verileri
$financial_stmt = $pdo->prepare("SELECT 
    SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
    SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expense
FROM income_expense 
WHERE date BETWEEN ? AND ?");
$financial_stmt->execute([$start_date, $end_date]);
$financial_data = $financial_stmt->fetch(PDO::FETCH_ASSOC);

// Fatura raporu
$invoice_stmt = $pdo->prepare("SELECT 
    COUNT(*) as total_invoices,
    SUM(total_amount) as total_amount,
    SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END) as paid_amount,
    SUM(CASE WHEN status = 'pending' THEN total_amount ELSE 0 END) as pending_amount,
    SUM(CASE WHEN status = 'overdue' THEN total_amount ELSE 0 END) as overdue_amount
FROM invoices 
WHERE invoice_date BETWEEN ? AND ?");
$invoice_stmt->execute([$start_date, $end_date]);
$invoice_data = $invoice_stmt->fetch(PDO::FETCH_ASSOC);

// Araç performans raporu
$vehicle_stmt = $pdo->prepare("SELECT 
    v.id, v.plate as plate_number, v.brand, v.model, v.type,
    COUNT(DISTINCT ps.id) as shift_count,
    SUM(vf.liters) as total_fuel,
    SUM(vf.cost) as fuel_cost,
    COUNT(DISTINCT vm.id) as maintenance_count,
    SUM(vm.cost) as maintenance_cost
FROM vehicles v
LEFT JOIN personnel_shifts ps ON v.id = ps.vehicle_id AND ps.shift_date BETWEEN ? AND ?
LEFT JOIN vehicle_fuel vf ON v.id = vf.vehicle_id AND vf.fuel_date BETWEEN ? AND ?
LEFT JOIN vehicle_maintenance vm ON v.id = vm.vehicle_id AND vm.maintenance_date BETWEEN ? AND ?
WHERE v.status != 'deleted'
GROUP BY v.id
ORDER BY shift_count DESC");
$vehicle_stmt->execute([$start_date, $end_date, $start_date, $end_date, $start_date, $end_date]);
$vehicle_performance = $vehicle_stmt->fetchAll(PDO::FETCH_ASSOC);

// Personel performans raporu
$personnel_stmt = $pdo->prepare("SELECT 
    p.id, p.name, p.position,
    COUNT(DISTINCT ps.id) as shift_count,
    SUM(TIMESTAMPDIFF(HOUR, ps.start_time, ps.end_time)) as total_hours,
    AVG(pp.performance_score) as avg_performance,
    COUNT(DISTINCT pp.id) as evaluation_count
FROM personnel p
LEFT JOIN personnel_shifts ps ON p.id = ps.personnel_id AND ps.shift_date BETWEEN ? AND ?
LEFT JOIN personnel_performance pp ON p.id = pp.personnel_id AND pp.evaluation_date BETWEEN ? AND ?
WHERE p.status != 'deleted'
GROUP BY p.id
ORDER BY total_hours DESC");
$personnel_stmt->execute([$start_date, $end_date, $start_date, $end_date]);
$personnel_performance = $personnel_stmt->fetchAll(PDO::FETCH_ASSOC);

// Aylık trend verileri (son 12 ay)
$trend_stmt = $pdo->prepare("SELECT 
    DATE_FORMAT(date, '%Y-%m') as month,
    SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as monthly_income,
    SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as monthly_expense
FROM income_expense 
WHERE date >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY DATE_FORMAT(date, '%Y-%m')
ORDER BY month ASC");
$trend_stmt->execute();
$trend_data = $trend_stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Gelişmiş Raporlama';
$page_subtitle = 'İşletmenizin performansını detaylı olarak inceleyin.';
include 'includes/header.php';
?>

<!-- Filtre Seçenekleri -->
<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Rapor Filtreleri</h5>
    </div>
    <div class="card-body">
        <form method="GET" action="reports_z.php" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label for="start_date" class="form-label">Başlangıç Tarihi</label>
                <input type="date" class="form-control" id="start_date" name="start_date" value="<?= htmlspecialchars($start_date) ?>">
            </div>
            <div class="col-md-3">
                <label for="end_date" class="form-label">Bitiş Tarihi</label>
                <input type="date" class="form-control" id="end_date" name="end_date" value="<?= htmlspecialchars($end_date) ?>">
            </div>
            <div class="col-md-3">
                <label for="report_type" class="form-label">Rapor Türü</label>
                <select class="form-select" id="report_type" name="report_type">
                    <option value="financial" <?= $report_type == 'financial' ? 'selected' : '' ?>>Finansal</option>
                    <option value="operational" <?= $report_type == 'operational' ? 'selected' : '' ?>>Operasyonel</option>
                    <option value="performance" <?= $report_type == 'performance' ? 'selected' : '' ?>>Performans</option>
                </select>
            </div>
            <div class="col-md-3">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-search me-1"></i> Filtrele
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Özet Kartları -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card border-start-success h-100">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Toplam Gelir</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">₺<?= number_format($financial_data['total_income'] ?? 0, 2, ',', '.') ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-arrow-up fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card border-start-danger h-100">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Toplam Gider</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">₺<?= number_format($financial_data['total_expense'] ?? 0, 2, ',', '.') ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-arrow-down fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card border-start-info h-100">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Net Kar</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">₺<?= number_format(($financial_data['total_income'] ?? 0) - ($financial_data['total_expense'] ?? 0), 2, ',', '.') ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-chart-line fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card border-start-warning h-100">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Fatura Cirosu</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800">₺<?= number_format($invoice_data['total_amount'] ?? 0, 2, ',', '.') ?></div>
                    </div>
                    <div class="col-auto"><i class="fas fa-file-invoice-dollar fa-2x text-gray-300"></i></div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Grafik Alanları -->
<div class="row mb-4">
    <div class="col-xl-8 col-lg-7">
        <div class="card">
            <div class="card-header"><h5 class="mb-0"><i class="fas fa-chart-area me-2"></i>Aylık Gelir-Gider Trendi</h5></div>
            <div class="card-body"><canvas id="trendChart" height="150"></canvas></div>
        </div>
    </div>
    <div class="col-xl-4 col-lg-5">
        <div class="card">
            <div class="card-header"><h5 class="mb-0"><i class="fas fa-chart-pie me-2"></i>Fatura Durumu</h5></div>
            <div class="card-body d-flex justify-content-center align-items-center"><canvas id="invoiceChart" height="300"></canvas></div>
        </div>
    </div>
</div>

<!-- Araç Performans Raporu -->
<div class="card mb-4">
    <div class="card-header"><h5 class="mb-0"><i class="fas fa-truck me-2"></i>Araç Performans Raporu</h5></div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Plaka</th><th>Araç</th><th>Tip</th><th>Vardiya</th><th>Yakıt (L)</th><th>Yakıt Maliyeti</th><th>Bakım</th><th>Bakım Maliyeti</th><th>Toplam Maliyet</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($vehicle_performance as $vehicle): ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($vehicle['plate_number']) ?></strong></td>
                            <td><?= htmlspecialchars($vehicle['brand'] . ' ' . $vehicle['model']) ?></td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($vehicle['type']) ?></span></td>
                            <td><?= $vehicle['shift_count'] ?></td>
                            <td><?= number_format($vehicle['total_fuel'] ?? 0, 2) ?></td>
                            <td><?= number_format($vehicle['fuel_cost'] ?? 0, 2) ?>₺</td>
                            <td><?= $vehicle['maintenance_count'] ?></td>
                            <td><?= number_format($vehicle['maintenance_cost'] ?? 0, 2) ?>₺</td>
                            <td><strong><?= number_format(($vehicle['fuel_cost'] ?? 0) + ($vehicle['maintenance_cost'] ?? 0), 2) ?>₺</strong></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (empty($vehicle_performance)): ?>
                        <tr><td colspan="9" class="text-center text-muted py-4">Bu tarih aralığında araç performansı verisi bulunamadı.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Trend Chart
    const trendCtx = document.getElementById('trendChart').getContext('2d');
    new Chart(trendCtx, {
        type: 'line',
        data: {
            labels: [<?php echo "'" . implode("','", array_column($trend_data, 'month')) . "'"; ?>],
            datasets: [{
                label: 'Gelir',
                data: [<?php echo implode(',', array_column($trend_data, 'monthly_income')); ?>],
                borderColor: 'rgb(28, 200, 138)',
                backgroundColor: 'rgba(28, 200, 138, 0.1)',
                tension: 0.3,
                fill: true
            }, {
                label: 'Gider',
                data: [<?php echo implode(',', array_column($trend_data, 'monthly_expense')); ?>],
                borderColor: 'rgb(231, 74, 59)',
                backgroundColor: 'rgba(231, 74, 59, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { position: 'top' } },
            scales: { y: { beginAtZero: true, ticks: { callback: value => '₺' + value.toLocaleString() } } }
        }
    });

    // Invoice Status Chart
    const invoiceCtx = document.getElementById('invoiceChart').getContext('2d');
    new Chart(invoiceCtx, {
        type: 'doughnut',
        data: {
            labels: ['Ödendi', 'Beklemede', 'Gecikmiş'],
            datasets: [{
                data: [
                    <?= $invoice_data['paid_amount'] ?? 0 ?>,
                    <?= $invoice_data['pending_amount'] ?? 0 ?>,
                    <?= $invoice_data['overdue_amount'] ?? 0 ?>
                ],
                backgroundColor: ['#1cc88a', '#f6c23e', '#e74a3b']
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { position: 'bottom' },
                tooltip: { callbacks: { label: context => context.label + ': ₺' + context.parsed.toLocaleString() } }
            }
        }
    });
});
</script>