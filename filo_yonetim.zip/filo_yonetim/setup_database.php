<?php
// Veritabanı kurulum scripti
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$username = 'root';
$password = '';

try {
    // İlk önce MySQL'e bağlan
    $pdo = new PDO("mysql:host=$host", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "MySQL bağlantısı başarılı!<br>";
    
    // SQL dosyasını oku
    $sql = file_get_contents('database/filo_yonetim.sql');
    
    if ($sql === false) {
        throw new Exception("SQL dosyası okunamadı!");
    }
    
    // SQL komutlarını ayır ve çalıştır
    $statements = explode(';', $sql);
    
    foreach ($statements as $statement) {
        $statement = trim($statement);
        if (!empty($statement)) {
            try {
                $pdo->exec($statement);
                echo "✓ SQL komutu çalıştırıldı: " . substr($statement, 0, 50) . "...<br>";
            } catch (PDOException $e) {
                echo "⚠ SQL hatası: " . $e->getMessage() . "<br>";
                echo "Komut: " . substr($statement, 0, 100) . "...<br>";
            }
        }
    }
    
    echo "<br><strong>Veritabanı kurulumu tamamlandı!</strong><br>";
    echo "<a href='invoices.php'>Faturalar sayfasına git</a>";
    
} catch (Exception $e) {
    echo "Hata: " . $e->getMessage();
}
?>
