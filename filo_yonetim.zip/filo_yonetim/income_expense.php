<?php
// Oturum kontrolü veya diğer PHP işlemleri buraya eklenebilir
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';
require_once 'includes/functions.php';

$pdo = getPDO();

// İstatistikler
$stats_stmt = $pdo->query("SELECT 
    SUM(CASE WHEN type = 'income' THEN amount ELSE 0 END) as total_income,
    SUM(CASE WHEN type = 'expense' THEN amount ELSE 0 END) as total_expense
    FROM income_expense");
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
$total_income = $stats['total_income'] ?? 0;
$total_expense = $stats['total_expense'] ?? 0;
$net_profit = $total_income - $total_expense;

// Projeleri çek
$projects = $pdo->query("SELECT id, project_name FROM projects WHERE status IN ('planning', 'active') ORDER BY project_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
$page_title = 'Gelir-Gider Yönetimi';
$page_subtitle = 'Finansal hareketlerinizi takip edin.';
include 'includes/header.php';
?>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="h4 mb-0">Gelir-Gider Yönetimi</h1>
                <div>
                    <button class="btn btn-income text-white me-2" data-bs-toggle="modal" data-bs-target="#incomeModal">
                        <i class="fas fa-plus"></i> Gelir Ekle
                    </button>
                    <button class="btn btn-expense text-white me-2" data-bs-toggle="modal" data-bs-target="#expenseModal">
                        <i class="fas fa-plus"></i> Gider Ekle
                    </button>
                    <button class="btn btn-warning text-white me-2" data-bs-toggle="modal" data-bs-target="#paymentModal">
                        <i class="fas fa-money-bill"></i> Ödeme Yap
                    </button>
                    <button class="btn btn-info text-white" data-bs-toggle="modal" data-bs-target="#collectionModal">
                        <i class="fas fa-cash-register"></i> Tahsilat Yap
                    </button>
                </div>
            </div>

            <!-- İstatistik Kartları -->
            <div class="row mb-4">
                <div class="col-md-4 mb-3">
                    <div class="card stats-card income-card">
                        <i class="fas fa-arrow-up income-icon"></i>
                        <h2><?= number_format($total_income, 0, ',', '.') ?>₺</h2>
                        <p>Toplam Gelir</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stats-card expense-card">
                        <i class="fas fa-arrow-down expense-icon"></i>
                        <h2><?= number_format($total_expense, 0, ',', '.') ?>₺</h2>
                        <p>Toplam Gider</p>
                    </div>
                </div>
                <div class="col-md-4 mb-3">
                    <div class="card stats-card profit-card">
                        <i class="fas fa-chart-line profit-icon"></i>
                        <h2 class="<?= $net_profit >= 0 ? 'text-success' : 'text-danger' ?>">
                            <?= number_format($net_profit, 0, ',', '.') ?>₺
                        </h2>
                        <p>Net Kar/Zarar</p>
                    </div>
                </div>
            </div>

            <!-- Filtreler -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-filter"></i> Filtreler</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <label class="form-label">Tarih Aralığı</label>
                            <select class="form-select" id="dateRange">
                                <option value="">Tüm Zamanlar</option>
                                <option value="week">Bu Hafta</option>
                                <option value="month" selected>Bu Ay</option>
                                <option value="year">Bu Yıl</option>
                                <option value="custom">Özel Tarih</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" id="categoryFilter">
                                <option value="">Tüm Kategoriler</option>
                                <option value="Nakliye">Nakliye</option>
                                <option value="Kargo">Kargo</option>
                                <option value="Depo">Depo</option>
                                <option value="Yakıt">Yakıt</option>
                                <option value="Bakım">Bakım</option>
                                <option value="Maaş">Maaş</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Tür</label>
                            <select class="form-select" id="typeFilter">
                                <option value="">Tümü</option>
                                <option value="income">Gelir</option>
                                <option value="expense">Gider</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gelir & Gider Tablosu -->
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-exchange-alt me-2"></i>Finansal Hareketler</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="recordsTable">
                            <thead>
                                <tr>
                                    <th>Tarih</th>
                                    <th>Açıklama</th>
                                    <th>Kategori</th>
                                    <th>Tutar</th>
                                    <th>Tür</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- DataTables tarafından doldurulacak -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

    <!-- Kayıt Düzenleme Modal -->
    <div class="modal fade" id="editRecordModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-edit"></i> Kaydı Düzenle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="editRecordForm">
                    <input type="hidden" name="id" id="editRecordId">
                    <input type="hidden" name="type" id="editRecordType">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Tarih</label>
                            <input type="date" class="form-control" name="date" id="editDate" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <input type="text" class="form-control" name="description" id="editDescription" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <input type="text" class="form-control" name="category" id="editCategory" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tutar (₺)</label>
                            <input type="number" class="form-control" name="amount" id="editAmount" step="0.01" min="0" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Güncelle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Gelir Ekleme Modal -->
    <div class="modal fade" id="incomeModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-success text-white">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> Gelir Ekle</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="incomeForm">
                    <div class="modal-body">
                        <input type="hidden" name="type" value="income">
                        <div class="mb-3">
                            <label class="form-label">Tarih</label>
                            <input type="date" class="form-control" name="date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <input type="text" class="form-control" name="description" placeholder="Gelir açıklaması" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" name="category" required>
                                <option value="">Kategori Seçin</option>
                                <option value="Nakliye">Nakliye</option>
                                <option value="Kargo">Kargo</option>
                                <option value="Depo">Depo</option>
                                <option value="Danışmanlık">Danışmanlık</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tutar (₺)</label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0" placeholder="0.00" required>
                        </div>
                        <div class="mb-3">
                            <label for="income_project_id" class="form-label">İlişkili Proje (Opsiyonel)</label>
                            <select class="form-select" id="income_project_id" name="project_id">
                                <option value="">Proje Seçiniz...</option>
                                <?php foreach ($projects as $project): ?>
                                    <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['project_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notlar</label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="Ek notlar (opsiyonel)"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-success">Gelir Ekle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Gider Ekleme Modal -->
    <div class="modal fade" id="expenseModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="fas fa-plus"></i> Gider Ekle</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="expenseForm">
                    <div class="modal-body">
                        <input type="hidden" name="type" value="expense">
                        <div class="mb-3">
                            <label class="form-label">Tarih</label>
                            <input type="date" class="form-control" name="date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <input type="text" class="form-control" name="description" placeholder="Gider açıklaması" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Kategori</label>
                            <select class="form-select" name="category" required>
                                <option value="">Kategori Seçin</option>
                                <option value="Yakıt">Yakıt</option>
                                <option value="Bakım">Bakım</option>
                                <option value="Maaş">Maaş</option>
                                <option value="Kira">Kira</option>
                                <option value="Sigorta">Sigorta</option>
                                <option value="Vergi">Vergi</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tutar (₺)</label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0" placeholder="0.00" required>
                        </div>
                        <div class="mb-3">
                            <label for="expense_project_id" class="form-label">İlişkili Proje (Opsiyonel)</label>
                            <select class="form-select" id="expense_project_id" name="project_id">
                                <option value="">Proje Seçiniz...</option>
                                <?php foreach ($projects as $project): ?>
                                    <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['project_name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notlar</label>
                            <textarea class="form-control" name="notes" rows="3" placeholder="Ek notlar (opsiyonel)"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-danger">Gider Ekle</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Ödeme Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title"><i class="fas fa-money-bill"></i> Ödeme Yap</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="paymentForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Tarih <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ödeme Türü <span class="text-danger">*</span></label>
                            <select class="form-select" name="payment_type" required>
                                <option value="">Seçin</option>
                                <option value="supplier">Tedarikçi Ödemesi</option>
                                <option value="salary">Maaş Ödemesi</option>
                                <option value="fuel">Yakıt Ödemesi</option>
                                <option value="maintenance">Bakım Ödemesi</option>
                                <option value="insurance">Sigorta Ödemesi</option>
                                <option value="tax">Vergi Ödemesi</option>
                                <option value="rent">Kira Ödemesi</option>
                                <option value="other">Diğer</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Alıcı/Firma <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="recipient" placeholder="Ödeme yapılacak kişi/firma" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tutar (₺) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0.01" placeholder="0.00" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Ödeme Yöntemi <span class="text-danger">*</span></label>
                            <select class="form-select" name="payment_method" required>
                                <option value="">Seçin</option>
                                <option value="cash">Nakit</option>
                                <option value="bank_transfer">Havale/EFT</option>
                                <option value="credit_card">Kredi Kartı</option>
                                <option value="check">Çek</option>
                                <option value="promissory_note">Senet</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Referans No</label>
                            <input type="text" class="form-control" name="reference_no" placeholder="İşlem referans numarası">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <textarea class="form-control" name="description" rows="3" placeholder="Ödeme detayları"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-warning">Ödemeyi Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Tahsilat Modal -->
    <div class="modal fade" id="collectionModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title"><i class="fas fa-cash-register"></i> Tahsilat Yap</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form id="collectionForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Tarih <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="date" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tahsilat Türü <span class="text-danger">*</span></label>
                            <select class="form-select" name="collection_type" required>
                                <option value="">Seçin</option>
                                <option value="invoice">Fatura Tahsilatı</option>
                                <option value="service">Hizmet Bedeli</option>
                                <option value="rental">Kira Geliri</option>
                                <option value="commission">Komisyon</option>
                                <option value="deposit">Depozito</option>
                                <option value="refund">İade</option>
                                <option value="other">Diğer</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Müşteri/Firma <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="customer" placeholder="Ödeme yapan kişi/firma" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tutar (₺) <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" name="amount" step="0.01" min="0.01" placeholder="0.00" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Tahsilat Yöntemi <span class="text-danger">*</span></label>
                            <select class="form-select" name="collection_method" required>
                                <option value="">Seçin</option>
                                <option value="cash">Nakit</option>
                                <option value="bank_transfer">Havale/EFT</option>
                                <option value="credit_card">Kredi Kartı</option>
                                <option value="check">Çek</option>
                                <option value="promissory_note">Senet</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Fatura No</label>
                            <input type="text" class="form-control" name="invoice_no" placeholder="İlgili fatura numarası (varsa)">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Referans No</label>
                            <input type="text" class="form-control" name="reference_no" placeholder="İşlem referans numarası">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <textarea class="form-control" name="description" rows="3" placeholder="Tahsilat detayları"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-info">Tahsilatı Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

    <!-- JS -->
    <script>
$(document).ready(function() {
    var table = $('#recordsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/income_expense_api.php?action=list',
            type: 'POST',
            data: function(d) {
                d.type = $('#typeFilter').val();
                d.category = $('#categoryFilter').val();
                
                let dateRange = $('#dateRange').val();
                if (dateRange) {
                    let startDate, endDate;
                    switch(dateRange) {
                        case 'today':
                            startDate = moment().format('YYYY-MM-DD');
                            endDate = moment().format('YYYY-MM-DD');
                            break;
                        case 'week':
                            startDate = moment().startOf('week').format('YYYY-MM-DD');
                            endDate = moment().endOf('week').format('YYYY-MM-DD');
                            break;
                        case 'month':
                            startDate = moment().startOf('month').format('YYYY-MM-DD');
                            endDate = moment().endOf('month').format('YYYY-MM-DD');
                            break;
                        case 'year':
                            startDate = moment().startOf('year').format('YYYY-MM-DD');
                            endDate = moment().endOf('year').format('YYYY-MM-DD');
                            break;
                    }
                    d.start_date = startDate;
                    d.end_date = endDate;
                }
            }
        },
        columns: [
            { data: 'date', render: function(data) { return moment(data).format('DD.MM.YYYY'); } },
            { data: 'description', render: function(data, type, row) {
                let link = '';
                if (row.related_receipt_id) {
                    link = ` <a href="receipts.php#receipt-${row.related_receipt_id}" class="badge bg-info text-dark text-decoration-none ms-2" title="İlgili Fişi Görüntüle"><i class="fas fa-receipt me-1"></i>Fiş</a>`;
                }
                return `${data}${link}`;
            }},
            { data: 'category' },
            { data: 'amount', render: function(data, type, row) {
                const amount = parseFloat(data);
                if (row.type === 'income') {
                    return `<span class="text-success fw-bold">+${amount.toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}</span>`;
                } else {
                    return `<span class="text-danger fw-bold">-${amount.toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}</span>`;
                }
            }},
            { data: 'type', render: function(data) {
                if (data === 'income') {
                    return '<span class="badge bg-success">Gelir</span>';
                } else {
                    return '<span class="badge bg-danger">Gider</span>';
                }
            }},
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<   <button class="btn btn-outline-danger" onclick="deleteRecord(${row.id})"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[0, 'desc']],
        language: getDataTablesLanguage()
    });

    // Filtreler değiştiğinde tabloyu yeniden yükle
    $('#dateRange, #categoryFilter, #typeFilter').on('change', function() {
        table.ajax.reload();
    });

    // Gelir formu
    $('#incomeForm').on('submit', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/income_expense_api.php?action=create',
            type: 'POST',
            data: $(this).serialize()
        }, submitButton).then(() => {
            $('#incomeModal').modal('hide');
            table.ajax.reload();
            this.reset();
        });

        // Bugünün tarihini default olarak set et
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date().toISOString().split('T')[0];
            document.querySelectorAll('input[type="date"]').forEach(input => {
                input.value = today;
            });
        });

    // Gider formu
    $('#expenseForm').on('submit', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/income_expense_api.php?action=create',
            type: 'POST',
            data: $(this).serialize()
        }, submitButton).then(() => {
            $('#expenseModal').modal('hide');
            table.ajax.reload();
            this.reset();
        });
    });

    // Düzenleme formu
    $('#editRecordForm').on('submit', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/income_expense_api.php?action=update',
            type: 'POST',
            data: $(this).serialize()
        }, submitButton).then(() => {
            $('#editRecordModal').modal('hide');
            table.ajax.reload();
        });
    });
});

function deleteRecord(id) {
    handleDelete('../api/income_expense_api.php?action=delete', id, $('#recordsTable').DataTable());
}

rd&id=${id}`,

            if (response.status === 'success') {
                const record = response.data;
                $('#editRecordId').val(record.id);
                $('#editRecordType').val(record.type);
                $('#editDate').val(record.date);
                $('#editDescription').val(record.description);
                $('#editCategory').val(record.category);
                $('#editAmount').val(record.amount);
                $('#editRecordModal').modal('show');
            } else {
                showToast('error', response.message);
            }
        },
        error: function() {
            showToast('error', 'Kayıt bilgileri alınırken bir hata oluştu.');
        }
    });
}
</script>
