<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'İrsaliyeler';
$page_subtitle = 'Mal sevkiyatlarınızı ve irsaliyelerinizi yönetin.';
include 'includes/header.php';

// Formlar için gerekli verileri çek
$customers = $pdo->query("SELECT id, name FROM customers WHERE status = 'active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
$vehicles = $pdo->query("SELECT id, plate, brand FROM vehicles WHERE status = 'active' ORDER BY plate ASC")->fetchAll(PDO::FETCH_ASSOC);
$personnel = $pdo->query("SELECT id, name FROM personnel WHERE status = 'active' AND position LIKE '%Şoför%' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Son irsaliye numarasını al ve bir sonraki numarayı oluştur
$lastDispatchNo = $pdo->query("SELECT dispatch_no FROM dispatches ORDER BY id DESC LIMIT 1")->fetchColumn();
$nextDispatchNo = 'IRS-' . str_pad((int)substr($lastDispatchNo, 4) + 1, 7, '0', STR_PAD_LEFT);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <!-- Başlıklar header.php'den geliyor -->
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#dispatchModal" onclick="prepareAddDispatch()">
        <i class="fas fa-plus me-2"></i>Yeni İrsaliye Oluştur
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-truck-loading me-2"></i>İrsaliye Listesi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="dispatchesTable">
                <thead class="table-light">
                    <tr>
                        <th>İrsaliye No</th>
                        <th>Müşteri</th>
                        <th>Araç</th>
                        <th>Sevk Tarihi</th>
                        <th>Teslimat Tarihi</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- İrsaliye Ekleme/Düzenleme Modal -->
<div class="modal fade" id="dispatchModal" tabindex="-1" aria-labelledby="dispatchModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="dispatchModalLabel">İrsaliye</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="dispatchForm">
                <div class="modal-body">
                    <input type="hidden" id="dispatchId" name="id">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="dispatch_no" class="form-label">İrsaliye No <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="dispatch_no" name="dispatch_no" value="<?= $nextDispatchNo ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="customer_id" class="form-label">Müşteri <span class="text-danger">*</span></label>
                            <select class="form-select" id="customer_id" name="customer_id" required>
                                <option value="">Seçiniz...</option>
                                <?php foreach ($customers as $customer): ?>
                                    <option value="<?= $customer['id'] ?>"><?= htmlspecialchars($customer['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="vehicle_id" class="form-label">Araç <span class="text-danger">*</span></label>
                            <select class="form-select" id="vehicle_id" name="vehicle_id" required>
                                <option value="">Seçiniz...</option>
                                <?php foreach ($vehicles as $vehicle): ?>
                                    <option value="<?= $vehicle['id'] ?>"><?= htmlspecialchars($vehicle['plate'] . ' - ' . $vehicle['brand']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="driver_id" class="form-label">Şoför</label>
                            <select class="form-select" id="driver_id" name="driver_id">
                                <option value="">Seçiniz...</option>
                                <?php foreach ($personnel as $driver): ?>
                                    <option value="<?= $driver['id'] ?>"><?= htmlspecialchars($driver['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="dispatch_date" class="form-label">Sevk Tarihi <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" id="dispatch_date" name="dispatch_date" value="<?= date('Y-m-d') ?>" required>
                        </div>
                        <div class="col-md-4">
                            <label for="delivery_date" class="form-label">Tahmini Teslimat Tarihi</label>
                            <input type="date" class="form-control" id="delivery_date" name="delivery_date">
                        </div>
                        <div class="col-md-6">
                            <label for="origin_address" class="form-label">Yükleme Adresi <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="origin_address" name="origin_address" rows="2" required></textarea>
                        </div>
                        <div class="col-md-6">
                            <label for="destination_address" class="form-label">Teslimat Adresi <span class="text-danger">*</span></label>
                            <textarea class="form-control" id="destination_address" name="destination_address" rows="2" required></textarea>
                        </div>
                        <div class="col-md-12">
                            <label for="status" class="form-label">Durum <span class="text-danger">*</span></label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="planned" selected>Planlandı</option>
                                <option value="in_transit">Yolda</option>
                                <option value="delivered">Teslim Edildi</option>
                                <option value="cancelled">İptal Edildi</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label for="notes" class="form-label">Notlar</label>
                            <textarea class="form-control" id="notes" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
let dispatchesTable;

$(document).ready(function() {
    dispatchesTable = $('#dispatchesTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/dispatches_api.php?action=list',
            type: 'POST'
        },
        columns: [
            { data: 'dispatch_no' },
            { data: 'customer_name' },
            { data: 'vehicle_plate' },
            { data: 'dispatch_date', render: function(data) { return moment(data).format('DD.MM.YYYY'); } },
            { data: 'delivery_date', render: function(data) { return data ? moment(data).format('DD.MM.YYYY') : '-'; } },
            { data: 'status', render: function(data) {
                const statuses = {
                    'planned': { text: 'Planlandı', class: 'secondary' },
                    'in_transit': { text: 'Yolda', class: 'primary' },
                    'delivered': { text: 'Teslim Edildi', class: 'success' },
                    'cancelled': { text: 'İptal Edildi', class: 'danger' }
                };
                const statusInfo = statuses[data] || { text: data, class: 'dark' };
                return `<span class="badge bg-${statusInfo.class}">${statusInfo.text}</span>`;
            }},
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="btn-group btn-group-sm">
                                <button class="btn btn-warning" onclick="editDispatch(${row.id})"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" onclick="deleteDispatch(${row.id})"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[3, 'desc']],
        language: getDataTablesLanguage()
    });

    $('#dispatchForm').on('submit', function(e) {
        e.preventDefault();
        const id = $('#dispatchId').val();
        const url = id ? `../api/dispatches_api.php?action=update` : `../api/dispatches_api.php?action=create`;
        
        sendAjaxRequest({
            url: url,
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#dispatchModal').modal('hide');
            dispatchesTable.ajax.reload(null, false);
        });
    });
});

function prepareAddDispatch() {
    $('#dispatchForm')[0].reset();
    $('#dispatchId').val('');
    $('#dispatch_no').val('<?= $nextDispatchNo ?>');
    $('#dispatch_date').val('<?= date('Y-m-d') ?>');
    $('#dispatchModalLabel').text('Yeni İrsaliye Oluştur');
}

function editDispatch(id) {
    $.get(`../api/dispatches_api.php?action=get_dispatch&id=${id}`, function(response) {
        if (response.status === 'success') {
            const dispatch = response.data;
            $('#dispatchId').val(dispatch.id);
            Object.keys(dispatch).forEach(key => {
                $(`#dispatchForm [name="${key}"]`).val(dispatch[key]);
            });
            $('#dispatchModalLabel').text('İrsaliyeyi Düzenle');
            $('#dispatchModal').modal('show');
        } else {
            toastr.error(response.message);
        }
    });
}

function deleteDispatch(id) {
    handleDelete('../api/dispatches_api.php?action=delete', id, dispatchesTable);
}
</script>