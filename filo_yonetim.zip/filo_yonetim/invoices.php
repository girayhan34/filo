<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Sayfa değişkenleri
$page_title = 'Faturalar';
$page_subtitle = 'Fatura yönetimi ve takibi';

// Veritabanı bağlantısı
$pdo = getPDO(); // config.php'de tanımlı fonksiyonu kullan

// Filtreleme parametreleri
$filters = [
    'invoice_no' => $_GET['invoice_no'] ?? '',
    'receipt_no' => $_GET['receipt_no'] ?? '',
    'status' => $_GET['status'] ?? '',
    'customer' => $_GET['customer'] ?? '',
    'vehicle' => $_GET['vehicle'] ?? '',
    'start_date' => $_GET['start_date'] ?? '',
    'end_date' => $_GET['end_date'] ?? ''
];

// Fatura verilerini çek
$query = "SELECT 
    i.*, 
    c.name as customer_name,
    v.plate as vehicle_plate,
    p.name as driver_name
FROM invoices i
LEFT JOIN customers c ON i.customer_id = c.id
LEFT JOIN vehicles v ON i.vehicle_id = v.id
LEFT JOIN personnel p ON i.driver_id = p.id
WHERE 1=1";

$params = [];

// Filtreleri uygula
if (!empty($filters['invoice_no'])) {
    $query .= " AND i.invoice_no LIKE :invoice_no";
    $params[':invoice_no'] = '%' . $filters['invoice_no'] . '%';
}

if (!empty($filters['receipt_no'])) {
    $query .= " AND i.receipt_no LIKE :receipt_no";
    $params[':receipt_no'] = '%' . $filters['receipt_no'] . '%';
}

if (!empty($filters['status'])) {
    $query .= " AND i.status = :status";
    $params[':status'] = $filters['status'];
}

if (!empty($filters['customer'])) {
    $query .= " AND (c.name LIKE :customer OR c.company_name LIKE :customer)";
    $params[':customer'] = '%' . $filters['customer'] . '%';
}

if (!empty($filters['vehicle'])) {
    $query .= " AND v.plate LIKE :vehicle";
    $params[':vehicle'] = '%' . $filters['vehicle'] . '%';
}

if (!empty($filters['start_date'])) {
    $query .= " AND i.invoice_date >= :start_date";
    $params[':start_date'] = $filters['start_date'];
}

if (!empty($filters['end_date'])) {
    $query .= " AND i.invoice_date <= :end_date";
    $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
}

$query .= " ORDER BY i.invoice_date DESC";

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);

// İstatistikleri hesapla
$stats_query = "SELECT 
    COUNT(*) as total_invoices,
    SUM(CASE WHEN status = 'paid' THEN 1 ELSE 0 END) as paid_invoices,
    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_invoices,
    SUM(CASE WHEN status = 'overdue' THEN 1 ELSE 0 END) as overdue_invoices,
    SUM(total_amount) as total_amount,
    SUM(CASE WHEN status = 'paid' THEN total_amount ELSE 0 END) as paid_amount,
    SUM(CASE WHEN status = 'pending' THEN total_amount ELSE 0 END) as pending_amount
FROM invoices";

$stats = $pdo->query($stats_query)->fetch(PDO::FETCH_ASSOC);

// Son fiş numarasını al
$next_receipt_no = $pdo->query("SELECT IFNULL(MAX(CAST(SUBSTRING(receipt_no, 3) AS UNSIGNED)), 0) + 1 as next_no FROM invoices")->fetchColumn();
$next_receipt_no = 'F-' . str_pad($next_receipt_no, 6, '0', STR_PAD_LEFT);

// Müşterileri, araçları ve personeli çek
$customers = $pdo->query("SELECT id, name, phone, email FROM customers ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
$vehicles = $pdo->query("SELECT id, CONCAT(plate, ' - ', brand, ' ', model) as display, plate, brand, model FROM vehicles WHERE status = 'active' ORDER BY plate")->fetchAll(PDO::FETCH_ASSOC);
$personnel = $pdo->query("SELECT id, name, position FROM personnel WHERE status = 'active' ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Header'ı dahil et
include 'includes/header.php';
?>

<!-- İstatistik Kartları -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card bg-primary text-white mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white-50">Toplam Fatura</h6>
                        <h3 class="mb-0"><?php echo number_format($stats['total_invoices'] ?? 0, 0, ',', '.'); ?></h3>
                    </div>
                    <i class="fas fa-file-invoice fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#" onclick="filterInvoices('all')">Tümünü Görüntüle</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-success text-white mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white-50">Ödenen Faturalar</h6>
                        <h3 class="mb-0"><?php echo number_format($stats['paid_invoices'] ?? 0, 0, ',', '.'); ?></h3>
                    </div>
                    <i class="fas fa-check-circle fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#" onclick="filterInvoices('paid')">Detaylar</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-warning text-white mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white-50">Bekleyen Faturalar</h6>
                        <h3 class="mb-0"><?php echo number_format($stats['pending_invoices'] ?? 0, 0, ',', '.'); ?></h3>
                    </div>
                    <i class="fas fa-clock fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#" onclick="filterInvoices('pending')">İncele</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card bg-danger text-white mb-4">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h6 class="text-white-50">Geciken Faturalar</h6>
                        <h3 class="mb-0"><?php echo number_format($stats['overdue_invoices'] ?? 0, 0, ',', '.'); ?></h3>
                    </div>
                    <i class="fas fa-exclamation-triangle fa-3x opacity-50"></i>
                </div>
            </div>
            <div class="card-footer d-flex align-items-center justify-content-between">
                <a class="small text-white stretched-link" href="#" onclick="filterInvoices('overdue')">İşlem Yap</a>
                <div class="small text-white"><i class="fas fa-angle-right"></i></div>
            </div>
        </div>
    </div>
</div>

<!-- Toplam Tutar Kartı -->
<div class="card bg-dark text-white mb-4">
    <div class="card-body">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h6 class="text-white-50">Toplam Tutar</h6>
                <h2 class="mb-0"><?php echo number_format($stats['total_amount'] ?? 0, 2, ',', '.'); ?>₺</h2>
                <div class="mt-2">
                    <span class="badge bg-success me-2">Ödenen: <?php echo number_format($stats['paid_amount'] ?? 0, 2, ',', '.'); ?>₺</span>
                    <span class="badge bg-warning">Bekleyen: <?php echo number_format($stats['pending_amount'] ?? 0, 2, ',', '.'); ?>₺</span>
                </div>
            </div>
            <i class="fas fa-coins fa-4x opacity-50"></i>
        </div>
    </div>
</div>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#newInvoiceModal">
                            <i class="fas fa-plus-circle mb-1"></i>
                            <small>Yeni Fatura</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-success w-100 quick-action-btn" onclick="filterInvoices('paid')">
                            <i class="fas fa-check-circle mb-1"></i>
                            <small>Ödenenler</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-warning w-100 quick-action-btn" onclick="filterInvoices('pending')">
                            <i class="fas fa-clock mb-1"></i>
                            <small>Bekleyenler</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-danger w-100 quick-action-btn" onclick="filterInvoices('overdue')">
                            <i class="fas fa-exclamation-triangle mb-1"></i>
                            <small>Geciken</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-info w-100 quick-action-btn" onclick="exportToExcel()">
                            <i class="fas fa-file-excel mb-1"></i>
                            <small>Excel'e Aktar</small>
                        </button>
                    </div>
                    <div class="col-xl-2 col-md-3 col-sm-4 col-6">
                        <button class="btn btn-secondary w-100 quick-action-btn" onclick="printInvoices()">
                            <i class="fas fa-print mb-1"></i>
                            <small>Yazdır</small>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Fatura İstatistikleri -->
<div class="row mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card">
            <i class="fas fa-file-invoice"></i>
            <h2><?= $total_invoices ?></h2>
            <p>Toplam Fatura</p>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card">
            <i class="fas fa-check-circle"></i>
            <h2><?= $paid_invoices ?></h2>
            <p>Ödenen Faturalar</p>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card">
            <i class="fas fa-clock"></i>
            <h2><?= $pending_invoices ?></h2>
            <p>Bekleyen Faturalar</p>
        </div>
    </div>
    
    <div class="col-xl-3 col-md-6">
        <div class="card stats-card">
            <i class="fas fa-lira-sign"></i>
            <h2><?= number_format($total_amount, 0, ',', '.') ?>₺</h2>
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="card-title mb-0">Fatura Listesi</h5>
        <div class="d-flex gap-2">
            <div class="input-group" style="width: 250px;">
                <input type="text" class="form-control form-control-sm" id="searchInput" placeholder="Fatura, müşteri veya araç ara...">
                <button class="btn btn-sm btn-outline-secondary" type="button" onclick="searchInvoices()">
                    <i class="fas fa-search"></i>
                </button>
            </div>
            <button class="btn btn-sm btn-outline-primary" data-bs-toggle="collapse" href="#filtersCollapse" role="button">
                <i class="fas fa-filter me-1"></i> Filtrele
            </button>
            <button class="btn btn-sm btn-success" onclick="exportToPDF()">
                <i class="fas fa-file-pdf me-1"></i> PDF
            </button>
        </div>
    </div>
    <div class="collapse" id="filtersCollapse">
        <div class="card-body">
            <form id="filterForm" class="row g-3">
                <div class="col-md-3">
                    <label for="invoiceNoFilter" class="form-label">Fatura No</label>
                    <input type="text" class="form-control form-control-sm" id="invoiceNoFilter" value="<?php echo htmlspecialchars($filters['invoice_no']); ?>">
                </div>
                <div class="col-md-3">
                    <label for="receiptNoFilter" class="form-label">Fiş No</label>
                    <input type="text" class="form-control form-control-sm" id="receiptNoFilter" value="<?php echo htmlspecialchars($filters['receipt_no']); ?>">
                </div>
                <div class="col-md-3">
                    <label for="statusFilter" class="form-label">Durum</label>
                    <select class="form-select form-select-sm" id="statusFilter">
                        <option value="">Tümü</option>
                        <option value="paid" <?php echo $filters['status'] === 'paid' ? 'selected' : ''; ?>>Ödendi</option>
                        <option value="pending" <?php echo $filters['status'] === 'pending' ? 'selected' : ''; ?>>Bekliyor</option>
                        <option value="overdue" <?php echo $filters['status'] === 'overdue' ? 'selected' : ''; ?>>Gecikmiş</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="customerFilter" class="form-label">Müşteri</label>
                    <input type="text" class="form-control form-control-sm" id="customerFilter" value="<?php echo htmlspecialchars($filters['customer']); ?>">
                </div>
                <div class="col-md-3">
                    <label for="vehicleFilter" class="form-label">Araç</label>
                    <select class="form-select form-select-sm" id="vehicleFilter">
                        <option value="">Tümü</option>
                        <?php foreach ($vehicles as $vehicle): ?>
                            <option value="<?php echo htmlspecialchars($vehicle['plate']); ?>" <?php echo $filters['vehicle'] === $vehicle['plate'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($vehicle['plate'] . ' - ' . $vehicle['brand'] . ' ' . $vehicle['model']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <label for="startDateFilter" class="form-label">Başlangıç Tarihi</label>
                    <input type="date" class="form-control form-control-sm" id="startDateFilter" value="<?php echo htmlspecialchars($filters['start_date']); ?>">
                </div>
                <div class="col-md-3">
                    <label for="endDateFilter" class="form-label">Bitiş Tarihi</label>
                    <input type="date" class="form-control form-control-sm" id="endDateFilter" value="<?php echo htmlspecialchars($filters['end_date']); ?>">
                </div>
                <div class="col-12 text-end">
                    <button type="button" class="btn btn-sm btn-outline-secondary me-2" onclick="clearFilters()">
                        <i class="fas fa-undo me-1"></i> Temizle
                    </button>
                    <button type="button" class="btn btn-sm btn-primary" onclick="applyFilters()">
                        <i class="fas fa-filter me-1"></i> Filtrele
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Fatura Listesi -->
<div class="card">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" id="invoicesTable">
                <thead class="table-light">
                    <tr>
                        <th>Fatura No</th>
                        <th>Tarih</th>
                        <th>Müşteri</th>
                        <th>Araç</th>
                        <th>Hizmet</th>
                        <th>Tutar</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($invoice_data as $invoice): ?>
                    <tr>
                        <td><strong><?= htmlspecialchars($invoice['invoice_no']) ?></strong></td>
                        <td><?= date('d.m.Y', strtotime($invoice['date'])) ?></td>
                        <td><?= htmlspecialchars($invoice['customer']) ?></td>
                        <td><?= htmlspecialchars($invoice['vehicle']) ?></td>
                        <td><?= htmlspecialchars($invoice['service']) ?></td>
                        <td><strong><?= number_format($invoice['total'], 2, ',', '.') ?>₺</strong></td>
                        <td>
                            <?php
                            $badge_class = match($invoice['status']) {
                                'paid' => 'bg-success',
                                'pending' => 'bg-warning',
                                'overdue' => 'bg-danger',
                                default => 'bg-secondary'
                            };
                            $status_text = match($invoice['status']) {
                                'paid' => 'Ödendi',
                                'pending' => 'Bekliyor',
                                'overdue' => 'Gecikti',
                                default => 'Bilinmiyor'
                            };
                            ?>
                            <span class="badge <?= $badge_class ?>"><?= $status_text ?></span>
                        </td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-outline-primary" onclick="viewInvoice(<?= $invoice['id'] ?>)" title="Görüntüle">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-outline-success" onclick="editInvoice(<?= $invoice['id'] ?>)" title="Düzenle">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-outline-info" onclick="printInvoice(<?= $invoice['id'] ?>)" title="Yazdır">
                                    <i class="fas fa-print"></i>
                                </button>
                                <?php if ($invoice['status'] !== 'paid'): ?>
                                <button class="btn btn-outline-warning" onclick="markAsPaid(<?= $invoice['id'] ?>)" title="Ödendi İşaretle">
                                    <i class="fas fa-check"></i>
                                </button>
                                <?php endif; ?>
                                <?php if ($invoice['status'] !== 'overdue'): ?>
                                <button class="btn btn-outline-danger" onclick="markAsOverdue(<?= $invoice['id'] ?>)" title="Gecikti İşaretle">
                                    <i class="fas fa-exclamation-triangle"></i>
                                </button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<script>
// Fatura filtreleme fonksiyonları
function filterInvoices(status) {
    const rows = document.querySelectorAll('#invoicesTable tbody tr');
    rows.forEach(row => {
        if (status === 'all') {
            row.style.display = '';
        } else {
            const statusBadge = row.querySelector('.badge');
            const rowStatus = statusBadge ? statusBadge.textContent.toLowerCase() : '';
            
            let shouldShow = false;
            if (status === 'paid' && rowStatus.includes('ödendi')) shouldShow = true;
            if (status === 'pending' && rowStatus.includes('bekliyor')) shouldShow = true;
            if (status === 'overdue' && rowStatus.includes('gecikti')) shouldShow = true;
            
            row.style.display = shouldShow ? '' : 'none';
        }
    });
}

// Fatura işlem fonksiyonları
function viewInvoice(id) {
    console.log('Fatura görüntüleniyor:', id);
}

function editInvoice(id) {
    console.log('Fatura düzenleniyor:', id);
}

function printInvoice(id) {
    window.print();
}

function markAsPaid(id) {
    if (confirm('Bu faturayı ödendi olarak işaretlemek istediğinizden emin misiniz?')) {
        location.reload();
    }
}

function markAsOverdue(id) {
    if (confirm('Bu faturayı gecikti olarak işaretlemek istediğinizden emin misiniz?')) {
        location.reload();
    }
}

function exportInvoices() {
    alert('Dışa aktarma özelliği yakında eklenecek');
}

function printInvoices() {
    window.print();
}

// Arama fonksiyonu
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#invoicesTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});
</script>
        let invoiceData = [];
        let vehicleData = [];
        let personnelData = [];
        let customerData = [];

        // Sayfa yüklendiğinde verileri çek
        document.addEventListener('DOMContentLoaded', function() {
            loadInitialData();
        });

        // İlk verileri yükle
        function loadInitialData() {
            loadInvoices();
            loadVehicles();
            loadPersonnel();
            loadCustomers();
            loadNextReceiptNo();
        }

        // Faturaları yükle (filtreli)
        function loadInvoices(filters = {}) {
            let url = 'includes/invoice_operations.php?action=get_invoices';
            
            // Filtre parametrelerini URL'ye ekle
            Object.keys(filters).forEach(key => {
                if (filters[key]) {
                    url += `&${key}=${encodeURIComponent(filters[key])}`;
                }
            });
            
            console.log('Faturalar yükleniyor:', url); // Debug için
            
            fetch(url)
            .then(response => {
                console.log('Response status:', response.status); // Debug için
                return response.json();
            })
            .then(data => {
                console.log('API Response:', data); // Debug için
                if (data.success) {
                    invoiceData = data.data.map(invoice => ({
                        id: invoice.id,
                        invoice_no: invoice.invoice_no,
                        receipt_no: invoice.receipt_no,
                        date: invoice.invoice_date,
                        customer: invoice.customer_name || 'Bilinmeyen',
                        vehicle: invoice.vehicle_plate || 'Bilinmeyen',
                        vehicle_type: invoice.vehicle_type || '',
                        service: invoice.service_type,
                        amount: parseFloat(invoice.amount) || 0,
                        tax: parseFloat(invoice.tax_amount) || 0,
                        total: parseFloat(invoice.total_amount) || 0,
                        status: invoice.status
                    }));
                    console.log('İşlenmiş fatura verisi:', invoiceData); // Debug için
                    updateInvoiceTable();
                    updateStatistics();
                } else {
                    console.error('API Hatası:', data.message);
                    alert('Faturalar yüklenirken hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Faturalar yüklenirken hata:', error);
                alert('Bağlantı hatası: ' + error.message);
            });
        }

        // Araçları yükle
        function loadVehicles() {
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=get_vehicles'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    vehicleData = data.data;
                    updateVehicleSelect();
                }
            })
            .catch(error => {
                console.error('Araçlar yüklenirken hata:', error);
            });
        }

        // Personeli yükle
        function loadPersonnel() {
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=get_personnel'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    personnelData = data.data;
                    updatePersonnelSelect();
                }
            })
            .catch(error => {
                console.error('Personel yüklenirken hata:', error);
            });
        }

        // Müşterileri yükle
        function loadCustomers() {
            fetch('includes/invoice_operations.php?action=get_customers', {
                method: 'GET'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    customerData = data.data;
                }
            })
            .catch(error => {
                console.error('Müşteriler yüklenirken hata:', error);
            });
        }

        // Sonraki fiş numarasını yükle
        function loadNextReceiptNo() {
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'action=get_next_receipt_no'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.querySelector('input[name="receipt_no"]').value = data.next_receipt_no;
                }
            })
            .catch(error => {
                console.error('Fiş numarası yüklenirken hata:', error);
            });
        }

        // Araç select'ini güncelle
        function updateVehicleSelect() {
            const vehicleSelect = document.querySelector('select[name="vehicle"]');
            vehicleSelect.innerHTML = '<option value="">Araç Seçin</option>';
            
            vehicleData.forEach(vehicle => {
                const option = document.createElement('option');
                option.value = vehicle.plate;
                option.textContent = `${vehicle.plate} - ${vehicle.type}`;
                vehicleSelect.appendChild(option);
            });
            
            // Filtre için araç select'ini de güncelle
            const vehicleFilterSelect = document.getElementById('vehicleFilter');
            if (vehicleFilterSelect) {
                vehicleFilterSelect.innerHTML = '<option value="">Tüm Araçlar</option>';
                vehicleData.forEach(vehicle => {
                    const option = document.createElement('option');
                    option.value = vehicle.plate;
                    option.textContent = `${vehicle.plate} - ${vehicle.type}`;
                    vehicleFilterSelect.appendChild(option);
                });
            }
        }

        // Personel select'ini güncelle
        function updatePersonnelSelect() {
            const personnelSelect = document.querySelector('select[name="driver"]');
            personnelSelect.innerHTML = '<option value="">Şoför Seçin</option>';
            
            personnelData.forEach(person => {
                const option = document.createElement('option');
                option.value = person.id;
                option.textContent = `${person.name} - ${person.position} (${person.license_types || 'Belirtilmemiş'})`;
                personnelSelect.appendChild(option);
            });
        }

        // Form submit handler - Gerçek veritabanı işlemi
        document.getElementById('invoiceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            console.log('Fatura formu gönderiliyor...'); // Debug
            
            // Form verilerini al
            const formData = new FormData(this);
            formData.append('action', 'create_invoice');
            
            // Form verilerini konsola yazdır
            for (let [key, value] of formData.entries()) {
                console.log(key, value);
            }
            
            // AJAX ile faturayı kaydet
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('Form response status:', response.status);
                return response.json();
            })
            .then(data => {
                console.log('Form response data:', data);
                if (data.success) {
                    alert('Fatura başarıyla oluşturuldu! Fiş No: ' + data.receipt_no);
                    // Fatura listesini yenile
                    loadInvoices();
                    // Formu temizle
                    this.reset();
                    // Tarihleri tekrar set et
                    setDefaultDates();
                    // Sonraki fiş numarasını yükle
                    loadNextReceiptNo();
                    // Modalı kapat
                    const modal = bootstrap.Modal.getInstance(document.getElementById('invoiceModal'));
                    if (modal) modal.hide();
                } else {
                    alert('Hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Fatura kaydedilirken hata:', error);
                alert('Fatura kaydedilirken bir hata oluştu: ' + error.message);
            });
        });

        // Müşteri verileri
        const customers = <?= json_encode($customer_data) ?>;

        // Müşteri arama fonksiyonu
        function setupCustomerSearch() {
            const customerInput = document.getElementById('customerSearch');
            const suggestions = document.getElementById('customerSuggestions');

            customerInput.addEventListener('input', function() {
                const query = this.value.toLowerCase();
                suggestions.innerHTML = '';
                
                if (query.length < 2) {
                    suggestions.classList.remove('show');
                    return;
                }

                const matches = customers.filter(customer => 
                    customer.name.toLowerCase().includes(query)
                );

                if (matches.length > 0) {
                    matches.forEach(customer => {
                        const item = document.createElement('a');
                        item.className = 'dropdown-item';
                        item.href = '#';
                        item.innerHTML = `
                            <div>
                                <strong>${customer.name}</strong><br>
                                <small class="text-muted">${customer.phone} - ${customer.email}</small>
                            </div>
                        `;
                        item.addEventListener('click', function(e) {
                            e.preventDefault();
                            customerInput.value = customer.name;
                            suggestions.classList.remove('show');
                        });
                        suggestions.appendChild(item);
                    });
                    suggestions.classList.add('show');
                } else {
                    const noMatch = document.createElement('div');
                    noMatch.className = 'dropdown-item-text text-muted';
                    noMatch.textContent = 'Müşteri bulunamadı. + butonuna tıklayarak yeni müşteri ekleyin.';
                    suggestions.appendChild(noMatch);
                    suggestions.classList.add('show');
                }
            });

            // Dışarı tıklandığında önerileri gizle
            document.addEventListener('click', function(e) {
                if (!customerInput.contains(e.target) && !suggestions.contains(e.target)) {
                    suggestions.classList.remove('show');
                }
            });
        }

        // Tarihleri set etme fonksiyonu
        function setDefaultDates() {
            const today = new Date().toISOString().split('T')[0];
            document.querySelector('input[name="date"]').value = today;
            document.querySelector('input[name="payment_date"]').value = today;
            
            // Vade tarihi için 30 gün sonrası
            const dueDate = new Date();
            dueDate.setDate(dueDate.getDate() + 30);
            document.querySelector('input[name="due_date"]').value = dueDate.toISOString().split('T')[0];
        }

        // Bugünün tarihini default olarak set et
        document.addEventListener('DOMContentLoaded', function() {
            setDefaultDates();
            
            // Müşteri arama fonksiyonunu başlat
            setupCustomerSearch();
        });

        // Tutar hesaplama
        function calculateAmounts() {
            const unitPrice = parseFloat(document.querySelector('input[name="unit_price"]').value) || 0;
            const quantity = parseFloat(document.querySelector('input[name="quantity"]').value) || 0;
            const taxRate = parseFloat(document.querySelector('select[name="tax_rate"]').value) || 0;
            
            const subtotal = unitPrice * quantity;
            const taxAmount = subtotal * (taxRate / 100);
            const total = subtotal + taxAmount;
            
            document.getElementById('subtotal').value = subtotal.toFixed(2) + '₺';
            document.getElementById('tax_amount').value = taxAmount.toFixed(2) + '₺';
            document.getElementById('total_amount').value = total.toFixed(2) + '₺';
        }

        // Input değişikliklerini dinle
        document.querySelector('input[name="unit_price"]').addEventListener('input', calculateAmounts);
        document.querySelector('input[name="quantity"]').addEventListener('input', calculateAmounts);
        document.querySelector('select[name="tax_rate"]').addEventListener('change', calculateAmounts);

        // Filtreleme fonksiyonu
        function applyFilters() {
            const filters = {
                invoice_no: document.getElementById('invoiceNoFilter').value,
                receipt_no: document.getElementById('receiptNoFilter').value,
                status: document.getElementById('statusFilter').value,
                customer: document.getElementById('customerFilter').value,
                vehicle: document.getElementById('vehicleFilter').value,
                vehicle_category: document.getElementById('vehicleCategoryFilter').value,
                start_date: document.getElementById('startDateFilter').value,
                end_date: document.getElementById('endDateFilter').value
            };
            
            // Boş değerleri temizle
            Object.keys(filters).forEach(key => {
                if (!filters[key]) {
                    delete filters[key];
                }
            });
            
            // Filtreleri uygula
            loadInvoices(filters);
        }

        // Filtreleri temizle
        function clearFilters() {
            document.getElementById('invoiceNoFilter').value = '';
            document.getElementById('receiptNoFilter').value = '';
            document.getElementById('statusFilter').value = '';
            document.getElementById('customerFilter').value = '';
            document.getElementById('vehicleFilter').value = '';
            document.getElementById('vehicleCategoryFilter').value = '';
            document.getElementById('startDateFilter').value = '';
            document.getElementById('endDateFilter').value = '';
            
            // Tüm faturaları yükle
            loadInvoices();
        }

        // Filtrelenmiş verileri dışa aktar
        function exportFiltered() {
            if (invoiceData.length === 0) {
                alert('Dışa aktarılacak veri bulunamadı!');
                return;
            }
            
            let csvContent = "data:text/csv;charset=utf-8,";
            csvContent += "Fatura No,Fiş No,Tarih,Müşteri,Araç,Hizmet,Tutar,KDV,Toplam,Durum\n";
            
            invoiceData.forEach(invoice => {
                const row = [
                    invoice.invoice_no,
                    invoice.receipt_no,
                    new Date(invoice.date).toLocaleDateString('tr-TR'),
                    invoice.customer,
                    invoice.vehicle,
                    invoice.service,
                    invoice.amount.toLocaleString('tr-TR'),
                    invoice.tax.toLocaleString('tr-TR'),
                    invoice.total.toLocaleString('tr-TR'),
                    invoice.status === 'paid' ? 'Ödendi' : (invoice.status === 'overdue' ? 'Gecikmiş' : 'Beklemede')
                ].join(',');
                csvContent += row + "\n";
            });
            
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `faturalar_${new Date().toISOString().split('T')[0]}.csv`);
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            alert('Veriler CSV formatında indirildi!');
        }

        // Fatura tablosunu güncelle
        function updateInvoiceTable() {
            const tbody = document.querySelector('.table tbody');
            tbody.innerHTML = '';
            
            invoiceData.forEach(invoice => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="fw-bold">${invoice.invoice_no}</td>
                    <td class="fw-bold text-primary">${invoice.receipt_no}</td>
                    <td>${new Date(invoice.date).toLocaleDateString('tr-TR')}</td>
                    <td>${invoice.customer}</td>
                    <td><span class="badge bg-secondary">${invoice.vehicle}</span></td>
                    <td>${invoice.service}</td>
                    <td>${invoice.amount.toLocaleString('tr-TR')}₺</td>
                    <td>${invoice.tax.toLocaleString('tr-TR')}₺</td>
                    <td class="fw-bold">${invoice.total.toLocaleString('tr-TR')}₺</td>
                    <td>
                        <span class="badge bg-${invoice.status === 'paid' ? 'success' : (invoice.status === 'overdue' ? 'danger' : 'warning')}">
                            ${invoice.status === 'paid' ? 'Ödendi' : (invoice.status === 'overdue' ? 'Gecikmiş' : 'Beklemede')}
                        </span>
                    </td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="viewInvoice(${invoice.id})" title="Görüntüle">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-sm btn-info" onclick="printInvoiceDirect(${invoice.id})" title="Yazdır">
                            <i class="fas fa-print"></i>
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="editInvoice(${invoice.id})" title="Düzenle">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteInvoice(${invoice.id})" title="Sil">
                            <i class="fas fa-trash"></i>
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
            
            // Kayıt sayısını güncelle
            document.querySelector('.badge.bg-primary').textContent = invoiceData.length + ' kayıt';
        }

        // İstatistikleri güncelle
        function updateStatistics() {
            const totalInvoices = invoiceData.length;
            const paidInvoices = invoiceData.filter(inv => inv.status === 'paid').length;
            const pendingInvoices = invoiceData.filter(inv => inv.status === 'pending').length;
            const overdueInvoices = invoiceData.filter(inv => inv.status === 'overdue').length;
            
            const totalAmount = invoiceData.reduce((sum, inv) => sum + inv.total, 0);
            const paidAmount = invoiceData.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.total, 0);
            const pendingAmount = invoiceData.filter(inv => inv.status === 'pending').reduce((sum, inv) => sum + inv.total, 0);
            
            // İstatistik kartlarını güncelle
            const statCards = document.querySelectorAll('.stats-card h2');
            statCards[0].textContent = totalInvoices;
            statCards[1].textContent = paidInvoices;
            statCards[2].textContent = pendingInvoices;
            statCards[3].textContent = overdueInvoices;
            statCards[4].textContent = totalAmount.toLocaleString('tr-TR') + '₺';
            statCards[5].textContent = paidAmount.toLocaleString('tr-TR') + '₺';
            statCards[6].textContent = pendingAmount.toLocaleString('tr-TR') + '₺';
        }

        // Global değişkenler
        let currentInvoiceId = null;
        let currentInvoiceData = null;

        // CRUD işlemleri - Gerçek veritabanı işlemleri
        function viewInvoice(id) {
            currentInvoiceId = id;
            
            fetch(`includes/invoice_operations.php?action=get_invoice_details&invoice_id=${id}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentInvoiceData = data;
                    displayInvoiceDetails(data);
                    const modal = new bootstrap.Modal(document.getElementById('viewInvoiceModal'));
                    modal.show();
                } else {
                    alert('Hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Fatura detayları yüklenirken hata:', error);
                alert('Fatura detayları yüklenirken hata oluştu!');
            });
        }

        function displayInvoiceDetails(data) {
            const invoice = data.invoice;
            const payments = data.payments;
            const totalPaid = data.total_paid;
            const remainingAmount = data.remaining_amount;
            
            let paymentsHtml = '';
            if (payments.length > 0) {
                paymentsHtml = `
                    <h6 class="mt-4"><i class="fas fa-money-bill"></i> Tahsilat Geçmişi</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Tarih</th>
                                    <th>Tutar</th>
                                    <th>Yöntem</th>
                                    <th>Referans</th>
                                    <th>Notlar</th>
                                </tr>
                            </thead>
                            <tbody>
                `;
                
                payments.forEach(payment => {
                    paymentsHtml += `
                        <tr>
                            <td>${new Date(payment.payment_date).toLocaleDateString('tr-TR')}</td>
                            <td class="fw-bold text-success">${parseFloat(payment.amount).toLocaleString('tr-TR')}₺</td>
                            <td><span class="badge bg-info">${payment.payment_method}</span></td>
                            <td>${payment.reference_no || '-'}</td>
                            <td>${payment.notes || '-'}</td>
                        </tr>
                    `;
                });
                
                paymentsHtml += `
                            </tbody>
                        </table>
                    </div>
                `;
            }
            
            const statusBadge = invoice.status === 'paid' ? 'bg-success' : (invoice.status === 'overdue' ? 'bg-danger' : 'bg-warning');
            const statusText = invoice.status === 'paid' ? 'Ödendi' : (invoice.status === 'overdue' ? 'Gecikmiş' : 'Beklemede');
            
            document.getElementById('invoiceDetailsContent').innerHTML = `
                <div class="row">
                    <div class="col-md-6">
                        <h6><i class="fas fa-file-invoice"></i> Fatura Bilgileri</h6>
                        <table class="table table-borderless table-sm">
                            <tr><td><strong>Fatura No:</strong></td><td>${invoice.invoice_no}</td></tr>
                            <tr><td><strong>Fiş No:</strong></td><td class="text-primary fw-bold">${invoice.receipt_no}</td></tr>
                            <tr><td><strong>Tarih:</strong></td><td>${new Date(invoice.invoice_date).toLocaleDateString('tr-TR')}</td></tr>
                            <tr><td><strong>Vade Tarihi:</strong></td><td>${invoice.due_date ? new Date(invoice.due_date).toLocaleDateString('tr-TR') : '-'}</td></tr>
                            <tr><td><strong>Durum:</strong></td><td><span class="badge ${statusBadge}">${statusText}</span></td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6><i class="fas fa-user"></i> Müşteri Bilgileri</h6>
                        <table class="table table-borderless table-sm">
                            <tr><td><strong>Müşteri:</strong></td><td>${invoice.customer_name}</td></tr>
                            <tr><td><strong>Telefon:</strong></td><td>${invoice.customer_phone || '-'}</td></tr>
                            <tr><td><strong>E-posta:</strong></td><td>${invoice.customer_email || '-'}</td></tr>
                            <tr><td><strong>Adres:</strong></td><td>${invoice.customer_address || '-'}</td></tr>
                        </table>
                    </div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <h6><i class="fas fa-truck"></i> Araç & Şoför</h6>
                        <table class="table table-borderless table-sm">
                            <tr><td><strong>Araç:</strong></td><td><span class="badge bg-secondary">${invoice.vehicle_plate} - ${invoice.vehicle_type}</span></td></tr>
                            <tr><td><strong>Şoför:</strong></td><td>${invoice.driver_name || '-'}</td></tr>
                            <tr><td><strong>Hizmet:</strong></td><td>${invoice.service_type}</td></tr>
                            <tr><td><strong>Ödeme Yöntemi:</strong></td><td>${invoice.payment_method}</td></tr>
                        </table>
                    </div>
                    <div class="col-md-6">
                        <h6><i class="fas fa-calculator"></i> Tutar Bilgileri</h6>
                        <table class="table table-borderless table-sm">
                            <tr><td><strong>Birim Fiyat:</strong></td><td>${parseFloat(invoice.unit_price).toLocaleString('tr-TR')}₺</td></tr>
                            <tr><td><strong>Miktar:</strong></td><td>${invoice.quantity}</td></tr>
                            <tr><td><strong>Ara Toplam:</strong></td><td>${parseFloat(invoice.amount).toLocaleString('tr-TR')}₺</td></tr>
                            <tr><td><strong>KDV (%${invoice.tax_rate}):</strong></td><td>${parseFloat(invoice.tax_amount).toLocaleString('tr-TR')}₺</td></tr>
                            <tr class="border-top"><td><strong>Genel Toplam:</strong></td><td class="fw-bold text-primary">${parseFloat(invoice.total_amount).toLocaleString('tr-TR')}₺</td></tr>
                            <tr><td><strong>Ödenen:</strong></td><td class="fw-bold text-success">${totalPaid.toLocaleString('tr-TR')}₺</td></tr>
                            <tr><td><strong>Kalan:</strong></td><td class="fw-bold text-danger">${remainingAmount.toLocaleString('tr-TR')}₺</td></tr>
                        </table>
                    </div>
                </div>
                
                ${invoice.description ? `
                <div class="row">
                    <div class="col-12">
                        <h6><i class="fas fa-comment"></i> Açıklama</h6>
                        <p class="bg-light p-2 rounded">${invoice.description}</p>
                    </div>
                </div>
                ` : ''}
                
                ${paymentsHtml}
            `;
        }

        function editInvoice(id) {
            if (!currentInvoiceData || currentInvoiceId !== id) {
                viewInvoice(id);
                return;
            }
            
            const invoice = currentInvoiceData.invoice;
            
            // Form alanlarını doldur
            document.getElementById('edit_invoice_id').value = invoice.id;
            document.getElementById('edit_customer_id').value = invoice.customer_id;
            document.getElementById('edit_vehicle_id').value = invoice.vehicle_id;
            document.getElementById('edit_driver_id').value = invoice.driver_id;
            document.getElementById('edit_invoice_no').value = invoice.invoice_no;
            document.getElementById('edit_receipt_no').value = invoice.receipt_no;
            document.getElementById('edit_invoice_date').value = invoice.invoice_date;
            document.getElementById('edit_payment_date').value = invoice.payment_date || '';
            document.getElementById('edit_due_date').value = invoice.due_date || '';
            document.getElementById('edit_service_type').value = invoice.service_type;
            document.getElementById('edit_payment_method').value = invoice.payment_method;
            document.getElementById('edit_unit_price').value = invoice.unit_price;
            document.getElementById('edit_quantity').value = invoice.quantity;
            document.getElementById('edit_tax_rate').value = invoice.tax_rate;
            document.getElementById('edit_description').value = invoice.description || '';
            document.getElementById('edit_status').value = invoice.status;
            
            // Görüntüleme modalını kapat ve düzenleme modalını aç
            const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewInvoiceModal'));
            if (viewModal) viewModal.hide();
            
            const editModal = new bootstrap.Modal(document.getElementById('editInvoiceModal'));
            editModal.show();
        }

        function openEditModal() {
            if (currentInvoiceId) {
                editInvoice(currentInvoiceId);
            }
        }

        function openPaymentModal() {
            if (!currentInvoiceData) return;
            
            const invoice = currentInvoiceData.invoice;
            const remainingAmount = currentInvoiceData.remaining_amount;
            
            if (remainingAmount <= 0) {
                alert('Bu fatura tamamen ödenmiş durumda!');
                return;
            }
            
            // Form alanlarını doldur
            document.getElementById('payment_invoice_id').value = invoice.id;
            document.getElementById('payment_invoice_info').innerHTML = `
                <strong>${invoice.invoice_no}</strong> - ${invoice.customer_name}<br>
                Toplam: ${parseFloat(invoice.total_amount).toLocaleString('tr-TR')}₺ | 
                Ödenen: ${currentInvoiceData.total_paid.toLocaleString('tr-TR')}₺
            `;
            document.getElementById('remaining_amount_text').textContent = remainingAmount.toLocaleString('tr-TR') + '₺';
            
            // Bugünün tarihini set et
            const today = new Date().toISOString().split('T')[0];
            document.querySelector('#paymentModal input[name="payment_date"]').value = today;
            
            // Kalan tutarı ödeme tutarı alanına set et
            document.querySelector('#paymentModal input[name="amount"]').value = remainingAmount.toFixed(2);
            
            // Görüntüleme modalını kapat ve tahsilat modalını aç
            const viewModal = bootstrap.Modal.getInstance(document.getElementById('viewInvoiceModal'));
            if (viewModal) viewModal.hide();
            
            const paymentModal = new bootstrap.Modal(document.getElementById('paymentModal'));
            paymentModal.show();
        }

        // Form submit işlemleri
        document.getElementById('invoiceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'create_invoice');
            
            console.log('Fatura oluşturma isteği gönderiliyor...');
            console.log('Form verileri:', Object.fromEntries(formData));
            
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log('API yanıtı:', data);
                if (data.success) {
                    alert('Fatura başarıyla oluşturuldu!');
                    this.reset();
                    const modal = bootstrap.Modal.getInstance(document.getElementById('invoiceModal'));
                    modal.hide();
                    loadInvoices(); // Tabloyu yenile
                } else {
                    alert('Hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Fatura oluşturma hatası:', error);
                alert('Fatura oluşturulurken hata oluştu!');
            });
        });

        // Fatura düzenleme form submit
        document.getElementById('editInvoiceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'update_invoice');
            
            console.log('Fatura güncelleme isteği gönderiliyor...');
            console.log('Form verileri:', Object.fromEntries(formData));
            
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log('API yanıtı:', data);
                if (data.success) {
                    alert('Fatura başarıyla güncellendi!');
                    const modal = bootstrap.Modal.getInstance(document.getElementById('editInvoiceModal'));
                    modal.hide();
                    loadInvoices(); // Tabloyu yenile
                    
                    // Eğer görüntüleme modalı açıksa, güncel verileri yükle
                    if (currentInvoiceId) {
                        viewInvoice(currentInvoiceId);
                    }
                } else {
                    alert('Hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Fatura güncelleme hatası:', error);
                alert('Fatura güncellenirken hata oluştu!');
            });
        });

        // Tahsilat form submit
        document.getElementById('paymentForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'add_payment');
            
            const amount = parseFloat(formData.get('amount'));
            const remainingAmount = currentInvoiceData ? currentInvoiceData.remaining_amount : 0;
            
            if (amount > remainingAmount) {
                alert(`Ödeme tutarı kalan tutardan (${remainingAmount.toLocaleString('tr-TR')}₺) fazla olamaz!`);
                return;
            }
            
            console.log('Tahsilat ekleme isteği gönderiliyor...');
            console.log('Form verileri:', Object.fromEntries(formData));
            
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                console.log('API yanıtı:', data);
                if (data.success) {
                    alert('Tahsilat başarıyla kaydedildi!');
                    this.reset();
                    const modal = bootstrap.Modal.getInstance(document.getElementById('paymentModal'));
                    modal.hide();
                    loadInvoices(); // Tabloyu yenile
                    
                    // Fatura detaylarını yenile
                    if (currentInvoiceId) {
                        viewInvoice(currentInvoiceId);
                    }
                } else {
                    alert('Hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Tahsilat ekleme hatası:', error);
                alert('Tahsilat eklenirken hata oluştu!');
            });
        });

        // Eksik fonksiyonları ekle
        function deleteInvoice(id) {
            if (confirm('Bu faturayı silmek istediğinizden emin misiniz?')) {
                const formData = new FormData();
                formData.append('action', 'delete_invoice');
                formData.append('invoice_id', id);
                
                fetch('includes/invoice_operations.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Fatura başarıyla silindi!');
                        loadInvoices(); // Tabloyu yenile
                    } else {
                        alert('Hata: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Fatura silme hatası:', error);
                    alert('Fatura silinirken hata oluştu!');
                });
            }
        }

        // Müşteri ekleme form submit
        document.getElementById('customerForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            formData.append('action', 'add_customer');
            
            fetch('includes/invoice_operations.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Müşteri başarıyla eklendi!');
                    this.reset();
                    const modal = bootstrap.Modal.getInstance(document.getElementById('customerModal'));
                    modal.hide();
                    loadCustomers(); // Müşteri listesini yenile
                } else {
                    alert('Hata: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Müşteri ekleme hatası:', error);
                alert('Müşteri eklenirken hata oluştu!');
            });
        });

        // CSV Export fonksiyonu
        function exportCSV() {
            const filters = getActiveFilters();
            let url = 'includes/invoice_operations.php?action=export_csv';
            
            Object.keys(filters).forEach(key => {
                if (filters[key]) {
                    url += `&${key}=${encodeURIComponent(filters[key])}`;
                }
            });
            
            window.open(url, '_blank');
        }

        // Aktif filtreleri al
        function getActiveFilters() {
            return {
                invoice_no: document.getElementById('filterInvoiceNo')?.value || '',
                receipt_no: document.getElementById('filterReceiptNo')?.value || '',
                customer_name: document.getElementById('filterCustomer')?.value || '',
                vehicle_id: document.getElementById('filterVehicle')?.value || '',
                vehicle_category: document.getElementById('filterVehicleCategory')?.value || '',
                start_date: document.getElementById('filterStartDate')?.value || '',
                end_date: document.getElementById('filterEndDate')?.value || '',
                status: document.getElementById('filterStatus')?.value || ''
            };
        }

        // Filtreleri temizle
        function clearFilters() {
            const filterElements = [
                'filterInvoiceNo', 'filterReceiptNo', 'filterCustomer', 
                'filterVehicle', 'filterVehicleCategory', 'filterStartDate', 
                'filterEndDate', 'filterStatus'
            ];
            
            filterElements.forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    element.value = '';
                }
            });
            
            loadInvoices(); // Filtresiz listeyi yükle
        }

        // Filtreleri uygula
        function applyFilters() {
            const filters = getActiveFilters();
            loadInvoices(filters);
        }

        // Fatura yazdırma fonksiyonları
        function printInvoice() {
            if (currentInvoiceId) {
                printInvoiceDirect(currentInvoiceId);
            }
        }

        function printInvoiceDirect(invoiceId) {
            const url = `includes/pdf_generator.php?action=generate_pdf&invoice_id=${invoiceId}`;
            window.open(url, '_blank');
        }

        // Sayfa yüklendiğinde çalıştır
        document.addEventListener('DOMContentLoaded', function() {
            loadCustomers();
            loadVehicles();
            loadPersonnel();
            loadInvoices();
            
            // Filter event listeners ekle
            const filterElements = [
                'filterInvoiceNo', 'filterReceiptNo', 'filterCustomer', 
                'filterVehicle', 'filterVehicleCategory', 'filterStartDate', 
                'filterEndDate', 'filterStatus'
            ];
            
            filterElements.forEach(id => {
                const element = document.getElementById(id);
                if (element) {
                    if (element.type === 'text' || element.type === 'date') {
                        element.addEventListener('input', function() {
                            // Debounce için timeout kullan
                            clearTimeout(this.filterTimeout);
                            this.filterTimeout = setTimeout(() => {
                                applyFilters();
                            }, 500);
                        });
                    } else if (element.tagName === 'SELECT') {
                        element.addEventListener('change', applyFilters);
                    }
                }
            });
        });
    </script>

<?php include 'includes/footer.php'; ?>