<?php
// Include configuration and authentication
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Check if user is logged in and has admin privileges
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    die('Erişim reddedildi. Bu işlem için yönetici yetkisi gereklidir.');
}

// Set page title and include header
$page_title = 'Personel Tabloları Kurulumu';
include 'includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Personel Yönetim Sistemi - Veritabanı Kurulumu</h5>
                    <p class="card-subtitle text-muted">Aşağıdaki tablolar oluşturulacak veya güncellenecektir.</p>
                </div>
                <div class="card-body">
                    <?php
                    // Read SQL file
                    $sql_file = __DIR__ . '/database/personel_yonetim_sistemi.sql';
                    
                    if (!file_exists($sql_file)) {
                        echo '<div class="alert alert-danger">SQL dosyası bulunamadı: ' . $sql_file . '</div>';
                    } else {
                        $sql = file_get_contents($sql_file);
                        
                        // Remove comments and split into individual queries
                        $queries = array_filter(
                            array_map('trim', 
                                preg_split("/\r\n|\r|\n/" , 
                                    preg_replace(
                                        ['/--.*?\n/', '/\/\*.*?\*\//s'], 
                                        '', 
                                        $sql
                                    )
                                )
                            ),
                            function($query) {
                                return !empty($query);
                            }
                        );
                        
                        // Execute queries
                        $success_count = 0;
                        $error_count = 0;
                        $errors = [];
                        
                        echo '<div class="table-responsive">';
                        echo '<table class="table table-sm table-bordered table-hover">';
                        echo '<thead class="table-light">';
                        echo '<tr><th>#</th><th>Sorgu</th><th>Durum</th><th>Hata</th></tr>';
                        echo '</thead><tbody>';
                        
                        $pdo->beginTransaction();
                        
                        try {
                            foreach ($queries as $i => $query) {
                                if (empty(trim($query))) continue;
                                
                                $query_short = (strlen($query) > 100) ? substr($query, 0, 100) . '...' : $query;
                                
                                echo '<tr>';
                                echo '<td>' . ($i + 1) . '</td>';
                                echo '<td><code>' . htmlspecialchars($query_short) . '</code></td>';
                                
                                try {
                                    $pdo->exec($query);
                                    echo '<td><span class="badge bg-success">Başarılı</span></td>';
                                    echo '<td>-</td>';
                                    $success_count++;
                                } catch (PDOException $e) {
                                    echo '<td><span class="badge bg-danger">Hata</span></td>';
                                    echo '<td><small class="text-danger">' . htmlspecialchars($e->getMessage()) . '</small></td>';
                                    $error_count++;
                                    $errors[] = 'Sorgu #' . ($i + 1) . ': ' . $e->getMessage();
                                }
                                
                                echo '</tr>';
                            }
                            
                            $pdo->commit();
                            
                        } catch (Exception $e) {
                            $pdo->rollBack();
                            echo '<tr><td colspan="4" class="text-center text-danger"><strong>İşlem iptal edildi:</strong> ' . htmlspecialchars($e->getMessage()) . '</td></tr>';
                        }
                        
                        echo '</tbody></table>';
                        echo '</div>';
                        
                        // Show summary
                        echo '<div class="alert ' . ($error_count > 0 ? 'alert-warning' : 'alert-success') . ' mt-4">';
                        echo '<h5 class="alert-heading">Kurulum Tamamlandı</h5>';
                        echo '<p>Toplam <strong>' . count($queries) . '</strong> sorgudan <strong>' . $success_count . '</strong> tanesi başarıyla çalıştırıldı.';
                        
                        if ($error_count > 0) {
                            echo ' <strong>' . $error_count . '</strong> sorgu hata verdi.';
                            echo '<hr>';
                            echo '<h6>Hatalar:</h6>';
                            echo '<ul class="mb-0">';
                            foreach ($errors as $error) {
                                echo '<li>' . htmlspecialchars($error) . '</li>';
                            }
                            echo '</ul>';
                        }
                        
                        echo '</p>';
                        echo '</div>';
                        
                        // Show next steps
                        if ($error_count === 0) {
                            echo '<div class="alert alert-info">';
                            echo '<h5 class="alert-heading">Sonraki Adımlar</h5>';
                            echo '<ol class="mb-0">';
                            echo '<li>Personel yönetim sistemini kullanmaya başlayabilirsiniz.</li>';
                            echo '<li>Güvenlik nedeniyle bu kurulum dosyasını sunucudan kaldırmanız önerilir.</li>';
                            echo '</ol>';
                            echo '</div>';
                            
                            // Create uploads directory if it doesn't exist
                            $upload_dir = __DIR__ . '/uploads/documents';
                            if (!file_exists($upload_dir)) {
                                if (mkdir($upload_dir, 0755, true)) {
                                    echo '<div class="alert alert-success">Dosya yükleme dizini başarıyla oluşturuldu: <code>' . htmlspecialchars($upload_dir) . '</code></div>';
                                } else {
                                    echo '<div class="alert alert-warning">Dosya yükleme dizini oluşturulamadı. Lütfen manuel olarak oluşturun: <code>' . htmlspecialchars($upload_dir) . '</code></div>';
                                }
                            }
                        }
                    }
                    ?>
                </div>
                <div class="card-footer text-end">
                    <a href="personel2.php" class="btn btn-primary">Personel Yönetimine Dön</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
