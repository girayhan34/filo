<?php
require_once __DIR__ . '/BaseApiController.php';

class PersonelApiController extends BaseApiController {

    protected function processRequest(): void {
        $action = $_GET['action'] ?? 'list';

        switch ($action) {
            case 'list':
                $this->listPersonnel();
                break;
            case 'get_details':
                $this->getPersonnelDetails();
                break;
            case 'update_contact':
                $this->updateContactDetails();
                break;
            // Diğer personel işlemleri (create, update, delete) buraya eklenebilir.
            default:
                $this->sendError('Geçersiz eylem.', 400);
                break;
        }
    }

    private function listPersonnel() {
        $this->checkPermission('personel:goruntule');

        $draw = intval($this->requestData['draw'] ?? 1);
        $start = intval($this->requestData['start'] ?? 0);
        $length = intval($this->requestData['length'] ?? 10);
        $searchValue = $this->requestData['search']['value'] ?? '';
        // Gelişmiş filtre parametreleri
        $statusFilter = $this->requestData['status'] ?? '';
        $departmentFilter = $this->requestData['department'] ?? '';
        $positionFilter = $this->requestData['position'] ?? '';

        // Güvenli sıralama için sütunları beyaz listeye alalım
        $allowedOrderColumns = [
            0 => 'p.name',
            1 => 'p.position',
            2 => 'p.phone',
            3 => 'p.status',
            4 => 'p.last_shift_date'
        ];
        $orderColumnIndex = intval($this->requestData['order'][0]['column'] ?? 0);
        $orderDir = $this->requestData['order'][0]['dir'] ?? 'asc';
        $orderColumn = $allowedOrderColumns[$orderColumnIndex] ?? 'p.name';

        // Temel sorgu
        $baseQuery = "FROM personnel p
                      LEFT JOIN (SELECT personnel_id, MAX(shift_date) as last_shift_date FROM personnel_shifts GROUP BY personnel_id) ps ON p.id = ps.personnel_id
                      LEFT JOIN (SELECT personnel_id, AVG(performance_score) as avg_performance FROM personnel_performance GROUP BY personnel_id) pp ON p.id = pp.personnel_id
                      LEFT JOIN departmanlar d ON p.departman_id = d.id
                      LEFT JOIN (SELECT personnel_id, COUNT(id) as document_count FROM personnel_documents GROUP BY personnel_id) pd ON p.id = pd.personnel_id";
        
        $whereClause = " WHERE p.status != 'deleted'";
        $params = [];

        // Arama filtresi
        if (!empty($searchValue)) {
            $whereClause .= " AND (p.ad LIKE :search OR p.soyad LIKE :search OR p.pozisyon LIKE :search OR p.email LIKE :search OR p.telefon LIKE :search OR d.departman_adi LIKE :search)";
            $params[':search'] = "%$searchValue%";
        }

        // Gelişmiş filtreleri uygula
        if (!empty($statusFilter)) {
            $whereClause .= " AND p.status = :status";
            $params[':status'] = $statusFilter;
        }

        if (!empty($departmentFilter)) {
            $whereClause .= " AND p.department = :department";
            $params[':department'] = $departmentFilter;
        }

        if (!empty($positionFilter)) {
            $whereClause .= " AND p.position = :position";
            $params[':position'] = $positionFilter;
        }

        // Toplam kayıt sayısı
        $totalRecordsStmt = $this->pdo->prepare("SELECT COUNT(p.id) FROM personnel p WHERE p.status != 'deleted'");
        $totalRecordsStmt->execute();
        $totalRecords = $totalRecordsStmt->fetchColumn();

        // Filtrelenmiş kayıt sayısı
        $filteredRecordsStmt = $this->pdo->prepare("SELECT COUNT(p.id) " . $baseQuery . $whereClause);
        $filteredRecordsStmt->execute($params);
        $recordsFiltered = $filteredRecordsStmt->fetchColumn();

        // Veriyi çek
        $dataQuery = "SELECT p.*, d.departman_adi, ps.last_shift_date, pp.avg_performance, pd.document_count " . $baseQuery . $whereClause . " ORDER BY $orderColumn $orderDir LIMIT :start, :length";
        $dataStmt = $this->pdo->prepare($dataQuery);
        
        foreach ($params as $key => &$val) {
            $dataStmt->bindParam($key, $val);
        }
        $dataStmt->bindParam(':start', $start, PDO::PARAM_INT);
        $dataStmt->bindParam(':length', $length, PDO::PARAM_INT);
        $dataStmt->execute();
        $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

        $response = [
            "draw" => $draw,
            "recordsTotal" => $totalRecords,
            "recordsFiltered" => $recordsFiltered,
            "data" => $data
        ];

        $this->sendSuccess($response);
    }

    private function getPersonnelDetails() {
        $this->checkPermission('personel:goruntule');

        $rules = ['id' => 'required|numeric'];
        $validatedData = $this->validate($this->requestData, $rules);
        $personnelId = intval($validatedData['id']);

        // Temel Personel Bilgileri
        $stmt = $this->pdo->prepare("SELECT * FROM personnel WHERE id = ?");
        $stmt->execute([$personnelId]);
        $personnel = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$personnel) {
            throw new Exception('Personel bulunamadı!', 404);
        }

        // Son 5 İzin Kaydı
        $stmt = $this->pdo->prepare("
            SELECT * FROM personel_izinleri 
            WHERE personel_id = ? 
            ORDER BY baslangic_tarihi DESC 
            LIMIT 5
        ");
        $stmt->execute([$personnelId]);
        $leaves = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Son 5 Performans Kaydı
        $stmt = $this->pdo->prepare("
            SELECT pd.*, CONCAT(p.ad, ' ', p.soyad) as degerlendiren_adi 
            FROM personel_performanslari pd
            LEFT JOIN personel p ON pd.degerlendiren_id = p.id
            WHERE pd.personel_id = ? 
            ORDER BY degerlendirme_tarihi DESC 
            LIMIT 5
        ");
        $stmt->execute([$personnelId]);
        $performances = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Son 5 Belge Kaydı
        $stmt = $this->pdo->prepare("
            SELECT * FROM personnel_documents 
            WHERE personnel_id = ? 
            ORDER BY uploaded_at DESC 
            LIMIT 5
        ");
        $stmt->execute([$personnelId]);
        $documents = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Son 5 Vardiya Kaydı
        $stmt = $this->pdo->prepare("
            SELECT ps.*, v.plate_number 
            FROM personnel_shifts ps
            LEFT JOIN vehicles v ON ps.vehicle_id = v.id
            WHERE ps.personnel_id = ? 
            ORDER BY ps.shift_date DESC, ps.start_time DESC
            LIMIT 5
        ");
        $stmt->execute([$personnelId]);
        $shifts = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Son 5 Maaş/Bordro Kaydı
        $stmt = $this->pdo->prepare("
            SELECT * FROM personel_maaslari
            WHERE personel_id = ? 
            ORDER BY donem_yil DESC, donem_ay DESC
            LIMIT 5
        ");
        $stmt->execute([$personnelId]);
        $salaries = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $response = [
            'details' => $personnel,
            'leaves' => $leaves,
            'performances' => $performances,
            'documents' => $documents,
            'shifts' => $shifts,
            'salaries' => $salaries
        ];

        $this->sendSuccess($response, 'Personel detayları başarıyla getirildi.');
    }

    private function updateContactDetails() {
        $this->checkPermission('personel:duzenle');

        $rules = [
            'id' => 'required|numeric',
            'email' => 'email',
            'phone' => 'min:10'
        ];
        $validatedData = $this->validate($this->requestData, $rules);
        $personnelId = intval($validatedData['id']);

        $personnel = Izin::find($personnelId, 'personnel'); // Using a generic find from a model
        if (!$personnel) {
            throw new Exception('Personel bulunamadı!', 404);
        }

        $updateData = [
            'email' => $validatedData['email'] ?? $personnel->email,
            'phone' => $validatedData['phone'] ?? $personnel->phone,
            'address' => $validatedData['address'] ?? $personnel->address
        ];

        if (!$personnel->update($updateData)) {
            throw new Exception('İletişim bilgileri güncellenirken bir veritabanı hatası oluştu.', 500);
        }

        $this->sendSuccess([], 'İletişim bilgileri başarıyla güncellendi.');
    }
}

$controller = new PersonelApiController();
$controller->handleRequest();