<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

if ($_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok.']);
    exit;
}

try {
    $pdo = getPDO();

    switch ($action) {
        case 'update_permissions':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Geçersiz istek metodu.');
            }

            $permissions = $_POST['permissions'] ?? [];
            
            $pdo->beginTransaction();

            // Önce tüm mevcut izinleri temizle
            $pdo->exec("DELETE FROM role_permissions");

            // Yeni izinleri ekle
            $stmt = $pdo->prepare("INSERT INTO role_permissions (role_id, permission_id) VALUES (?, ?)");
            foreach ($permissions as $role_id => $perms) {
                foreach ($perms as $permission_id => $value) {
                    if ($value == '1') {
                        $stmt->execute([$role_id, $permission_id]);
                    }
                }
            }

            $pdo->commit();
            $response = ['status' => 'success', 'message' => 'İzinler başarıyla güncellendi.'];
            break;

        case 'create_role':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['role_name'])) {
                throw new Exception('Geçersiz istek veya eksik rol adı.');
            }

            $sql = "INSERT INTO roles (role_name, description) VALUES (:role_name, :description)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':role_name' => $_POST['role_name'],
                ':description' => $_POST['description'] ?? null
            ]);

            $response = ['status' => 'success', 'message' => 'Yeni rol başarıyla oluşturuldu.'];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>