<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// JSON yanıtı için dizi oluştur
$response = array('success' => false, 'message' => '');

// Yetki kontrolü - Sadece adminler toplu silme yapabilir
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    $response['message'] = 'Bu işlem için yetkiniz yok! Sadece yöneticiler toplu personel silebilir.';
    echo json_encode($response);
    exit;
}

try {
    // Gelen verileri al
    $personel_ids = isset($_POST['personel_ids']) ? $_POST['personel_ids'] : [];
    
    // Doğrulamalar
    if (empty($personel_ids) || !is_array($personel_ids)) {
        throw new Exception('Lütfen silinecek en az bir personel seçin!');
    }
    
    // ID'leri güvenli hale getir
    $personel_ids = array_map('intval', $personel_ids);
    $placeholders = rtrim(str_repeat('?,', count($personel_ids)), ',');
    
    // Önce silinecek personel bilgilerini al (loglama için)
    $stmt = $pdo->prepare("SELECT id, ad, soyad, personel_no FROM personel WHERE id IN ($placeholders)");
    $stmt->execute($personel_ids);
    $silinecek_personeller = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($silinecek_personeller)) {
        throw new Exception('Belirtilen personeller bulunamadı!');
    }
    
    // Silme işlemi
    $stmt = $pdo->prepare("DELETE FROM personel WHERE id IN ($placeholders)");
    $stmt->execute($personel_ids);
    $affected_rows = $stmt->rowCount();
    
    // İşlem başarılı
    $response['success'] = true;
    $response['message'] = $affected_rows . ' personel başarıyla silindi.';
    $response['affected_rows'] = $affected_rows;
    
    // Silinen personellerin listesini de dönebiliriz (isteğe bağlı)
    $response['silinen_personeller'] = array_map(function($p) {
        return [
            'id' => $p['id'],
            'ad' => $p['ad'],
            'soyad' => $p['soyad'],
            'personel_no' => $p['personel_no']
        ];
    }, $silinecek_personeller);
    
} catch (PDOException $e) {
    $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>
