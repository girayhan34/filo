<?php
require_once __DIR__ . '/BaseApiController.php';
require_once __DIR__ . '/../models/Izin.php';

class IzinOnaylaController extends BaseApiController {

    protected function processRequest(): void {
        if ($this->method !== 'POST') {
            $this->sendError('Geçersiz istek metodu.', 405);
            return;
        }

        // 1. Yetki Kontrolü
        $this->checkPermission('izinler:onayla');

        // 2. Veri Doğrulama
        $rules = ['id' => 'required|numeric'];
        $validatedData = $this->validate($this->requestData, $rules);

        $izin_id = intval($validatedData['id']);
        $aciklama = $validatedData['aciklama'] ?? null;

        // 3. İş Mantığı (Business Logic)
        $izin = Izin::find($izin_id);

        if (!$izin) {
            throw new Exception('Onaylanacak izin kaydı bulunamadı!', 404);
        }

        if ($izin->durum !== 'Onay Bekliyor') {
            throw new Exception('Bu izin zaten daha önce işlem görmüş!', 409);
        }

        // 4. Veritabanı İşlemi (Model kullanarak)
        // Not: Bu kısım, veritabanı transaction'ı gerektirebilir.
        // Şimdilik adımları ayrı ayrı yapıyoruz.
        
        $updateData = [
            'durum' => 'Onaylandı',
            'izin_veren_id' => $this->kullanici_id,
            'onay_red_aciklama' => $aciklama,
            'guncelleme_tarihi' => date('Y-m-d H:i:s')
        ];

        if (!$izin->update($updateData)) {
            throw new Exception('İzin güncellenirken bir veritabanı hatası oluştu.', 500);
        }

        // TODO: İzin kullanımını güncelle (personel_izin_haklari tablosu)
        // Bu kısım için ayrı bir metot veya servis sınıfı oluşturulabilir.
        // Örneğin: IzinHakki::kullanimiGuncelle($izin);

        // TODO: İşlem geçmişine kaydet (loglama)
        // Loglama için de ayrı bir servis kullanılabilir.

        // 5. Başarılı Yanıt Gönderme
        $this->sendSuccess([], 'İzin başarıyla onaylandı.');
    }
}

$controller = new IzinOnaylaController();
$controller->handleRequest();
