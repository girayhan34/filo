<?php

abstract class BaseModel {
    protected static PDO $pdo;
    protected static string $tableName;
    protected array $attributes = [];

    /**
     * Doldurulmasına izin verilen sütunlar. Mass assignment'a karşı koruma sağlar.
     * @var array
     */
    protected array $fillable = [];

    public function __construct(array $attributes = []) {
        if (!isset(self::$pdo)) {
            self::$pdo = getPDO();
        }
        $this->fill($attributes);
    }

    /**
     * Verilen ID'ye sahip kaydı bulur.
     * @param int $id
     * @return static|null
     */
    public static function find(int $id): ?static {
        if (!isset(self::$pdo)) {
            self::$pdo = getPDO();
        }
        $stmt = self::$pdo->prepare("SELECT * FROM " . static::$tableName . " WHERE id = ?");
        $stmt->execute([$id]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        return $data ? new static($data) : null;
    }

    /**
     * Yeni bir kayıt oluşturur.
     * @param array $data
     * @return static|null
     */
    public static function create(array $data): ?static {
        if (!isset(self::$pdo)) {
            self::$pdo = getPDO();
        }

        $instance = new static();
        $fillableData = array_intersect_key($data, array_flip($instance->fillable));

        $columns = implode(', ', array_keys($fillableData));
        $placeholders = ':' . implode(', :', array_keys($fillableData));

        $sql = "INSERT INTO " . static::$tableName . " ($columns) VALUES ($placeholders)";
        $stmt = self::$pdo->prepare($sql);

        if ($stmt->execute($fillableData)) {
            $id = self::$pdo->lastInsertId();
            return static::find($id);
        }

        return null;
    }

    /**
     * Mevcut kaydı günceller.
     * @param array $data
     * @return bool
     */
    public function update(array $data): bool {
        $fillableData = array_intersect_key($data, array_flip($this->fillable));
        
        if (empty($fillableData)) {
            return false;
        }

        $setClauses = [];
        foreach ($fillableData as $key => $value) {
            $setClauses[] = "$key = :$key";
        }

        $sql = "UPDATE " . static::$tableName . " SET " . implode(', ', $setClauses) . " WHERE id = :id";
        $stmt = self::$pdo->prepare($sql);

        $fillableData['id'] = $this->attributes['id'];
        return $stmt->execute($fillableData);
    }

    /**
     * Kaydı siler.
     * @return bool
     */
    public function delete(): bool {
        $sql = "DELETE FROM " . static::$tableName . " WHERE id = :id";
        $stmt = self::$pdo->prepare($sql);
        return $stmt->execute([':id' => $this->attributes['id']]);
    }

    /**
     * Modelin özelliklerini doldurur.
     * @param array $attributes
     */
    public function fill(array $attributes): void {
        foreach ($attributes as $key => $value) {
            $this->setAttribute($key, $value);
        }
    }

    public function __get(string $name) {
        return $this->attributes[$name] ?? null;
    }

    public function __set(string $name, $value): void {
        $this->setAttribute($name, $value);
    }

    private function setAttribute(string $key, $value): void {
        $this->attributes[$key] = $value;
    }
}