<?php
require_once __DIR__ . '/BaseApiController.php';
require_once __DIR__ . '/../models/Izin.php';

class IzinSilController extends BaseApiController {

    protected function processRequest(): void {
        if ($this->method !== 'POST') {
            $this->sendError('Geçersiz istek metodu.', 405);
            return;
        }

        // 1. Yetki Kontrolü
        $this->checkPermission('izinler:sil');

        // 2. Veri Doğrulama
        $rules = ['id' => 'required|numeric'];
        $validatedData = $this->validate($this->requestData, $rules);

        $izin_id = intval($validatedData['id']);

        // 3. İş Mantığı (Business Logic)
        $izin = Izin::find($izin_id);

        if (!$izin) {
            throw new Exception('Silinecek izin kaydı bulunamadı!', 404);
        }

        // Onaylanmış bir iznin silinip silinemeyeceği iş kuralına bağlıdır.
        // Örneğin, sadece 'Onay Bekliyor' durumundaki izinler silinebilir.
        if ($izin->durum === 'Onaylandı') {
            // throw new Exception('Onaylanmış izinler silinemez. Lütfen önce iptal ediniz.', 409);
        }

        // 4. Veritabanı İşlemi (Model kullanarak)
        if (!$izin->delete()) {
            throw new Exception('İzin silinirken bir veritabanı hatası oluştu.', 500);
        }

        // 5. Başarılı Yanıt Gönderme
        $this->sendSuccess([], 'İzin kaydı başarıyla silindi.');
    }
}

$controller = new IzinSilController();
$controller->handleRequest();