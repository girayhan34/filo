<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

// Get POST data
$personnel_id = isset($_POST['personnel_id']) ? (int)$_POST['personnel_id'] : 0;
$document_type = isset($_POST['document_type']) ? trim($_POST['document_type']) : '';
$notes = isset($_POST['document_notes']) ? trim($_POST['document_notes']) : '';

// Validate input
if ($personnel_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz personel ID.']);
    exit;
}

// Check if file was uploaded without errors
if (!isset($_FILES['document_file']) || $_FILES['document_file']['error'] !== UPLOAD_ERR_OK) {
    $error = $_FILES['document_file']['error'] ?? 'Bilinmeyen hata';
    echo json_encode(['success' => false, 'message' => 'Dosya yüklenirken hata oluştu: ' . $error]);
    exit;
}

// File upload configuration
$upload_dir = '../uploads/documents/';
$allowed_types = ['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'image/jpeg', 'image/png'];
$max_size = 5 * 1024 * 1024; // 5MB

// Create upload directory if it doesn't exist
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Get file info
$file = $_FILES['document_file'];
$file_name = $file['name'];
$file_tmp = $file['tmp_name'];
$file_size = $file['size'];
$file_type = $file['type'];
$file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

// Validate file type
if (!in_array($file_type, $allowed_types)) {
    echo json_encode(['success' => false, 'message' => 'İzin verilmeyen dosya türü. Sadece PDF, DOC, DOCX, JPG ve PNG dosyaları yükleyebilirsiniz.']);
    exit;
}

// Validate file size
if ($file_size > $max_size) {
    echo json_encode(['success' => false, 'message' => 'Dosya boyutu çok büyük. Maksimum 5MB boyutunda dosya yükleyebilirsiniz.']);
    exit;
}

// Generate unique filename
$new_filename = 'doc_' . $personnel_id . '_' . time() . '.' . $file_ext;
$upload_path = $upload_dir . $new_filename;

// Upload file
if (!move_uploaded_file($file_tmp, $upload_path)) {
    echo json_encode(['success' => false, 'message' => 'Dosya yüklenirken bir hata oluştu.']);
    exit;
}

try {
    // Insert document record to database
    $stmt = $pdo->prepare("INSERT INTO personnel_documents (personnel_id, document_type, file_name, file_path, notes, uploaded_by, uploaded_at) 
                           VALUES (?, ?, ?, ?, ?, ?, NOW())");
    
    $stmt->execute([
        $personnel_id,
        $document_type,
        $file_name,
        'uploads/documents/' . $new_filename,
        $notes,
        $_SESSION['user_id']
    ]);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Belge başarıyla yüklendi.',
        'document_id' => $pdo->lastInsertId()
    ]);
    
} catch (PDOException $e) {
    // Delete the uploaded file if database insert fails
    if (file_exists($upload_path)) {
        unlink($upload_path);
    }
    
    echo json_encode([
        'success' => false, 
        'message' => 'Veritabanı hatası: ' . $e->getMessage()
    ]);
}
