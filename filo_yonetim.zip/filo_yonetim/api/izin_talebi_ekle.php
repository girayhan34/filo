<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// JSON yanıtı için başlık
header('Content-Type: application/json');

// Yetki kontrolü - Personeller kendileri için izin talebinde bulunabilir
$kullanici_id = $_SESSION['user_id'];
$yetkili_roller = ['admin', 'ik'];
$yetkili_mi = in_array($_SESSION['user_role'], $yetkili_roller);

if (!isset($_SESSION['user_id']) && !$yetkili_mi) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok!']);
    exit;
}

// Hata mesajları dizisi
$errors = [];

// Gerekli alanlar
$requiredFields = [
    'personel_id' => 'Personel',
    'izin_tipi' => 'İzin Tipi',
    'baslangic_tarihi' => 'Başlangıç Tarihi',
    'bitis_tarihi' => 'Bitiş Tarihi'
];

// Zorunlu alanları kontrol et
foreach ($requiredFields as $field => $label) {
    if (empty($_POST[$field])) {
        $errors[] = "$label alanı zorunludur.";
    }
}

// Hata varsa dön
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $errors]);
    exit;
}

// Verileri al ve temizle
$personel_id = intval($_POST['personel_id']);
$izin_tipi = trim($_POST['izin_tipi']);
$baslangic_tarihi = date('Y-m-d', strtotime($_POST['baslangic_tarihi']));
$bitis_tarihi = date('Y-m-d', strtotime($_POST['bitis_tarihi']));
$aciklama = !empty($_POST['aciklama']) ? trim($_POST['aciklama']) : null;

// Eğer yetkili değilse, sadece kendi adına izin talep edebilir
if (!$yetkili_mi && $personel_id != $kullanici_id) {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Sadece kendi adınıza izin talebinde bulunabilirsiniz!']);
    exit;
}

// Tarih kontrolü
if (strtotime($baslangic_tarihi) > strtotime($bitis_tarihi)) {
    $errors[] = "Bitiş tarihi, başlangıç tarihinden önce olamaz.";
}

// İzin gün sayısını hesapla
$gun_sayisi = (strtotime($bitis_tarihi) - strtotime($baslangic_tarihi)) / (60 * 60 * 24) + 1;

// Geçmiş tarih kontrolü
if (strtotime($baslangic_tarihi) < strtotime(date('Y-m-d'))) {
    $errors[] = "Geçmiş tarih için izin talebinde bulunamazsınız.";
}

// Aynı tarih aralığında başka bir izin talebi var mı kontrol et
$sql = "SELECT COUNT(*) FROM personel_izinleri 
        WHERE personel_id = :personel_id 
        AND (
            (:baslangic_tarihi BETWEEN baslangic_tarihi AND bitis_tarihi) OR
            (:bitis_tarihi BETWEEN baslangic_tarihi AND bitis_tarihi) OR
            (baslangic_tarihi BETWEEN :baslangic_tarihi2 AND :bitis_tarihi2) OR
            (bitis_tarihi BETWEEN :baslangic_tarihi3 AND :bitis_tarihi3)
        )
        AND durum != 'Reddedildi'";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ':personel_id' => $personel_id,
    ':baslangic_tarihi' => $baslangic_tarihi,
    ':bitis_tarihi' => $bitis_tarihi,
    ':baslangic_tarihi2' => $baslangic_tarihi,
    ':bitis_tarihi2' => $bitis_tarihi,
    ':baslangic_tarihi3' => $baslangic_tarihi,
    ':bitis_tarihi3' => $bitis_tarihi
]);

$conflictingLeaves = $stmt->fetchColumn();

if ($conflictingLeaves > 0) {
    $errors[] = "Belirtilen tarih aralığında zaten bir izin talebiniz bulunmaktadır.";
}

// Yıllık izin kontrolü
if ($izin_tipi === 'Yıllık İzin') {
    // Personelin yıllık izin hakkını kontrol et
    $sql = "SELECT 
                yillik_izin_hakki,
                (SELECT COALESCE(SUM(toplam_gun), 0) 
                 FROM personel_izinleri 
                 WHERE personel_id = :personel_id 
                 AND izin_tipi = 'Yıllık İzin' 
                 AND durum = 'Onaylandı'
                 AND YEAR(baslangic_tarihi) = YEAR(CURDATE())) as kullanilan_izin
            FROM personel 
            WHERE id = :personel_id2";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':personel_id' => $personel_id,
        ':personel_id2' => $personel_id
    ]);
    $izin_bilgisi = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $kalan_izin = $izin_bilgisi['yillik_izin_hakki'] - $izin_bilgisi['kullanilan_izin'];
    
    if ($gun_sayisi > $kalan_izin) {
        $errors[] = "Yeterli yıllık izin hakkınız bulunmamaktadır. Kalan izin hakkınız: $kalan_izin gün";
    }
}

// Hata varsa dön
if (!empty($errors)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $errors]);
    exit;
}

try {
    // İzin talebini veritabanına ekle
    $sql = "INSERT INTO personel_izinleri (
                personel_id, 
                izin_tipi, 
                baslangic_tarihi, 
                bitis_tarihi, 
                toplam_gun, 
                aciklama, 
                durum,
                created_by
            ) VALUES (
                :personel_id, 
                :izin_tipi, 
                :baslangic_tarihi, 
                :bitis_tarihi, 
                :toplam_gun, 
                :aciklama, 
                :durum,
                :created_by
            )";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':personel_id' => $personel_id,
        ':izin_tipi' => $izin_tipi,
        ':baslangic_tarihi' => $baslangic_tarihi,
        ':bitis_tarihi' => $bitis_tarihi,
        ':toplam_gun' => $gun_sayisi,
        ':aciklama' => $aciklama,
        ':durum' => $yetkili_mi ? 'Onaylandı' : 'Beklemede',
        ':created_by' => $kullanici_id
    ]);
    
    $izin_id = $pdo->lastInsertId();
    
    // Eğer yetkili biri tarafından doğrudan onaylandıysa, onaylayan bilgisini güncelle
    if ($yetkili_mi) {
        $sql = "UPDATE personel_izinleri 
                SET onaylayan_id = :onaylayan_id, 
                    onay_tarihi = NOW(),
                    updated_at = NOW()
                WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':onaylayan_id' => $kullanici_id,
            ':id' => $izin_id
        ]);
        
        // Personelin toplam kullanılan izin gününü güncelle
        if ($izin_tipi === 'Yıllık İzin') {
            $sql = "UPDATE personel 
                    SET kullanilan_yillik_izin = kullanilan_yillik_izin + :gun_sayisi,
                        updated_at = NOW()
                    WHERE id = :personel_id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':gun_sayisi' => $gun_sayisi,
                ':personel_id' => $personel_id
            ]);
        }
    }
    
    // Başarılı yanıt dön
    echo json_encode([
        'status' => 'success', 
        'message' => $yetkili_mi ? 'İzin başarıyla eklendi.' : 'İzin talebiniz alındı. Onay bekliyor.',
        'data' => ['id' => $izin_id]
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>
