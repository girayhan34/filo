<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            $draw = intval($_POST['draw'] ?? 1);
            $start = intval($_POST['start'] ?? 0);
            $length = intval($_POST['length'] ?? 10);
            $searchValue = $_POST['search']['value'] ?? '';

            $totalRecords = $pdo->query("SELECT COUNT(id) FROM stock_items")->fetchColumn();

            $queryFiltered = "SELECT COUNT(s.id) FROM stock_items s WHERE s.item_name LIKE :search OR s.item_code LIKE :search OR s.category LIKE :search";
            $stmtFiltered = $pdo->prepare($queryFiltered);
            $stmtFiltered->execute([':search' => "%$searchValue%"]);
            $recordsFiltered = $stmtFiltered->fetchColumn();

            $queryData = "SELECT s.*, u.name as updated_by_name 
                          FROM stock_items s
                          LEFT JOIN users u ON s.last_updated_by = u.id
                          WHERE s.item_name LIKE :search OR s.item_code LIKE :search OR s.category LIKE :search
                          ORDER BY s.item_name ASC
                          LIMIT :start, :length";
            
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':search', "%$searchValue%", PDO::PARAM_STR);
            $stmtData->bindValue(':start', (int)$start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', (int)$length, PDO::PARAM_INT);
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                "draw" => $draw,
                "recordsTotal" => intval($totalRecords),
                "recordsFiltered" => intval($recordsFiltered),
                "data" => $data
            ];
            break;

        case 'create':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Geçersiz istek metodu.');
            }

            $sql = "INSERT INTO stock_items (item_name, item_code, category, quantity, unit, location, min_stock_level, last_updated_by) 
                    VALUES (:item_name, :item_code, :category, :quantity, :unit, :location, :min_stock_level, :last_updated_by)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':item_name' => $_POST['item_name'],
                ':item_code' => $_POST['item_code'] ?: null,
                ':category' => $_POST['category'] ?: null,
                ':quantity' => intval($_POST['quantity']),
                ':unit' => $_POST['unit'],
                ':location' => $_POST['location'] ?: null,
                ':min_stock_level' => intval($_POST['min_stock_level']),
                ':last_updated_by' => $_SESSION['user_id']
            ]);

            $response = ['status' => 'success', 'message' => 'Stok kalemi başarıyla eklendi.'];
            break;

        case 'get_item':
            if (!isset($_GET['id'])) {
                throw new Exception('Stok ID belirtilmedi.');
            }
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("SELECT * FROM stock_items WHERE id = ?");
            $stmt->execute([$id]);
            $item = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($item) {
                $response = ['status' => 'success', 'data' => $item];
            } else {
                $response = ['status' => 'error', 'message' => 'Stok kalemi bulunamadı.'];
            }
            break;

        case 'update':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }

            $id = intval($_POST['id']);
            $sql = "UPDATE stock_items SET 
                        item_name = :item_name, 
                        item_code = :item_code, 
                        category = :category, 
                        quantity = :quantity, 
                        unit = :unit, 
                        location = :location, 
                        min_stock_level = :min_stock_level, 
                        last_updated_by = :last_updated_by
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':item_name' => $_POST['item_name'],
                ':item_code' => $_POST['item_code'] ?: null,
                ':category' => $_POST['category'] ?: null,
                ':quantity' => intval($_POST['quantity']),
                ':unit' => $_POST['unit'],
                ':location' => $_POST['location'] ?: null,
                ':min_stock_level' => intval($_POST['min_stock_level']),
                ':last_updated_by' => $_SESSION['user_id']
            ]);

            $response = ['status' => 'success', 'message' => 'Stok kalemi başarıyla güncellendi.'];
            break;

        case 'delete':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }

            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("DELETE FROM stock_items WHERE id = ?");
            $stmt->execute([$id]);

            $response = ['status' => 'success', 'message' => 'Stok kalemi başarıyla silindi.'];
            break;

        case 'add_movement':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Geçersiz istek metodu.');
            }

            $pdo->beginTransaction();

            $stock_item_id = intval($_POST['stock_item_id']);
            $movement_type = $_POST['movement_type'];
            $quantity = intval($_POST['movement_quantity']);
            $notes = $_POST['movement_notes'] ?? null;
            $user_id = $_SESSION['user_id'];

            if ($quantity <= 0) {
                throw new Exception('Miktar 0\'dan büyük olmalıdır.');
            }

            // Stok hareketini kaydet
            $stmt = $pdo->prepare("INSERT INTO stock_movements (stock_item_id, movement_type, quantity, user_id, notes) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$stock_item_id, $movement_type, $quantity, $user_id, $notes]);

            // Ana stok miktarını güncelle
            if ($movement_type == 'in') {
                $updateSql = "UPDATE stock_items SET quantity = quantity + ? WHERE id = ?";
            } else {
                // Stoktan düşerken mevcut miktarın yeterli olup olmadığını kontrol et
                $currentStock = $pdo->prepare("SELECT quantity FROM stock_items WHERE id = ?");
                $currentStock->execute([$stock_item_id]);
                if ($currentStock->fetchColumn() < $quantity) {
                    throw new Exception('Yetersiz stok! Stoktan düşülecek miktar mevcut miktardan fazla olamaz.');
                }
                $updateSql = "UPDATE stock_items SET quantity = quantity - ? WHERE id = ?";
            }
            $updateStmt = $pdo->prepare($updateSql);
            $updateStmt->execute([$quantity, $stock_item_id]);

            $pdo->commit();

            $response = ['status' => 'success', 'message' => 'Stok hareketi başarıyla kaydedildi.'];
            break;

        case 'list_movements':
            $draw = intval($_POST['draw'] ?? 1);
            $start = intval($_POST['start'] ?? 0);
            $length = intval($_POST['length'] ?? 10);
            $searchValue = $_POST['search']['value'] ?? '';

            $baseQuery = "FROM stock_movements sm 
                          LEFT JOIN stock_items si ON sm.stock_item_id = si.id
                          LEFT JOIN users u ON sm.user_id = u.id";
            $whereClause = " WHERE 1=1";
            $params = [];

            // Filtreler
            if (!empty($_POST['item_id'])) {
                $whereClause .= " AND sm.stock_item_id = :item_id";
                $params[':item_id'] = $_POST['item_id'];
            }
            if (!empty($_POST['movement_type'])) {
                $whereClause .= " AND sm.movement_type = :movement_type";
                $params[':movement_type'] = $_POST['movement_type'];
            }
            if (!empty($_POST['start_date']) && !empty($_POST['end_date'])) {
                $whereClause .= " AND sm.movement_date BETWEEN :start_date AND :end_date";
                $params[':start_date'] = $_POST['start_date'] . ' 00:00:00';
                $params[':end_date'] = $_POST['end_date'] . ' 23:59:59';
            }

            $totalRecords = $pdo->query("SELECT COUNT(id) FROM stock_movements")->fetchColumn();
            
            $stmtFiltered = $pdo->prepare("SELECT COUNT(sm.id) " . $baseQuery . $whereClause);
            $stmtFiltered->execute($params);
            $recordsFiltered = $stmtFiltered->fetchColumn();

            $queryData = "SELECT sm.*, si.item_name, si.item_code, u.name as user_name " . $baseQuery . $whereClause . " ORDER BY sm.movement_date DESC LIMIT :start, :length";
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':start', $start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', $length, PDO::PARAM_INT);
            foreach ($params as $key => $val) {
                $stmtData->bindValue($key, $val);
            }
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = ["draw" => $draw, "recordsTotal" => intval($totalRecords), "recordsFiltered" => intval($recordsFiltered), "data" => $data];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    // Benzersiz anahtar hatasını yakala
    if ($e->getCode() == 23000) {
        $response['message'] = 'Bu stok kodu zaten kullanımda. Lütfen farklı bir kod girin.';
    } else {
        $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
    }
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>