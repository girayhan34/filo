<?php
require_once __DIR__ . '/BaseApiController.php';

class IncomeExpenseApiController extends BaseApiController {

    protected function processRequest(): void {
        $action = $_REQUEST['action'] ?? 'list';

        switch ($action) {
            case 'list':
                $this->listRecords();
                break;
            case 'create':
                $this->createRecord();
                break;
            case 'get_record':
                $this->getRecord();
                break;
            case 'update':
                $this->updateRecord();
                break;
            case 'delete':
                $this->deleteRecord();
                break;
            default:
                $this->sendError('Geçersiz eylem.', 400);
                break;
        }
    }

    private function listRecords() {
        $this->checkPermission('income_expense:goruntule');

        $draw = intval($this->requestData['draw'] ?? 1);
        $start = intval($this->requestData['start'] ?? 0);
        $length = intval($this->requestData['length'] ?? 10);
        $searchValue = $this->requestData['search']['value'] ?? '';

        $allowedOrderColumns = [0 => 'date', 1 => 'description', 2 => 'category', 3 => 'amount', 4 => 'type'];
        $orderColumnIndex = intval($this->requestData['order'][0]['column'] ?? 0);
        $orderDir = $this->requestData['order'][0]['dir'] ?? 'desc';
        $orderColumn = $allowedOrderColumns[$orderColumnIndex] ?? 'date';

        $baseQuery = "FROM income_expense";
        $whereClause = " WHERE 1=1";
        $params = [];

        // Filtreler
        if (!empty($this->requestData['type'])) {
            $whereClause .= " AND type = :type";
            $params[':type'] = $this->requestData['type'];
        }
        if (!empty($this->requestData['category'])) {
            $whereClause .= " AND category = :category";
            $params[':category'] = $this->requestData['category'];
        }
        if (!empty($this->requestData['start_date'])) {
            $whereClause .= " AND date >= :start_date";
            $params[':start_date'] = $this->requestData['start_date'];
        }
        if (!empty($this->requestData['end_date'])) {
            $whereClause .= " AND date <= :end_date";
            $params[':end_date'] = $this->requestData['end_date'];
        }

        // Arama
        if (!empty($searchValue)) {
            $whereClause .= " AND (description LIKE :search OR category LIKE :search)";
            $params[':search'] = "%$searchValue%";
        }

        $totalRecordsStmt = $this->pdo->prepare("SELECT COUNT(id) FROM income_expense");
        $totalRecordsStmt->execute();
        $totalRecords = $totalRecordsStmt->fetchColumn();

        $filteredRecordsStmt = $this->pdo->prepare("SELECT COUNT(id) " . $baseQuery . $whereClause);
        $filteredRecordsStmt->execute($params);
        $recordsFiltered = $filteredRecordsStmt->fetchColumn();

        $dataQuery = "SELECT * " . $baseQuery . $whereClause . " ORDER BY $orderColumn $orderDir LIMIT :start, :length";
        $dataStmt = $this->pdo->prepare($dataQuery);
        
        foreach ($params as $key => &$val) {
            $dataStmt->bindParam($key, $val);
        }
        $dataStmt->bindParam(':start', $start, PDO::PARAM_INT);
        $dataStmt->bindParam(':length', $length, PDO::PARAM_INT);
        $dataStmt->execute();
        $data = $dataStmt->fetchAll(PDO::FETCH_ASSOC);

        $response = [
            "draw" => $draw,
            "recordsTotal" => $totalRecords,
            "recordsFiltered" => $recordsFiltered,
            "data" => $data
        ];

        $this->sendSuccess($response);
    }

    private function createRecord() {
        $this->checkPermission('income_expense:olustur');

        $rules = [
            'type' => 'required|in:income,expense',
            'date' => 'required',
            'description' => 'required|min:3',
            'category' => 'required',
            'amount' => 'required|numeric|min:0.01'
        ];
        $validatedData = $this->validate($this->requestData, $rules);

        $sql = "INSERT INTO income_expense (type, date, description, category, amount, notes, project_id, created_by) 
                VALUES (:type, :date, :description, :category, :amount, :notes, :project_id, :created_by)";
        
        $stmt = $this->pdo->prepare($sql);
        $stmt->execute([
            ':type' => $validatedData['type'],
            ':date' => $validatedData['date'],
            ':description' => $validatedData['description'],
            ':category' => $validatedData['category'],
            ':amount' => $validatedData['amount'],
            ':notes' => $validatedData['notes'] ?? null,
            ':project_id' => $validatedData['project_id'] ?: null,
            ':created_by' => $this->kullanici_id
        ]);

        $this->sendSuccess(['id' => $this->pdo->lastInsertId()], 'Kayıt başarıyla oluşturuldu.', 201);
    }

    private function getRecord() {
        $this->checkPermission('income_expense:goruntule');

        $rules = ['id' => 'required|numeric'];
        $validatedData = $this->validate($this->requestData, $rules);

        $stmt = $this->pdo->prepare("SELECT * FROM income_expense WHERE id = ?");
        $stmt->execute([$validatedData['id']]);
        $record = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$record) {
            $this->sendError('Kayıt bulunamadı.', 404);
        }

        $this->sendSuccess($record, 'Kayıt başarıyla getirildi.');
    }

    private function updateRecord() {
        $this->checkPermission('income_expense:duzenle');

        $rules = [
            'id' => 'required|numeric',
            'type' => 'required|in:income,expense',
            'date' => 'required',
            'description' => 'required|min:3',
            'category' => 'required',
            'amount' => 'required|numeric|min:0.01'
        ];
        $validatedData = $this->validate($this->requestData, $rules);

        $sql = "UPDATE income_expense SET 
                    type = :type, date = :date, description = :description, 
                    category = :category, amount = :amount, notes = :notes, updated_at = NOW()
                WHERE id = :id";
        
        $stmt = $this->pdo->prepare($sql);
        $validatedData['notes'] = $validatedData['notes'] ?? null;
        $stmt->execute($validatedData);

        $this->sendSuccess([], 'Kayıt başarıyla güncellendi.');
    }

    private function deleteRecord() {
        $this->checkPermission('income_expense:sil');

        $rules = ['id' => 'required|numeric'];
        $validatedData = $this->validate($this->requestData, $rules);

        $stmt = $this->pdo->prepare("DELETE FROM income_expense WHERE id = ?");
        $stmt->execute([$validatedData['id']]);

        $this->sendSuccess([], 'Kayıt başarıyla silindi.');
    }
}

$controller = new IncomeExpenseApiController();
$controller->handleRequest();
?>