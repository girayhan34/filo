<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Yetki kontrolü
if (!yetki_kontrol('izin_goruntule')) {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok!']);
    exit;
}

// Hata raporlama
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Varsayılan yanıt
$response = [
    'status' => 'success',
    'toplam_izin' => 0,
    'onay_bekleyen' => 0,
    'onaylanan' => 0,
    'reddedilen' => 0,
    'izin_dagilim' => []
];

try {
    // Tarih aralığı filtresi
    $tarih_baslangic = isset($_GET['tarih_baslangic']) ? $_GET['tarih_baslangic'] : date('Y-m-01');
    $tarih_bitis = isset($_GET['tarih_bitis']) ? $_GET['tarih_bitis'] : date('Y-m-t');
    
    // Toplam izin sayısı
    $query = "SELECT COUNT(*) as toplam FROM izin_talepleri 
              WHERE (baslangic_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) 
              OR (bitis_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis)";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':tarih_baslangic' => $tarih_baslangic . ' 00:00:00',
        ':tarih_bitis' => $tarih_bitis . ' 23:59:59'
    ]);
    $response['toplam_izin'] = (int)$stmt->fetchColumn();
    
    // Onay bekleyen izinler
    $query = "SELECT COUNT(*) as onay_bekleyen FROM izin_talepleri 
              WHERE durum = 'Onay Bekliyor' 
              AND ((baslangic_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) 
              OR (bitis_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis))";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':tarih_baslangic' => $tarih_baslangic . ' 00:00:00',
        ':tarih_bitis' => $tarih_bitis . ' 23:59:59'
    ]);
    $response['onay_bekleyen'] = (int)$stmt->fetchColumn();
    
    // Onaylanan izinler
    $query = "SELECT COUNT(*) as onaylanan FROM izin_talepleri 
              WHERE durum = 'Onaylandı' 
              AND ((baslangic_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) 
              OR (bitis_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis))";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':tarih_baslangic' => $tarih_baslangic . ' 00:00:00',
        ':tarih_bitis' => $tarih_bitis . ' 23:59:59'
    ]);
    $response['onaylanan'] = (int)$stmt->fetchColumn();
    
    // Reddedilen izinler
    $query = "SELECT COUNT(*) as reddedilen FROM izin_talepleri 
              WHERE durum = 'Reddedildi' 
              AND ((baslangic_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) 
              OR (bitis_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis))";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':tarih_baslangic' => $tarih_baslangic . ' 00:00:00',
        ':tarih_bitis' => $tarih_bitis . ' 23:59:59'
    ]);
    $response['reddedilen'] = (int)$stmt->fetchColumn();
    
    // İzin türlerine göre dağılım
    $query = "
        SELECT 
            it.adi as izin_tipi,
            COUNT(*) as adet,
            SUM(i.toplam_gun) as toplam_gun
        FROM izin_talepleri i
        INNER JOIN izin_tipleri it ON i.izin_tipi_id = it.id
        WHERE (i.baslangic_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) 
           OR (i.bitis_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis)
        GROUP BY i.izin_tipi_id, it.adi
        ORDER BY adet DESC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':tarih_baslangic' => $tarih_baslangic . ' 00:00:00',
        ':tarih_bitis' => $tarih_bitis . ' 23:59:59'
    ]);
    
    $response['izin_dagilim'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $response = [
        'status' => 'error',
        'message' => 'Veritabanı hatası: ' . $e->getMessage()
    ];
} catch (Exception $e) {
    $response = [
        'status' => 'error',
        'message' => 'Beklenmeyen hata: ' . $e->getMessage()
    ];
}

// JSON yanıtını döndür
header('Content-Type: application/json');
echo json_encode($response);
?>
