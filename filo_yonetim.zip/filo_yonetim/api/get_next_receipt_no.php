<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getPDO();
    
    // Get the next receipt number
    $stmt = $pdo->query("SELECT IFNULL(MAX(CAST(SUBSTRING(receipt_no, 3) AS UNSIGNED)), 0) + 1 as next_no FROM receipts");
    $nextNo = $stmt->fetch(PDO::FETCH_ASSOC)['next_no'];
    
    // Format the receipt number (e.g., F-000123)
    $nextReceiptNo = 'F-' . str_pad($nextNo, 6, '0', STR_PAD_LEFT);
    
    echo json_encode([
        'success' => true,
        'next_receipt_no' => $nextReceiptNo
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
