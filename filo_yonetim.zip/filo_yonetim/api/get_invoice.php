<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

// Check if ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid invoice ID']);
    exit;
}

$id = (int)$_GET['id'];
$editMode = isset($_GET['edit']) && $_GET['edit'] === 'true';

try {
    $pdo = getPDO();
    
    // Get invoice details
    $query = "SELECT 
            i.*, 
            c.name as customer_name,
            c.company_name as customer_company,
            c.phone as customer_phone,
            c.email as customer_email,
            c.address as customer_address,
            c.tax_office,
            c.tax_number,
            v.plate as vehicle_plate,
            v.brand as vehicle_brand,
            v.model as vehicle_model,
            v.year as vehicle_year,
            CONCAT(p.first_name, ' ', p.last_name) as driver_name,
            p.phone as driver_phone
        FROM invoices i
        LEFT JOIN customers c ON i.customer_id = c.id
        LEFT JOIN vehicles v ON i.vehicle_id = v.id
        LEFT JOIN personnel p ON i.driver_id = p.id
        WHERE i.id = :id";
    
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    
    $invoice = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$invoice) {
        http_response_code(404);
        echo json_encode(['error' => 'Invoice not found']);
        exit;
    }
    
    // Check permissions for edit mode
    if ($editMode && !hasPermission('invoices', 'edit')) {
        http_response_code(403);
        echo json_encode(['error' => 'You do not have permission to edit this invoice']);
        exit;
    }
    
    // Get invoice items
    $itemsQuery = "SELECT * FROM invoice_items WHERE invoice_id = :invoice_id";
    $itemsStmt = $pdo->prepare($itemsQuery);
    $itemsStmt->bindParam(':invoice_id', $id, PDO::PARAM_INT);
    $itemsStmt->execute();
    $invoice['items'] = $itemsStmt->fetchAll(PDO::FETCH_ASSOC);
    
    // If not in edit mode, get payment information
    if (!$editMode) {
        // Get payments
        $paymentsQuery = "SELECT * FROM payments WHERE invoice_id = :invoice_id ORDER BY payment_date DESC";
        $paymentsStmt = $pdo->prepare($paymentsQuery);
        $paymentsStmt->bindParam(':invoice_id', $id, PDO::PARAM_INT);
        $paymentsStmt->execute();
        $payments = $paymentsStmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Calculate total paid amount
        $totalPaid = 0;
        foreach ($payments as $payment) {
            $totalPaid += $payment['amount'];
        }
        
        // Calculate remaining amount
        $remainingAmount = $invoice['total_amount'] - $totalPaid;
        
        // Prepare response
        $response = [
            'success' => true,
            'invoice' => $invoice,
            'payments' => $payments,
            'total_paid' => $totalPaid,
            'remaining_amount' => $remainingAmount
        ];
    } else {
        // In edit mode, just return the invoice data
        $response = [
            'success' => true,
            'invoice' => $invoice
        ];
    }
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
