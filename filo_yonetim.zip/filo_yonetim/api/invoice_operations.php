<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
session_start(); // Session'ı başlat
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'Unauthorized access']);
    exit;
}

// Get the action from the request
$action = $_POST['action'] ?? $_GET['action'] ?? '';
// Validate action
$validActions = ['create_invoice', 'update_invoice', 'delete_invoice', 'send_invoice_email', 'print_invoice'];
if (!in_array($action, $validActions)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Invalid action']);
    exit;
}

try {
    $pdo = getPDO();
    $pdo->beginTransaction();
    
    switch ($action) {
        case 'create_invoice':
        case 'update_invoice':
            $invoiceId = handleCreateUpdateInvoice($pdo, $action);
            $pdo->commit();
            echo json_encode([
                'success' => true,
                'message' => $action === 'create_invoice' ? 'Invoice created successfully' : 'Invoice updated successfully',
                'invoice_id' => $invoiceId
            ]);
            break;
            
        case 'delete_invoice':
            $invoiceId = $_POST['invoice_id'] ?? 0;
            if (empty($invoiceId) || !is_numeric($invoiceId)) {
                throw new Exception('Invalid invoice ID');
            }
            
            // Check permissions
            if (!hasPermission('invoices', 'delete')) {
                throw new Exception('You do not have permission to delete invoices');
            }
            
            // Check if invoice exists
            $stmt = $pdo->prepare("SELECT id FROM invoices WHERE id = ?");
            $stmt->execute([$invoiceId]);
            if (!$stmt->fetch()) {
                throw new Exception('Invoice not found');
            }
            
            // Delete invoice items
            $stmt = $pdo->prepare("DELETE FROM invoice_items WHERE invoice_id = ?");
            $stmt->execute([$invoiceId]);
            
            // Delete payments
            $stmt = $pdo->prepare("DELETE FROM payments WHERE invoice_id = ?");
            $stmt->execute([$invoiceId]);
            
            // Delete invoice
            $stmt = $pdo->prepare("DELETE FROM invoices WHERE id = ?");
            $stmt->execute([$invoiceId]);
            
            $pdo->commit();
            echo json_encode([
                'success' => true,
                'message' => 'Invoice deleted successfully'
            ]);
            break;
            
        case 'send_invoice_email':
            $invoiceId = $_POST['invoice_id'] ?? 0;
            if (empty($invoiceId) || !is_numeric($invoiceId)) {
                throw new Exception('Invalid invoice ID');
            }
            
            // Check permissions
            if (!hasPermission('invoices', 'edit')) {
                throw new Exception('You do not have permission to send invoices');
            }
            
            // Get invoice details
            $stmt = $pdo->prepare("SELECT i.*, c.email as customer_email, c.name as customer_name FROM invoices i LEFT JOIN customers c ON i.customer_id = c.id WHERE i.id = ?");
            $stmt->execute([$invoiceId]);
            $invoice = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$invoice) {
                throw new Exception('Invoice not found');
            }
            
            if (empty($invoice['customer_email'])) {
                throw new Exception('Customer email not found');
            }
            
            // In a real application, you would send the email here
            // For now, we'll just simulate a successful send
            
            // Update invoice status to 'sent' if it's a draft
            if ($invoice['status'] === 'draft') {
                $stmt = $pdo->prepare("UPDATE invoices SET status = 'sent', updated_at = NOW() WHERE id = ?");
                $stmt->execute([$invoiceId]);
            }
            
            // Log the email sending
            $stmt = $pdo->prepare("INSERT INTO invoice_emails (invoice_id, recipient_email, sent_at) VALUES (?, ?, NOW())");
            $stmt->execute([$invoiceId, $invoice['customer_email']]);
            
            $pdo->commit();
            echo json_encode([
                'success' => true,
                'message' => 'Invoice sent successfully to ' . $invoice['customer_email']
            ]);
            break;
            
        case 'print_invoice':
            $invoiceId = $_GET['id'] ?? 0;
            if (empty($invoiceId) || !is_numeric($invoiceId)) {
                throw new Exception('Invalid invoice ID');
            }
            
            // Get invoice details for printing
            $stmt = $pdo->prepare("SELECT * FROM invoices WHERE id = ?");
            $stmt->execute([$invoiceId]);
            $invoice = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$invoice) {
                throw new Exception('Invoice not found');
            }
            
            // In a real application, you would generate a PDF here
            // For now, we'll just return the invoice data
            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="invoice_' . $invoice['invoice_no'] . '.pdf"');
            
            // This is a placeholder - in a real app, you would use a PDF library like TCPDF or Dompdf
            // Here we're just returning a simple text representation for demonstration
            echo "INVOICE #" . $invoice['invoice_no'] . "\n";
            echo "Date: " . $invoice['invoice_date'] . "\n";
            echo "Due Date: " . $invoice['due_date'] . "\n";
            echo "Amount: " . number_format($invoice['total_amount'], 2) . " " . $invoice['currency'] . "\n";
            echo "Status: " . ucfirst($invoice['status']) . "\n";
            
            break;
    }
    
} catch (Exception $e) {
    $pdo->rollBack();
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}

/**
 * Handle create or update invoice
 */
function handleCreateUpdateInvoice($pdo, $action) {
    // Check permissions
    $permission = $action === 'create_invoice' ? 'create' : 'edit';
    if (!hasPermission('invoices', $permission)) {
        throw new Exception('You do not have permission to ' . $permission . ' invoices');
    }
    
    // Validate required fields
    $requiredFields = [
        'customer_id', 'invoice_date', 'due_date', 'status', 'subtotal', 'tax_total', 'total_amount', 'currency'
    ];
    
    foreach ($requiredFields as $field) {
        if (!isset($_POST[$field]) || (is_string($_POST[$field]) && trim($_POST[$field]) === '')) {
            throw new Exception("Required field missing: $field");
        }
    }
    
    $invoiceId = $action === 'update_invoice' ? (int)$_POST['invoice_id'] : null;
    
    // Prepare invoice data
    $invoiceData = [
        'customer_id' => (int)$_POST['customer_id'],
        'customer_contact' => $_POST['customer_contact'] ?? null,
        'customer_phone' => $_POST['customer_phone'] ?? null,
        'customer_email' => $_POST['customer_email'] ?? null,
        'customer_address' => $_POST['customer_address'] ?? null,
        'tax_office' => $_POST['tax_office'] ?? null,
        'tax_number' => $_POST['tax_number'] ?? null,
        'invoice_no' => $_POST['invoice_no'] ?? null,
        'receipt_no' => $_POST['receipt_no'] ?? null,
        'invoice_date' => $_POST['invoice_date'],
        'due_date' => $_POST['due_date'],
        'status' => $_POST['status'],
        'subtotal' => (float)$_POST['subtotal'],
        'tax_total' => (float)$_POST['tax_total'],
        'discount_amount' => isset($_POST['discount_amount']) ? (float)$_POST['discount_amount'] : 0,
        'total_amount' => (float)$_POST['total_amount'],
        'currency' => $_POST['currency'],
        'notes' => $_POST['notes'] ?? null,
        'terms_conditions' => $_POST['terms_conditions'] ?? null,
        'vehicle_id' => !empty($_POST['vehicle_id']) ? (int)$_POST['vehicle_id'] : null,
        'driver_id' => !empty($_POST['driver_id']) ? (int)$_POST['driver_id'] : null,
        'service_type' => $_POST['service_type'] ?? null,
        'updated_at' => date('Y-m-d H:i:s')
    ];
    
    // Handle file upload if present
    if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
        $fileName = uniqid() . '_' . basename($_FILES['attachment']['name']);
        $uploadPath = '../uploads/invoices/' . $fileName;
        
        if (move_uploaded_file($_FILES['attachment']['tmp_name'], $uploadPath)) {
            $invoiceData['attachment_path'] = $uploadPath;
        } else {
            throw new Exception('Failed to upload file');
        }
    }
    
    if ($action === 'create_invoice') {
        // Generate invoice number if not provided
        if (empty($invoiceData['invoice_no'])) {
            $year = date('Y');
            $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM invoices WHERE YEAR(created_at) = ?");
            $stmt->execute([$year]);
            $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'] + 1;
            $invoiceData['invoice_no'] = 'INV-' . $year . '-' . str_pad($count, 5, '0', STR_PAD_LEFT);
        }
        
        // Insert new invoice
        $columns = implode(', ', array_keys($invoiceData));
        $placeholders = ':' . implode(', :', array_keys($invoiceData));
        
        $query = "INSERT INTO invoices ($columns, created_at) VALUES ($placeholders, NOW())";
        $stmt = $pdo->prepare($query);
        
        foreach ($invoiceData as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        
        $stmt->execute();
        $invoiceId = $pdo->lastInsertId();
        
    } else {
        // Update existing invoice
        $setClause = [];
        foreach (array_keys($invoiceData) as $column) {
            $setClause[] = "$column = :$column";
        }
        
        $query = "UPDATE invoices SET " . implode(', ', $setClause) . " WHERE id = :id";
        $stmt = $pdo->prepare($query);
        
        foreach ($invoiceData as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        $stmt->bindValue(':id', $invoiceId, PDO::PARAM_INT);
        
        $stmt->execute();
        
        // Delete existing items to re-insert them
        $stmt = $pdo->prepare("DELETE FROM invoice_items WHERE invoice_id = ?");
        $stmt->execute([$invoiceId]);
    }
    
    // Process invoice items
    if (isset($_POST['items']) && is_array($_POST['items'])) {
        $items = $_POST['items'];
        
        foreach ($items as $item) {
            if (empty($item['description'])) continue;
            
            $itemData = [
                'invoice_id' => $invoiceId,
                'description' => $item['description'],
                'quantity' => (float)$item['quantity'],
                'unit' => $item['unit'] ?? 'adet',
                'unit_price' => (float)$item['unit_price'],
                'tax_rate' => (float)($item['tax_rate'] ?? 18),
                'tax_amount' => (float)($item['tax_amount'] ?? 0),
                'total' => (float)($item['total'] ?? 0),
                'created_at' => date('Y-m-d H:i:s')
            ];
            
            $columns = implode(', ', array_keys($itemData));
            $placeholders = ':' . implode(', :', array_keys($itemData));
            
            $query = "INSERT INTO invoice_items ($columns) VALUES ($placeholders)";
            $stmt = $pdo->prepare($query);
            
            foreach ($itemData as $key => $value) {
                $stmt->bindValue(':' . $key, $value);
            }
            
            $stmt->execute();
        }
    }
    
    // Process payment if status is paid
    if ($_POST['status'] === 'paid' && !empty($_POST['payment_amount']) && (float)$_POST['payment_amount'] > 0) {
        $paymentData = [
            'invoice_id' => $invoiceId,
            'amount' => (float)$_POST['payment_amount'],
            'payment_date' => $_POST['payment_date'] ?? date('Y-m-d'),
            'payment_method' => $_POST['payment_method'] ?? 'bank_transfer',
            'reference_no' => $_POST['payment_reference'] ?? null,
            'notes' => $_POST['payment_notes'] ?? null,
            'created_at' => date('Y-m-d H:i:s')
        ];
        
        $columns = implode(', ', array_keys($paymentData));
        $placeholders = ':' . implode(', :', array_keys($paymentData));
        
        $query = "INSERT INTO payments ($columns) VALUES ($placeholders)";
        $stmt = $pdo->prepare($query);
        
        foreach ($paymentData as $key => $value) {
            $stmt->bindValue(':' . $key, $value);
        }
        
        $stmt->execute();
    }
    
    return $invoiceId;
}
