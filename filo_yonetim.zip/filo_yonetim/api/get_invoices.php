<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in and has permission
if (!isLoggedIn() || !hasPermission('invoices', 'view')) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getPDO();
    
    // Get filter parameters
    $filters = [
        'invoice_no' => $_GET['invoice_no'] ?? '',
        'receipt_no' => $_GET['receipt_no'] ?? '',
        'status' => $_GET['status'] ?? '',
        'customer_id' => $_GET['customer_id'] ?? '',
        'vehicle_id' => $_GET['vehicle_id'] ?? '',
        'driver_id' => $_GET['driver_id'] ?? '',
        'start_date' => $_GET['start_date'] ?? '',
        'end_date' => $_GET['end_date'] ?? '',
        'min_amount' => $_GET['min_amount'] ?? '',
        'max_amount' => $_GET['max_amount'] ?? ''
    ];
    
    // Build the query
    $query = "SELECT 
            i.*, 
            c.name as customer_name,
            c.company_name as customer_company,
            v.plate as vehicle_plate,
            v.brand as vehicle_brand,
            v.model as vehicle_model,
            CONCAT(p.first_name, ' ', p.last_name) as driver_name
        FROM invoices i
        LEFT JOIN customers c ON i.customer_id = c.id
        LEFT JOIN vehicles v ON i.vehicle_id = v.id
        LEFT JOIN personnel p ON i.driver_id = p.id
        WHERE 1=1";
    
    $params = [];
    
    // Apply filters
    if (!empty($filters['invoice_no'])) {
        $query .= " AND i.invoice_no LIKE :invoice_no";
        $params[':invoice_no'] = '%' . $filters['invoice_no'] . '%';
    }
    
    if (!empty($filters['receipt_no'])) {
        $query .= " AND i.receipt_no LIKE :receipt_no";
        $params[':receipt_no'] = '%' . $filters['receipt_no'] . '%';
    }
    
    if (!empty($filters['status'])) {
        $query .= " AND i.status = :status";
        $params[':status'] = $filters['status'];
    }
    
    if (!empty($filters['customer_id'])) {
        $query .= " AND i.customer_id = :customer_id";
        $params[':customer_id'] = $filters['customer_id'];
    }
    
    if (!empty($filters['vehicle_id'])) {
        $query .= " AND i.vehicle_id = :vehicle_id";
        $params[':vehicle_id'] = $filters['vehicle_id'];
    }
    
    if (!empty($filters['driver_id'])) {
        $query .= " AND i.driver_id = :driver_id";
        $params[':driver_id'] = $filters['driver_id'];
    }
    
    if (!empty($filters['start_date'])) {
        $query .= " AND i.invoice_date >= :start_date";
        $params[':start_date'] = $filters['start_date'];
    }
    
    if (!empty($filters['end_date'])) {
        $query .= " AND i.invoice_date <= :end_date";
        $params[':end_date'] = $filters['end_date'] . ' 23:59:59';
    }
    
    if (is_numeric($filters['min_amount'])) {
        $query .= " AND i.total_amount >= :min_amount";
        $params[':min_amount'] = $filters['min_amount'];
    }
    
    if (is_numeric($filters['max_amount'])) {
        $query .= " AND i.total_amount <= :max_amount";
        $params[':max_amount'] = $filters['max_amount'];
    }
    
    // Add sorting
    $sort = $_GET['sort'] ?? 'i.invoice_date';
    $order = $_GET['order'] ?? 'DESC';
    $validSorts = ['i.invoice_no', 'i.invoice_date', 'i.due_date', 'i.status', 'i.total_amount', 'c.name', 'v.plate'];
    $validOrders = ['ASC', 'DESC'];
    
    if (in_array($sort, $validSorts) && in_array(strtoupper($order), $validOrders)) {
        $query .= " ORDER BY $sort $order";
    } else {
        $query .= " ORDER BY i.invoice_date DESC";
    }
    
    // Add pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 25;
    $offset = ($page - 1) * $perPage;
    
    $query .= " LIMIT :offset, :per_page";
    
    // Prepare and execute the query
    $stmt = $pdo->prepare($query);
    
    // Bind parameters with proper types
    foreach ($params as $key => $value) {
        $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
        $stmt->bindValue($key, $value, $paramType);
    }
    
    // Bind pagination parameters
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':per_page', $perPage, PDO::PARAM_INT);
    
    $stmt->execute();
    $invoices = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination
    $countQuery = "SELECT COUNT(*) as total FROM invoices i";
    if (strpos($query, 'WHERE 1=1 AND') !== false) {
        $countQuery .= substr($query, strpos($query, 'WHERE 1=1'));
        $countQuery = preg_replace('/ORDER BY.*$|LIMIT.*$/i', '', $countQuery);
    }
    
    $countStmt = $pdo->prepare($countQuery);
    
    // Remove pagination and order by from params
    unset($params[':offset'], $params[':per_page']);
    
    // Bind parameters to count query
    foreach ($params as $key => $value) {
        $paramType = is_int($value) ? PDO::PARAM_INT : PDO::PARAM_STR;
        $countStmt->bindValue($key, $value, $paramType);
    }
    
    $countStmt->execute();
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Format the response
    $response = [
        'success' => true,
        'data' => $invoices,
        'pagination' => [
            'total' => (int)$total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ]
    ];
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
