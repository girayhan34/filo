<?php
require_once __DIR__ . '/BaseApiController.php';
require_once __DIR__ . '/../models/Izin.php';

class IzinReddetController extends BaseApiController {

    protected function processRequest(): void {
        if ($this->method !== 'POST') {
            $this->sendError('Geçersiz istek metodu.', 405);
            return;
        }

        // 1. Yetki Kontrolü (izin_onayla ile aynı yetkiyi kullanıyor varsayıyoruz)
        $this->checkPermission('izinler:onayla');

        // 2. Veri Doğrulama
        $rules = [
            'id' => 'required|numeric',
            'red_nedeni' => 'required|min:3'
        ];
        $validatedData = $this->validate($this->requestData, $rules);

        $izin_id = intval($validatedData['id']);
        $red_nedeni = $validatedData['red_nedeni'];
        $ek_aciklama = $validatedData['ek_aciklama'] ?? null;

        // 3. İş Mantığı (Business Logic)
        $izin = Izin::find($izin_id);

        if (!$izin) {
            throw new Exception('Reddedilecek izin kaydı bulunamadı!', 404);
        }

        if ($izin->durum !== 'Onay Bekliyor') {
            throw new Exception('Bu izin zaten daha önce işlem görmüş!', 409);
        }

        // 4. Veritabanı İşlemi (Model kullanarak)
        $updateData = [
            'durum' => 'Reddedildi',
            'izin_veren_id' => $this->kullanici_id,
            'onay_red_aciklama' => "Red Nedeni: {$red_nedeni}" . ($ek_aciklama ? " | Açıklama: {$ek_aciklama}" : ''),
            'guncelleme_tarihi' => date('Y-m-d H:i:s')
        ];

        if (!$izin->update($updateData)) {
            throw new Exception('İzin reddedilirken bir veritabanı hatası oluştu.', 500);
        }

        // 5. Başarılı Yanıt Gönderme
        $this->sendSuccess([], 'İzin başarıyla reddedildi.');
    }
}

$controller = new IzinReddetController();
$controller->handleRequest();
