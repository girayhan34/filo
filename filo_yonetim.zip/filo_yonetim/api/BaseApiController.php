<?php

require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

abstract class BaseApiController {
    protected PDO $pdo;
    protected string $method;
    protected ?int $kullanici_id;
    protected ?string $kullanici_rol;
    protected array $requestData;

    public function __construct() {
        $this->pdo = getPDO();
        $this->method = $_SERVER['REQUEST_METHOD'];
        $this->kullanici_id = $_SESSION['user_id'] ?? null;
        $this->kullanici_rol = $_SESSION['user_role'] ?? null;

        $this->parseRequestData();

        header('Content-Type: application/json');
    }

    /**
     * Gelen isteğin verisini (JSON, POST, GET) ayrıştırır.
     */
    private function parseRequestData(): void {
        if (in_array($this->method, ['POST', 'PUT', 'PATCH'])) {
            $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
            if (stripos($contentType, 'application/json') !== false) {
                $this->requestData = json_decode(file_get_contents('php://input'), true) ?? [];
            } else {
                $this->requestData = $_POST;
            }
        } else {
            $this->requestData = $_GET;
        }
    }

    /**
     * API endpoint'ini çalıştırır.
     */
    public function handleRequest(): void {
        try {
            $this->processRequest();
        } catch (Exception $e) {
            $statusCode = ($e->getCode() >= 400 && $e->getCode() < 600) ? $e->getCode() : 500;
            $this->sendError($e->getMessage(), $statusCode);
        }
    }

    /**
     * Alt sınıfların kendi mantığını uygulayacağı ana metod.
     */
    abstract protected function processRequest(): void;

    /**
     * Kullanıcının belirli bir işlem için yetkisi olup olmadığını kontrol eder.
     * @param string $permission Kontrol edilecek yetki.
     * @throws Exception Yetki yoksa hata fırlatır.
     */
    protected function checkPermission(string $permission): void {
        if (!hasPermission($permission)) {
            throw new Exception('Bu işlem için yetkiniz yok.', 403);
        }
    }

    /**
     * Başarılı bir yanıt gönderir.
     * @param array $data Yanıt verisi.
     * @param string $message Başarı mesajı.
     * @param int $statusCode HTTP durum kodu.
     */
    protected function sendSuccess(array $data = [], string $message = 'İşlem başarılı.', int $statusCode = 200): void {
        http_response_code($statusCode);
        echo json_encode([
            'status' => 'success',
            'message' => $message,
            'data' => $data
        ]);
    }

    /**
     * Hatalı bir yanıt gönderir.
     * @param string|array $message Hata mesajı veya mesajları.
     * @param int $statusCode HTTP durum kodu.
     */
    protected function sendError($message, int $statusCode = 400): void {
        http_response_code($statusCode);
        echo json_encode([
            'status' => 'error',
            'message' => $message
        ]);
    }

    /**
     * Gelen veriyi belirli kurallara göre doğrular.
     * @param array $data Doğrulanacak veri.
     * @param array $rules Doğrulama kuralları. Örn: ['personel_id' => 'required|numeric']
     * @return array Doğrulanmış veri.
     * @throws Exception Doğrulama başarısız olursa hata fırlatır.
     * @throws \InvalidArgumentException
     */
    protected function validate(array $data, array $rules): array {
        $errors = [];

        foreach ($rules as $field => $ruleString) {
            $ruleList = explode('|', $ruleString);
            $value = $data[$field] ?? null;

            foreach ($ruleList as $rule) {
                $ruleName = $rule;
                $ruleParam = null;

                if (strpos($rule, ':') !== false) {
                    [$ruleName, $ruleParam] = explode(':', $rule, 2);
                }

                // 'required' kuralı
                if ($ruleName === 'required' && (empty($value) && $value !== '0' && $value !== 0)) {
                    $errors[$field][] = "{$field} alanı zorunludur.";
                    // Zorunlu alan yoksa diğer kuralları kontrol etmeye gerek yok.
                    continue 2; 
                }

                // Eğer alan zorunlu değilse ve boşsa, diğer kuralları atla.
                if (!in_array('required', $ruleList) && empty($value)) {
                    continue 2;
                }

                switch ($ruleName) {
                    case 'numeric':
                        if (!is_numeric($value)) {
                            $errors[$field][] = "{$field} alanı sayısal olmalıdır.";
                        }
                        break;

                    case 'email':
                        if (!filter_var($value, FILTER_VALIDATE_EMAIL)) {
                            $errors[$field][] = "{$field} alanı geçerli bir e-posta adresi olmalıdır.";
                        }
                        break;

                    case 'min':
                        if (mb_strlen(strval($value)) < (int)$ruleParam) {
                            $errors[$field][] = "{$field} alanı en az {$ruleParam} karakter olmalıdır.";
                        }
                        break;
                }
            }
        }

        if (!empty($errors)) {
            // Hataları tek bir mesajda birleştirmek yerine, bir dizi olarak göndermek daha esnek olabilir.
            // Şimdilik ilk hatayı gönderelim.
            throw new Exception(reset($errors)[0], 422); // 422 Unprocessable Entity
        }

        return $data;
    }
}