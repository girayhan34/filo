<?php

require_once __DIR__ . '/BaseModel.php';

class Izin extends BaseModel {
    protected static string $tableName = 'izin_talepleri';

    /**
     * Doldurulmasına izin verilen sütunlar.
     * @var array
     */
    protected array $fillable = [
        'personel_id',
        'izin_tipi_id',
        'baslangic_tarihi',
        'bitis_tarihi',
        'toplam_gun',
        'aciklama',
        'durum',
        'izin_veren_id',
        'onay_red_aciklama',
        'olusturma_tarihi',
        'guncelleme_tarihi'
    ];

    /**
     * Belirtilen personel için çakışan bir izin olup olmadığını kontrol eder.
     *
     * @param integer $personel_id
     * @param string $baslangic 'Y-m-d' formatında tarih.
     * @param string $bitis 'Y-m-d' formatında tarih.
     * @param integer $excludeId Kontrol dışı bırakılacak izin ID'si (güncelleme için).
     * @return boolean Çakışma varsa true, yoksa false döner.
     */
    public static function checkConflicting(int $personel_id, string $baslangic, string $bitis, int $excludeId = 0): bool {
        if (!isset(self::$pdo)) {
            self::$pdo = getPDO();
        }
        
        $sql = "SELECT COUNT(*) FROM " . self::$tableName . "
                WHERE personel_id = :personel_id AND id != :exclude_id
                AND durum NOT IN ('Reddedildi', 'İptal Edildi')
                AND (:baslangic <= bitis_tarihi AND :bitis >= baslangic_tarihi)";
        $stmt = self::$pdo->prepare($sql);
        $stmt->execute([':personel_id' => $personel_id, ':exclude_id' => $excludeId, ':baslangic' => $baslangic, ':bitis' => $bitis]);
        
        return $stmt->fetchColumn() > 0;
    }
}