<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getPDO();
    
    // Get search term if provided
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : 'active';
    $position = isset($_GET['position']) ? trim($_GET['position']) : '';
    
    // Build the query
    $query = "SELECT 
            id,
            CONCAT(first_name, ' ', last_name) as name,
            first_name,
            last_name,
            identity_number,
            position,
            department,
            phone,
            email,
            address,
            hire_date,
            status,
            created_at
        FROM personnel 
        WHERE 1=1";
    
    $params = [];
    
    // Add status filter
    if (!empty($status)) {
        $query .= " AND status = :status";
        $params[':status'] = $status;
    }
    
    // Add position filter
    if (!empty($position)) {
        $query .= " AND position = :position";
        $params[':position'] = $position;
    }
    
    // Add search condition if search term is provided
    if (!empty($search)) {
        $query .= " AND (
            CONCAT(first_name, ' ', last_name) LIKE :search OR
            identity_number LIKE :search OR
            phone LIKE :search OR
            email LIKE :search
        )";
        $params[':search'] = "%$search%";
    }
    
    // Add sorting
    $sort = $_GET['sort'] ?? 'first_name';
    $order = $_GET['order'] ?? 'ASC';
    $validSorts = ['first_name', 'last_name', 'position', 'department', 'hire_date', 'status'];
    $validOrders = ['ASC', 'DESC'];
    
    if (in_array($sort, $validSorts) && in_array(strtoupper($order), $validOrders)) {
        $query .= " ORDER BY $sort $order";
    } else {
        $query .= " ORDER BY first_name, last_name";
    }
    
    // Add pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 100;
    $offset = ($page - 1) * $perPage;
    
    $query .= " LIMIT :offset, :per_page";
    
    // Prepare and execute the query
    $stmt = $pdo->prepare($query);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value, PDO::PARAM_STR);
    }
    
    // Bind pagination parameters
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':per_page', $perPage, PDO::PARAM_INT);
    
    $stmt->execute();
    $personnel = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination
    $countQuery = "SELECT COUNT(*) as total FROM personnel WHERE 1=1";
    
    if (!empty($status)) {
        $countQuery .= " AND status = :status";
    }
    
    if (!empty($position)) {
        $countQuery .= " AND position = :position";
    }
    
    if (!empty($search)) {
        $countQuery .= " AND (
            CONCAT(first_name, ' ', last_name) LIKE :search OR
            identity_number LIKE :search OR
            phone LIKE :search OR
            email LIKE :search
        )";
    }
    
    $countStmt = $pdo->prepare($countQuery);
    
    // Bind parameters to count query
    foreach ($params as $key => $value) {
        $countStmt->bindValue($key, $value, PDO::PARAM_STR);
    }
    
    $countStmt->execute();
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Format the response
    $response = [
        'success' => true,
        'data' => $personnel,
        'pagination' => [
            'total' => (int)$total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ]
    ];
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
