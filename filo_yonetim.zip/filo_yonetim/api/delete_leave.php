<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

// Get leave ID from POST data
$leave_id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if ($leave_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz izin ID.']);
    exit;
}

try {
    // Start transaction
    $pdo->beginTransaction();
    
    // Get leave info before deleting
    $stmt = $pdo->prepare("SELECT * FROM personnel_leaves WHERE id = ?");
    $stmt->execute([$leave_id]);
    $leave = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$leave) {
        throw new Exception('İzin kaydı bulunamadı.');
    }
    
    // Check if the leave is in a state that can be deleted
    if ($leave['status'] === 'approved') {
        throw new Exception('Onaylanmış izin kayıtları silinemez.');
    }
    
    // Delete the leave record
    $stmt = $pdo->prepare("DELETE FROM personnel_leaves WHERE id = ?");
    $stmt->execute([$leave_id]);
    
    // Log the action
    $log_stmt = $pdo->prepare("INSERT INTO system_logs 
                              (user_id, action, table_name, record_id, details, created_at) 
                              VALUES (?, ?, 'personnel_leaves', ?, ?, NOW())");
    $log_stmt->execute([
        $_SESSION['user_id'],
        'delete',
        $leave_id,
        json_encode(['personnel_id' => $leave['personnel_id'], 'start_date' => $leave['start_date'], 'end_date' => $leave['end_date']])
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true, 
        'message' => 'İzin kaydı başarıyla silindi.'
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'İzin kaydı silinirken bir hata oluştu: ' . $e->getMessage()]);
}
