<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getPDO();
    
    // Get search term if provided
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    $status = isset($_GET['status']) ? trim($_GET['status']) : 'active';
    
    // Build the query
    $query = "SELECT 
            id,
            plate,
            brand,
            model,
            year,
            color,
            chassis_no,
            engine_no,
            fuel_type,
            gear_type,
            status,
            created_at
        FROM vehicles 
        WHERE 1=1";
    
    $params = [];
    
    // Add status filter
    if (!empty($status)) {
        $query .= " AND status = :status";
        $params[':status'] = $status;
    }
    
    // Add search condition if search term is provided
    if (!empty($search)) {
        $query .= " AND (
            plate LIKE :search OR 
            brand LIKE :search OR
            model LIKE :search OR
            chassis_no LIKE :search OR
            engine_no LIKE :search
        )";
        $params[':search'] = "%$search%";
    }
    
    // Add sorting
    $sort = $_GET['sort'] ?? 'plate';
    $order = $_GET['order'] ?? 'ASC';
    $validSorts = ['plate', 'brand', 'model', 'year', 'status'];
    $validOrders = ['ASC', 'DESC'];
    
    if (in_array($sort, $validSorts) && in_array(strtoupper($order), $validOrders)) {
        $query .= " ORDER BY $sort $order";
    } else {
        $query .= " ORDER BY plate ASC";
    }
    
    // Add pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 100;
    $offset = ($page - 1) * $perPage;
    
    $query .= " LIMIT :offset, :per_page";
    
    // Prepare and execute the query
    $stmt = $pdo->prepare($query);
    
    // Bind parameters
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value, PDO::PARAM_STR);
    }
    
    // Bind pagination parameters
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':per_page', $perPage, PDO::PARAM_INT);
    
    $stmt->execute();
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format the response
    $response = [
        'success' => true,
        'data' => $vehicles,
        'pagination' => [
            'total' => count($vehicles),
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil(count($vehicles) / $perPage)
        ]
    ];
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
