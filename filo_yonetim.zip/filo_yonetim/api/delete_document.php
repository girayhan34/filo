<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

// Get document ID from POST data
$document_id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

if ($document_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz belge ID.']);
    exit;
}

try {
    // Start transaction
    $pdo->beginTransaction();
    
    // Get document info before deleting
    $stmt = $pdo->prepare("SELECT * FROM personnel_documents WHERE id = ?");
    $stmt->execute([$document_id]);
    $document = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$document) {
        throw new Exception('Belge bulunamadı.');
    }
    
    // Delete the document record
    $stmt = $pdo->prepare("DELETE FROM personnel_documents WHERE id = ?");
    $stmt->execute([$document_id]);
    
    // Delete the physical file
    $file_path = '../' . $document['file_path'];
    if (file_exists($file_path)) {
        unlink($file_path);
    }
    
    // Log the action
    $log_stmt = $pdo->prepare("INSERT INTO system_logs 
                              (user_id, action, table_name, record_id, details, created_at) 
                              VALUES (?, ?, 'personnel_documents', ?, ?, NOW())");
    $log_stmt->execute([
        $_SESSION['user_id'],
        'delete',
        $document_id,
        json_encode(['file_name' => $document['file_name'], 'personnel_id' => $document['personnel_id']])
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true, 
        'message' => 'Belge başarıyla silindi.'
    ]);
    
} catch (Exception $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Belge silinirken bir hata oluştu: ' . $e->getMessage()]);
}
