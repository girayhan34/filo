<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

// Get POST data
$personnel_id = isset($_POST['personnel_id']) ? (int)$_POST['personnel_id'] : 0;
$leave_type = isset($_POST['leave_type']) ? trim($_POST['leave_type']) : '';
$start_date = isset($_POST['start_date']) ? trim($_POST['start_date']) : '';
$end_date = isset($_POST['end_date']) ? trim($_POST['end_date']) : '';
$notes = isset($_POST['notes']) ? trim($_POST['notes']) : '';

// Validate input
if ($personnel_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz personel ID.']);
    exit;
}

if (empty($leave_type) || empty($start_date) || empty($end_date)) {
    echo json_encode(['success' => false, 'message' => 'Lütfen tüm zorunlu alanları doldurun.']);
    exit;
}

// Convert dates to MySQL format
$start_date_mysql = date('Y-m-d', strtotime($start_date));
$end_date_mysql = date('Y-m-d', strtotime($end_date));

if ($start_date_mysql > $end_date_mysql) {
    echo json_encode(['success' => false, 'message' => 'Başlangıç tarihi, bitiş tarihinden sonra olamaz.']);
    exit;
}

try {
    // Check for date conflicts
    $stmt = $pdo->prepare("SELECT id FROM personnel_leaves 
                          WHERE personnel_id = ? 
                          AND ((start_date BETWEEN ? AND ?) OR (end_date BETWEEN ? AND ?) 
                          OR (? BETWEEN start_date AND end_date) OR (? BETWEEN start_date AND end_date))");
    $stmt->execute([$personnel_id, $start_date_mysql, $end_date_mysql, $start_date_mysql, $end_date_mysql, $start_date_mysql, $end_date_mysql]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => false, 'message' => 'Bu tarih aralığında başka bir izin kaydı bulunmaktadır.']);
        exit;
    }
    
    // Insert leave record to database
    $stmt = $pdo->prepare("INSERT INTO personnel_leaves 
                          (personnel_id, leave_type, start_date, end_date, notes, status, created_by, created_at) 
                          VALUES (?, ?, ?, ?, ?, 'pending', ?, NOW())");
    
    $stmt->execute([
        $personnel_id,
        $leave_type,
        $start_date_mysql,
        $end_date_mysql,
        $notes,
        $_SESSION['user_id']
    ]);
    
    $leave_id = $pdo->lastInsertId();
    
    // Log the action
    $log_stmt = $pdo->prepare("INSERT INTO system_logs 
                              (user_id, action, table_name, record_id, details, created_at) 
                              VALUES (?, ?, 'personnel_leaves', ?, ?, NOW())");
    $log_stmt->execute([
        $_SESSION['user_id'],
        'create',
        $leave_id,
        json_encode(['personnel_id' => $personnel_id, 'leave_type' => $leave_type, 'start_date' => $start_date_mysql, 'end_date' => $end_date_mysql])
    ]);
    
    echo json_encode([
        'success' => true, 
        'message' => 'İzin başarıyla eklendi.',
        'leave_id' => $leave_id
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}
