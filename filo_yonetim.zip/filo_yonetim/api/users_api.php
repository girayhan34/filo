<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

if ($_SESSION['user_role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok.']);
    exit;
}

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            $stmt = $pdo->query("
                SELECT u.id, u.name, u.username, u.email, u.status, u.last_login, r.role_name 
                FROM users u 
                LEFT JOIN user_roles ur ON u.id = ur.user_id 
                LEFT JOIN roles r ON ur.role_id = r.id
            ");
            $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $response = ['status' => 'success', 'data' => $users];
            break;

        case 'create':
            $sql = "INSERT INTO users (name, username, email, password, status) VALUES (:name, :username, :email, :password, :status)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':name' => $_POST['name'],
                ':username' => $_POST['username'],
                ':email' => $_POST['email'],
                ':password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                ':status' => $_POST['status']
            ]);
            $user_id = $pdo->lastInsertId();

            // Rolü ata
            $role_stmt = $pdo->prepare("INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)");
            $role_stmt->execute([$user_id, $_POST['role_id']]);

            add_log($pdo, 'create', 'users', $user_id, ['username' => $_POST['username']]);
            $response = ['status' => 'success', 'message' => 'Kullanıcı başarıyla oluşturuldu.'];
            break;

        case 'get_user':
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("
                SELECT u.id, u.name, u.username, u.email, u.status, ur.role_id 
                FROM users u 
                LEFT JOIN user_roles ur ON u.id = ur.user_id 
                WHERE u.id = ?
            ");
            $stmt->execute([$id]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($user) {
                $response = ['status' => 'success', 'data' => $user];
            } else {
                $response = ['status' => 'error', 'message' => 'Kullanıcı bulunamadı.'];
            }
            break;

        case 'update':
            $id = intval($_POST['id']);
            $update_fields = [
                'name' => $_POST['name'],
                'email' => $_POST['email'],
                'status' => $_POST['status']
            ];

            // Şifre alanı doluysa güncelle
            if (!empty($_POST['password'])) {
                $update_fields['password'] = password_hash($_POST['password'], PASSWORD_DEFAULT);
            }

            $set_clause = [];
            foreach ($update_fields as $key => $value) {
                $set_clause[] = "$key = :$key";
            }

            $sql = "UPDATE users SET " . implode(', ', $set_clause) . " WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $update_fields['id'] = $id;
            $stmt->execute($update_fields);

            // Rolü güncelle
            $role_stmt = $pdo->prepare("DELETE FROM user_roles WHERE user_id = ?");
            $role_stmt->execute([$id]);
            $role_stmt = $pdo->prepare("INSERT INTO user_roles (user_id, role_id) VALUES (?, ?)");
            $role_stmt->execute([$id, $_POST['role_id']]);

            add_log($pdo, 'update', 'users', $id);
            $response = ['status' => 'success', 'message' => 'Kullanıcı başarıyla güncellendi.'];
            break;

        case 'delete':
            $id = intval($_POST['id']);
            if ($id === 1) { // Admin kullanıcısının silinmesini engelle
                throw new Exception('Sistem yöneticisi silinemez.');
            }
            add_log($pdo, 'delete', 'users', $id);
            $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
            $stmt->execute([$id]);
            $response = ['status' => 'success', 'message' => 'Kullanıcı başarıyla silindi.'];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>