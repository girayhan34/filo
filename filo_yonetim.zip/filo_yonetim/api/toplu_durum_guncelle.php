<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// JSON yanıtı için dizi oluştur
$response = array('success' => false, 'message' => '');

// Yetki kontrolü
if (!isset($_SESSION['user_id'])) {
    $response['message'] = 'Yetkisiz erişim! Lütfen giriş yapın.';
    echo json_encode($response);
    exit;
}

try {
    // Gelen verileri al
    $personel_ids = isset($_POST['personel_ids']) ? $_POST['personel_ids'] : [];
    $yeni_durum = isset($_POST['yeni_durum']) ? trim($_POST['yeni_durum']) : '';
    
    // Geçerli durumlar
    $gecerli_durumlar = ['Aktif', 'İzinli', 'İşten Ayrıldı', 'İşten Çıkarıldı'];
    
    // Doğrulamalar
    if (empty($personel_ids) || !is_array($personel_ids)) {
        throw new Exception('Lütfen en az bir personel seçin!');
    }
    
    if (empty($yeni_durum) || !in_array($yeni_durum, $gecerli_durumlar)) {
        throw new Exception('Geçersiz durum değeri!');
    }
    
    // ID'leri güvenli hale getir
    $personel_ids = array_map('intval', $personel_ids);
    $placeholders = rtrim(str_repeat('?,', count($personel_ids)), ',');
    
    // Güncelleme işlemi
    $stmt = $pdo->prepare("UPDATE personel SET durum = ?, updated_at = NOW(), updated_by = ? WHERE id IN ($placeholders)");
    
    // Parametreleri hazırla (yeni_durum, updated_by ve ID'ler)
    $params = array_merge([$yeni_durum, $_SESSION['user_id']], $personel_ids);
    
    // Sorguyu çalıştır
    $stmt->execute($params);
    $affected_rows = $stmt->rowCount();
    
    // İşlem başarılı
    $response['success'] = true;
    $response['message'] = $affected_rows . ' personelin durumu "' . $yeni_durum . '" olarak güncellendi.';
    $response['affected_rows'] = $affected_rows;
    
} catch (PDOException $e) {
    $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>
