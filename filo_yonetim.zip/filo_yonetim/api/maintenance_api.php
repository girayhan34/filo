<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            $draw = intval($_POST['draw'] ?? 1);
            $start = intval($_POST['start'] ?? 0);
            $length = intval($_POST['length'] ?? 10);
            $searchValue = $_POST['search']['value'] ?? '';

            $totalRecords = $pdo->query("SELECT COUNT(id) FROM vehicle_maintenance")->fetchColumn();

            $queryFiltered = "SELECT COUNT(vm.id) FROM vehicle_maintenance vm JOIN vehicles v ON vm.vehicle_id = v.id WHERE v.plate LIKE :search OR vm.maintenance_type LIKE :search";
            $stmtFiltered = $pdo->prepare($queryFiltered);
            $stmtFiltered->execute([':search' => "%$searchValue%"]);
            $recordsFiltered = $stmtFiltered->fetchColumn();

            $queryData = "SELECT vm.*, v.plate, v.brand, v.model 
                          FROM vehicle_maintenance vm
                          JOIN vehicles v ON vm.vehicle_id = v.id
                          WHERE v.plate LIKE :search OR vm.maintenance_type LIKE :search
                          ORDER BY vm.maintenance_date DESC
                          LIMIT :start, :length";
            
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':search', "%$searchValue%", PDO::PARAM_STR);
            $stmtData->bindValue(':start', (int)$start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', (int)$length, PDO::PARAM_INT);
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                "draw" => $draw,
                "recordsTotal" => intval($totalRecords),
                "recordsFiltered" => intval($recordsFiltered),
                "data" => $data
            ];
            break;

        case 'create':
            $sql = "INSERT INTO vehicle_maintenance (vehicle_id, maintenance_date, maintenance_type, cost, description, status, next_maintenance_date) 
                    VALUES (:vehicle_id, :maintenance_date, :maintenance_type, :cost, :description, :status, :next_maintenance_date)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':vehicle_id' => $_POST['vehicle_id'],
                ':maintenance_date' => $_POST['maintenance_date'],
                ':maintenance_type' => $_POST['maintenance_type'],
                ':cost' => $_POST['cost'] ?: null,
                ':description' => $_POST['description'] ?: null,
                ':status' => $_POST['status'],
                ':next_maintenance_date' => $_POST['next_maintenance_date'] ?: null
            ]);
            $response = ['status' => 'success', 'message' => 'Bakım kaydı başarıyla oluşturuldu.'];
            break;

        case 'get_maintenance':
            if (!isset($_GET['id'])) {
                throw new Exception('Bakım ID belirtilmedi.');
            }
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("SELECT * FROM vehicle_maintenance WHERE id = ?");
            $stmt->execute([$id]);
            $maintenance = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($maintenance) {
                $response = ['status' => 'success', 'data' => $maintenance];
            } else {
                $response = ['status' => 'error', 'message' => 'Bakım kaydı bulunamadı.'];
            }
            break;

        case 'update':
            $id = intval($_POST['id']);
            $sql = "UPDATE vehicle_maintenance SET 
                        vehicle_id = :vehicle_id, 
                        maintenance_date = :maintenance_date, 
                        maintenance_type = :maintenance_type, 
                        cost = :cost, 
                        description = :description, 
                        status = :status, 
                        next_maintenance_date = :next_maintenance_date
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':vehicle_id' => $_POST['vehicle_id'],
                ':maintenance_date' => $_POST['maintenance_date'],
                ':maintenance_type' => $_POST['maintenance_type'],
                ':cost' => $_POST['cost'] ?: null,
                ':description' => $_POST['description'] ?: null,
                ':status' => $_POST['status'],
                ':next_maintenance_date' => $_POST['next_maintenance_date'] ?: null
            ]);

            $response = ['status' => 'success', 'message' => 'Bakım kaydı başarıyla güncellendi.'];
            break;

        case 'delete':
            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("DELETE FROM vehicle_maintenance WHERE id = ?");
            $stmt->execute([$id]);
            $response = ['status' => 'success', 'message' => 'Bakım kaydı başarıyla silindi.'];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>