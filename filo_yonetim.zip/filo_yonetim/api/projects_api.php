<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            $draw = intval($_POST['draw'] ?? 1);
            $start = intval($_POST['start'] ?? 0);
            $length = intval($_POST['length'] ?? 10);
            $searchValue = $_POST['search']['value'] ?? '';

            $totalRecords = $pdo->query("SELECT COUNT(id) FROM projects")->fetchColumn();

            $queryFiltered = "SELECT COUNT(p.id) FROM projects p LEFT JOIN customers c ON p.customer_id = c.id WHERE p.project_name LIKE :search OR c.name LIKE :search";
            $stmtFiltered = $pdo->prepare($queryFiltered);
            $stmtFiltered->execute([':search' => "%$searchValue%"]);
            $recordsFiltered = $stmtFiltered->fetchColumn();

            $queryData = "SELECT p.*, c.name as customer_name 
                          FROM projects p
                          LEFT JOIN customers c ON p.customer_id = c.id
                          WHERE p.project_name LIKE :search OR c.name LIKE :search
                          ORDER BY p.start_date DESC
                          LIMIT :start, :length";
            
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':search', "%$searchValue%", PDO::PARAM_STR);
            $stmtData->bindValue(':start', (int)$start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', (int)$length, PDO::PARAM_INT);
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                "draw" => $draw,
                "recordsTotal" => intval($totalRecords),
                "recordsFiltered" => intval($recordsFiltered),
                "data" => $data
            ];
            break;

        case 'create':
            $sql = "INSERT INTO projects (project_name, customer_id, start_date, end_date, status, budget, description, created_by) 
                    VALUES (:project_name, :customer_id, :start_date, :end_date, :status, :budget, :description, :created_by)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':project_name' => $_POST['project_name'],
                ':customer_id' => $_POST['customer_id'] ?: null,
                ':start_date' => $_POST['start_date'] ?: null,
                ':end_date' => $_POST['end_date'] ?: null,
                ':status' => $_POST['status'],
                ':budget' => $_POST['budget'] ?: null,
                ':description' => $_POST['description'] ?: null,
                ':created_by' => $_SESSION['user_id']
            ]);

            $response = ['status' => 'success', 'message' => 'Proje başarıyla oluşturuldu.'];
            break;

        case 'get_project':
            if (!isset($_GET['id'])) {
                throw new Exception('Proje ID belirtilmedi.');
            }
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ?");
            $stmt->execute([$id]);
            $project = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($project) {
                $response = ['status' => 'success', 'data' => $project];
            } else {
                $response = ['status' => 'error', 'message' => 'Proje bulunamadı.'];
            }
            break;

        case 'update':
            $id = intval($_POST['id']);
            $sql = "UPDATE projects SET 
                        project_name = :project_name, 
                        customer_id = :customer_id, 
                        start_date = :start_date, 
                        end_date = :end_date, 
                        status = :status, 
                        budget = :budget, 
                        description = :description
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':project_name' => $_POST['project_name'],
                ':customer_id' => $_POST['customer_id'] ?: null,
                ':start_date' => $_POST['start_date'] ?: null,
                ':end_date' => $_POST['end_date'] ?: null,
                ':status' => $_POST['status'],
                ':budget' => $_POST['budget'] ?: null,
                ':description' => $_POST['description'] ?: null
            ]);

            $response = ['status' => 'success', 'message' => 'Proje başarıyla güncellendi.'];
            break;

        case 'delete':
            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
            $stmt->execute([$id]);
            $response = ['status' => 'success', 'message' => 'Proje başarıyla silindi.'];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>