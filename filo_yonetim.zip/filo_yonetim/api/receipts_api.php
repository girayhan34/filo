<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';

$action = $_GET['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            // DataTables için sunucu taraflı işleme
            $draw = $_POST['draw'] ?? 1;
            $start = $_POST['start'] ?? 0;
            $length = $_POST['length'] ?? 10;
            $searchValue = $_POST['search']['value'] ?? '';

            // Toplam kayıt sayısı
            $totalRecords = $pdo->query("SELECT COUNT(id) FROM receipts")->fetchColumn();

            // Filtrelenmiş kayıt sayısı
            $queryFiltered = "SELECT COUNT(r.id) FROM receipts r 
                              LEFT JOIN vehicles v ON r.vehicle_id = v.id 
                              LEFT JOIN users u ON r.created_by = u.id 
                              WHERE r.receipt_no LIKE :search
                              OR v.plate LIKE :search 
                              OR r.customer_name LIKE :search";
            $stmtFiltered = $pdo->prepare($queryFiltered);
            $stmtFiltered->execute([':search' => "%$searchValue%"]);
            $totalFiltered = $stmtFiltered->fetchColumn();

            // Verileri çek
            $queryData = "SELECT r.*, v.plate as plate_number, v.brand, u.name as created_by_name 
                          FROM receipts r 
                          LEFT JOIN vehicles v ON r.vehicle_id = v.id 
                          LEFT JOIN users u ON r.created_by = u.id
                          WHERE r.receipt_no LIKE :search
                          OR v.plate LIKE :search 
                          OR r.customer_name LIKE :search
                          ORDER BY r.receipt_date DESC, r.id DESC
                          LIMIT :start, :length";
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':search', "%$searchValue%", PDO::PARAM_STR);
            $stmtData->bindValue(':start', (int)$start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', (int)$length, PDO::PARAM_INT);
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                "draw" => intval($draw),
                "recordsTotal" => intval($totalRecords),
                "recordsFiltered" => intval($totalFiltered),
                "data" => $data
            ];
            break;

        case 'create':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Geçersiz istek metodu.');
            }

            $pdo->beginTransaction();

            $hours = (float)($_POST['working_hours'] ?? 0);
            $price = (float)($_POST['unit_price'] ?? 0);
            $total_amount = $hours * $price;

            $stmt = $pdo->prepare(
                "INSERT INTO receipts (receipt_no, receipt_date, vehicle_id, customer_name, description, working_hours, unit_price, total_amount, created_by) 
                 VALUES (:receipt_no, :receipt_date, :vehicle_id, :customer_name, :description, :working_hours, :unit_price, :total_amount, :created_by)"
            );

            $stmt->execute([
                ':receipt_no' => $_POST['receipt_no'],
                ':receipt_date' => $_POST['receipt_date'],
                ':vehicle_id' => $_POST['vehicle_id'],
                ':customer_name' => $_POST['customer_name'],
                ':description' => $_POST['description'] ?? null,
                ':working_hours' => $hours,
                ':unit_price' => $price,
                ':total_amount' => $total_amount,
                ':created_by' => $_SESSION['user_id']
            ]);

            $receipt_id = $pdo->lastInsertId();

            // Gelir-Gider tablosuna otomatik kayıt ekle
            $income_stmt = $pdo->prepare(
                "INSERT INTO income_expense (type, date, description, category, amount, related_receipt_id, created_by)
                 VALUES ('income', :date, :description, 'Fiş Geliri', :amount, :receipt_id, :created_by)"
            );
            $income_stmt->execute([
                ':date' => $_POST['receipt_date'],
                ':description' => "Fiş No: {$_POST['receipt_no']} - {$_POST['customer_name']}",
                ':amount' => $total_amount,
                ':receipt_id' => $receipt_id,
                ':created_by' => $_SESSION['user_id']
            ]);

            $pdo->commit();

            $response = ['status' => 'success', 'message' => 'Fiş başarıyla oluşturuldu ve gelir olarak kaydedildi.'];
            break;

        case 'get_receipt':
            if (!isset($_GET['id'])) {
                throw new Exception('Fiş ID belirtilmedi.');
            }
            $id = (int)$_GET['id'];
            $stmt = $pdo->prepare("SELECT * FROM receipts WHERE id = ?");
            $stmt->execute([$id]);
            $receipt = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($receipt) {
                $response = ['status' => 'success', 'data' => $receipt];
            } else {
                $response = ['status' => 'error', 'message' => 'Fiş bulunamadı.'];
            }
            break;

        case 'update':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }

            $pdo->beginTransaction();

            $id = (int)$_POST['id'];
            $hours = (float)($_POST['working_hours'] ?? 0);
            $price = (float)($_POST['unit_price'] ?? 0);
            $total_amount = $hours * $price;

            // Fişi güncelle
            $stmt = $pdo->prepare(
                "UPDATE receipts SET receipt_date = :receipt_date, vehicle_id = :vehicle_id, customer_name = :customer_name, 
                 description = :description, working_hours = :working_hours, unit_price = :unit_price, total_amount = :total_amount
                 WHERE id = :id"
            );

            $receipt_data = [
                ':id' => $id,
                ':receipt_date' => $_POST['receipt_date'],
                ':vehicle_id' => $_POST['vehicle_id'],
                ':customer_name' => $_POST['customer_name'],
                ':description' => $_POST['description'] ?? null,
                ':working_hours' => $hours,
                ':unit_price' => $price,
                ':total_amount' => $total_amount
            ];
            $stmt->execute($receipt_data);

            // İlişkili gelir kaydını güncelle
            $income_stmt = $pdo->prepare(
                "UPDATE income_expense SET date = :date, description = :description, amount = :amount WHERE related_receipt_id = :receipt_id"
            );
            $income_stmt->execute([
                ':date' => $_POST['receipt_date'],
                ':description' => "Fiş No: {$_POST['receipt_no']} - {$_POST['customer_name']}",
                ':amount' => $total_amount,
                ':receipt_id' => $id
            ]);

            $pdo->commit();

            $response = ['status' => 'success', 'message' => 'Fiş ve ilişkili gelir kaydı başarıyla güncellendi.'];
            break;

        case 'delete':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }

            $id = (int)$_POST['id'];
            $pdo->beginTransaction();

            // İlişkili gelir kaydını sil
            $stmt_delete_income = $pdo->prepare("DELETE FROM income_expense WHERE related_receipt_id = ?");
            $stmt_delete_income->execute([$id]);

            // Fişi sil
            $stmt = $pdo->prepare("DELETE FROM receipts WHERE id = ?");
            $stmt->execute([$id]);

            $pdo->commit();

            $response = ['status' => 'success', 'message' => 'Fiş ve ilişkili gelir kaydı başarıyla silindi.'];
            break;
    }
} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    $response = ['status' => 'error', 'message' => $e->getMessage()];
}

echo json_encode($response);