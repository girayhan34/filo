<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Get personnel ID from query string
$personnel_id = isset($_GET['personnel_id']) ? (int)$_GET['personnel_id'] : 0;

if ($personnel_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz personel ID.']);
    exit;
}

try {
    // Get leaves for the personnel
    $stmt = $pdo->prepare("SELECT pl.*, u.name as evaluator_name 
                          FROM personnel_leaves pl
                          LEFT JOIN users u ON pl.evaluated_by = u.id
                          WHERE pl.personnel_id = ? 
                          ORDER BY pl.start_date DESC");
    $stmt->execute([$personnel_id]);
    $leaves = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format the response
    $response = [];
    foreach ($leaves as $leave) {
        $response[] = [
            'id' => $leave['id'],
            'leave_type' => $leave['leave_type'],
            'start_date' => $leave['start_date'],
            'end_date' => $leave['end_date'],
            'notes' => $leave['notes'],
            'status' => $leave['status'],
            'evaluator_name' => $leave['evaluator_name'],
            'created_at' => $leave['created_at']
        ];
    }
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}
