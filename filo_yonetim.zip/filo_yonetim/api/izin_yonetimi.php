<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// JSON yanıtı için başlık
header('Content-Type: application/json');

// HTTP Metodunu al
$method = $_SERVER['REQUEST_METHOD'];

// Yetki kontrolleri
$kullanici_id = $_SESSION['user_id'] ?? null;
$yetkili_roller = ['admin', 'ik'];
$yetkili_mi = isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], $yetkili_roller);

// İzin yönetimi endpoint'i
switch ($method) {
    case 'GET':
        // İzin listesini getir
        getIzinler();
        break;
    case 'POST':
        // Yeni izin talebi ekle
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $_POST;
        }
        izinTalebiEkle($data);
        break;
    case 'PUT':
        // İzin durumunu güncelle (onayla/reddet)
        $data = json_decode(file_get_contents('php://input'), true);
        izinDurumuGuncelle($data);
        break;
    case 'DELETE':
        // İzin talebini sil
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            parse_str(file_get_contents('php://input'), $data);
        }
        izinTalebiSil($data);
        break;
    default:
        http_response_code(405);
        echo json_encode(['status' => 'error', 'message' => 'Geçersiz metod']);
        break;
}

// İzin listesini getir
function getIzinler() {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    try {
        $params = [];
        $where = [];
        
        // Yetkili değilse sadece kendi izinlerini görebilir
        if (!$yetkili_mi) {
            $where[] = "pi.personel_id = :personel_id";
            $params[':personel_id'] = $kullanici_id;
        } else {
            // Filtreleme parametreleri
            if (!empty($_GET['personel_id'])) {
                $where[] = "pi.personel_id = :personel_id";
                $params[':personel_id'] = intval($_GET['personel_id']);
            }
            
            if (!empty($_GET['durum'])) {
                $where[] = "pi.durum = :durum";
                $params[':durum'] = $_GET['durum'];
            }
            
            if (!empty($_GET['izin_tipi'])) {
                $where[] = "pi.izin_tipi = :izin_tipi";
                $params[':izin_tipi'] = $_GET['izin_tipi'];
            }
            
            if (!empty($_GET['baslangic_tarihi'])) {
                $where[] = "pi.bitis_tarihi >= :baslangic_tarihi";
                $params[':baslangic_tarihi'] = $_GET['baslangic_tarihi'];
            }
            
            if (!empty($_GET['bitis_tarihi'])) {
                $where[] = "pi.baslangic_tarihi <= :bitis_tarihi";
                $params[':bitis_tarihi'] = $_GET['bitis_tarihi'] . ' 23:59:59';
            }
        }
        
        // Sorguyu oluştur
        $sql = "SELECT 
                    pi.*,
                    CONCAT(p.ad, ' ', p.soyad) as personel_adi,
                    p.sicil_no,
                    p.departman_id,
                    d.departman_adi,
                    u1.ad_soyad as olusturan_kullanici,
                    u2.ad_soyad as onaylayan_kullanici
                FROM personel_izinleri pi
                LEFT JOIN personel p ON pi.personel_id = p.id
                LEFT JOIN departmanlar d ON p.departman_id = d.id
                LEFT JOIN users u1 ON pi.created_by = u1.id
                LEFT JOIN users u2 ON pi.onaylayan_id = u2.id";
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        
        $sql .= " ORDER BY pi.baslangic_tarihi DESC, pi.created_at DESC";
        
        // Sayfalama
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 25;
        $offset = ($page - 1) * $limit;
        
        $sql .= " LIMIT :limit OFFSET :offset";
        
        $stmt = $pdo->prepare($sql);
        
        // Parametreleri bağla
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        $izinler = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Toplam kayıt sayısını al
        $countSql = "SELECT COUNT(*) as total FROM personel_izinleri pi";
        if (!empty($where)) {
            $countSql .= " WHERE " . implode(" AND ", $where);
        }
        
        $stmt = $pdo->prepare($countSql);
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        $stmt->execute();
        $total = $stmt->fetchColumn();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success',
            'data' => $izinler,
            'pagination' => [
                'total' => (int)$total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ]
        ]);
        
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

// Yeni izin talebi ekle
function izinTalebiEkle($data) {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    // Gerekli alanlar
    $requiredFields = [
        'personel_id' => 'Personel',
        'izin_tipi' => 'İzin Tipi',
        'baslangic_tarihi' => 'Başlangıç Tarihi',
        'bitis_tarihi' => 'Bitiş Tarihi'
    ];
    
    $errors = [];
    
    // Zorunlu alanları kontrol et
    foreach ($requiredFields as $field => $label) {
        if (empty($data[$field])) {
            $errors[] = "$label alanı zorunludur.";
        }
    }
    
    // Hata varsa dön
    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $errors]);
        return;
    }
    
    // Verileri al ve temizle
    $personel_id = intval($data['personel_id']);
    $izin_tipi = trim($data['izin_tipi']);
    $baslangic_tarihi = date('Y-m-d', strtotime($data['baslangic_tarihi']));
    $bitis_tarihi = date('Y-m-d', strtotime($data['bitis_tarihi']));
    $aciklama = !empty($data['aciklama']) ? trim($data['aciklama']) : null;
    
    // Eğer yetkili değilse, sadece kendi adına izin talep edebilir
    if (!$yetkili_mi && $personel_id != $kullanici_id) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Sadece kendi adınıza izin talebinde bulunabilirsiniz!']);
        return;
    }
    
    // Tarih kontrolü
    if (strtotime($baslangic_tarihi) > strtotime($bitis_tarihi)) {
        $errors[] = "Bitiş tarihi, başlangıç tarihinden önce olamaz.";
    }
    
    // İzin gün sayısını hesapla
    $gun_sayisi = (strtotime($bitis_tarihi) - strtotime($baslangic_tarihi)) / (60 * 60 * 24) + 1;
    
    // Geçmiş tarih kontrolü
    if (strtotime($baslangic_tarihi) < strtotime(date('Y-m-d'))) {
        $errors[] = "Geçmiş tarih için izin talebinde bulunamazsınız.";
    }
    
    // Aynı tarih aralığında başka bir izin talebi var mı kontrol et
    $sql = "SELECT COUNT(*) FROM personel_izinleri 
            WHERE personel_id = :personel_id 
            AND (
                (:baslangic_tarihi BETWEEN baslangic_tarihi AND bitis_tarihi) OR
                (:bitis_tarihi BETWEEN baslangic_tarihi AND bitis_tarihi) OR
                (baslangic_tarihi BETWEEN :baslangic_tarihi2 AND :bitis_tarihi2) OR
                (bitis_tarihi BETWEEN :baslangic_tarihi3 AND :bitis_tarihi3)
            )
            AND durum != 'Reddedildi'
            AND id != :izin_id";
    
    $izin_id = isset($data['id']) ? intval($data['id']) : 0;
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':personel_id' => $personel_id,
        ':baslangic_tarihi' => $baslangic_tarihi,
        ':bitis_tarihi' => $bitis_tarihi,
        ':baslangic_tarihi2' => $baslangic_tarihi,
        ':bitis_tarihi2' => $bitis_tarihi,
        ':baslangic_tarihi3' => $baslangic_tarihi,
        ':bitis_tarihi3' => $bitis_tarihi,
        ':izin_id' => $izin_id
    ]);
    
    $conflictingLeaves = $stmt->fetchColumn();
    
    if ($conflictingLeaves > 0) {
        $errors[] = "Belirtilen tarih aralığında zaten bir izin talebiniz bulunmaktadır.";
    }
    
    // Yıllık izin kontrolü
    if ($izin_tipi === 'Yıllık İzin') {
        // Personelin yıllık izin hakkını kontrol et
        $sql = "SELECT 
                    yillik_izin_hakki,
                    (SELECT COALESCE(SUM(toplam_gun), 0) 
                     FROM personel_izinleri 
                     WHERE personel_id = :personel_id 
                     AND izin_tipi = 'Yıllık İzin' 
                     AND durum = 'Onaylandı'
                     AND id != :izin_id
                     AND YEAR(baslangic_tarihi) = YEAR(CURDATE())) as kullanilan_izin
                FROM personel 
                WHERE id = :personel_id2";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':personel_id' => $personel_id,
            ':personel_id2' => $personel_id,
            ':izin_id' => $izin_id
        ]);
        $izin_bilgisi = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $kalan_izin = $izin_bilgisi['yillik_izin_hakki'] - $izin_bilgisi['kullanilan_izin'];
        
        if ($gun_sayisi > $kalan_izin) {
            $errors[] = "Yeterli yıllık izin hakkınız bulunmamaktadır. Kalan izin hakkınız: $kalan_izin gün";
        }
    }
    
    // Hata varsa dön
    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $errors]);
        return;
    }
    
    try {
        // İşlemi başlat
        $pdo->beginTransaction();
        
        if ($izin_id > 0) {
            // Mevcut izni güncelle
            $sql = "UPDATE personel_izinleri SET 
                        izin_tipi = :izin_tipi,
                        baslangic_tarihi = :baslangic_tarihi,
                        bitis_tarihi = :bitis_tarihi,
                        toplam_gun = :toplam_gun,
                        aciklama = :aciklama,
                        durum = :durum,
                        updated_at = NOW()
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                ':izin_tipi' => $izin_tipi,
                ':baslangic_tarihi' => $baslangic_tarihi,
                ':bitis_tarihi' => $bitis_tarihi,
                ':toplam_gun' => $gun_sayisi,
                ':aciklama' => $aciklama,
                ':durum' => $yetkili_mi ? 'Onaylandı' : 'Beklemede',
                ':id' => $izin_id
            ]);
            
            $message = 'İzin talebi başarıyla güncellendi.';
        } else {
            // Yeni izin talebi ekle
            $sql = "INSERT INTO personel_izinleri (
                        personel_id, 
                        izin_tipi, 
                        baslangic_tarihi, 
                        bitis_tarihi, 
                        toplam_gun, 
                        aciklama, 
                        durum,
                        created_by
                    ) VALUES (
                        :personel_id, 
                        :izin_tipi, 
                        :baslangic_tarihi, 
                        :bitis_tarihi, 
                        :toplam_gun, 
                        :aciklama, 
                        :durum,
                        :created_by
                    )";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                ':personel_id' => $personel_id,
                ':izin_tipi' => $izin_tipi,
                ':baslangic_tarihi' => $baslangic_tarihi,
                ':bitis_tarihi' => $bitis_tarihi,
                ':toplam_gun' => $gun_sayisi,
                ':aciklama' => $aciklama,
                ':durum' => $yetkili_mi ? 'Onaylandı' : 'Beklemede',
                ':created_by' => $kullanici_id
            ]);
            
            $izin_id = $pdo->lastInsertId();
            $message = $yetkili_mi ? 'İzin başarıyla eklendi.' : 'İzin talebiniz alındı. Onay bekliyor.';
        }
        
        // Eğer yetkili biri tarafından doğrudan onaylandıysa, onaylayan bilgisini güncelle
        if ($yetkili_mi && $data['durum'] === 'Onaylandı') {
            $sql = "UPDATE personel_izinleri 
                    SET onaylayan_id = :onaylayan_id, 
                        onay_tarihi = NOW(),
                        updated_at = NOW()
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':onaylayan_id' => $kullanici_id,
                ':id' => $izin_id
            ]);
            
            // Personelin toplam kullanılan izin gününü güncelle
            if ($izin_tipi === 'Yıllık İzin') {
                $sql = "UPDATE personel 
                        SET kullanilan_yillik_izin = (
                            SELECT COALESCE(SUM(toplam_gun), 0)
                            FROM personel_izinleri 
                            WHERE personel_id = :personel_id 
                            AND izin_tipi = 'Yıllık İzin' 
                            AND durum = 'Onaylandi'
                        ),
                        updated_at = NOW()
                        WHERE id = :personel_id";
                
                $stmt = $pdo->prepare($sql);
                $stmt->execute([':personel_id' => $personel_id]);
            }
        }
        
        // İşlemi onayla
        $pdo->commit();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success', 
            'message' => $message,
            'data' => ['id' => $izin_id]
        ]);
        
    } catch (PDOException $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

// İzin durumunu güncelle (onayla/reddet)
function izinDurumuGuncelle($data) {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    // Yetki kontrolü
    if (!$yetkili_mi) {
        http_response_code(403);
        echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok!']);
        return;
    }
    
    // Gerekli alanlar
    if (empty($data['id']) || empty($data['durum'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'İzin ID ve durum bilgisi zorunludur.']);
        return;
    }
    
    $izin_id = intval($data['id']);
    $durum = trim($data['durum']);
    $aciklama = !empty($data['aciklama']) ? trim($data['aciklama']) : null;
    
    // Geçerli durum kontrolü
    if (!in_array($durum, ['Onaylandı', 'Reddedildi', 'İptal Edildi'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Geçersiz durum değeri.']);
        return;
    }
    
    try {
        // İşlemi başlat
        $pdo->beginTransaction();
        
        // İzin bilgilerini al
        $sql = "SELECT * FROM personel_izinleri WHERE id = :id FOR UPDATE";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $izin_id]);
        $izin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$izin) {
            throw new Exception('İzin kaydı bulunamadı.');
        }
        
        // Eğer zaten onaylanmış veya reddedilmişse işlem yapma
        if (in_array($izin['durum'], ['Onaylandı', 'Reddedildi', 'İptal Edildi'])) {
            throw new Exception('Bu izin talebi zaten ' . $izin['durum'] . ' durumunda.');
        }
        
        // İzin durumunu güncelle
        $sql = "UPDATE personel_izinleri 
                SET durum = :durum,
                    onaylayan_id = :onaylayan_id,
                    onay_tarihi = NOW(),
                    aciklama = COALESCE(:aciklama, aciklama),
                    updated_at = NOW()
                WHERE id = :id";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':durum' => $durum,
            ':onaylayan_id' => $kullanici_id,
            ':aciklama' => $aciklama,
            ':id' => $izin_id
        ]);
        
        // Eğer izin onaylandıysa, personelin kullanılan izin gününü güncelle
        if ($durum === 'Onaylandı' && $izin['izin_tipi'] === 'Yıllık İzin') {
            $sql = "UPDATE personel 
                    SET kullanilan_yillik_izin = (
                        SELECT COALESCE(SUM(toplam_gun), 0)
                        FROM personel_izinleri 
                        WHERE personel_id = :personel_id 
                        AND izin_tipi = 'Yıllık İzin' 
                        AND durum = 'Onaylandı'
                    ),
                    updated_at = NOW()
                    WHERE id = :personel_id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([':personel_id' => $izin['personel_id']]);
            
            // Eğer mevcut yılda değilse, bir sonraki yıla aktarım yapılabilir
            if (date('Y', strtotime($izin['baslangic_tarihi'])) > date('Y')) {
                // Bir sonraki yıla aktarım yapılacaksa burada işlemler yapılabilir
            }
        }
        
        // İşlemi onayla
        $pdo->commit();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success', 
            'message' => 'İzin durumu başarıyla güncellendi.'
        ]);
        
    } catch (PDOException $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

// İzin talebini sil
function izinTalebiSil($data) {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    // Gerekli alanlar
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'İzin ID zorunludur.']);
        return;
    }
    
    $izin_id = intval($data['id']);
    
    try {
        // İzin bilgilerini al
        $sql = "SELECT * FROM personel_izinleri WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $izin_id]);
        $izin = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$izin) {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'İzin kaydı bulunamadı.']);
            return;
        }
        
        // Yetki kontrolü - sadece oluşturan veya yetkili silebilir
        if (!$yetkili_mi && $izin['created_by'] != $kullanici_id) {
            http_response_code(403);
            echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok!']);
            return;
        }
        
        // İşlemi başlat
        $pdo->beginTransaction();
        
        // Eğer izin onaylanmışsa, personelin kullanılan izin gününü güncelle
        if ($izin['durum'] === 'Onaylandı' && $izin['izin_tipi'] === 'Yıllık İzin') {
            $sql = "UPDATE personel 
                    SET kullanilan_yillık_izin = GREATEST(0, kullanilan_yillık_izin - :gun_sayisi),
                        updated_at = NOW()
                    WHERE id = :personel_id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':gun_sayisi' => $izin['toplam_gun'],
                ':personel_id' => $izin['personel_id']
            ]);
        }
        
        // İzni sil
        $sql = "DELETE FROM personel_izinleri WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([':id' => $izin_id]);
        
        // İşlemi onayla
        $pdo->commit();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success', 
            'message' => 'İzin talebi başarıyla silindi.'
        ]);
        
    } catch (PDOException $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>
