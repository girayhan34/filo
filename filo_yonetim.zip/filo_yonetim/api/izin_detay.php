<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Yetki kontrolü
if (!yetki_kontrol('izin_goruntule')) {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok!']);
    exit;
}

// Hata raporlama
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Varsayılan yanıt
$response = [
    'status' => 'error',
    'message' => 'İzin detayları getirilemedi!',
    'data' => null
];

try {
    // İzin ID'sini al
    $izin_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
    
    if ($izin_id <= 0) {
        throw new Exception('Geçersiz izin ID\'si!');
    }
    
    // İzin detaylarını getir
    $query = "
        SELECT 
            i.*,
            CONCAT(p.ad, ' ', p.soyad) as personel_adi,
            p.departman,
            p.unvan,
            it.adi as izin_tipi_adi,
            it.ucretli_mi,
            it.renk_kodu,
            CONCAT(u.ad, ' ', u.soyad) as islem_yapan,
            i.olusturma_tarihi as talep_tarihi,
            i.guncelleme_tarihi as son_islem_tarihi
        FROM izin_talepleri i
        INNER JOIN personel p ON i.personel_id = p.id
        LEFT JOIN izin_tipleri it ON i.izin_tipi_id = it.id
        LEFT JOIN kullanicilar u ON i.izin_veren_id = u.id
        WHERE i.id = :id
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':id' => $izin_id]);
    $izin = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$izin) {
        throw new Exception('İzin kaydı bulunamadı!');
    }
    
    // İlgili belgeleri getir (eğer varsa)
    $query = "
        SELECT 
            id,
            dosya_adi,
            dosya_yolu,
            aciklama,
            olusturma_tarihi
        FROM izin_dokumanlari
        WHERE izin_talebi_id = :izin_id
        ORDER BY olusturma_tarihi DESC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':izin_id' => $izin_id]);
    $dokumanlar = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // İşlem geçmişini getir (eğer varsa)
    $query = "
        SELECT 
            ih.*,
            CONCAT(u.ad, ' ', u.soyad) as islem_yapan
        FROM islem_gecmisi ih
        LEFT JOIN kullanicilar u ON ih.kullanici_id = u.id
        WHERE ih.tablo_adi = 'izin_talepleri' 
        AND ih.kayit_id = :izin_id
        ORDER BY ih.islem_tarihi DESC
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([':izin_id' => $izin_id]);
    $islem_gecmisi = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // İzin kullanım istatistiklerini getir
    $query = "
        SELECT 
            it.adi as izin_tipi,
            COUNT(*) as toplam_talep,
            SUM(CASE WHEN i.durum = 'Onaylandı' THEN 1 ELSE 0 END) as onaylanan,
            SUM(CASE WHEN i.durum = 'Reddedildi' THEN 1 ELSE 0 END) as reddedilen,
            SUM(CASE WHEN i.durum = 'Onay Bekliyor' THEN 1 ELSE 0 END) as bekleyen,
            SUM(i.toplam_gun) as toplam_gun
        FROM izin_talepleri i
        INNER JOIN izin_tipleri it ON i.izin_tipi_id = it.id
        WHERE i.personel_id = :personel_id
        AND i.id != :izin_id
        GROUP BY i.izin_tipi_id, it.adi
    ";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute([
        ':personel_id' => $izin['personel_id'],
        ':izin_id' => $izin_id
    ]);
    $istatistikler = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Tüm verileri birleştir
    $response = [
        'status' => 'success',
        'message' => 'İzin detayları başarıyla getirildi.',
        'data' => [
            'temel_bilgiler' => $izin,
            'dokumanlar' => $dokumanlar,
            'islem_gecmisi' => $islem_gecmisi,
            'istatistikler' => $istatistikler
        ]
    ];
    
} catch (PDOException $e) {
    $response = [
        'status' => 'error',
        'message' => 'Veritabanı hatası: ' . $e->getMessage(),
        'data' => null
    ];
} catch (Exception $e) {
    $response = [
        'status' => 'error',
        'message' => $e->getMessage(),
        'data' => null
    ];
}

// JSON yanıtını döndür
header('Content-Type: application/json');
echo json_encode($response);
?>
