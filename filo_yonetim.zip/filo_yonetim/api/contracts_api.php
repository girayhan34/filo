<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';
require_once '../includes/functions.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            $draw = intval($_POST['draw'] ?? 1);
            $start = intval($_POST['start'] ?? 0);
            $length = intval($_POST['length'] ?? 10);
            $searchValue = $_POST['search']['value'] ?? '';

            $totalRecords = $pdo->query("SELECT COUNT(id) FROM contracts")->fetchColumn();

            $queryFiltered = "SELECT COUNT(co.id) FROM contracts co 
                              LEFT JOIN customers c ON co.customer_id = c.id 
                              WHERE co.contract_no LIKE :search OR co.title LIKE :search OR c.name LIKE :search";
            $stmtFiltered = $pdo->prepare($queryFiltered);
            $stmtFiltered->execute([':search' => "%$searchValue%"]);
            $recordsFiltered = $stmtFiltered->fetchColumn();

            $queryData = "SELECT co.*, c.name as customer_name 
                          FROM contracts co
                          LEFT JOIN customers c ON co.customer_id = c.id
                          WHERE co.contract_no LIKE :search OR co.title LIKE :search OR c.name LIKE :search
                          ORDER BY co.start_date DESC
                          LIMIT :start, :length";
            
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':search', "%$searchValue%", PDO::PARAM_STR);
            $stmtData->bindValue(':start', (int)$start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', (int)$length, PDO::PARAM_INT);
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                "draw" => $draw,
                "recordsTotal" => intval($totalRecords),
                "recordsFiltered" => intval($recordsFiltered),
                "data" => $data
            ];
            break;

        case 'create':
            $file_path = handleFileUpload('contract_file');

            $sql = "INSERT INTO contracts (contract_no, title, customer_id, project_id, start_date, end_date, renewal_date, total_value, status, file_path, notes, created_by) 
                    VALUES (:contract_no, :title, :customer_id, :project_id, :start_date, :end_date, :renewal_date, :total_value, :status, :file_path, :notes, :created_by)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':contract_no' => $_POST['contract_no'],
                ':title' => $_POST['title'],
                ':customer_id' => $_POST['customer_id'],
                ':project_id' => $_POST['project_id'] ?: null,
                ':start_date' => $_POST['start_date'],
                ':end_date' => $_POST['end_date'] ?: null,
                ':renewal_date' => $_POST['renewal_date'] ?: null,
                ':total_value' => $_POST['total_value'] ?: null,
                ':status' => $_POST['status'],
                ':file_path' => $file_path,
                ':notes' => $_POST['notes'] ?: null,
                ':created_by' => $_SESSION['user_id']
            ]);

            $contract_id = $pdo->lastInsertId();
            add_log($pdo, 'create', 'contracts', $contract_id, ['contract_no' => $_POST['contract_no'], 'title' => $_POST['title']]);
            $response = ['status' => 'success', 'message' => 'Sözleşme başarıyla oluşturuldu.'];
            break;

        case 'get_contract':
            if (!isset($_GET['id'])) {
                throw new Exception('Sözleşme ID belirtilmedi.');
            }
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("SELECT * FROM contracts WHERE id = ?");
            $stmt->execute([$id]);
            $contract = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($contract) {
                $response = ['status' => 'success', 'data' => $contract];
            } else {
                $response = ['status' => 'error', 'message' => 'Sözleşme bulunamadı.'];
            }
            break;

        case 'update':
            $id = intval($_POST['id']);
            $file_path = handleFileUpload('contract_file');

            // Eğer yeni dosya yüklenmediyse, mevcut dosya yolunu koru
            if ($file_path === null) {
                $stmt = $pdo->prepare("SELECT file_path FROM contracts WHERE id = ?");
                $stmt->execute([$id]);
                $file_path = $stmt->fetchColumn();
            }

            $sql = "UPDATE contracts SET 
                        title = :title, 
                        customer_id = :customer_id, 
                        project_id = :project_id, 
                        start_date = :start_date, 
                        end_date = :end_date, 
                        renewal_date = :renewal_date, 
                        total_value = :total_value, 
                        status = :status, 
                        file_path = :file_path,
                        notes = :notes
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':title' => $_POST['title'],
                ':customer_id' => $_POST['customer_id'],
                ':project_id' => $_POST['project_id'] ?: null,
                ':start_date' => $_POST['start_date'],
                ':end_date' => $_POST['end_date'] ?: null,
                ':renewal_date' => $_POST['renewal_date'] ?: null,
                ':total_value' => $_POST['total_value'] ?: null,
                ':status' => $_POST['status'],
                ':file_path' => $file_path,
                ':notes' => $_POST['notes'] ?: null
            ]);

            add_log($pdo, 'update', 'contracts', $id, ['contract_no' => $_POST['contract_no']]);
            $response = ['status' => 'success', 'message' => 'Sözleşme başarıyla güncellendi.'];
            break;

        case 'delete':
            $id = intval($_POST['id']);

            // Önce dosyayı sunucudan sil
            $stmt = $pdo->prepare("SELECT file_path FROM contracts WHERE id = ?");
            $stmt->execute([$id]);
            $contract = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($contract && !empty($contract['file_path']) && file_exists('../' . $contract['file_path'])) {
                unlink('../' . $contract['file_path']);
            }

            add_log($pdo, 'delete', 'contracts', $id, ['contract_no' => $contract['contract_no'] ?? 'Bilinmiyor']);

            $stmt = $pdo->prepare("DELETE FROM contracts WHERE id = ?");
            $stmt->execute([$id]);
            $response = ['status' => 'success', 'message' => 'Sözleşme başarıyla silindi.'];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    if ($e->getCode() == 23000) {
        $response['message'] = 'Bu sözleşme numarası zaten kullanımda.';
    } else {
        $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
    }
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);

function handleFileUpload($file_input_name) {
    if (isset($_FILES[$file_input_name]) && $_FILES[$file_input_name]['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES[$file_input_name];
        $upload_dir = __DIR__ . '/../uploads/contracts/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        $allowed_types = ['application/pdf', 'image/jpeg', 'image/png'];
        if (!in_array($file['type'], $allowed_types)) {
            throw new Exception('Geçersiz dosya türü. Sadece PDF, JPG veya PNG yükleyebilirsiniz.');
        }

        $file_name = preg_replace("/[^a-zA-Z0-9-_\.]/", "", basename($file['name']));
        $file_path = 'uploads/contracts/' . time() . '_' . $file_name;
        $destination = __DIR__ . '/../' . $file_path;

        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            throw new Exception('Dosya sunucuya taşınamadı.');
        }
        return $file_path;
    }
    return null; // Dosya yüklenmediyse null döndür
}

?>