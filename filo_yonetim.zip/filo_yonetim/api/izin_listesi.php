<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Yetki kontrolü
if (!yetki_kontrol('izin_goruntule')) {
    header('Content-Type: application/json');
    echo json_encode(['status' => 'error', 'message' => 'Bu işlem için yetkiniz yok!']);
    exit;
}

// Hata raporlama
ini_set('display_errors', 0);
error_reporting(E_ALL);

// Varsayılan yanıt
$response = [
    'draw' => 1,
    'recordsTotal' => 0,
    'recordsFiltered' => 0,
    'data' => [],
    'error' => ''
];

try {
    // POST verilerini al
    $draw = isset($_POST['draw']) ? intval($_POST['draw']) : 1;
    $start = isset($_POST['start']) ? intval($_POST['start']) : 0;
    $length = isset($_POST['length']) ? intval($_POST['length']) : 10;
    $searchValue = isset($_POST['search']['value']) ? trim($_POST['search']['value']) : '';
    $orderColumn = isset($_POST['order'][0]['column']) ? intval($_POST['order'][0]['column']) : 0;
    $orderDir = isset($_POST['order'][0]['dir']) ? strtoupper($_POST['order'][0]['dir']) : 'DESC';
    
    // Filtreleme parametreleri
    $filters = [
        'personel_id' => isset($_POST['personel_id']) ? intval($_POST['personel_id']) : null,
        'izin_tipi' => isset($_POST['izin_tipi']) ? $_POST['izin_tipi'] : null,
        'durum' => isset($_POST['durum']) ? $_POST['durum'] : null,
        'tarih_baslangic' => isset($_POST['tarih_baslangic']) ? $_POST['tarih_baslangic'] : date('Y-m-01'),
        'tarih_bitis' => isset($_POST['tarih_bitis']) ? $_POST['tarih_bitis'] : date('Y-m-t')
    ];
    
    // Sıralama sütunları eşleştirmesi
    $columns = [
        0 => 'p.ad',
        1 => 'i.izin_tipi_id',
        2 => 'i.baslangic_tarihi',
        3 => 'i.bitis_tarihi',
        4 => 'i.toplam_gun',
        5 => 'i.durum'
    ];
    
    $orderBy = isset($columns[$orderColumn]) ? $columns[$orderColumn] : 'i.olusturma_tarihi';
    
    // Sorgu oluştur
    $query = "
        SELECT SQL_CALC_FOUND_ROWS 
            i.id,
            CONCAT(p.ad, ' ', p.soyad) as personel_adi,
            it.adi as izin_tipi_adi,
            i.baslangic_tarihi,
            i.bitis_tarihi,
            i.toplam_gun,
            i.durum,
            i.aciklama,
            i.olusturma_tarihi,
            i.izin_veren_id,
            CONCAT(u.ad, ' ', u.soyad) as islem_yapan
        FROM izin_talepleri i
        INNER JOIN personel p ON i.personel_id = p.id
        LEFT JOIN izin_tipleri it ON i.izin_tipi_id = it.id
        LEFT JOIN kullanicilar u ON i.izin_veren_id = u.id
        WHERE 1=1
    ";
    
    $params = [];
    
    // Arama kriterleri
    if (!empty($searchValue)) {
        $query .= " AND (
            CONCAT(p.ad, ' ', p.soyad) LIKE :search 
            OR it.adi LIKE :search 
            OR i.durum LIKE :search
            OR i.aciklama LIKE :search
        )";
        $params[':search'] = "%$searchValue%";
    }
    
    // Filtreler
    if (!empty($filters['personel_id'])) {
        $query .= " AND i.personel_id = :personel_id";
        $params[':personel_id'] = $filters['personel_id'];
    }
    
    if (!empty($filters['izin_tipi'])) {
        $query .= " AND i.izin_tipi_id = :izin_tipi";
        $params[':izin_tipi'] = $filters['izin_tipi'];
    }
    
    if (!empty($filters['durum'])) {
        $query .= " AND i.durum = :durum";
        $params[':durum'] = $filters['durum'];
    }
    
    // Tarih aralığı filtresi
    if (!empty($filters['tarih_baslangic']) && !empty($filters['tarih_bitis'])) {
        $query .= " AND (
            (i.baslangic_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) OR
            (i.bitis_tarihi BETWEEN :tarih_baslangic AND :tarih_bitis) OR
            (i.baslangic_tarihi <= :tarih_baslangic AND i.bitis_tarihi >= :tarih_bitis)
        )";
        $params[':tarih_baslangic'] = $filters['tarih_baslangic'] . ' 00:00:00';
        $params[':tarih_bitis'] = $filters['tarih_bitis'] . ' 23:59:59';
    }
    
    // Sıralama
    $query .= " ORDER BY $orderBy $orderDir";
    
    // Sayfalama
    $query .= " LIMIT :start, :length";
    
    // Sorguyu hazırla ve çalıştır
    $stmt = $pdo->prepare($query);
    
    // Parametreleri bağla
    foreach ($params as $key => $value) {
        $stmt->bindValue($key, $value);
    }
    
    $stmt->bindValue(':start', $start, PDO::PARAM_INT);
    $stmt->bindValue(':length', $length, PDO::PARAM_INT);
    
    $stmt->execute();
    $data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Toplam kayıt sayısını al
    $totalRecords = $pdo->query("SELECT FOUND_ROWS()")->fetchColumn();
    
    // Verileri formatla
    $formattedData = [];
    foreach ($data as $row) {
        $formattedData[] = [
            'DT_RowId' => 'row_' . $row['id'],
            'personel_adi' => $row['personel_adi'],
            'izin_tipi_adi' => $row['izin_tipi_adi'],
            'baslangic_tarihi' => $row['baslangic_tarihi'],
            'bitis_tarihi' => $row['bitis_tarihi'],
            'toplam_gun' => $row['toplam_gun'],
            'durum' => $row['durum'],
            'aciklama' => $row['aciklama'],
            'islem_tarihi' => $row['olusturma_tarihi'],
            'islem_yapan' => $row['islem_yapan'] ?? '-',
            'DT_RowData' => ['id' => $row['id']],
            'actions' => ''
        ];
    }
    
    // Yanıtı hazırla
    $response = [
        'draw' => $draw,
        'recordsTotal' => $totalRecords,
        'recordsFiltered' => $totalRecords,
        'data' => $formattedData
    ];
    
} catch (PDOException $e) {
    $response['error'] = 'Veritabanı hatası: ' . $e->getMessage();
} catch (Exception $e) {
    $response['error'] = 'Beklenmeyen hata: ' . $e->getMessage();
}

// JSON yanıtını döndür
header('Content-Type: application/json');
echo json_encode($response);
?>
