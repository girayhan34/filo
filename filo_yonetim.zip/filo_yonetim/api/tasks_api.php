<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list_all':
            $sql = "
                SELECT t.*, u.name as assigned_to_name 
                FROM tasks t 
                LEFT JOIN users u ON t.assigned_to = u.id 
            ";
            $params = [];

            // Eğer kullanıcı 'Admin' değilse, sadece kendine atanan görevleri göster
            if ($_SESSION['user_role'] !== 'Admin') {
                $sql .= " WHERE t.assigned_to = :user_id";
                $params[':user_id'] = $_SESSION['user_id'];
            }

            $sql .= " ORDER BY t.priority DESC, t.due_date ASC";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
            $response = ['status' => 'success', 'data' => $tasks];
            break;

        case 'create':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Geçersiz istek metodu.');
            }

            $sql = "INSERT INTO tasks (title, description, project_id, assigned_to, created_by, due_date, priority, status) 
                    VALUES (:title, :description, :project_id, :assigned_to, :created_by, :due_date, :priority, :status)";
            
            $stmt = $pdo->prepare($sql);

            $project_id = !empty($_POST['project_id']) ? intval($_POST['project_id']) : null;
            $assigned_to = !empty($_POST['assigned_to']) ? intval($_POST['assigned_to']) : null;
            $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

            $stmt->execute([
                ':title' => $_POST['title'],
                ':description' => $_POST['description'] ?? null,
                ':project_id' => $project_id,
                ':assigned_to' => $assigned_to,
                ':created_by' => $_SESSION['user_id'],
                ':due_date' => $due_date,
                ':priority' => $_POST['priority'],
                ':status' => $_POST['status']
            ]);

            $response = ['status' => 'success', 'message' => 'Görev başarıyla oluşturuldu.', 'id' => $pdo->lastInsertId()];
            break;

        case 'update_status':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
                throw new Exception('Geçersiz istek metodu.');
            }
            $id = $_POST['id'] ?? 0;
            $status = $_POST['status'] ?? '';
            $valid_statuses = ['todo', 'inprogress', 'done', 'archived', 'cancelled'];
            if (empty($id) || !in_array($status, $valid_statuses)) {
                throw new Exception('Geçersiz görev ID veya durum.');
            }

            $stmt = $pdo->prepare("UPDATE tasks SET status = :status WHERE id = :id");
            $stmt->execute([':status' => $status, ':id' => $id]);

            $response = ['status' => 'success', 'message' => 'Görev durumu güncellendi.'];
            break;

        case 'get_task':
            if (!isset($_GET['id'])) {
                throw new Exception('Görev ID belirtilmedi.');
            }
            $id = intval($_GET['id']);
            
            // Görev detaylarını çek
            $stmt = $pdo->prepare("SELECT * FROM tasks WHERE id = ?");
            $stmt->execute([$id]);
            $task = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($task) {
                // Görev yorumlarını çek
                $comment_stmt = $pdo->prepare("
                    SELECT tc.*, u.name as user_name 
                    FROM task_comments tc 
                    LEFT JOIN users u ON tc.user_id = u.id 
                    WHERE tc.task_id = ? ORDER BY tc.created_at ASC
                ");
                $comment_stmt->execute([$id]);
                $comments = $comment_stmt->fetchAll(PDO::FETCH_ASSOC);

                // Görev dosyalarını çek
                $file_stmt = $pdo->prepare("SELECT tf.*, u.name as uploader_name FROM task_files tf LEFT JOIN users u ON tf.user_id = u.id WHERE tf.task_id = ? ORDER BY tf.uploaded_at DESC");
                $file_stmt->execute([$id]);
                $files = $file_stmt->fetchAll(PDO::FETCH_ASSOC);

                $response = ['status' => 'success', 'data' => ['task' => $task, 'comments' => $comments, 'files' => $files]];
            } else {
                http_response_code(404);
                $response = ['status' => 'error', 'message' => 'Görev bulunamadı.'];
            }
            break;

        case 'update_task':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }
            $id = intval($_POST['id']);
            $project_id = !empty($_POST['project_id']) ? intval($_POST['project_id']) : null;
            $assigned_to = !empty($_POST['assigned_to']) ? intval($_POST['assigned_to']) : null;
            $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;

            $sql = "UPDATE tasks SET title = :title, description = :description, project_id = :project_id, assigned_to = :assigned_to, 
                    due_date = :due_date, priority = :priority WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':title' => $_POST['title'],
                ':description' => $_POST['description'] ?? null,
                ':project_id' => $project_id,
                ':assigned_to' => $assigned_to,
                ':due_date' => $due_date,
                ':priority' => $_POST['priority']
            ]);
            $response = ['status' => 'success', 'message' => 'Görev başarıyla güncellendi.'];
            break;

        case 'delete_task':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }
            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("DELETE FROM tasks WHERE id = ?");
            $stmt->execute([$id]);

            if ($stmt->rowCount() > 0) {
                $response = ['status' => 'success', 'message' => 'Görev başarıyla silindi.'];
            } else {
                throw new Exception('Silinecek görev bulunamadı veya silme işlemi başarısız oldu.');
            }
            break;

        case 'upload_file':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['task_id']) || !isset($_FILES['task_file'])) {
                throw new Exception('Geçersiz istek veya eksik dosya.');
            }

            $task_id = intval($_POST['task_id']);
            $file = $_FILES['task_file'];

            if ($file['error'] !== UPLOAD_ERR_OK) {
                throw new Exception('Dosya yüklenirken hata oluştu. Hata kodu: ' . $file['error']);
            }

            $upload_dir = __DIR__ . '/../uploads/tasks/';
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            $file_name = preg_replace("/[^a-zA-Z0-9-_\.]/", "", basename($file['name']));
            $file_path = 'uploads/tasks/' . time() . '_' . $file_name;
            $destination = __DIR__ . '/../' . $file_path;

            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                throw new Exception('Dosya sunucuya taşınamadı.');
            }

            $sql = "INSERT INTO task_files (task_id, user_id, file_name, file_path, file_type, file_size) 
                    VALUES (:task_id, :user_id, :file_name, :file_path, :file_type, :file_size)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':task_id' => $task_id,
                ':user_id' => $_SESSION['user_id'],
                ':file_name' => $file_name,
                ':file_path' => $file_path,
                ':file_type' => $file['type'],
                ':file_size' => $file['size']
            ]);

            $response = ['status' => 'success', 'message' => 'Dosya başarıyla yüklendi.'];
            break;

        case 'delete_file':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['id'])) {
                throw new Exception('Geçersiz istek.');
            }
            $file_id = intval($_POST['id']);

            $stmt = $pdo->prepare("SELECT * FROM task_files WHERE id = ?");
            $stmt->execute([$file_id]);
            $file = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($file) {
                // Dosyayı sunucudan sil
                if (file_exists(__DIR__ . '/../' . $file['file_path'])) {
                    unlink(__DIR__ . '/../' . $file['file_path']);
                }
                // Kaydı veritabanından sil
                $delete_stmt = $pdo->prepare("DELETE FROM task_files WHERE id = ?");
                $delete_stmt->execute([$file_id]);
            }
            $response = ['status' => 'success', 'message' => 'Dosya başarıyla silindi.'];
            break;

        case 'add_comment':
            if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['task_id']) || empty($_POST['comment'])) {
                throw new Exception('Geçersiz istek veya boş yorum.');
            }
            $task_id = intval($_POST['task_id']);
            $comment = trim($_POST['comment']);
            $user_id = $_SESSION['user_id'];

            $sql = "INSERT INTO task_comments (task_id, user_id, comment) VALUES (:task_id, :user_id, :comment)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':task_id' => $task_id,
                ':user_id' => $user_id,
                ':comment' => $comment
            ]);
            $comment_id = $pdo->lastInsertId();

            $response = ['status' => 'success', 'message' => 'Yorum eklendi.', 'comment_id' => $comment_id];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}


echo json_encode($response);
?>