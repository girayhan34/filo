<?php
require_once '../includes/config.php';
require_once '../includes/auth.php';

// JSON yanıtı için başlık
header('Content-Type: application/json');

// HTTP Metodunu al
$method = $_SERVER['REQUEST_METHOD'];

// Yetki kontrolleri
$kullanici_id = $_SESSION['user_id'] ?? null;
$yetkili_roller = ['admin', 'ik', 'yonetici'];
$yetkili_mi = isset($_SESSION['user_role']) && in_array($_SESSION['user_role'], $yetkili_roller);

// Performans değerlendirme endpoint'i
switch ($method) {
    case 'GET':
        // Performans değerlendirme listesini getir
        getPerformansDegerlendirmeleri();
        break;
    case 'POST':
        // Yeni performans değerlendirmesi ekle
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            $data = $_POST;
        }
        performansDegerlendirmesiEkle($data);
        break;
    case 'PUT':
        // Performans değerlendirmesini güncelle
        $data = json_decode(file_get_contents('php://input'), true);
        performansDegerlendirmesiGuncelle($data);
        break;
    case 'DELETE':
        // Performans değerlendirmesini sil
        $data = json_decode(file_get_contents('php://input'), true);
        if (empty($data)) {
            parse_str(file_get_contents('php://input'), $data);
        }
        performansDegerlendirmesiSil($data);
        break;
    default:
        http_response_code(405);
        echo json_encode(['status' => 'error', 'message' => 'Geçersiz metod']);
        break;
}

// Performans değerlendirme listesini getir
function getPerformansDegerlendirmeleri() {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    try {
        $params = [];
        $where = [];
        
        // Yetkili değilse sadece kendi değerlendirmelerini veya kendisi hakkındaki değerlendirmeleri görebilir
        if (!$yetkili_mi) {
            $where[] = "(pd.personel_id = :personel_id OR pd.degerlendiren_id = :degerlendiren_id)";
            $params[':personel_id'] = $kullanici_id;
            $params[':degerlendiren_id'] = $kullanici_id;
        } else {
            // Filtreleme parametreleri
            if (!empty($_GET['personel_id'])) {
                $where[] = "pd.personel_id = :personel_id";
                $params[':personel_id'] = intval($_GET['personel_id']);
            }
            
            if (!empty($_GET['degerlendiren_id'])) {
                $where[] = "pd.degerlendiren_id = :degerlendiren_id";
                $params[':degerlendiren_id'] = intval($_GET['degerlendiren_id']);
            }
            
            if (!empty($_GET['baslangic_tarihi'])) {
                $where[] = "pd.degerlendirme_tarihi >= :baslangic_tarihi";
                $params[':baslangic_tarihi'] = $_GET['baslangic_tarihi'];
            }
            
            if (!empty($_GET['bitis_tarihi'])) {
                $where[] = "pd.degerlendirme_tarihi <= :bitis_tarihi";
                $params[':bitis_tarihi'] = $_GET['bitis_tarihi'] . ' 23:59:59';
            }
            
            if (!empty($_GET['durum'])) {
                $where[] = "pd.durum = :durum";
                $params[':durum'] = $_GET['durum'];
            }
        }
        
        // Sorguyu oluştur
        $sql = "SELECT 
                    pd.*,
                    CONCAT(p1.ad, ' ', p1.soyad) as personel_adi,
                    p1.sicil_no,
                    d1.departman_adi as personel_departman,
                    CONCAT(p2.ad, ' ', p2.soyad) as degerlendiren_adi,
                    d2.departman_adi as degerlendiren_departman,
                    u1.ad_soyad as olusturan_kullanici,
                    u2.ad_soyad as guncelleyen_kullanici
                FROM personel_performanslari pd
                LEFT JOIN personel p1 ON pd.personel_id = p1.id
                LEFT JOIN departmanlar d1 ON p1.departman_id = d1.id
                LEFT JOIN personel p2 ON pd.degerlendiren_id = p2.id
                LEFT JOIN departmanlar d2 ON p2.departman_id = d2.id
                LEFT JOIN users u1 ON pd.created_by = u1.id
                LEFT JOIN users u2 ON pd.updated_by = u2.id";
        
        if (!empty($where)) {
            $sql .= " WHERE " . implode(" AND ", $where);
        }
        
        $sql .= " ORDER BY pd.degerlendirme_tarihi DESC, pd.created_at DESC";
        
        // Sayfalama
        $page = isset($_GET['page']) ? intval($_GET['page']) : 1;
        $limit = isset($_GET['limit']) ? intval($_GET['limit']) : 25;
        $offset = ($page - 1) * $limit;
        
        $sql .= " LIMIT :limit OFFSET :offset";
        
        $stmt = $pdo->prepare($sql);
        
        // Parametreleri bağla
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        
        $stmt->execute();
        $degerlendirmeler = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Toplam kayıt sayısını al
        $countSql = "SELECT COUNT(*) as total FROM personel_performanslari pd";
        if (!empty($where)) {
            $countSql .= " WHERE " . implode(" AND ", $where);
        }
        
        $stmt = $pdo->prepare($countSql);
        foreach ($params as $key => $value) {
            if ($key !== ':limit' && $key !== ':offset') {
                $stmt->bindValue($key, $value);
            }
        }
        $stmt->execute();
        $total = $stmt->fetchColumn();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success',
            'data' => $degerlendirmeler,
            'pagination' => [
                'total' => (int)$total,
                'page' => $page,
                'limit' => $limit,
                'total_pages' => ceil($total / $limit)
            ]
        ]);
        
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

// Yeni performans değerlendirmesi ekle
function performansDegerlendirmesiEkle($data) {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    // Gerekli alanlar
    $requiredFields = [
        'personel_id' => 'Personel',
        'degerlendirme_tarihi' => 'Değerlendirme Tarihi',
        'donem_baslangic' => 'Dönem Başlangıç Tarihi',
        'donem_bitis' => 'Dönem Bitiş Tarihi',
        'puan_verimlilik' => 'Verimlilik Puanı',
        'puan_iletisim' => 'İletişim Puanı',
        'puan_uzmanlik' => 'Uzmanlık Puanı',
        'puan_guvenlik' => 'Güvenlik Puanı',
        'puan_takim_calismasi' => 'Takım Çalışması Puanı'
    ];
    
    $errors = [];
    
    // Zorunlu alanları kontrol et
    foreach ($requiredFields as $field => $label) {
        if (!isset($data[$field]) || (is_string($data[$field]) && trim($data[$field]) === '')) {
            $errors[] = "$label alanı zorunludur.";
        }
    }
    
    // Hata varsa dön
    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $errors]);
        return;
    }
    
    // Verileri al ve temizle
    $personel_id = intval($data['personel_id']);
    $degerlendiren_id = !empty($data['degerlendiren_id']) ? intval($data['degerlendiren_id']) : $kullanici_id;
    $degerlendirme_tarihi = date('Y-m-d', strtotime($data['degerlendirme_tarihi']));
    $donem_baslangic = date('Y-m-d', strtotime($data['donem_baslangic']));
    $donem_bitis = date('Y-m-d', strtotime($data['donem_bitis']));
    
    // Puanları kontrol et (0-10 arası olmalı)
    $puanlar = [
        'verimlilik' => floatval($data['puan_verimlilik']),
        'iletisim' => floatval($data['puan_iletisim']),
        'uzmanlik' => floatval($data['puan_uzmanlik']),
        'guvenlik' => floatval($data['puan_guvenlik']),
        'takim_calismasi' => floatval($data['puan_takim_calismasi'])
    ];
    
    foreach ($puanlar as $key => $puan) {
        if ($puan < 0 || $puan > 10) {
            $errors[] = ucfirst(str_replace('_', ' ', $key)) . " puanı 0-10 arasında olmalıdır.";
        }
    }
    
    // Toplam puanı hesapla
    $puan_toplam = array_sum($puanlar);
    
    // Diğer alanlar
    $guclu_yonler = !empty($data['guclu_yonler']) ? trim($data['guclu_yonler']) : null;
    $gelistirilecek_alanlar = !empty($data['gelistirilecek_alanlar']) ? trim($data['gelistirilecek_alanlar']) : null;
    $hedefler = !empty($data['hedefler']) ? trim($data['hedefler']) : null;
    $yonetici_yorumu = !empty($data['yonetici_yorumu']) ? trim($data['yonetici_yorumu']) : null;
    $durum = $yetkili_mi ? 'Onaylandı' : 'Taslak';
    
    // Hata varsa dön
    if (!empty($errors)) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => $errors]);
        return;
    }
    
    try {
        // İşlemi başlat
        $pdo->beginTransaction();
        
        // Aynı dönem için daha önce değerlendirme yapılmış mı kontrol et
        $sql = "SELECT COUNT(*) FROM personel_performanslari 
                WHERE personel_id = :personel_id 
                AND (
                    (:donem_baslangic BETWEEN donem_baslangic AND donem_bitis) OR
                    (:donem_bitis BETWEEN donem_baslangic AND donem_bitis) OR
                    (donem_baslangic BETWEEN :donem_baslangic2 AND :donem_bitis2) OR
                    (donem_bitis BETWEEN :donem_baslangic3 AND :donem_bitis3)
                )";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            ':personel_id' => $personel_id,
            ':donem_baslangic' => $donem_baslangic,
            ':donem_bitis' => $donem_bitis,
            ':donem_baslangic2' => $donem_baslangic,
            ':donem_bitis2' => $donem_bitis,
            ':donem_baslangic3' => $donem_baslangic,
            ':donem_bitis3' => $donem_bitis
        ]);
        
        $conflictingEvaluations = $stmt->fetchColumn();
        
        if ($conflictingEvaluations > 0) {
            throw new Exception('Bu personel için belirtilen dönemde zaten bir performans değerlendirmesi bulunmaktadır.');
        }
        
        // Yeni performans değerlendirmesi ekle
        $sql = "INSERT INTO personel_performanslari (
                    personel_id,
                    degerlendiren_id,
                    degerlendirme_tarihi,
                    donem_baslangic,
                    donem_bitis,
                    puan_toplam,
                    puan_verimlilik,
                    puan_iletisim,
                    puan_uzmanlik,
                    puan_guvenlik,
                    puan_takim_calismasi,
                    guclu_yonler,
                    gelistirilecek_alanlar,
                    hedefler,
                    yonetici_yorumu,
                    durum,
                    created_by
                ) VALUES (
                    :personel_id,
                    :degerlendiren_id,
                    :degerlendirme_tarihi,
                    :donem_baslangic,
                    :donem_bitis,
                    :puan_toplam,
                    :puan_verimlilik,
                    :puan_iletisim,
                    :puan_uzmanlik,
                    :puan_guvenlik,
                    :puan_takim_calismasi,
                    :guclu_yonler,
                    :gelistirilecek_alanlar,
                    :hedefler,
                    :yonetici_yorumu,
                    :durum,
                    :created_by
                )";
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([
            ':personel_id' => $personel_id,
            ':degerlendiren_id' => $degerlendiren_id,
            ':degerlendirme_tarihi' => $degerlendirme_tarihi,
            ':donem_baslangic' => $donem_baslangic,
            ':donem_bitis' => $donem_bitis,
            ':puan_toplam' => $puan_toplam,
            ':puan_verimlilik' => $puanlar['verimlilik'],
            ':puan_iletisim' => $puanlar['iletisim'],
            ':puan_uzmanlik' => $puanlar['uzmanlik'],
            ':puan_guvenlik' => $puanlar['guvenlik'],
            ':puan_takim_calismasi' => $puanlar['takim_calismasi'],
            ':guclu_yonler' => $guclu_yonler,
            ':gelistirilecek_alanlar' => $gelistirilecek_alanlar,
            ':hedefler' => $hedefler,
            ':yonetici_yorumu' => $yonetici_yorumu,
            ':durum' => $durum,
            ':created_by' => $kullanici_id
        ]);
        
        $degerlendirme_id = $pdo->lastInsertId();
        
        // İşlemi onayla
        $pdo->commit();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success', 
            'message' => 'Performans değerlendirmesi başarıyla eklendi.',
            'data' => ['id' => $degerlendirme_id]
        ]);
        
    } catch (PDOException $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

// Performans değerlendirmesini güncelle
function performansDegerlendirmesiGuncelle($data) {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    // Gerekli alanlar
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Değerlendirme ID zorunludur.']);
        return;
    }
    
    $degerlendirme_id = intval($data['id']);
    
    try {
        // İşlemi başlat
        $pdo->beginTransaction();
        
        // Mevcut değerlendirmeyi al
        $sql = "SELECT * FROM personel_performanslari WHERE id = :id FOR UPDATE";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $degerlendirme_id]);
        $mevcutDegerlendirme = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$mevcutDegerlendirme) {
            throw new Exception('Performans değerlendirmesi bulunamadı.');
        }
        
        // Yetki kontrolü - sadece oluşturan veya yetkili güncelleyebilir
        if (!$yetkili_mi && $mevcutDegerlendirme['created_by'] != $kullanici_id) {
            throw new Exception('Bu işlem için yetkiniz yok!');
        }
        
        // Eğer onaylanmışsa ve yetkili değilse güncelleme yapılamaz
        if ($mevcutDegerlendirme['durum'] === 'Onaylandı' && !$yetkili_mi) {
            throw new Exception('Onaylanmış performans değerlendirmesi güncellenemez.');
        }
        
        // Güncellenecek alanları belirle
        $guncellenecekAlanlar = [];
        $params = [':id' => $degerlendirme_id];
        
        // Temel alanlar
        $alanlar = [
            'personel_id' => 'personel_id',
            'degerlendiren_id' => 'degerlendiren_id',
            'degerlendirme_tarihi' => 'degerlendirme_tarihi',
            'donem_baslangic' => 'donem_baslangic',
            'donem_bitis' => 'donem_bitis',
            'puan_verimlilik' => 'puan_verimlilik',
            'puan_iletisim' => 'puan_iletisim',
            'puan_uzmanlik' => 'puan_uzmanlik',
            'puan_guvenlik' => 'puan_guvenlik',
            'puan_takim_calismasi' => 'puan_takim_calismasi',
            'guclu_yonler' => 'guclu_yonler',
            'gelistirilecek_alanlar' => 'gelistirilecek_alanlar',
            'hedefler' => 'hedefler',
            'yonetici_yorumu' => 'yonetici_yorumu',
            'durum' => 'durum'
        ];
        
        // Güncellenecek alanları doldur
        $puanlar = [];
        $puanToplam = 0;
        
        foreach ($alanlar as $alan => $dbAlan) {
            if (isset($data[$alan]) && $data[$alan] !== '') {
                // Puan alanları için özel işlem
                if (strpos($alan, 'puan_') === 0) {
                    $puan = floatval($data[$alan]);
                    if ($puan < 0 || $puan > 10) {
                        throw new Exception(ucfirst(str_replace('_', ' ', substr($alan, 5))) . " puanı 0-10 arasında olmalıdır.");
                    }
                    $puanlar[$alan] = $puan;
                    $puanToplam += $puan;
                }
                
                $guncellenecekAlanlar[] = "$dbAlan = :$alan";
                $params[":$alan"] = $data[$alan];
            }
        }
        
        // Eğer puanlar güncellendiyse, toplam puanı da güncelle
        if (!empty($puanlar)) {
            $guncellenecekAlanlar[] = "puan_toplam = :puan_toplam";
            $params[":puan_toplam"] = $puanToplam;
        }
        
        // Eğer güncellenecek alan yoksa hata dön
        if (empty($guncellenecekAlanlar)) {
            throw new Exception('Güncellenecek alan belirtilmedi.');
        }
        
        // Güncelleme sorgusunu oluştur
        $sql = "UPDATE personel_performanslari SET 
                   " . implode(", ", $guncellenecekAlanlar) . ",
                   updated_at = NOW(),
                   updated_by = :updated_by
                WHERE id = :id";
        
        $params[':updated_by'] = $kullanici_id;
        
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute($params);
        
        // İşlemi onayla
        $pdo->commit();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success', 
            'message' => 'Performans değerlendirmesi başarıyla güncellendi.'
        ]);
        
    } catch (PDOException $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}

// Performans değerlendirmesini sil
function performansDegerlendirmesiSil($data) {
    global $pdo, $kullanici_id, $yetkili_mi;
    
    // Gerekli alanlar
    if (empty($data['id'])) {
        http_response_code(400);
        echo json_encode(['status' => 'error', 'message' => 'Değerlendirme ID zorunludur.']);
        return;
    }
    
    $degerlendirme_id = intval($data['id']);
    
    try {
        // İşlemi başlat
        $pdo->beginTransaction();
        
        // Mevcut değerlendirmeyi al
        $sql = "SELECT * FROM personel_performanslari WHERE id = :id FOR UPDATE";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([':id' => $degerlendirme_id]);
        $mevcutDegerlendirme = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if (!$mevcutDegerlendirme) {
            throw new Exception('Performans değerlendirmesi bulunamadı.');
        }
        
        // Yetki kontrolü - sadece oluşturan veya yetkili silebilir
        if (!$yetkili_mi && $mevcutDegerlendirme['created_by'] != $kullanici_id) {
            throw new Exception('Bu işlem için yetkiniz yok!');
        }
        
        // Eğer onaylanmışsa ve yetkili değilse silinemez
        if ($mevcutDegerlendirme['durum'] === 'Onaylandı' && !$yetkili_mi) {
            throw new Exception('Onaylanmış performans değerlendirmesi silinemez.');
        }
        
        // Performans değerlendirmesini sil
        $sql = "DELETE FROM personel_performanslari WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $result = $stmt->execute([':id' => $degerlendirme_id]);
        
        // İşlemi onayla
        $pdo->commit();
        
        // Başarılı yanıt dön
        echo json_encode([
            'status' => 'success', 
            'message' => 'Performans değerlendirmesi başarıyla silindi.'
        ]);
        
    } catch (PDOException $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
    } catch (Exception $e) {
        // Hata durumunda işlemi geri al
        $pdo->rollBack();
        http_response_code(500);
        echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
    }
}
?>
