<?php
require_once __DIR__ . '/BaseApiController.php';
require_once __DIR__ . '/../models/Izin.php';

class IzinEkleController extends BaseApiController {

    protected function processRequest(): void {
        if ($this->method !== 'POST') {
            $this->sendError('Geçersiz istek metodu.', 405);
            return;
        }

        // 1. Yetki Kontrolü
        $this->checkPermission('izinler:olustur');

        // 2. Veri Doğrulama
        $rules = [
            'personel_id' => 'required|numeric',
            'izin_tipi_id' => 'required|numeric',
            'baslangic_tarihi' => 'required',
            'bitis_tarihi' => 'required',
            'toplam_gun' => 'required|numeric|min:1'
        ];
        $validatedData = $this->validate($this->requestData, $rules);

        // 3. Veri İşleme
        $personel_id = intval($validatedData['personel_id']);
        $baslangic_tarihi = date('Y-m-d', strtotime($validatedData['baslangic_tarihi']));
        $bitis_tarihi = date('Y-m-d', strtotime($validatedData['bitis_tarihi']));

        // 4. İş Mantığı (Business Logic)
        if (strtotime($bitis_tarihi) < strtotime($baslangic_tarihi)) {
            throw new Exception('Bitiş tarihi başlangıç tarihinden önce olamaz!', 400);
        }

        // Çakışma kontrolü (Model üzerinden)
        if (Izin::checkConflicting($personel_id, $baslangic_tarihi, $bitis_tarihi)) {
            throw new Exception('Bu tarih aralığında zaten bir izin talebi bulunmaktadır!', 409);
        }

        // 5. Veritabanı İşlemi (Model kullanarak)
        $izinData = [
            'personel_id' => $personel_id,
            'izin_tipi_id' => intval($validatedData['izin_tipi_id']),
            'baslangic_tarihi' => $baslangic_tarihi,
            'bitis_tarihi' => $bitis_tarihi,
            'toplam_gun' => intval($validatedData['toplam_gun']),
            'aciklama' => $validatedData['aciklama'] ?? null,
            'durum' => 'Onay Bekliyor', // Varsayılan durum
            'olusturma_tarihi' => date('Y-m-d H:i:s')
        ];

        $yeniIzin = Izin::create($izinData);

        if (!$yeniIzin) {
            throw new Exception('İzin talebi oluşturulurken bir veritabanı hatası oluştu.', 500);
        }

        // 6. Başarılı Yanıt Gönderme
        $this->sendSuccess(['id' => $yeniIzin->id], 'İzin talebiniz başarıyla oluşturuldu.', 201);
    }
}

$controller = new IzinEkleController();
$controller->handleRequest();
