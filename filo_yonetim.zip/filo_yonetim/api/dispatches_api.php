<?php
session_start();
header('Content-Type: application/json');

require_once '../includes/config.php';
require_once '../includes/auth.php';

$action = $_REQUEST['action'] ?? '';
$response = ['status' => 'error', 'message' => 'Geçersiz işlem.'];

try {
    $pdo = getPDO();

    switch ($action) {
        case 'list':
            $draw = intval($_POST['draw'] ?? 1);
            $start = intval($_POST['start'] ?? 0);
            $length = intval($_POST['length'] ?? 10);
            $searchValue = $_POST['search']['value'] ?? '';

            $totalRecords = $pdo->query("SELECT COUNT(id) FROM dispatches")->fetchColumn();

            $queryFiltered = "SELECT COUNT(d.id) FROM dispatches d 
                              LEFT JOIN customers c ON d.customer_id = c.id 
                              LEFT JOIN vehicles v ON d.vehicle_id = v.id 
                              WHERE d.dispatch_no LIKE :search OR c.name LIKE :search OR v.plate LIKE :search";
            $stmtFiltered = $pdo->prepare($queryFiltered);
            $stmtFiltered->execute([':search' => "%$searchValue%"]);
            $recordsFiltered = $stmtFiltered->fetchColumn();

            $queryData = "SELECT d.*, c.name as customer_name, v.plate as vehicle_plate, p.name as driver_name
                          FROM dispatches d
                          LEFT JOIN customers c ON d.customer_id = c.id
                          LEFT JOIN vehicles v ON d.vehicle_id = v.id
                          LEFT JOIN personnel p ON d.driver_id = p.id
                          WHERE d.dispatch_no LIKE :search OR c.name LIKE :search OR v.plate LIKE :search
                          ORDER BY d.dispatch_date DESC
                          LIMIT :start, :length";
            
            $stmtData = $pdo->prepare($queryData);
            $stmtData->bindValue(':search', "%$searchValue%", PDO::PARAM_STR);
            $stmtData->bindValue(':start', (int)$start, PDO::PARAM_INT);
            $stmtData->bindValue(':length', (int)$length, PDO::PARAM_INT);
            $stmtData->execute();
            $data = $stmtData->fetchAll(PDO::FETCH_ASSOC);

            $response = [
                "draw" => $draw,
                "recordsTotal" => intval($totalRecords),
                "recordsFiltered" => intval($recordsFiltered),
                "data" => $data
            ];
            break;

        case 'create':
            $sql = "INSERT INTO dispatches (dispatch_no, customer_id, vehicle_id, driver_id, dispatch_date, delivery_date, origin_address, destination_address, status, notes, created_by) 
                    VALUES (:dispatch_no, :customer_id, :vehicle_id, :driver_id, :dispatch_date, :delivery_date, :origin_address, :destination_address, :status, :notes, :created_by)";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':dispatch_no' => $_POST['dispatch_no'],
                ':customer_id' => $_POST['customer_id'],
                ':vehicle_id' => $_POST['vehicle_id'],
                ':driver_id' => $_POST['driver_id'] ?: null,
                ':dispatch_date' => $_POST['dispatch_date'],
                ':delivery_date' => $_POST['delivery_date'] ?: null,
                ':origin_address' => $_POST['origin_address'],
                ':destination_address' => $_POST['destination_address'],
                ':status' => $_POST['status'],
                ':notes' => $_POST['notes'] ?: null,
                ':created_by' => $_SESSION['user_id']
            ]);

            $response = ['status' => 'success', 'message' => 'İrsaliye başarıyla oluşturuldu.'];
            break;

        case 'get_dispatch':
            if (!isset($_GET['id'])) {
                throw new Exception('İrsaliye ID belirtilmedi.');
            }
            $id = intval($_GET['id']);
            $stmt = $pdo->prepare("SELECT * FROM dispatches WHERE id = ?");
            $stmt->execute([$id]);
            $dispatch = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($dispatch) {
                $response = ['status' => 'success', 'data' => $dispatch];
            } else {
                $response = ['status' => 'error', 'message' => 'İrsaliye bulunamadı.'];
            }
            break;

        case 'update':
            $id = intval($_POST['id']);
            $sql = "UPDATE dispatches SET 
                        customer_id = :customer_id, 
                        vehicle_id = :vehicle_id, 
                        driver_id = :driver_id, 
                        dispatch_date = :dispatch_date, 
                        delivery_date = :delivery_date, 
                        origin_address = :origin_address, 
                        destination_address = :destination_address, 
                        status = :status, 
                        notes = :notes
                    WHERE id = :id";
            
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ':id' => $id,
                ':customer_id' => $_POST['customer_id'],
                ':vehicle_id' => $_POST['vehicle_id'],
                ':driver_id' => $_POST['driver_id'] ?: null,
                ':dispatch_date' => $_POST['dispatch_date'],
                ':delivery_date' => $_POST['delivery_date'] ?: null,
                ':origin_address' => $_POST['origin_address'],
                ':destination_address' => $_POST['destination_address'],
                ':status' => $_POST['status'],
                ':notes' => $_POST['notes'] ?: null
            ]);

            $response = ['status' => 'success', 'message' => 'İrsaliye başarıyla güncellendi.'];
            break;

        case 'delete':
            $id = intval($_POST['id']);
            $stmt = $pdo->prepare("DELETE FROM dispatches WHERE id = ?");
            $stmt->execute([$id]);
            $response = ['status' => 'success', 'message' => 'İrsaliye başarıyla silindi.'];
            break;

        default:
            http_response_code(400);
            $response['message'] = 'Bilinmeyen eylem.';
            break;
    }
} catch (PDOException $e) {
    http_response_code(500);
    if ($e->getCode() == 23000) {
        $response['message'] = 'Bu irsaliye numarası zaten kullanımda.';
    } else {
        $response['message'] = 'Veritabanı hatası: ' . $e->getMessage();
    }
} catch (Exception $e) {
    http_response_code(500);
    $response['message'] = $e->getMessage();
}

echo json_encode($response);
?>