<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Get personnel ID from query string
$personnel_id = isset($_GET['personnel_id']) ? (int)$_GET['personnel_id'] : 0;

if ($personnel_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz personel ID.']);
    exit;
}

try {
    // Get performance evaluations for the personnel
    $stmt = $pdo->prepare("SELECT pp.*, u.name as evaluator_name 
                          FROM personnel_performance pp
                          LEFT JOIN users u ON pp.evaluated_by = u.id
                          WHERE pp.personnel_id = ? 
                          ORDER BY pp.evaluation_date DESC");
    $stmt->execute([$personnel_id]);
    $performance = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Format the response
    $response = [];
    foreach ($performance as $eval) {
        $response[] = [
            'id' => $eval['id'],
            'evaluation_date' => $eval['evaluation_date'],
            'score' => (float)$eval['score'],
            'comment' => $eval['comment'],
            'evaluator_name' => $eval['evaluator_name'],
            'created_at' => $eval['created_at']
        ];
    }
    
    echo json_encode($response);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}
