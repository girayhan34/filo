<?php
header('Content-Type: application/json');
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isLoggedIn()) {
    http_response_code(403);
    echo json_encode(['error' => 'Unauthorized access']);
    exit;
}

try {
    $pdo = getPDO();
    
    // Get search term if provided
    $search = isset($_GET['search']) ? trim($_GET['search']) : '';
    
    // Build the query
    $query = "SELECT 
            id,
            COALESCE(company_name, CONCAT(first_name, ' ', last_name)) as name,
            first_name,
            last_name,
            company_name,
            email,
            phone,
            tax_number,
            tax_office,
            address,
            city,
            country,
            created_at
        FROM customers 
        WHERE status = 'active'";
    
    $params = [];
    
    // Add search condition if search term is provided
    if (!empty($search)) {
        $query .= " AND (
            company_name LIKE :search OR 
            CONCAT(first_name, ' ', last_name) LIKE :search OR
            email LIKE :search OR
            phone LIKE :search OR
            tax_number LIKE :search
        )";
        $params[':search'] = "%$search%";
    }
    
    // Add sorting
    $sort = $_GET['sort'] ?? 'company_name';
    $order = $_GET['order'] ?? 'ASC';
    $validSorts = ['company_name', 'name', 'email', 'phone', 'created_at'];
    $validOrders = ['ASC', 'DESC'];
    
    if (in_array($sort, $validSorts) && in_array(strtoupper($order), $validOrders)) {
        $query .= " ORDER BY $sort $order";
    } else {
        $query .= " ORDER BY company_name, name";
    }
    
    // Add pagination
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $perPage = isset($_GET['per_page']) ? (int)$_GET['per_page'] : 100;
    $offset = ($page - 1) * $perPage;
    
    $query .= " LIMIT :offset, :per_page";
    
    // Prepare and execute the query
    $stmt = $pdo->prepare($query);
    
    // Bind search parameter if needed
    if (!empty($search)) {
        $stmt->bindValue(':search', $search, PDO::PARAM_STR);
    }
    
    // Bind pagination parameters
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->bindValue(':per_page', $perPage, PDO::PARAM_INT);
    
    $stmt->execute();
    $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Get total count for pagination
    $countQuery = "SELECT COUNT(*) as total FROM customers WHERE status = 'active'";
    if (!empty($search)) {
        $countQuery .= " AND (
            company_name LIKE :search OR 
            CONCAT(first_name, ' ', last_name) LIKE :search OR
            email LIKE :search OR
            phone LIKE :search OR
            tax_number LIKE :search
        )";
    }
    
    $countStmt = $pdo->prepare($countQuery);
    
    if (!empty($search)) {
        $countStmt->bindValue(':search', "%$search%", PDO::PARAM_STR);
    }
    
    $countStmt->execute();
    $total = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];
    
    // Format the response
    $response = [
        'success' => true,
        'data' => $customers,
        'pagination' => [
            'total' => (int)$total,
            'page' => $page,
            'per_page' => $perPage,
            'total_pages' => ceil($total / $perPage)
        ]
    ];
    
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Database error: ' . $e->getMessage()
    ]);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
