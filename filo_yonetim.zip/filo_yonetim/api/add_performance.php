<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

// Get POST data
$personnel_id = isset($_POST['personnel_id']) ? (int)$_POST['personnel_id'] : 0;
$evaluation_date = isset($_POST['evaluation_date']) ? trim($_POST['evaluation_date']) : date('Y-m-d');
$score = isset($_POST['score']) ? (float)$_POST['score'] : 0;
$comment = isset($_POST['comment']) ? trim($_POST['comment']) : '';

// Validate input
if ($personnel_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Geçersiz personel ID.']);
    exit;
}

if ($score < 1 || $score > 10) {
    echo json_encode(['success' => false, 'message' => 'Puan 1 ile 10 arasında olmalıdır.']);
    exit;
}

// Convert date to MySQL format
$evaluation_date_mysql = date('Y-m-d', strtotime($evaluation_date));

try {
    // Insert performance evaluation record to database
    $stmt = $pdo->prepare("INSERT INTO personnel_performance 
                          (personnel_id, evaluation_date, score, comment, evaluated_by, created_at) 
                          VALUES (?, ?, ?, ?, ?, NOW())");
    
    $stmt->execute([
        $personnel_id,
        $evaluation_date_mysql,
        $score,
        $comment,
        $_SESSION['user_id']
    ]);
    
    $performance_id = $pdo->lastInsertId();
    
    // Log the action
    $log_stmt = $pdo->prepare("INSERT INTO system_logs 
                              (user_id, action, table_name, record_id, details, created_at) 
                              VALUES (?, ?, 'personnel_performance', ?, ?, NOW())");
    $log_stmt->execute([
        $_SESSION['user_id'],
        'create',
        $performance_id,
        json_encode(['personnel_id' => $personnel_id, 'score' => $score, 'evaluation_date' => $evaluation_date_mysql])
    ]);
    
    echo json_encode([
        'success' => true, 
        'message' => 'Performans değerlendirmesi başarıyla eklendi.',
        'performance_id' => $performance_id
    ]);
    
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Veritabanı hatası: ' . $e->getMessage()]);
}
