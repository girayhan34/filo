<?php
header('Content-Type: application/json');
session_start();
require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Yetkisiz erişim.']);
    exit;
}

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Geçersiz istek metodu.']);
    exit;
}

// Get and validate input data
$name = trim($_POST['name'] ?? '');
$position = trim($_POST['position'] ?? '');
$department = trim($_POST['department'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$email = trim($_POST['email'] ?? '');
$hire_date = !empty($_POST['hire_date']) ? $_POST['hire_date'] : null;
$status = in_array($_POST['status'] ?? '', ['active', 'on_leave', 'inactive']) ? $_POST['status'] : 'active';

// Validate required fields
if (empty($name)) {
    echo json_encode(['success' => false, 'message' => 'Ad soyad alanı zorunludur.']);
    exit;
}

try {
    // Start transaction
    $pdo->beginTransaction();
    
    // Insert new personnel
    $stmt = $pdo->prepare("INSERT INTO personnel (name, position, department, phone, email, hire_date, status, created_by, created_at) 
                          VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
    
    $stmt->execute([
        $name,
        $position ?: null,
        $department ?: null,
        $phone ?: null,
        $email ?: null,
        $hire_date,
        $status,
        $_SESSION['user_id']
    ]);
    
    $personnel_id = $pdo->lastInsertId();
    
    // Log the action
    $log_stmt = $pdo->prepare("INSERT INTO system_logs 
                              (user_id, action, table_name, record_id, details, created_at) 
                              VALUES (?, ?, 'personnel', ?, ?, NOW())");
    $log_stmt->execute([
        $_SESSION['user_id'],
        'create',
        $personnel_id,
        json_encode([
            'name' => $name,
            'position' => $position,
            'department' => $department,
            'status' => $status,
            'hire_date' => $hire_date
        ])
    ]);
    
    // Commit transaction
    $pdo->commit();
    
    echo json_encode([
        'success' => true, 
        'message' => 'Personel başarıyla eklendi.',
        'personnel_id' => $personnel_id
    ]);
    
} catch (PDOException $e) {
    // Rollback transaction on error
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    http_response_code(500);
    echo json_encode([
        'success' => false, 
        'message' => 'Veritabanı hatası: ' . $e->getMessage()
    ]);
}
