<?php
session_start();
// Doğrudan dashboard'a yönlendir
header("Location: dashboard.php");
exit();
?>