<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

if ($_SESSION['user_role'] !== 'admin') {
    die('Bu sayfaya erişim yetkiniz yok.');
}

$page_title = 'Rol ve İzin Yönetimi';
$page_subtitle = 'Kullanıcı rollerini ve yetkilerini yönetin.';
include 'includes/header.php';

// Tüm rolleri ve izinleri çek
$roles = $pdo->query("SELECT * FROM roles ORDER BY role_name ASC")->fetchAll(PDO::FETCH_ASSOC);
$permissions = $pdo->query("SELECT * FROM permissions ORDER BY module, description ASC")->fetchAll(PDO::FETCH_ASSOC);

// Rollerin mevcut izinlerini çek
$role_permissions_stmt = $pdo->query("SELECT * FROM role_permissions");
$role_permissions = [];
foreach ($role_permissions_stmt as $rp) {
    $role_permissions[$rp['role_id']][] = $rp['permission_id'];
}

// İzinleri modüllere göre grupla
$grouped_permissions = [];
foreach ($permissions as $permission) {
    $grouped_permissions[$permission['module']][] = $permission;
}
?>

<div class="card shadow-sm">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0"><i class="fas fa-user-shield me-2"></i>Roller ve İzinler</h5>
        <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#roleModal" onclick="prepareAddRole()">
            <i class="fas fa-plus me-1"></i> Yeni Rol Ekle
        </button>
    </div>
    <div class="card-body">
        <p class="text-muted">Bu arayüzden kullanıcı rollerini ve her bir rolün sistemdeki hangi modüllere erişebileceğini, hangi işlemleri yapabileceğini yönetebilirsiniz.</p>
        <form id="permissionsForm">
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-light">
                        <tr>
                            <th class="text-start">İzinler</th>
                            <?php foreach ($roles as $role): ?>
                                <th class="text-center"><?= htmlspecialchars($role['role_name']) ?></th>
                            <?php endforeach; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grouped_permissions as $module => $perms): ?>
                            <tr class="table-secondary">
                                <td colspan="<?= count($roles) + 1 ?>"><strong><?= ucfirst($module) ?> Modülü</strong></td>
                            </tr>
                            <?php foreach ($perms as $permission): ?>
                                <tr>
                                    <td><?= htmlspecialchars($permission['description']) ?></td>
                                    <?php foreach ($roles as $role): ?>
                                        <td class="text-center">
                                            <div class="form-check form-switch d-inline-block">
                                                <input class="form-check-input" type="checkbox" 
                                                       name="permissions[<?= $role['id'] ?>][<?= $permission['id'] ?>]"
                                                       value="1"
                                                       <?= isset($role_permissions[$role['id']]) && in_array($permission['id'], $role_permissions[$role['id']]) ? 'checked' : '' ?>>
                                            </div>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="text-end mt-3">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save me-2"></i> İzinleri Kaydet
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Rol Ekleme/Düzenleme Modal -->
<div class="modal fade" id="roleModal" tabindex="-1" aria-labelledby="roleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="roleModalLabel">Yeni Rol Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="roleForm">
                <div class="modal-body">
                    <input type="hidden" id="roleId" name="id">
                    <div class="mb-3">
                        <label for="role_name" class="form-label">Rol Adı <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="role_name" name="role_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Açıklama</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>
<script>
$(document).ready(function() {
    $('#permissionsForm').on('submit', function(e) {
        e.preventDefault();
        sendAjaxRequest({
            url: '../api/roles_api.php?action=update_permissions',
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            // Başarılı olduğunda bir şey yapmaya gerek yok, sadece bildirim gösterilir.
        });
    });

    $('#roleForm').on('submit', function(e) {
        e.preventDefault();
        sendAjaxRequest({
            url: '../api/roles_api.php?action=create_role',
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            location.reload(); // Sayfayı yenileyerek yeni rolün tabloda görünmesini sağla
        });
    });
});

function prepareAddRole() {
    $('#roleForm')[0].reset();
    $('#roleId').val('');
    $('#roleModalLabel').text('Yeni Rol Ekle');
}
</script>