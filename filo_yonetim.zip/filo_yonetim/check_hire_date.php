<?php
require_once 'includes/config.php';

try {
    $stmt = $pdo->query("SHOW COLUMNS FROM personnel LIKE 'hire_date'");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result) {
        echo "hire_date sütunu mevcut. Detaylar: " . print_r($result, true);
    } else {
        echo "hire_date sütunu bulunamadı. Eklenmesi gerekiyor.";
        
        // Sütunu ekle
        $pdo->exec("ALTER TABLE personnel ADD COLUMN hire_date DATE DEFAULT NULL AFTER department");
        echo "<br>hire_date sütunu başarıyla eklendi.";
    }
} catch (PDOException $e) {
    echo "Hata oluştu: " . $e->getMessage();
}
?>
