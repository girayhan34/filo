<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Sayfa değişkenlerini ayarla
$page_title = 'Araç Yönetimi';
$page_subtitle = 'Araçlarınızı yönetin ve takip edin';

// Araçları listeleme ve istatistikler
try {
    $stmt = $pdo->query("SELECT v.*, 
        vm_last.maintenance_date as last_maintenance,
        vm_next.next_maintenance_date as next_maintenance,
        vf_last.fuel_date as last_fuel_date,
        vf_last.km_reading as current_km,
        vf_last.fuel_consumption as last_consumption
    FROM vehicles v
    LEFT JOIN (SELECT vehicle_id, MAX(maintenance_date) as maintenance_date 
               FROM vehicle_maintenance WHERE status = 'completed' GROUP BY vehicle_id) vm_last 
               ON v.id = vm_last.vehicle_id
    LEFT JOIN (SELECT vehicle_id, MIN(next_maintenance_date) as next_maintenance_date 
               FROM vehicle_maintenance WHERE next_maintenance_date > CURDATE() GROUP BY vehicle_id) vm_next 
               ON v.id = vm_next.vehicle_id
    LEFT JOIN (SELECT vehicle_id, fuel_date, km_reading, fuel_consumption,
                      ROW_NUMBER() OVER (PARTITION BY vehicle_id ORDER BY fuel_date DESC) as rn 
               FROM vehicle_fuel) vf_last 
               ON v.id = vf_last.vehicle_id AND vf_last.rn = 1
    WHERE v.status != 'deleted'
    ORDER BY v.created_at DESC");
    $vehicles = $stmt->fetchAll();
    
    // Dashboard istatistikleri
    $stats = [
        'total' => count($vehicles),
        'active' => count(array_filter($vehicles, fn($v) => $v['status'] == 'active')),
        'maintenance' => count(array_filter($vehicles, fn($v) => $v['status'] == 'maintenance')),
        'inactive' => count(array_filter($vehicles, fn($v) => $v['status'] == 'inactive')),
        'due_maintenance' => count(array_filter($vehicles, function($v) {
            return $v['next_maintenance'] && strtotime($v['next_maintenance']) <= strtotime('+7 days');
        }))
    ];
} catch (Exception $e) {
    $vehicles = [];
    $stats = [
        'total' => 0, 
        'active' => 0, 
        'maintenance' => 0, 
        'inactive' => 0,
        'due_maintenance' => 0
    ];
}

// Araç silme
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    try {
        $pdo->beginTransaction();
        
        // İlişkili kayıtları sil
        $pdo->prepare("DELETE FROM vehicle_maintenance WHERE vehicle_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM vehicle_fuel WHERE vehicle_id = ?")->execute([$id]);
        
        // Aracı sil
        $pdo->prepare("UPDATE vehicles SET status = 'deleted' WHERE id = ?")->execute([$id]);
        
        $pdo->commit();
        $_SESSION['success'] = 'Araç başarıyla silindi.';
    } catch (Exception $e) {
        $pdo->rollBack();
        $_SESSION['error'] = 'Araç silinirken bir hata oluştu: ' . $e->getMessage();
    }
    header("Location: vehicles.php");
    exit();
}

// Başarı/başarısızlık mesajlarını kontrol et
$success = $_SESSION['success'] ?? null;
$error = $_SESSION['error'] ?? null;
unset($_SESSION['success'], $_SESSION['error']);

// Header'ı dahil et
include 'includes/header.php';
?>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#addVehicleModal">
                            <i class="fas fa-plus-circle mb-1"></i>
                            <small>Yeni Araç</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-success w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#maintenanceModal">
                            <i class="fas fa-tools mb-1"></i>
                            <small>Bakım Ekle</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-info w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#fuelModal">
                            <i class="fas fa-gas-pump mb-1"></i>
                            <small>Yakıt Ekle</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-warning w-100 quick-action-btn" onclick="printVehicles()">
                            <i class="fas fa-print mb-1"></i>
                            <small>Yazdır</small>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- İstatistik Kartları -->
<div class="row mb-4">
    <div class="col-md-3 col-6 mb-3">
        <div class="card stats-card">
            <i class="fas fa-truck"></i>
            <h2><?= $stats['total'] ?></h2>
            <p>Toplam Araç</p>
        </div>
    </div>
    <div class="col-md-3 col-6 mb-3">
        <div class="card stats-card">
            <i class="fas fa-check-circle text-success"></i>
            <h2><?= $stats['active'] ?></h2>
            <p>Aktif Araç</p>
        </div>
    </div>
    <div class="col-md-2 col-4 mb-3">
        <div class="card stats-card">
            <i class="fas fa-tools text-warning"></i>
            <h2><?= $stats['maintenance'] ?></h2>
            <p>Bakımda</p>
        </div>
    </div>
    <div class="col-md-2 col-4 mb-3">
        <div class="card stats-card">
            <i class="fas fa-exclamation-triangle text-danger"></i>
            <h2><?= $stats['due_maintenance'] ?></h2>
            <p>Bakım Gerekiyor</p>
        </div>
    </div>
    <div class="col-md-2 col-4 mb-3">
        <div class="card stats-card">
            <i class="fas fa-pause-circle text-secondary"></i>
            <h2><?= $stats['inactive'] ?></h2>
            <p>Pasif Araç</p>
        </div>
    </div>
</div>

<!-- Bildirimler -->
<?php if ($success): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?= $success ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
</div>
<?php endif; ?>

<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <?= $error ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Kapat"></button>
</div>
<?php endif; ?>

<!-- Arama ve Filtre -->
<div class="row mb-4">
    <div class="col-md-8">
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-search"></i></span>
            <input type="text" class="form-control" id="searchInput" placeholder="Araç ara (plaka, marka, model, şase no...)">
        </div>
    </div>
    <div class="col-md-4">
        <select class="form-select" id="statusFilter" onchange="filterVehicles(this.value)">
            <option value="all">Tüm Araçlar</option>
            <option value="active">Aktif Araçlar</option>
            <option value="maintenance">Bakımdakiler</option>
            <option value="inactive">Pasif Araçlar</option>
            <option value="due_maintenance">Bakım Gerekenler</option>
        </select>
    </div>
</div>

<!-- Araç Listesi -->
<div class="card mb-4">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-truck me-2"></i>Araç Listesi</h5>
            <div>
                <button class="btn btn-sm btn-outline-secondary me-2" onclick="exportVehicles()">
                    <i class="fas fa-file-export me-1"></i>Dışa Aktar
                </button>
            </div>
        </div>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0" id="vehiclesTable">
                <thead class="table-light">
                    <tr>
                        <th>Plaka</th>
                        <th>Marka/Model</th>
                        <th>Yıl</th>
                        <th>KM</th>
                        <th>Son Bakım</th>
                        <th>Sonraki Bakım</th>
                        <th>Yakıt Tüketimi</th>
                        <th>Durum</th>
                        <th class="text-end">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($vehicles)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-5">
                            <i class="fas fa-truck fa-3x text-muted mb-3"></i>
                            <h5>Henüz araç kaydı bulunmuyor</h5>
                            <p class="text-muted">İlk aracınızı eklemek için "Yeni Araç" butonunu kullanın.</p>
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($vehicles as $vehicle): 
                            $status_class = [
                                'active' => 'success',
                                'maintenance' => 'warning',
                                'inactive' => 'secondary'
                            ][$vehicle['status']] ?? 'secondary';
                            
                            $is_due_maintenance = $vehicle['next_maintenance'] && 
                                                strtotime($vehicle['next_maintenance']) <= strtotime('+7 days');
                        ?>
                        <tr class="vehicle-item" data-status="<?= $vehicle['status'] ?>" 
                            <?= $is_due_maintenance ? 'data-due-maintenance="1"' : '' ?>>
                            <td>
                                <strong><?= htmlspecialchars($vehicle['plate_number']) ?></strong>
                                <?php if ($vehicle['is_company']): ?>
                                    <span class="badge bg-primary ms-1" data-bs-toggle="tooltip" title="Kurumsal Araç">
                                        <i class="fas fa-building"></i>
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="me-2">
                                        <i class="fas fa-<?= $vehicle['vehicle_type'] == 'car' ? 'car' : 'truck' ?> fa-lg"></i>
                                    </div>
                                    <div>
                                        <div class="fw-medium"><?= htmlspecialchars($vehicle['brand']) ?></div>
                                        <div class="text-muted small"><?= htmlspecialchars($vehicle['model']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td><?= $vehicle['model_year'] ?: '-' ?></td>
                            <td><?= number_format($vehicle['current_km'] ?? $vehicle['km_reading'] ?? 0, 0, ',', '.') ?> km</td>
                            <td>
                                <?php if ($vehicle['last_maintenance']): ?>
                                    <?= date('d.m.Y', strtotime($vehicle['last_maintenance'])) ?>
                                <?php else: ?>
                                    <span class="text-muted">Kayıt yok</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($vehicle['next_maintenance']): ?>
                                    <?php if ($is_due_maintenance): ?>
                                        <span class="badge bg-danger">
                                            <?= date('d.m.Y', strtotime($vehicle['next_maintenance'])) ?>
                                        </span>
                                    <?php else: ?>
                                        <?= date('d.m.Y', strtotime($vehicle['next_maintenance'])) ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">Planlanmamış</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if (isset($vehicle['last_consumption'])): ?>
                                    <?= number_format($vehicle['last_consumption'], 1, ',', '.') ?> L/100km
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="badge bg-<?= $status_class ?>">
                                    <?= [
                                        'active' => 'Aktif',
                                        'maintenance' => 'Bakımda',
                                        'inactive' => 'Pasif'
                                    ][$vehicle['status']] ?? $vehicle['status'] ?>
                                </span>
                            </td>
                            <td class="text-end">
                                <div class="btn-group btn-group-sm">
                                    <button type="button" class="btn btn-outline-primary" 
                                            onclick="viewVehicle(<?= $vehicle['id'] ?>)" 
                                            data-bs-toggle="tooltip" data-bs-title="Detayları Görüntüle">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-outline-warning" 
                                            onclick="editVehicle(<?= $vehicle['id'] ?>)" 
                                            data-bs-toggle="tooltip" data-bs-title="Düzenle">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="vehicles.php?delete=<?= $vehicle['id'] ?>" 
                                       class="btn btn-outline-danger delete-vehicle"
                                       data-bs-toggle="tooltip" data-bs-title="Sil"
                                       onclick="return confirm('Bu aracı silmek istediğinize emin misiniz?\n\nBu işlem geri alınamaz ve araca ait tüm bakım ve yakıt kayıtları da silinecektir.');">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Yeni Araç Modal -->
<div class="modal fade" id="addVehicleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yeni Araç Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="addVehicleForm" action="api/vehicles.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6 class="mb-3">Temel Bilgiler</h6>
                            <div class="mb-3">
                                <label class="form-label">Plaka *</label>
                                <input type="text" class="form-control" name="plate_number" required 
                                       placeholder="34ABC123" style="text-transform:uppercase">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Araç Türü *</label>
                                <select class="form-select" name="vehicle_type" required>
                                    <option value="car">Binek Araç</option>
                                    <option value="truck">Ticari Araç</option>
                                    <option value="van">Minibüs / Panelvan</option>
                                    <option value="motorcycle">Motosiklet</option>
                                    <option value="other">Diğer</option>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Marka *</label>
                                        <input type="text" class="form-control" name="brand" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Model *</label>
                                        <input type="text" class="form-control" name="model" required>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Model Yılı</label>
                                        <select class="form-select" name="model_year">
                                            <option value="">Seçiniz</option>
                                            <?php for ($year = date('Y') + 1; $year >= 1990; $year--): ?>
                                                <option value="<?= $year ?>" <?= $year == date('Y') ? 'selected' : '' ?>>
                                                    <?= $year ?>
                                                </option>
                                            <?php endfor; ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Renk</label>
                                        <input type="text" class="form-control" name="color">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6 class="mb-3">Teknik Özellikler</h6>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Şase No</label>
                                        <input type="text" class="form-control" name="chassis_number">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Motor No</label>
                                        <input type="text" class="form-control" name="engine_number">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">KM Bilgisi</label>
                                        <div class="input-group">
                                            <input type="number" class="form-control" name="km_reading" min="0">
                                            <span class="input-group-text">km</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="mb-3">
                                        <label class="form-label">Yakıt Türü</label>
                                        <select class="form-select" name="fuel_type">
                                            <option value="diesel">Dizel</option>
                                            <option value="gasoline">Benzin</option>
                                            <option value="lpg">LPG</option>
                                            <option value="electric">Elektrik</option>
                                            <option value="hybrid">Hibrit</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Açıklama</label>
                                <textarea class="form-control" name="description" rows="2"></textarea>
                            </div>
                            <div class="form-check form-switch mb-3">
                                <input class="form-check-input" type="checkbox" name="is_company" id="isCompany">
                                <label class="form-check-label" for="isCompany">Kurumsal Araç</label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Araç Detay Modal -->
<div class="modal fade" id="vehicleDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Araç Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body" id="vehicleDetailContent">
                <!-- Dinamik içerik buraya yüklenecek -->
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Yükleniyor...</span>
                    </div>
                    <p class="mt-2">Araç bilgileri yükleniyor...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
            </div>
        </div>
    </div>
</div>

<!-- Bakım Ekleme Modal -->
<div class="modal fade" id="maintenanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bakım Kaydı Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="maintenanceForm" action="api/maintenance.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Araç Seçin *</label>
                        <select class="form-select" name="vehicle_id" required>
                            <option value="">Araç seçin</option>
                            <?php foreach ($vehicles as $v): ?>
                            <option value="<?= $v['id'] ?>">
                                <?= htmlspecialchars("{$v['plate_number']} - {$v['brand']} {$v['model']}") ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Bakım Tarihi *</label>
                                <input type="date" class="form-control" name="maintenance_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Sonraki Bakım Tarihi</label>
                                <input type="date" class="form-control" name="next_maintenance_date">
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Bakım Türü *</label>
                        <select class="form-select" name="maintenance_type" required>
                            <option value="routine">Rutin Bakım</option>
                            <option value="repair">Tamir</option>
                            <option value="inspection">Muayene</option>
                            <option value="tire_change">Lastik Değişimi</option>
                            <option value="oil_change">Yağ Değişimi</option>
                            <option value="other">Diğer</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Açıklama</label>
                        <textarea class="form-control" name="description" rows="2"></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">KM Bilgisi</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="km_reading" min="0">
                                    <span class="input-group-text">km</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Tutar</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="cost" step="0.01" min="0">
                                    <span class="input-group-text">₺</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Servis</label>
                        <input type="text" class="form-control" name="service_center">
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="is_completed" id="isCompleted" checked>
                        <label class="form-check-label" for="isCompleted">Bakım tamamlandı</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Yakıt Ekleme Modal -->
<div class="modal fade" id="fuelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yakıt Kaydı Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="fuelForm" action="api/fuel.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Araç Seçin *</label>
                        <select class="form-select" name="vehicle_id" required>
                            <option value="">Araç seçin</option>
                            <?php foreach ($vehicles as $v): ?>
                            <option value="<?= $v['id'] ?>">
                                <?= htmlspecialchars("{$v['plate_number']} - {$v['brand']} {$v['model']}") ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Yakıt Tarihi *</label>
                                <input type="date" class="form-control" name="fuel_date" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">KM Bilgisi *</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="km_reading" required min="0">
                                    <span class="input-group-text">km</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Yakıt Miktarı (Litre) *</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="fuel_amount" step="0.01" required min="0">
                                    <span class="input-group-text">L</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Birim Fiyat (₺) *</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="price_per_liter" step="0.01" required min="0">
                                    <span class="input-group-text">₺/L</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Toplam Tutar</label>
                                <div class="input-group">
                                    <input type="number" class="form-control" name="total_cost" step="0.01" min="0" readonly>
                                    <span class="input-group-text">₺</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Yakıt Türü</label>
                                <select class="form-select" name="fuel_type">
                                    <option value="diesel">Dizel</option>
                                    <option value="gasoline">Benzin</option>
                                    <option value="lpg">LPG</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notlar</label>
                        <textarea class="form-control" name="notes" rows="2"></textarea>
                    </div>
                    <div class="form-check form-switch mb-3">
                        <input class="form-check-input" type="checkbox" name="is_full_tank" id="isFullTank">
                        <label class="form-check-label" for="isFullTank">Depo tam dolduruldu</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bugünün tarihini default olarak set et
    const today = new Date().toISOString().split('T')[0];
    document.querySelectorAll('input[type="date"]').forEach(input => {
        if (!input.value) input.value = today;
    });

    // Yakıt hesaplamaları
    const fuelForm = document.getElementById('fuelForm');
    if (fuelForm) {
        const fuelAmount = fuelForm.querySelector('[name="fuel_amount"]');
        const pricePerLiter = fuelForm.querySelector('[name="price_per_liter"]');
        const totalCost = fuelForm.querySelector('[name="total_cost"]');
        
        function calculateTotal() {
            if (fuelAmount.value && pricePerLiter.value) {
                const total = parseFloat(fuelAmount.value) * parseFloat(pricePerLiter.value);
                totalCost.value = total.toFixed(2);
            } else {
                totalCost.value = '';
            }
        }
        
        fuelAmount?.addEventListener('input', calculateTotal);
        pricePerLiter?.addEventListener('input', calculateTotal);
    }

    // Silme işlemi onayı
    document.querySelectorAll('.delete-vehicle').forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Bu aracı silmek istediğinize emin misiniz?\n\nBu işlem geri alınamaz ve araca ait tüm bakım ve yakıt kayıtları da silinecektir.')) {
                e.preventDefault();
            }
        });
    });

    // Tooltip'leri etkinleştir
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});

// Araç görüntüleme fonksiyonu
function viewVehicle(vehicleId) {
    const modal = new bootstrap.Modal(document.getElementById('vehicleDetailModal'));
    const content = document.getElementById('vehicleDetailContent');
    
    // Yükleme göstergesi
    content.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Yükleniyor...</span>
            </div>
            <p class="mt-2">Araç bilgileri yükleniyor...</p>
        </div>
    `;
    
    modal.show();
    
    // Simüle edilmiş veri yükleme
    setTimeout(() => {
        // Gerçek uygulamada burada AJAX ile sunucudan veri çekilecek
        content.innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <h6><i class="fas fa-info-circle me-2"></i>Araç Bilgileri</h6>
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Plaka:</strong> 34ABC123</p>
                                    <p><strong>Marka/Model:</strong> Ford Focus</p>
                                    <p><strong>Yıl:</strong> 2020</p>
                                    <p><strong>Renk:</strong> Beyaz</p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Şase No:</strong> WF0EXXGBB12345678</p>
                                    <p><strong>Yakıt Türü:</strong> Dizel</p>
                                    <p><strong>KM:</strong> 45.250 km</p>
                                    <p><strong>Durum:</strong> <span class="badge bg-success">Aktif</span></p>
                                </div>
                            </div>
                            <div class="mt-3">
                                <h6>Açıklama</h6>
                                <p class="text-muted">Şirket aracı - Genel Müdür kullanımında</p>
                            </div>
                        </div>
                    </div>
                    
                    <h6><i class="fas fa-tools me-2"></i>Son Bakımlar</h6>
                    <div class="card">
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h6 class="mb-1">Yağ Değişimi</h6>
                                            <small class="text-muted">15.03.2023 - 42.500 km</small>
                                        </div>
                                        <span class="badge bg-success">Tamamlandı</span>
                                    </div>
                                    <p class="mb-0 mt-1">Motor yağı ve filtre değişimi yapıldı.</p>
                                    <small class="text-muted">Tutar: 1.250,00 ₺</small>
                                </div>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h6 class="mb-1">Periyodik Bakım</h6>
                                            <small class="text-muted">15.09.2023 - 45.000 km</small>
                                        </div>
                                        <span class="badge bg-warning">Bekliyor</span>
                                    </div>
                                    <p class="mb-0 mt-1">Sonraki bakım: 15.03.2024</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <h6><i class="fas fa-gas-pump me-2"></i>Yakıt Tüketimi</h6>
                    <div class="card mb-4">
                        <div class="card-body">
                            <div class="row text-center">
                                <div class="col-4">
                                    <h3 class="mb-0">6.8</h3>
                                    <small class="text-muted">Ortalama (L/100km)</small>
                                </div>
                                <div class="col-4">
                                    <h3 class="mb-0">1.450</h3>
                                    <small class="text-muted">Aylık Ortalama (₺)</small>
                                </div>
                                <div class="col-4">
                                    <h3 class="mb-0">45.250</h3>
                                    <small class="text-muted">Toplam KM</small>
                                </div>
                            </div>
                            <div class="mt-3">
                                <canvas id="fuelConsumptionChart" height="150"></canvas>
                            </div>
                        </div>
                    </div>
                    
                    <h6><i class="fas fa-history me-2"></i>Son Yakıt Alımları</h6>
                    <div class="card">
                        <div class="card-body p-0">
                            <div class="list-group list-group-flush">
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h6 class="mb-1">30.00 L Dizel</h6>
                                            <small class="text-muted">10.03.2023 - 45.000 km</small>
                                        </div>
                                        <span class="text-nowrap">1.250,00 ₺</span>
                                    </div>
                                    <p class="mb-0 mt-1">Opet - Kartal Şubesi</p>
                                </div>
                                <div class="list-group-item">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h6 class="mb-1">45.50 L Dizel</h6>
                                            <small class="text-muted">25.02.2023 - 44.200 km</small>
                                        </div>
                                        <span class="text-nowrap">1.865,50 ₺</span>
                                    </div>
                                    <p class="mb-0 mt-1">Shell - Kadıköy Şubesi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="alert alert-info mt-3">
                <i class="fas fa-info-circle me-2"></i>
                Detaylı araç bilgileri için backend entegrasyonu gereklidir.
            </div>
            <script>
            // Grafik oluşturma (demo amaçlı)
            document.addEventListener('DOMContentLoaded', function() {
                const ctx = document.getElementById('fuelConsumptionChart');
                if (ctx) {
                    new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: ['Oca', 'Şub', 'Mar', 'Nis', 'May', 'Haz', 'Tem', 'Ağu', 'Eyl', 'Eki', 'Kas', 'Ara'],
                            datasets: [{
                                label: 'Ortalama Tüketim (L/100km)',
                                data: [7.1, 7.3, 6.9, 6.5, 6.2, 6.8, 7.0, 6.7, 6.5, 6.3, 6.8, 6.5],
                                borderColor: '#4e73df',
                                tension: 0.3,
                                fill: false
                            }]
                        },
                        options: {
                            responsive: true,
                            plugins: {
                                legend: {
                                    display: false
                                }
                            },
                            scales: {
                                y: {
                                    beginAtZero: false,
                                    min: 5,
                                    max: 8
                                }
                            }
                        }
                    });
                }
            });
            <\/script>
        `;
    }, 1000);
}

// Araç düzenleme fonksiyonu
function editVehicle(vehicleId) {
    // Bu fonksiyon düzenleme modalını açacak
    alert(`Araç düzenleme sayfası açılacak (ID: ${vehicleId})\n\nBackend entegrasyonu gereklidir.`);
}

// Araç filtreleme fonksiyonu
function filterVehicles(status) {
    const rows = document.querySelectorAll('.vehicle-item');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const rowStatus = row.dataset.status;
        const isDueMaintenance = row.dataset.dueMaintenance === '1';
        
        if (status === 'all' || 
            (status === 'due_maintenance' && isDueMaintenance) ||
            (status !== 'due_maintenance' && rowStatus === status)) {
            row.style.display = '';
            visibleCount++;
        } else {
            row.style.display = 'none';
        }
    });
    
    // Eğer hiç sonuç yoksa bilgi mesajı göster
    const noResults = document.getElementById('noResults');
    if (noResults) {
        noResults.style.display = visibleCount === 0 ? 'block' : 'none';
    }
}

// Arama fonksiyonu
document.getElementById('searchInput')?.addEventListener('input', function() {
    const searchTerm = this.value.toLowerCase();
    const rows = document.querySelectorAll('.vehicle-item');
    let visibleCount = 0;
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        const isVisible = text.includes(searchTerm);
        row.style.display = isVisible ? '' : 'none';
        if (isVisible) visibleCount++;
    });
    
    // Eğer hiç sonuç yoksa bilgi mesajı göster
    const noResults = document.getElementById('noResults');
    if (noResults) {
        noResults.style.display = visibleCount === 0 ? 'block' : 'none';
    }
});

// Dışa aktarma fonksiyonu
function exportVehicles() {
    const vehicles = [
        ['Plaka', 'Marka', 'Model', 'Yıl', 'KM', 'Son Bakım', 'Sonraki Bakım', 'Durum']
    ];
    
    document.querySelectorAll('.vehicle-item').forEach(row => {
        if (row.style.display !== 'none') {
            const cells = row.querySelectorAll('td');
            const vehicle = [
                cells[0].textContent.trim(),
                cells[1].querySelector('.fw-medium')?.textContent.trim() || '',
                cells[1].querySelector('.small')?.textContent.trim() || '',
                cells[2].textContent.trim(),
                cells[3].textContent.trim(),
                cells[4].textContent.trim(),
                cells[5].textContent.trim(),
                cells[7].textContent.trim()
            ];
            vehicles.push(vehicle);
        }
    });
    
    // CSV içeriğini oluştur
    let csvContent = 'data:text/csv;charset=utf-8,';
    vehicles.forEach(vehicle => {
        // Özel karakterleri ve virgülleri düzelt
        const escapedRow = vehicle.map(cell => 
            `"${cell.replace(/"/g, '""')}"`
        ).join(',');
        csvContent += escapedRow + '\r\n';
    });

    // İndirme bağlantısı oluştur
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'arac_listesi_' + new Date().toISOString().split('T')[0] + '.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Kullanıcıya bildirim göster
    alert('Araç listesi başarıyla dışa aktarıldı!');
}

// Yazdırma fonksiyonu
function printVehicles() {
    window.print();
}
</script>

<?php include 'includes/footer.php'; ?>
