<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Stok Hareket Raporu';
$page_subtitle = 'Tüm stok giriş ve çıkış hareketlerini inceleyin.';
include 'includes/header.php';

// Filtreleme için stok kalemlerini çek
$stock_items = $pdo->query("SELECT id, item_name, item_code FROM stock_items ORDER BY item_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<!-- Filtreleme Kartı -->
<div class="card shadow-sm mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-filter me-2"></i>Filtreler</h5>
    </div>
    <div class="card-body">
        <div class="row g-3">
            <div class="col-md-3">
                <label for="dateRangeFilter" class="form-label">Tarih Aralığı</label>
                <input type="text" class="form-control" id="dateRangeFilter" placeholder="Tarih aralığı seçin">
            </div>
            <div class="col-md-3">
                <label for="itemFilter" class="form-label">Ürün/Malzeme</label>
                <select class="form-select" id="itemFilter">
                    <option value="">Tümü</option>
                    <?php foreach ($stock_items as $item): ?>
                        <option value="<?= $item['id'] ?>"><?= htmlspecialchars($item['item_name']) ?> (<?= htmlspecialchars($item['item_code']) ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="movementTypeFilter" class="form-label">Hareket Türü</label>
                <select class="form-select" id="movementTypeFilter">
                    <option value="">Tümü</option>
                    <option value="in">Stok Girişi</option>
                    <option value="out">Stok Çıkışı</option>
                </select>
            </div>
            <div class="col-md-3 d-flex align-items-end">
                <button class="btn btn-secondary" id="resetFilters">Filtreleri Temizle</button>
            </div>
        </div>
    </div>
</div>

<!-- Stok Hareketleri Tablosu -->
<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-history me-2"></i>Stok Hareket Geçmişi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="stockMovementsTable">
                <thead class="table-light">
                    <tr>
                        <th>Tarih</th>
                        <th>Ürün Adı</th>
                        <th>Stok Kodu</th>
                        <th>Hareket Türü</th>
                        <th>Miktar</th>
                        <th>İşlemi Yapan</th>
                        <th>Notlar</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables ve DateRangePicker için gerekli kütüphaneler -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
$(document).ready(function() {
    // DateRangePicker'ı başlat
    $('#dateRangeFilter').daterangepicker({
        autoUpdateInput: false,
        locale: {
            cancelLabel: 'Temizle',
            applyLabel: 'Uygula',
            format: 'DD.MM.YYYY'
        }
    });

    $('#dateRangeFilter').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
        table.ajax.reload();
    });

    $('#dateRangeFilter').on('cancel.daterangepicker', function(ev, picker) {
        $(this).val('');
        table.ajax.reload();
    });

    // DataTables'ı başlat
    var table = $('#stockMovementsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/stock_api.php?action=list_movements',
            type: 'POST',
            data: function(d) {
                d.item_id = $('#itemFilter').val();
                d.movement_type = $('#movementTypeFilter').val();
                if ($('#dateRangeFilter').val()) {
                    d.start_date = moment($('#dateRangeFilter').data('daterangepicker').startDate).format('YYYY-MM-DD');
                    d.end_date = moment($('#dateRangeFilter').data('daterangepicker').endDate).format('YYYY-MM-DD');
                }
            }
        },
        columns: [
            { data: 'movement_date', render: function(data) { return moment(data).format('DD.MM.YYYY HH:mm'); }},
            { data: 'item_name' },
            { data: 'item_code' },
            { data: 'movement_type', render: function(data) {
                return data === 'in' 
                    ? '<span class="badge bg-success"><i class="fas fa-arrow-down me-1"></i>Giriş</span>' 
                    : '<span class="badge bg-danger"><i class="fas fa-arrow-up me-1"></i>Çıkış</span>';
            }},
            { data: 'quantity', render: function(data, type, row) {
                const sign = row.movement_type === 'in' ? '+' : '-';
                return `<strong>${sign}${data}</strong>`;
            }},
            { data: 'user_name' },
            { data: 'notes' }
        ],
        order: [[0, 'desc']],
        language: getDataTablesLanguage()
    });

    // Filtreler değiştiğinde tabloyu yeniden yükle
    $('#itemFilter, #movementTypeFilter').on('change', function() {
        table.ajax.reload();
    });

    $('#resetFilters').on('click', function() {
        $('#itemFilter').val('');
        $('#movementTypeFilter').val('');
        $('#dateRangeFilter').val('');
        $('#dateRangeFilter').data('daterangepicker').setStartDate(moment());
        $('#dateRangeFilter').data('daterangepicker').setEndDate(moment());
        table.ajax.reload();
    });
});
</script>