-- PERSONEL YÖNETİM SİSTEMİ VERİTABANI ŞEMASI

-- Ana personel tablosu
CREATE TABLE IF NOT EXISTS `personel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_no` varchar(20) NOT NULL COMMENT 'Sicil No',
  `tc_kimlik` varchar(11) DEFAULT NULL,
  `ad` varchar(50) NOT NULL,
  `soyad` varchar(50) NOT NULL,
  `dogum_tarihi` date DEFAULT NULL,
  `cinsiyet` enum('Erkek','Kadın','Diğer') DEFAULT NULL,
  `medeni_durum` enum('Bekar','Evli','Dul','Boşanmış') DEFAULT NULL,
  `cocuk_sayisi` int(2) DEFAULT 0,
  `kan_grubu` varchar(5) DEFAULT NULL,
  `ehliyet_tur` varchar(50) DEFAULT NULL,
  `fotograf` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `telefon` varchar(20) DEFAULT NULL,
  `adres` text DEFAULT NULL,
  `il` varchar(50) DEFAULT NULL,
  `ilce` varchar(50) DEFAULT NULL,
  `posta_kodu` varchar(10) DEFAULT NULL,
  `departman_id` int(11) DEFAULT NULL,
  `pozisyon` varchar(100) DEFAULT NULL,
  `ise_giris_tarihi` date DEFAULT NULL,
  `isten_ayrilma_tarihi` date DEFAULT NULL,
  `calisma_sekli` enum('Tam Zamanlı','Yarı Zamanlı','Stajyer','Dönemsel') DEFAULT 'Tam Zamanlı',
  `durum` enum('Aktif','İzinli','İşten Ayrıldı','İşten Çıkarıldı') DEFAULT 'Aktif',
  `acil_durum_kisi` varchar(100) DEFAULT NULL,
  `acil_durum_telefon` varchar(20) DEFAULT NULL,
  `acil_durum_yakinlik` varchar(50) DEFAULT NULL,
  `bank_adi` varchar(100) DEFAULT NULL,
  `sube_adi` varchar(100) DEFAULT NULL,
  `sube_kodu` varchar(20) DEFAULT NULL,
  `hesap_no` varchar(50) DEFAULT NULL,
  `iban` varchar(26) DEFAULT NULL,
  `sgk_sicil_no` varchar(20) DEFAULT NULL,
  `sgk_giris_tarihi` date DEFAULT NULL,
  `sgk_tescil_tarihi` date DEFAULT NULL,
  `engelli_durumu` tinyint(1) DEFAULT 0,
  `engel_derecesi` varchar(50) DEFAULT NULL,
  `engel_turu` varchar(100) DEFAULT NULL,
  `notlar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personel_no` (`personel_no`),
  UNIQUE KEY `tc_kimlik` (`tc_kimlik`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Departmanlar tablosu
CREATE TABLE IF NOT EXISTS `departmanlar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `departman_adi` varchar(100) NOT NULL,
  `ust_departman_id` int(11) DEFAULT NULL,
  `yonetici_id` int(11) DEFAULT NULL COMMENT 'Departman yöneticisi personel ID',
  `aciklama` text DEFAULT NULL,
  `durum` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Personel Belgeleri
CREATE TABLE IF NOT EXISTS `personel_belgeleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_id` int(11) NOT NULL,
  `belge_turu` varchar(100) NOT NULL,
  `belge_adi` varchar(255) NOT NULL,
  `dosya_yolu` varchar(255) NOT NULL,
  `gecerlilik_baslangic` date DEFAULT NULL,
  `gecerlilik_bitis` date DEFAULT NULL,
  `aciklama` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personel_id` (`personel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- İzinler
CREATE TABLE IF NOT EXISTS `personel_izinleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_id` int(11) NOT NULL,
  `izin_turu` enum('Yıllık İzin','Hastalık İzni','Doğum İzni','Babalık İzni','Ücretsiz İzin','Diğer') NOT NULL,
  `baslangic_tarihi` date NOT NULL,
  `bitis_tarihi` date NOT NULL,
  `gun_sayisi` int(11) NOT NULL,
  `durum` enum('Bekliyor','Onaylandı','Reddedildi','İptal Edildi') DEFAULT 'Bekliyor',
  `aciklama` text DEFAULT NULL,
  `onaylayan_id` int(11) DEFAULT NULL,
  `onay_tarihi` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personel_id` (`personel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Performans Değerlendirmeleri
CREATE TABLE IF NOT EXISTS `personel_performans` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_id` int(11) NOT NULL,
  `degerlendirme_tarihi` date NOT NULL,
  `donem` varchar(50) NOT NULL COMMENT 'Örn: 2023 Yılı 1. Çeyrek',
  `puan` decimal(3,1) DEFAULT 0,
  `degerlendiren_id` int(11) NOT NULL,
  `aciklama` text DEFAULT NULL,
  `hedefler` text DEFAULT NULL,
  `gelistirilecek_alanlar` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `personel_id` (`personel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Maaş Bilgileri
CREATE TABLE IF NOT EXISTS `personel_maas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_id` int(11) NOT NULL,
  `brut_maas` decimal(10,2) NOT NULL,
  `net_maas` decimal(10,2) NOT NULL,
  `para_birimi` varchar(3) DEFAULT 'TRY',
  `odeme_sekli` enum('Aylık','Haftalık','Günlük','Saatlik') DEFAULT 'Aylık',
  `baslangic_tarihi` date NOT NULL,
  `bitis_tarihi` date DEFAULT NULL,
  `aciklama` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personel_id` (`personel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Eğitimler
CREATE TABLE IF NOT EXISTS `personel_egitimler` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `personel_id` int(11) NOT NULL,
  `egitim_adi` varchar(255) NOT NULL,
  `egitim_turu` varchar(100) DEFAULT NULL,
  `verilis_tarihi` date DEFAULT NULL,
  `bitis_tarihi` date DEFAULT NULL,
  `sertifika_no` varchar(100) DEFAULT NULL,
  `sertifika_gecerlilik` date DEFAULT NULL,
  `aciklama` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `personel_id` (`personel_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Yabancı Kısıtlamaları
ALTER TABLE `personel`
  ADD CONSTRAINT `personel_ibfk_1` FOREIGN KEY (`departman_id`) REFERENCES `departmanlar` (`id`) ON DELETE SET NULL;

ALTER TABLE `personel_belgeleri`
  ADD CONSTRAINT `personel_belgeleri_ibfk_1` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`id`) ON DELETE CASCADE;

ALTER TABLE `personel_izinleri`
  ADD CONSTRAINT `personel_izinleri_ibfk_1` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`id`) ON DELETE CASCADE;

ALTER TABLE `personel_performans`
  ADD CONSTRAINT `personel_performans_ibfk_1` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`id`) ON DELETE CASCADE;

ALTER TABLE `personel_maas`
  ADD CONSTRAINT `personel_maas_ibfk_1` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`id`) ON DELETE CASCADE;

ALTER TABLE `personel_egitimler`
  ADD CONSTRAINT `personel_egitimler_ibfk_1` FOREIGN KEY (`personel_id`) REFERENCES `personel` (`id`) ON DELETE CASCADE;

-- Varsayılan Departmanlar
INSERT INTO `departmanlar` (`departman_adi`, `aciklama`, `durum`) VALUES
('İnsan Kaynakları', 'İnsan Kaynakları Departmanı', 1),
('Muhasebe', 'Muhasebe ve Finans Departmanı', 1),
('Bilgi İşlem', 'Bilgi İşlem ve Teknoloji Departmanı', 1),
('Satış', 'Satış ve Pazarlama Departmanı', 1),
('Üretim', 'Üretim ve İmalat Departmanı', 1),
('Kalite', 'Kalite Kontrol Departmanı', 1),
('Lojistik', 'Lojistik ve Dağıtım Departmanı', 1),
('Satın Alma', 'Satın Alma ve Tedarik Departmanı', 1);
