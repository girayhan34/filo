-- Filo Yönetim Sistemi Veritabanı
-- Önce mevcut veritabanını sil ve yeniden oluştur
DROP DATABASE IF EXISTS filo_yonetim;
CREATE DATABASE filo_yonetim CHARACTER SET utf8mb4 COLLATE utf8mb4_turkish_ci;
USE filo_yonetim;

-- Müşteriler tablosu
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    email VARCHAR(255),
    address TEXT,
    tax_office VARCHAR(255),
    tax_number VARCHAR(50),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Araçlar tablosu
CREATE TABLE vehicles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    plate VARCHAR(20) NOT NULL UNIQUE,
    type VARCHAR(50) NOT NULL,
    model VARCHAR(100),
    brand VARCHAR(50),
    year YEAR,
    status ENUM('active', 'maintenance', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Personel tablosu
CREATE TABLE personnel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    position VARCHAR(100),
    license_types TEXT,
    phone VARCHAR(20),
    email VARCHAR(255),
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Faturalar tablosu
CREATE TABLE invoices (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_no VARCHAR(50) NOT NULL UNIQUE,
    receipt_no INT NOT NULL,
    customer_id INT,
    vehicle_id INT,
    driver_id INT,
    invoice_date DATE NOT NULL,
    payment_date DATE,
    due_date DATE,
    service_type VARCHAR(100),
    payment_method VARCHAR(50),
    unit_price DECIMAL(10,2) NOT NULL,
    quantity INT DEFAULT 1,
    amount DECIMAL(10,2) NOT NULL,
    tax_rate DECIMAL(5,2) DEFAULT 0,
    tax_amount DECIMAL(10,2) DEFAULT 0,
    total_amount DECIMAL(10,2) NOT NULL,
    description TEXT,
    status ENUM('pending', 'paid', 'overdue') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE SET NULL,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
    FOREIGN KEY (driver_id) REFERENCES personnel(id) ON DELETE SET NULL
);

-- Gelir-Gider tablosu
CREATE TABLE income_expense (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('income', 'expense') NOT NULL,
    date DATE NOT NULL,
    description VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    amount DECIMAL(10,2) NOT NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Örnek veriler ekle
INSERT INTO customers (name, phone, email, address, tax_office, tax_number) VALUES
('ABC Nakliyat Ltd.', '0212 555 0001', 'info@abcnakliyat.com', 'İstanbul Merkez', 'Beşiktaş VD', '1234567890'),
('XYZ Lojistik A.Ş.', '0312 555 0002', 'contact@xyzlojistik.com', 'Ankara Çankaya', 'Çankaya VD', '2345678901'),
('DEF Ticaret', '0216 555 0003', 'def@ticaret.com', 'İstanbul Kadıköy', 'Kadıköy VD', '3456789012'),
('GHI İnşaat', '0232 555 0004', 'info@ghiinsaat.com', 'İzmir Konak', 'Konak VD', '4567890123'),
('JKL Endüstri', '0262 555 0005', 'jkl@endustri.com', 'Kocaeli Gebze', 'Gebze VD', '5678901234');

-- Araç bakım tablosu
CREATE TABLE vehicle_maintenance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    maintenance_type VARCHAR(100) NOT NULL,
    description TEXT,
    cost DECIMAL(10,2),
    maintenance_date DATE NOT NULL,
    next_maintenance_date DATE,
    km_reading INT,
    service_provider VARCHAR(255),
    notes TEXT,
    status ENUM('completed', 'scheduled', 'overdue') DEFAULT 'completed',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
);

-- Araç yakıt tüketimi tablosu
CREATE TABLE vehicle_fuel (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    fuel_date DATE NOT NULL,
    liters DECIMAL(8,2) NOT NULL,
    cost DECIMAL(10,2) NOT NULL,
    km_reading INT,
    fuel_type ENUM('benzin', 'dizel', 'lpg', 'elektrik') DEFAULT 'dizel',
    station_name VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
);

-- Araç sigorta ve ruhsat tablosu
CREATE TABLE vehicle_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    document_type ENUM('sigorta', 'ruhsat', 'muayene', 'kasko', 'diger') NOT NULL,
    document_name VARCHAR(255) NOT NULL,
    issue_date DATE,
    expiry_date DATE,
    cost DECIMAL(10,2),
    provider VARCHAR(255),
    document_number VARCHAR(100),
    notes TEXT,
    status ENUM('active', 'expired', 'expiring_soon') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
);

INSERT INTO vehicles (plate, type, model, brand, year, status, km_reading, fuel_capacity, insurance_expiry, inspection_expiry) VALUES
('34 ABC 123', 'Kamyon', 'Actros', 'Mercedes', 2020, 'active', 125000, 300, '2024-12-15', '2024-11-30'),
('06 XYZ 456', 'Kamyonet', 'Transit', 'Ford', 2019, 'active', 89000, 80, '2024-10-20', '2024-12-10'),
('35 DEF 789', 'Vinç', 'LTM 1030', 'Liebherr', 2021, 'active', 45000, 400, '2025-01-15', '2024-11-25'),
('16 GHI 101', 'Kepçe', '320D', 'Caterpillar', 2018, 'maintenance', 156000, 200, '2024-09-30', '2024-10-15'),
('41 JKL 202', 'Forklift', '8FG25', 'Toyota', 2020, 'active', 23000, 50, '2024-11-10', '2024-12-05');

INSERT INTO personnel (name, position, license_types, phone) VALUES
('Ahmet Yılmaz', 'Şoför', 'B, C, CE', '0532 111 1111'),
('Mehmet Demir', 'Şoför', 'B, C', '0533 222 2222'),
('Ali Kaya', 'Operatör', 'B, Vinç', '0534 333 3333'),
('Hasan Çelik', 'Şoför', 'B, C, CE, D', '0535 444 4444'),
('İbrahim Özkan', 'Operatör', 'B, Kepçe', '0536 555 5555'),
('Mustafa Arslan', 'Şoför', 'B, C', '0537 666 6666');

-- Araç bakım kayıtları örnek veri
INSERT INTO vehicle_maintenance (vehicle_id, maintenance_type, description, cost, maintenance_date, next_maintenance_date, km_reading, service_provider, status) VALUES
(1, 'Periyodik Bakım', 'Motor yağı değişimi, filtre değişimi', 850.00, '2024-08-15', '2024-11-15', 125000, 'Mercedes Servis', 'completed'),
(1, 'Lastik Değişimi', '4 adet lastik değişimi', 2400.00, '2024-07-20', NULL, 123000, 'Lastik Dünyası', 'completed'),
(2, 'Fren Balata', 'Ön fren balata değişimi', 650.00, '2024-09-01', NULL, 89000, 'Ford Servis', 'completed'),
(3, 'Hidrolik Yağ', 'Hidrolik sistem bakımı', 1200.00, '2024-08-30', '2024-12-30', 45000, 'Liebherr Servis', 'completed'),
(4, 'Motor Arızası', 'Motor revizyonu gerekli', 15000.00, '2024-09-05', NULL, 156000, 'CAT Servis', 'scheduled');

-- Araç yakıt kayıtları örnek veri
INSERT INTO vehicle_fuel (vehicle_id, fuel_date, liters, cost, km_reading, fuel_type, station_name) VALUES
(1, '2024-09-01', 250.00, 6250.00, 124800, 'dizel', 'Shell Mecidiyeköy'),
(1, '2024-08-28', 280.00, 7000.00, 124200, 'dizel', 'BP Levent'),
(2, '2024-09-02', 65.00, 1625.00, 88900, 'dizel', 'Petrol Ofisi Kadıköy'),
(3, '2024-08-29', 180.00, 4500.00, 44800, 'dizel', 'Shell Bostancı'),
(5, '2024-09-01', 35.00, 875.00, 22900, 'dizel', 'Total Kartal');

-- Araç belge kayıtları örnek veri
INSERT INTO vehicle_documents (vehicle_id, document_type, document_name, issue_date, expiry_date, cost, provider, document_number, status) VALUES
(1, 'sigorta', 'Kasko Sigortası', '2023-12-15', '2024-12-15', 8500.00, 'Axa Sigorta', 'AXA-2023-001234', 'expiring_soon'),
(1, 'muayene', 'Araç Muayenesi', '2023-11-30', '2024-11-30', 150.00, 'TÜVTÜRK', 'TT-2023-567890', 'expiring_soon'),
(2, 'sigorta', 'Trafik Sigortası', '2023-10-20', '2024-10-20', 1200.00, 'Allianz', 'ALZ-2023-002345', 'expired'),
(3, 'sigorta', 'Kasko Sigortası', '2024-01-15', '2025-01-15', 12000.00, 'Mapfre', 'MAP-2024-003456', 'active'),
(4, 'muayene', 'Araç Muayenesi', '2023-10-15', '2024-10-15', 200.00, 'TÜVTÜRK', 'TT-2023-678901', 'expired');

-- Müşteri iletişim geçmişi tablosu
CREATE TABLE customer_communications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    communication_type ENUM('phone', 'email', 'meeting', 'note', 'complaint', 'request') NOT NULL,
    subject VARCHAR(255),
    description TEXT,
    communication_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    follow_up_date DATE,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    status ENUM('open', 'in_progress', 'resolved', 'closed') DEFAULT 'open',
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Müşteri proje/iş geçmişi tablosu
CREATE TABLE customer_projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    project_name VARCHAR(255) NOT NULL,
    project_type VARCHAR(100),
    start_date DATE,
    end_date DATE,
    project_value DECIMAL(12,2),
    status ENUM('planning', 'active', 'completed', 'cancelled', 'on_hold') DEFAULT 'planning',
    description TEXT,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- Müşteri iletişim geçmişi örnek veri
INSERT INTO customer_communications (customer_id, communication_type, subject, description, communication_date, priority, status, created_by) VALUES
(1, 'phone', 'Fiyat Teklifi Talebi', 'Yeni proje için kamyon kiralama fiyat teklifi istedi', '2024-09-01 10:30:00', 'high', 'resolved', 'admin'),
(1, 'meeting', 'Proje Görüşmesi', 'İnşaat sahası ziyareti ve ihtiyaç analizi yapıldı', '2024-09-03 14:00:00', 'medium', 'closed', 'admin'),
(2, 'email', 'Fatura Sorgusu', 'Ağustos ayı faturası hakkında bilgi talep etti', '2024-09-02 09:15:00', 'low', 'resolved', 'admin'),
(3, 'complaint', 'Geciken Teslimat', 'Malzeme teslimatının gecikmesi hakkında şikayet', '2024-08-28 16:45:00', 'urgent', 'resolved', 'admin'),
(4, 'request', 'Ek Hizmet Talebi', 'Mevcut projeye ek vinç hizmeti talep etti', '2024-09-05 11:20:00', 'medium', 'in_progress', 'admin');

-- Müşteri proje geçmişi örnek veri
INSERT INTO customer_projects (customer_id, project_name, project_type, start_date, end_date, project_value, status, description) VALUES
(1, 'Ataşehir Rezidans İnşaatı', 'İnşaat', '2024-06-01', '2024-12-31', 450000.00, 'active', 'Konut projesi için kamyon ve vinç kiralama'),
(1, 'Maltepe AVM Projesi', 'İnşaat', '2024-02-15', '2024-05-30', 280000.00, 'completed', 'AVM inşaatı için ağır makine kiralama'),
(2, 'Ankara-İstanbul Nakliyat', 'Lojistik', '2024-07-01', '2024-09-30', 125000.00, 'active', 'Düzenli kargo taşımacılığı hizmeti'),
(3, 'Gebze Fabrika Taşıma', 'Endüstriyel', '2024-08-15', '2024-08-20', 35000.00, 'completed', 'Fabrika ekipmanları taşıma işi'),
(4, 'Kadıköy Konut Projesi', 'İnşaat', '2024-09-01', '2025-02-28', 320000.00, 'active', 'Konut inşaatı için makine parkı kiralama');

-- Personel vardiya tablosu
CREATE TABLE personnel_shifts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id INT NOT NULL,
    shift_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    shift_type ENUM('normal', 'overtime', 'night', 'weekend') DEFAULT 'normal',
    vehicle_id INT,
    project_id INT,
    status ENUM('scheduled', 'active', 'completed', 'cancelled') DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (personnel_id) REFERENCES personnel(id) ON DELETE CASCADE,
    FOREIGN KEY (vehicle_id) REFERENCES vehicles(id) ON DELETE SET NULL,
    FOREIGN KEY (project_id) REFERENCES customer_projects(id) ON DELETE SET NULL
);

-- Personel performans tablosu
CREATE TABLE personnel_performance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id INT NOT NULL,
    evaluation_date DATE NOT NULL,
    performance_score DECIMAL(3,2) CHECK (performance_score >= 0 AND performance_score <= 10),
    punctuality_score DECIMAL(3,2) CHECK (punctuality_score >= 0 AND punctuality_score <= 10),
    safety_score DECIMAL(3,2) CHECK (safety_score >= 0 AND safety_score <= 10),
    customer_feedback_score DECIMAL(3,2) CHECK (customer_feedback_score >= 0 AND customer_feedback_score <= 10),
    total_hours_worked INT DEFAULT 0,
    overtime_hours INT DEFAULT 0,
    incidents_count INT DEFAULT 0,
    comments TEXT,
    evaluated_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (personnel_id) REFERENCES personnel(id) ON DELETE CASCADE
);

-- Personel maaş tablosu
CREATE TABLE personnel_salary (
    id INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id INT NOT NULL,
    salary_month DATE NOT NULL,
    base_salary DECIMAL(10,2) NOT NULL,
    overtime_pay DECIMAL(10,2) DEFAULT 0,
    bonus DECIMAL(10,2) DEFAULT 0,
    deductions DECIMAL(10,2) DEFAULT 0,
    total_salary DECIMAL(10,2) NOT NULL,
    payment_date DATE,
    payment_status ENUM('pending', 'paid', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (personnel_id) REFERENCES personnel(id) ON DELETE CASCADE
);

-- Personel belge tablosu
CREATE TABLE personnel_documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    personnel_id INT NOT NULL,
    document_type ENUM('license', 'certificate', 'contract', 'insurance', 'medical', 'other') NOT NULL,
    document_name VARCHAR(255) NOT NULL,
    document_number VARCHAR(100),
    issue_date DATE,
    expiry_date DATE,
    issuer VARCHAR(255),
    status ENUM('active', 'expired', 'expiring_soon', 'cancelled') DEFAULT 'active',
    file_path VARCHAR(500),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (personnel_id) REFERENCES personnel(id) ON DELETE CASCADE
);

-- Personel vardiya örnek veri
INSERT INTO personnel_shifts (personnel_id, shift_date, start_time, end_time, shift_type, vehicle_id, status, notes) VALUES
(1, '2024-09-07', '08:00:00', '17:00:00', 'normal', 1, 'completed', 'Ataşehir projesinde kamyon kullanımı'),
(1, '2024-09-08', '08:00:00', '17:00:00', 'normal', 1, 'scheduled', 'Devam eden proje'),
(2, '2024-09-07', '09:00:00', '18:00:00', 'normal', 2, 'completed', 'Malzeme nakliyesi'),
(3, '2024-09-07', '07:00:00', '19:00:00', 'overtime', 3, 'completed', 'Acil vinç operasyonu - fazla mesai'),
(4, '2024-09-07', '06:00:00', '14:00:00', 'normal', 4, 'completed', 'Kepçe operasyonu'),
(5, '2024-09-07', '14:00:00', '22:00:00', 'night', 5, 'completed', 'Gece vardiyası forklift');

-- Personel performans örnek veri
INSERT INTO personnel_performance (personnel_id, evaluation_date, performance_score, punctuality_score, safety_score, customer_feedback_score, total_hours_worked, overtime_hours, incidents_count, comments, evaluated_by) VALUES
(1, '2024-08-31', 8.5, 9.0, 8.0, 9.5, 180, 15, 0, 'Çok güvenilir şoför, müşteri memnuniyeti yüksek', 'admin'),
(2, '2024-08-31', 7.5, 8.0, 9.0, 8.0, 175, 10, 1, 'İyi performans, küçük bir kaza yaşandı', 'admin'),
(3, '2024-08-31', 9.0, 8.5, 9.5, 9.0, 190, 25, 0, 'Mükemmel vinç operatörü, güvenlik kurallarına uyumlu', 'admin'),
(4, '2024-08-31', 8.0, 7.5, 8.5, 8.5, 185, 20, 0, 'Deneyimli operatör, zamanında işlerini tamamlıyor', 'admin'),
(5, '2024-08-31', 7.0, 9.5, 8.0, 7.5, 160, 5, 2, 'Dakik ama dikkat eksikliği var', 'admin');

-- Personel maaş örnek veri
INSERT INTO personnel_salary (personnel_id, salary_month, base_salary, overtime_pay, bonus, deductions, total_salary, payment_date, payment_status) VALUES
(1, '2024-08-01', 15000.00, 1500.00, 1000.00, 500.00, 17000.00, '2024-09-01', 'paid'),
(2, '2024-08-01', 13000.00, 1000.00, 500.00, 300.00, 14200.00, '2024-09-01', 'paid'),
(3, '2024-08-01', 16000.00, 2000.00, 1500.00, 600.00, 18900.00, '2024-09-01', 'paid'),
(4, '2024-08-01', 14000.00, 1600.00, 800.00, 400.00, 16000.00, '2024-09-01', 'paid'),
(5, '2024-08-01', 12000.00, 400.00, 300.00, 200.00, 12500.00, '2024-09-01', 'paid'),
(6, '2024-08-01', 13500.00, 800.00, 600.00, 350.00, 14550.00, '2024-09-01', 'paid');

-- Personel belge örnek veri
INSERT INTO personnel_documents (personnel_id, document_type, document_name, document_number, issue_date, expiry_date, issuer, status) VALUES
(1, 'license', 'CE Sınıfı Ehliyet', 'CE123456789', '2020-03-15', '2030-03-15', 'Emniyet Müdürlüğü', 'active'),
(1, 'certificate', 'Mesleki Yeterlilik Belgesi', 'MYB2024001', '2024-01-10', '2029-01-10', 'MEB', 'active'),
(2, 'license', 'C Sınıfı Ehliyet', 'C987654321', '2019-05-20', '2029-05-20', 'Emniyet Müdürlüğü', 'active'),
(3, 'license', 'Vinç Operatörü Belgesi', 'VO2023001', '2023-02-28', '2028-02-28', 'İSG Kurumu', 'active'),
(3, 'certificate', 'İş Güvenliği Sertifikası', 'IGS2024002', '2024-03-01', '2025-03-01', 'İSG Kurumu', 'expiring_soon'),
(4, 'license', 'Kepçe Operatörü Belgesi', 'KO2022001', '2022-06-15', '2027-06-15', 'MEB', 'active');

-- Tahsilat/Ödeme tablosu
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_id INT NOT NULL,
    payment_date DATE NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    reference_no VARCHAR(100),
    notes TEXT,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (invoice_id) REFERENCES invoices(id) ON DELETE CASCADE
);

-- Son fiş numarası için tablo
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value VARCHAR(255) NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO system_settings (setting_key, setting_value) VALUES
('last_receipt_no', '156');

-- Kullanıcılar tablosu
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    role ENUM('admin', 'user', 'viewer') DEFAULT 'user',
    status ENUM('active', 'inactive') DEFAULT 'active',
    last_login TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Varsayılan admin kullanıcısı (şifre: 123456)
INSERT INTO users (username, password, name, email, role) VALUES
('admin', '$2y$10$7KIXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Sistem Yöneticisi', 'admin@gaval.com', 'admin'),
('user', '$2y$10$7KIXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Normal Kullanıcı', 'user@gaval.com', 'user');

-- Örnek faturalar ekle
INSERT INTO invoices (invoice_no, receipt_no, customer_id, vehicle_id, driver_id, invoice_date, service_type, payment_method, unit_price, quantity, amount, tax_rate, tax_amount, total_amount, status) VALUES
('FAT-2024-001', 157, 1, 1, 1, '2024-01-15', 'Nakliye Hizmeti', 'Nakit', 5000.00, 1, 5000.00, 20.00, 1000.00, 6000.00, 'paid'),
('FAT-2024-002', 158, 2, 2, 2, '2024-01-16', 'Kargo Taşımacılığı', 'Havale/EFT', 3500.00, 1, 3500.00, 20.00, 700.00, 4200.00, 'pending'),
('FAT-2024-003', 159, 3, 3, 3, '2024-01-10', 'Vinç Hizmeti', 'Çek', 8000.00, 1, 8000.00, 20.00, 1600.00, 9600.00, 'overdue'),
('FAT-2024-004', 160, 4, 4, 4, '2024-01-20', 'Kepçe Hizmeti', 'Kredi Kartı', 4500.00, 2, 9000.00, 10.00, 900.00, 9900.00, 'paid'),
('FAT-2024-005', 161, 5, 5, 5, '2024-01-25', 'Forklift Kiralama', 'Senet', 2500.00, 3, 7500.00, 0.00, 0.00, 7500.00, 'pending');

-- Örnek tahsilat kayıtları
INSERT INTO payments (invoice_id, payment_date, amount, payment_method, reference_no, notes, created_by) VALUES
(1, '2024-01-15', 6000.00, 'Nakit', 'NAK-001', 'Tam ödeme alındı', 'Admin'),
(4, '2024-01-20', 5000.00, 'Kredi Kartı', 'KK-12345', 'Kısmi ödeme', 'Admin'),
(4, '2024-01-25', 4900.00, 'Havale/EFT', 'HV-67890', 'Kalan tutar ödendi', 'Admin');
