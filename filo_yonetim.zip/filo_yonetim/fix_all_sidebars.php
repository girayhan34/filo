<?php
// Tüm modüllerdeki sidebar'ları düzelten script
$modules = [
    'dashboard.php',
    'invoices.php', 
    'income_expense.php',
    'vehicles.php',
    'customers.php',
    'personel.php',
    'reports.php'
];

foreach ($modules as $module) {
    if (file_exists($module)) {
        $content = file_get_contents($module);
        
        // Eski sidebar kodunu bul ve değiştir
        $old_sidebar_pattern = '/<!-- Sidebar -->.*?<\/nav>/s';
        $new_sidebar = '<?php include \'includes/sidebar.php\'; ?>';
        
        // Alternatif pattern
        $old_sidebar_pattern2 = '/<nav class="col-md-3.*?<\/nav>/s';
        
        if (preg_match($old_sidebar_pattern, $content)) {
            $content = preg_replace($old_sidebar_pattern, $new_sidebar, $content);
            file_put_contents($module, $content);
            echo "✅ $module sidebar güncellendi<br>";
        } elseif (preg_match($old_sidebar_pattern2, $content)) {
            $content = preg_replace($old_sidebar_pattern2, $new_sidebar, $content);
            file_put_contents($module, $content);
            echo "✅ $module sidebar güncellendi<br>";
        } else {
            echo "⚠️ $module - sidebar bulunamadı<br>";
        }
    } else {
        echo "❌ $module bulunamadı<br>";
    }
}

echo "<br><strong>Sidebar güncellemeleri tamamlandı!</strong><br>";
echo "<a href='dashboard.php'>Dashboard'a Git</a>";
?>
