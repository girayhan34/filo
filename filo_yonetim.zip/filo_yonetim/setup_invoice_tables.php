<?php
/**
 * Invoice Management System - Database Setup
 * This script creates all necessary database tables for the invoice management system.
 */

// Set error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start output buffering
ob_start();

// Include configuration and database connection
require_once 'includes/config.php';

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Bypass authentication for setup
$isSetupPage = true;

// Set content type to HTML
header('Content-Type: text/html; charset=utf-8');

// Function to log messages
function logMessage($message, $type = 'info') {
    $timestamp = date('Y-m-d H:i:s');
    $color = '';
    
    switch ($type) {
        case 'success':
            $color = 'success';
            $icon = '✓';
            break;
        case 'error':
            $color = 'danger';
            $icon = '✗';
            break;
        case 'warning':
            $color = 'warning';
            $icon = '⚠';
            break;
        default:
            $color = 'text-dark';
            $icon = 'ℹ';
    }
    
    echo "<div class='mb-2'><span class='text-muted'>$timestamp</span> <span class='text-$color'>$icon $message</span></div>\n";
    ob_flush();
    flush();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fatura Yönetim Sistemi - Veritabanı Kurulumu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            padding: 20px;
            background-color: #f8f9fa;
        }
        .card {
            margin-bottom: 20px;
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
        }
        .card-header {
            font-weight: 600;
        }
        .success {
            color: #198754;
        }
        .error {
            color: #dc3545;
        }
        .log {
            max-height: 400px;
            overflow-y: auto;
            background-color: #f8f9fa;
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #dee2e6;
            font-family: monospace;
            font-size: 14px;
            white-space: pre-wrap;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <i class="fas fa-database me-2"></i> Fatura Yönetim Sistemi - Veritabanı Kurulumu
                    </div>
                    <div class="card-body">
                        <?php

                        try {
                            // Test database connection
                            logMessage("Veritabanı bağlantısı test ediliyor...");
                            $pdo = getPDO();
                            
                            logMessage("Veritabanı bağlantısı başarılı.", 'success');
                            
                            // Read SQL file
                            $sqlFile = __DIR__ . '/database/invoice_management_schema.sql';
                            
                            if (!file_exists($sqlFile)) {
                                throw new Exception("SQL dosyası bulunamadı: $sqlFile");
                            }
                            
                            $sql = file_get_contents($sqlFile);
                            
                            if (empty($sql)) {
                                throw new Exception("SQL dosyası boş veya okunamadı.");
                            }
                            
                            logMessage("SQL dosyası okundu. Şema oluşturuluyor...");
                            
                            // Split SQL into individual queries
                            $queries = preg_split('/;\s*\n/', $sql);
                            $successCount = 0;
                            $errorCount = 0;
                            
                            // Execute each query
                            foreach ($queries as $query) {
                                $query = trim($query);
                                
                                if (empty($query)) {
                                    continue;
                                }
                                
                                try {
                                    $pdo->exec($query);
                                    $successCount++;
                                    logMessage("Sorgu başarıyla çalıştırıldı: " . substr($query, 0, 100) . (strlen($query) > 100 ? '...' : ''), 'success');
                                } catch (PDOException $e) {
                                    // Skip duplicate key errors (tables already exist)
                                    if ($e->getCode() == '42S01') {
                                        logMessage("Tablo zaten mevcut: " . substr($query, 0, 100) . (strlen($query) > 100 ? '...' : ''), 'warning');
                                        continue;
                                    }
                                    
                                    $errorCount++;
                                    logMessage("Sorgu hatası: " . $e->getMessage(), 'error');
                                }
                            }
                            
                            logMessage("Şema oluşturma tamamlandı. Başarılı: $successCount, Hatalı: $errorCount", 'success');
                            
                            // Check if all required tables exist
                            $requiredTables = ['customers', 'vehicles', 'personnel', 'invoices', 'invoice_items', 'payments', 'receipts'];
                            $missingTables = [];
                            
                            foreach ($requiredTables as $table) {
                                try {
                                    $pdo->query("SELECT 1 FROM `$table` LIMIT 1");
                                } catch (PDOException $e) {
                                    $missingTables[] = $table;
                                }
                            }
                            
                            if (empty($missingTables)) {
                                echo "<div class='alert alert-success mt-4'>";
                                echo "<h4><i class='fas fa-check-circle me-2'></i> Kurulum Başarılı!</h4>";
                                echo "<p class='mb-0'>Fatura yönetim sistemi için gerekli tüm tablolar başarıyla oluşturuldu.</p>";
                                echo "</div>";
                                
                                // Create default admin user if not exists
                                try {
                                    $stmt = $pdo->query("SELECT id FROM users WHERE username = 'admin' LIMIT 1");
                                    if (!$stmt->fetch()) {
                                        $hashedPassword = password_hash('admin123', PASSWORD_DEFAULT);
                                        $pdo->exec("INSERT INTO users (username, password, email, full_name, role, status) 
                                                   VALUES ('admin', '$hashedPassword', 'admin@example.com', 'Sistem Yöneticisi', 'admin', 'active')");
                                        logMessage("Varsayılan yönetici hesabı oluşturuldu (kullanıcı adı: admin, şifre: admin123)", 'success');
                                    }
                                } catch (Exception $e) {
                                    logMessage("Varsayılan yönetici hesabı oluşturulurken hata: " . $e->getMessage(), 'warning');
                                }
                                
                                echo "<div class='mt-4'>";
                                echo "<a href='invoices.php' class='btn btn-primary me-2'><i class='fas fa-tachometer-alt me-1'></i> Panele Git</a>";
                                echo "<a href='index.php' class='btn btn-outline-secondary'><i class='fas fa-home me-1'></i> Ana Sayfa</a>";
                                echo "</div>";
                            } else {
                                echo "<div class='alert alert-warning mt-4'>";
                                echo "<h4><i class='fas fa-exclamation-triangle me-2'></i> Eksik Tablolar</h4>";
                                echo "<p>Aşağıdaki tablolar oluşturulamadı:</p>";
                                echo "<ul>";
                                foreach ($missingTables as $table) {
                                    echo "<li>$table</li>";
                                }
                                echo "</ul>";
                                echo "<p class='mb-0'>Lütfen veritabanı kullanıcısının yeterli izinlere sahip olduğundan emin olun ve tekrar deneyin.</p>";
                                echo "</div>";
                                
                                echo "<div class='mt-4'>";
                                echo "<a href='setup_invoice_tables.php' class='btn btn-warning me-2'><i class='fas fa-redo me-1'></i> Tekrar Dene</a>";
                                echo "</div>";
                            }
                            
                        } catch (PDOException $e) {
                            echo "<div class='alert alert-danger'>";
                            echo "<h4><i class='fas fa-times-circle me-2'></i> Veritabanı Hatası</h4>";
                            echo "<p class='mb-1'><strong>Hata Kodu:</strong> " . $e->getCode() . "</p>";
                            echo "<p class='mb-1'><strong>Hata Mesajı:</strong> " . $e->getMessage() . "</p>";
                            echo "<p class='mb-0 mt-3'><strong>Bağlantı Ayrıntıları:</strong></p>";
                            echo "<ul class='mb-0'>";
                            echo "<li>Sunucu: " . DB_HOST . "</li>";
                            echo "<li>Veritabanı: " . DB_NAME . "</li>";
                            echo "<li>Kullanıcı: " . DB_USER . "</li>";
                            echo "</ul>";
                            echo "</div>";
                            
                            echo "<div class='mt-4'>";
                            echo "<a href='setup_invoice_tables.php' class='btn btn-warning me-2'><i class='fas fa-redo me-1'></i> Tekrar Dene</a>";
                            echo "</div>";
                            
                            logMessage("Veritabanı bağlantı hatası: " . $e->getMessage(), 'error');
                        } catch (Exception $e) {
                            echo "<div class='alert alert-danger'>";
                            echo "<h4><i class='fas fa-times-circle me-2'></i> Hata</h4>";
                            echo "<p class='mb-0'>" . $e->getMessage() . "</p>";
                            echo "</div>";
                            
                            echo "<div class='mt-4'>";
                            echo "<a href='setup_invoice_tables.php' class='btn btn-warning me-2'><i class='fas fa-redo me-1'></i> Tekrar Dene</a>";
                            echo "</div>";
                            
                            logMessage("Hata: " . $e->getMessage(), 'error');
                        }
                        ?>
                        
                        <div class='mt-4'>
                            <h5>İşlem Günlüğü:</h5>
                            <div class='log'>
                                <?php 
                                $log = ob_get_clean();
                                echo $log;
                                ?>
                            </div>
                        </div>
                    </div>
                    <div class='card-footer text-muted'>
                        <small>Fatura Yönetim Sistemi &copy; <?php echo date('Y'); ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Scroll to bottom of log
        document.addEventListener('DOMContentLoaded', function() {
            const logContainer = document.querySelector('.log');
            if (logContainer) {
                logContainer.scrollTop = logContainer.scrollHeight;
            }
        });
    </script>
</body>
</html>
