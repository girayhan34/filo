<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Personel ID'sini al
$personel_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Personel bilgilerini çek
$stmt = $pdo->prepare("SELECT * FROM personnel WHERE id = ?");
$stmt->execute([$personel_id]);
$personel = $stmt->fetch();

if (!$personel) {
    header('Location: personel2.php');
    exit;
}

// Sayfa başlıklarını ayarla
$page_title = $personel['name'] . ' ' . $personel['surname'];
$page_subtitle = 'Personel Detayları';

// Include header
include 'includes/header.php';
?>

<!-- Ana İçerik -->
<main class="main-content">
    <!-- Sayfa Başlığı -->
    <div class="page-header">
        <div class="container-fluid">
            <div class="row align-items-center">
                <div class="col">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0">
                            <li class="breadcrumb-item"><a href="dashboard.php">Ana Sayfa</a></li>
                            <li class="breadcrumb-item"><a href="personel2.php">Personel Yönetimi</a></li>
                            <li class="breadcrumb-item active" aria-current="page"><?= $personel['name'] . ' ' . $personel['surname'] ?></li>
                        </ol>
                    </nav>
                    <h1 class="page-title"><?= $page_title ?></h1>
                    <p class="page-subtitle text-muted mb-0"><?= $page_subtitle ?></p>
                </div>
                <div class="col-auto">
                    <a href="personel2.php" class="btn btn-outline-secondary me-2">
                        <i class="fas fa-arrow-left me-2"></i>Geri Dön
                    </a>
                    <a href="#" class="btn btn-primary" onclick="editPersonnel(<?= $personel_id ?>)">
                        <i class="fas fa-edit me-2"></i>Düzenle
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="row">
            <!-- Sol Sütun -->
            <div class="col-lg-4">
                <!-- Profil Kartı -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body text-center">
                        <div class="position-relative d-inline-block mb-3">
                            <img src="https://ui-avatars.com/api/?name=<?= urlencode($personel['name'] . ' ' . $personel['surname']) ?>" 
                                 class="rounded-circle mb-3" width="150" height="150" alt="Profil Fotoğrafı">
                            <span class="position-absolute bottom-0 end-0 bg-<?= $personel['status'] === 'active' ? 'success' : ($personel['status'] === 'on_leave' ? 'warning' : 'secondary') ?> 
                                rounded-circle border border-3 border-white" style="width: 20px; height: 20px;"></span>
                        </div>
                        <h4 class="mb-1"><?= $personel['name'] . ' ' . $personel['surname'] ?></h4>
                        <p class="text-muted mb-3"><?= $personel['position'] ?></p>
                        
                        <div class="d-flex justify-content-center gap-2 mb-3">
                            <a href="tel:<?= $personel['phone'] ?>" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-phone-alt me-1"></i> Ara
                            </a>
                            <a href="mailto:<?= $personel['email'] ?>" class="btn btn-outline-primary btn-sm">
                                <i class="fas fa-envelope me-1"></i> E-posta
                            </a>
                        </div>
                        
                        <hr>
                        
                        <div class="text-start">
                            <h6 class="mb-3">İletişim Bilgileri</h6>
                            <ul class="list-unstyled">
                                <li class="mb-2">
                                    <i class="fas fa-phone-alt text-muted me-2"></i>
                                    <?= $personel['phone'] ?: 'Belirtilmemiş' ?>
                                </li>
                                <li class="mb-2">
                                    <i class="fas fa-envelope text-muted me-2"></i>
                                    <?= $personel['email'] ?: 'Belirtilmemiş' ?>
                                </li>
                                <li class="mb-2">
                                    <i class="fas fa-map-marker-alt text-muted me-2"></i>
                                    <?= $personel['address'] ?: 'Belirtilmemiş' ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Belge Yükleme -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white border-0 py-3">
                        <h6 class="card-title mb-0">Belgeler</h6>
                    </div>
                    <div class="card-body">
                        <!-- Belge Yükleme Formu -->
                        <form id="documentUploadForm" enctype="multipart/form-data">
                            <input type="hidden" name="personnel_id" value="<?= $personel_id ?>">
                            <div class="mb-3">
                                <label for="documentType" class="form-label">Belge Türü</label>
                                <select class="form-select" id="documentType" name="document_type" required>
                                    <option value="">Seçiniz</option>
                                    <option value="cv">Özgeçmiş (CV)</option>
                                    <option value="id_card">Kimlik Fotokopisi</option>
                                    <option value="diploma">Diploma</option>
                                    <option value="license">Ehliyet</option>
                                    <option value="certificate">Sertifika</option>
                                    <option value="other">Diğer</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <label for="documentFile" class="form-label">Dosya Seç</label>
                                <input class="form-control" type="file" id="documentFile" name="document_file" required>
                                <div class="form-text">Maksimum dosya boyutu: 5MB. İzin verilen formatlar: PDF, DOC, DOCX, JPG, PNG</div>
                            </div>
                            <div class="mb-3">
                                <label for="documentNotes" class="form-label">Notlar</label>
                                <textarea class="form-control" id="documentNotes" name="document_notes" rows="2"></textarea>
                            </div>
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-upload me-2"></i>Yükle
                            </button>
                        </form>
                        
                        <hr class="my-4">
                        
                        <!-- Yüklenen Belgeler Listesi -->
                        <h6 class="mb-3">Yüklenen Belgeler</h6>
                        <div id="documentsList">
                            <div class="text-center py-4">
                                <div class="spinner-border text-primary" role="status">
                                    <span class="visually-hidden">Yükleniyor...</span>
                                </div>
                                <p class="mt-2 text-muted">Belgeler yükleniyor...</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Sağ Sütun -->
            <div class="col-lg-8">
                <!-- Kişisel Bilgiler -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white border-0 py-3">
                        <h6 class="card-title mb-0">Kişisel Bilgiler</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">TC Kimlik No</p>
                                <p class="mb-0"><?= $personel['tc_kimlik'] ?: 'Belirtilmemiş' ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Doğum Tarihi</p>
                                <p class="mb-0"><?= $personel['birth_date'] ? date('d.m.Y', strtotime($personel['birth_date'])) : 'Belirtilmemiş' ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">İşe Başlama Tarihi</p>
                                <p class="mb-0"><?= $personel['hire_date'] ? date('d.m.Y', strtotime($personel['hire_date'])) : 'Belirtilmemiş' ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Departman</p>
                                <p class="mb-0"><?= $personel['department'] ?: 'Belirtilmemiş' ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Pozisyon</p>
                                <p class="mb-0"><?= $personel['position'] ?: 'Belirtilmemiş' ?></p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <p class="text-muted mb-1">Durum</p>
                                <span class="badge bg-<?= $personel['status'] === 'active' ? 'success' : ($personel['status'] === 'on_leave' ? 'warning' : 'secondary') ?>-subtle text-<?= $personel['status'] === 'active' ? 'success' : ($personel['status'] === 'on_leave' ? 'warning' : 'secondary') ?>">
                                    <?= $personel['status'] === 'active' ? 'Aktif' : ($personel['status'] === 'on_leave' ? 'İzinli' : 'Pasif') ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- İzin Bilgileri -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                        <h6 class="card-title mb-0">İzin Bilgileri</h6>
                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addLeaveModal">
                            <i class="fas fa-plus me-1"></i>İzin Ekle
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>Başlangıç</th>
                                        <th>Bitiş</th>
                                        <th>Tür</th>
                                        <th>Süre (Gün)</th>
                                        <th>Durum</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody id="leaveList">
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Yükleniyor...</span>
                                            </div>
                                            <p class="mt-2 text-muted">İzin bilgileri yükleniyor...</p>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                
                <!-- Performans Değerlendirmeleri -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 py-3 d-flex justify-content-between align-items-center">
                        <h6 class="card-title mb-0">Performans Değerlendirmeleri</h6>
                        <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#addPerformanceModal">
                            <i class="fas fa-plus me-1"></i>Değerlendirme Ekle
                        </button>
                    </div>
                    <div class="card-body">
                        <div id="performanceChart" style="height: 300px;"></div>
                        
                        <div class="mt-4">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Tarih</th>
                                            <th>Değerlendiren</th>
                                            <th>Puan</th>
                                            <th>Yorum</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody id="performanceList">
                                        <tr>
                                            <td colspan="5" class="text-center py-4">
                                                <div class="spinner-border text-primary" role="status">
                                                    <span class="visually-hidden">Yükleniyor...</span>
                                                </div>
                                                <p class="mt-2 text-muted">Performans kayıtları yükleniyor...</p>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<!-- İzin Ekleme Modal -->
<div class="modal fade" id="addLeaveModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">İzin Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="addLeaveForm">
                <input type="hidden" name="personnel_id" value="<?= $personel_id ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="leaveType" class="form-label">İzin Türü</label>
                        <select class="form-select" id="leaveType" name="leave_type" required>
                            <option value="">Seçiniz</option>
                            <option value="annual">Yıllık İzin</option>
                            <option value="sick">Hastalık İzni</option>
                            <option value="unpaid">Ücretsiz İzin</option>
                            <option value="maternity">Doğum İzni</option>
                            <option value="paternity">Babalık İzni</option>
                            <option value="other">Diğer</option>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="startDate" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" id="startDate" name="start_date" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="endDate" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="endDate" name="end_date" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="leaveNotes" class="form-label">Açıklama</label>
                        <textarea class="form-control" id="leaveNotes" name="notes" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Performans Değerlendirme Ekleme Modal -->
<div class="modal fade" id="addPerformanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Performans Değerlendirmesi Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="addPerformanceForm">
                <input type="hidden" name="personnel_id" value="<?= $personel_id ?>">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="evaluationDate" class="form-label">Değerlendirme Tarihi</label>
                        <input type="date" class="form-control" id="evaluationDate" name="evaluation_date" required>
                    </div>
                    <div class="mb-3">
                        <label for="performanceScore" class="form-label">Puan (1-10)</label>
                        <input type="number" class="form-control" id="performanceScore" name="score" min="1" max="10" required>
                    </div>
                    <div class="mb-3">
                        <label for="performanceComment" class="form-label">Değerlendirme Notu</label>
                        <textarea class="form-control" id="performanceComment" name="comment" rows="3" required></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Gerekli Scriptler -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>

<script>
$(document).ready(function() {
    // Sayfa yüklendiğinde verileri çek
    loadDocuments();
    loadLeaves();
    loadPerformance();
    
    // Belge yükleme formu
    $('#documentUploadForm').on('submit', function(e) {
        e.preventDefault();
        
        const formData = new FormData(this);
        
        $.ajax({
            url: 'api/upload_document.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Başarılı!',
                        text: 'Belge başarıyla yüklendi.',
                        icon: 'success',
                        confirmButtonText: 'Tamam'
                    });
                    
                    // Formu temizle ve belge listesini yenile
                    $('#documentUploadForm')[0].reset();
                    loadDocuments();
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: response.message || 'Belge yüklenirken bir hata oluştu.',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    title: 'Hata!',
                    text: 'Sunucu ile bağlantı kurulamadı.',
                    icon: 'error',
                    confirmButtonText: 'Tamam'
                });
            }
        });
    });
    
    // İzin ekleme formu
    $('#addLeaveForm').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: 'api/add_leave.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Başarılı!',
                        text: 'İzin başarıyla eklendi.',
                        icon: 'success',
                        confirmButtonText: 'Tamam'
                    }).then(() => {
                        $('#addLeaveModal').modal('hide');
                        loadLeaves();
                    });
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: response.message || 'İzin eklenirken bir hata oluştu.',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    title: 'Hata!',
                    text: 'Sunucu ile bağlantı kurulamadı.',
                    icon: 'error',
                    confirmButtonText: 'Tamam'
                });
            }
        });
    });
    
    // Performans değerlendirme formu
    $('#addPerformanceForm').on('submit', function(e) {
        e.preventDefault();
        
        $.ajax({
            url: 'api/add_performance.php',
            type: 'POST',
            data: $(this).serialize(),
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Başarılı!',
                        text: 'Performans değerlendirmesi başarıyla eklendi.',
                        icon: 'success',
                        confirmButtonText: 'Tamam'
                    }).then(() => {
                        $('#addPerformanceModal').modal('hide');
                        loadPerformance();
                    });
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: response.message || 'Performans değerlendirmesi eklenirken bir hata oluştu.',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    title: 'Hata!',
                    text: 'Sunucu ile bağlantı kurulamadı.',
                    icon: 'error',
                    confirmButtonText: 'Tamam'
                });
            }
        });
    });
});

// Belgeleri yükle
function loadDocuments() {
    $.ajax({
        url: `api/get_documents.php?personnel_id=<?= $personel_id ?>`,
        type: 'GET',
        success: function(response) {
            if (response.length > 0) {
                let html = '';
                response.forEach(doc => {
                    html += `
                    <div class="d-flex justify-content-between align-items-center border-bottom pb-2 mb-2">
                        <div>
                            <i class="fas fa-file-pdf text-danger me-2"></i>
                            <span>${doc.document_type} - ${doc.notes || 'Açıklama yok'}</span>
                        </div>
                        <div>
                            <a href="${doc.file_path}" target="_blank" class="btn btn-sm btn-outline-primary me-1" title="Görüntüle">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="${doc.file_path}" download class="btn btn-sm btn-outline-secondary me-1" title="İndir">
                                <i class="fas fa-download"></i>
                            </a>
                            <button class="btn btn-sm btn-outline-danger" onclick="deleteDocument(${doc.id}, this)" title="Sil">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </div>
                    `;
                });
                $('#documentsList').html(html);
            } else {
                $('#documentsList').html('<div class="text-center py-4"><p class="text-muted">Henüz belge yüklenmemiş.</p></div>');
            }
        },
        error: function() {
            $('#documentsList').html('<div class="alert alert-danger">Belgeler yüklenirken bir hata oluştu.</div>');
        }
    });
}

// İzinleri yükle
function loadLeaves() {
    $.ajax({
        url: `api/get_leaves.php?personnel_id=<?= $personel_id ?>`,
        type: 'GET',
        success: function(response) {
            if (response.length > 0) {
                let html = '';
                response.forEach(leave => {
                    const startDate = new Date(leave.start_date);
                    const endDate = new Date(leave.end_date);
                    const diffTime = Math.abs(endDate - startDate);
                    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
                    
                    html += `
                    <tr>
                        <td>${formatDate(leave.start_date)}</td>
                        <td>${formatDate(leave.end_date)}</td>
                        <td>${getLeaveTypeName(leave.leave_type)}</td>
                        <td>${diffDays} gün</td>
                        <td><span class="badge bg-${leave.status === 'approved' ? 'success' : 'warning'}-subtle text-${leave.status === 'approved' ? 'success' : 'warning'}">
                            ${leave.status === 'approved' ? 'Onaylandı' : 'Bekliyor'}
                        </span></td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-outline-primary" onclick="viewLeave(${leave.id})">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-outline-secondary" onclick="editLeave(${leave.id})">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-outline-danger" onclick="deleteLeave(${leave.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    `;
                });
                $('#leaveList').html(html);
            } else {
                $('#leaveList').html('<tr><td colspan="6" class="text-center py-4"><p class="text-muted mb-0">Henüz izin kaydı bulunmamaktadır.</p></td></tr>');
            }
        },
        error: function() {
            $('#leaveList').html('<tr><td colspan="6" class="text-center py-4"><div class="alert alert-danger">İzin bilgileri yüklenirken bir hata oluştu.</div></td></tr>');
        }
    });
}

// Performans verilerini yükle
function loadPerformance() {
    $.ajax({
        url: `api/get_performance.php?personnel_id=<?= $personel_id ?>`,
        type: 'GET',
        success: function(response) {
            // Performans grafiğini oluştur
            createPerformanceChart(response);
            
            // Performans listesini güncelle
            if (response.length > 0) {
                let html = '';
                response.forEach(perf => {
                    html += `
                    <tr>
                        <td>${formatDate(perf.evaluation_date)}</td>
                        <td>${perf.evaluator_name || 'Sistem'}</td>
                        <td>
                            <span class="badge bg-${getScoreBadgeClass(perf.score)}">
                                ${perf.score}/10
                            </span>
                        </td>
                        <td>${perf.comment || 'Yorum yok'}</td>
                        <td>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-outline-primary" onclick="viewPerformance(${perf.id})">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-outline-secondary" onclick="editPerformance(${perf.id})">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-outline-danger" onclick="deletePerformance(${perf.id})">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    `;
                });
                $('#performanceList').html(html);
            } else {
                $('#performanceList').html('<tr><td colspan="5" class="text-center py-4"><p class="text-muted mb-0">Henüz performans değerlendirmesi bulunmamaktadır.</p></td></tr>');
            }
        },
        error: function() {
            $('#performanceList').html('<tr><td colspan="5" class="text-center py-4"><div class="alert alert-danger">Performans verileri yüklenirken bir hata oluştu.</div></td></tr>');
        }
    });
}

// Performans grafiği oluştur
function createPerformanceChart(data) {
    // Verileri işle
    const categories = [];
    const scores = [];
    
    data.forEach(item => {
        categories.push(formatDate(item.evaluation_date, 'short'));
        scores.push(parseFloat(item.score));
    });
    
    // Graik ayarları
    const options = {
        series: [{
            name: 'Performans Puanı',
            data: scores
        }],
        chart: {
            height: 300,
            type: 'line',
            zoom: {
                enabled: false
            },
            toolbar: {
                show: false
            }
        },
        stroke: {
            curve: 'smooth',
            width: 3
        },
        colors: ['#4361ee'],
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    fontSize: '12px'
                }
            }
        },
        yaxis: {
            min: 0,
            max: 10,
            tickAmount: 5,
            labels: {
                formatter: function(val) {
                    return val.toFixed(1);
                }
            }
        },
        tooltip: {
            y: {
                formatter: function(val) {
                    return val + ' / 10';
                }
            }
        },
        markers: {
            size: 5,
            hover: {
                size: 7
            }
        }
    };
    
    // Graiği oluştur
    const chart = new ApexCharts(document.querySelector("#performanceChart"), options);
    chart.render();
}

// Yardımcı fonksiyonlar
function formatDate(dateString, format = 'long') {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    const day = date.getDate().toString().padStart(2, '0');
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const year = date.getFullYear();
    
    if (format === 'short') {
        return `${day}.${month}.${year.toString().slice(-2)}`;
    }
    
    const months = [
        'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran',
        'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'
    ];
    
    return `${day} ${months[date.getMonth()]} ${year}`;
}

function getLeaveTypeName(type) {
    const types = {
        'annual': 'Yıllık İzin',
        'sick': 'Hastalık İzni',
        'unpaid': 'Ücretsiz İzin',
        'maternity': 'Doğum İzni',
        'paternity': 'Babalık İzni',
        'other': 'Diğer'
    };
    
    return types[type] || type;
}

function getScoreBadgeClass(score) {
    if (score >= 8) return 'success';
    if (score >= 6) return 'primary';
    if (score >= 4) return 'warning';
    return 'danger';
}

// Belge silme
function deleteDocument(id, element) {
    Swal.fire({
        title: 'Emin misiniz?',
        text: 'Bu belgeyi silmek istediğinize emin misiniz?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, sil',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#dc3545'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'api/delete_document.php',
                type: 'POST',
                data: { id: id },
                success: function(response) {
                    if (response.success) {
                        $(element).closest('.d-flex').fadeOut(300, function() {
                            $(this).remove();
                            if ($('#documentsList .d-flex').length === 0) {
                                $('#documentsList').html('<div class="text-center py-4"><p class="text-muted">Henüz belge yüklenmemiş.</p></div>');
                            }
                        });
                    } else {
                        Swal.fire({
                            title: 'Hata!',
                            text: response.message || 'Belge silinirken bir hata oluştu.',
                            icon: 'error',
                            confirmButtonText: 'Tamam'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Hata!',
                        text: 'Sunucu ile bağlantı kurulamadı.',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                }
            });
        }
    });
}

// İzin işlemleri
function viewLeave(id) {
    // İzin detaylarını göster
    // Bu fonksiyon, API'den izin detaylarını çekip bir modalda gösterebilir
    console.log('View leave:', id);
}

function editLeave(id) {
    // İzin düzenleme formunu aç
    // Bu fonksiyon, API'den izin detaylarını çekip düzenleme formunu doldurabilir
    console.log('Edit leave:', id);
}

function deleteLeave(id) {
    Swal.fire({
        title: 'Emin misiniz?',
        text: 'Bu izin kaydını silmek istediğinize emin misiniz?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, sil',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#dc3545'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'api/delete_leave.php',
                type: 'POST',
                data: { id: id },
                success: function(response) {
                    if (response.success) {
                        loadLeaves();
                    } else {
                        Swal.fire({
                            title: 'Hata!',
                            text: response.message || 'İzin silinirken bir hata oluştu.',
                            icon: 'error',
                            confirmButtonText: 'Tamam'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Hata!',
                        text: 'Sunucu ile bağlantı kurulamadı.',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                }
            });
        }
    });
}

// Performans işlemleri
function viewPerformance(id) {
    // Performans değerlendirme detaylarını göster
    // Bu fonksiyon, API'den detayları çekip bir modalda gösterebilir
    console.log('View performance:', id);
}

function editPerformance(id) {
    // Performans değerlendirme düzenleme formunu aç
    // Bu fonksiyon, API'den detayları çekip düzenleme formunu doldurabilir
    console.log('Edit performance:', id);
}

function deletePerformance(id) {
    Swal.fire({
        title: 'Emin misiniz?',
        text: 'Bu performans değerlendirmesini silmek istediğinize emin misiniz?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Evet, sil',
        cancelButtonText: 'İptal',
        confirmButtonColor: '#dc3545'
    }).then((result) => {
        if (result.isConfirmed) {
            $.ajax({
                url: 'api/delete_performance.php',
                type: 'POST',
                data: { id: id },
                success: function(response) {
                    if (response.success) {
                        loadPerformance();
                    } else {
                        Swal.fire({
                            title: 'Hata!',
                            text: response.message || 'Performans değerlendirmesi silinirken bir hata oluştu.',
                            icon: 'error',
                            confirmButtonText: 'Tamam'
                        });
                    }
                },
                error: function() {
                    Swal.fire({
                        title: 'Hata!',
                        text: 'Sunucu ile bağlantı kurulamadı.',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                }
            });
        }
    });
}
</script>

<?php include 'includes/footer.php'; ?>
