<?php
// Admin kullanıcısı oluşturma scripti
require_once 'includes/config.php';

try {
    // Mevcut admin kullanıcısını sil
    $stmt = $pdo->prepare("DELETE FROM users WHERE username = 'admin'");
    $stmt->execute();
    
    // Yeni admin kullanıcısı oluştur (şifre: 123456)
    $password_hash = password_hash('123456', PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("INSERT INTO users (username, password, name, email, role, status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute(['admin', $password_hash, 'Sistem Yöneticisi', 'admin@gaval.com', 'admin', 'active']);
    
    echo "✅ Admin kullanıcısı başarıyla oluşturuldu!<br>";
    echo "Kullanıcı adı: <strong>admin</strong><br>";
    echo "Şifre: <strong>123456</strong><br><br>";
    echo "<a href='login.php' class='btn btn-primary'>Giriş Sayfasına Git</a>";
    
} catch (Exception $e) {
    echo "❌ Hata: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Oluştur</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-5">
</body>
</html>
