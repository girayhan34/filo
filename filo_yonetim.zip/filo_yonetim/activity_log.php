<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

if ($_SESSION['user_role'] !== 'admin') {
    die('Bu sayfaya erişim yetkiniz yok.');
}

$page_title = 'Aktivite Geçmişi';
$page_subtitle = 'Sistemde gerçekleşen önemli olayları takip edin.';
include 'includes/header.php';

// Logları çek
$logs_stmt = $pdo->query("
    SELECT sl.*, u.name as user_name 
    FROM system_logs sl 
    LEFT JOIN users u ON sl.user_id = u.id 
    ORDER BY sl.created_at DESC 
    LIMIT 100
");
$logs = $logs_stmt->fetchAll(PDO::FETCH_ASSOC);

function getActionBadge($action) {
    $map = [
        'create' => ['class' => 'success', 'icon' => 'plus-circle', 'text' => 'Oluşturma'],
        'update' => ['class' => 'warning', 'icon' => 'edit', 'text' => 'Güncelleme'],
        'delete' => ['class' => 'danger', 'icon' => 'trash', 'text' => 'Silme'],
        'login_success' => ['class' => 'info', 'icon' => 'sign-in-alt', 'text' => 'Giriş Başarılı'],
        'login_fail' => ['class' => 'danger', 'icon' => 'exclamation-triangle', 'text' => 'Giriş Başarısız']
    ];
    $info = $map[$action] ?? ['class' => 'secondary', 'icon' => 'info-circle', 'text' => $action];
    return "<span class='badge bg-{$info['class']}'><i class='fas fa-{$info['icon']} me-1'></i> {$info['text']}</span>";
}
?>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-history me-2"></i>Sistem Logları</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="logsTable">
                <thead class="table-light">
                    <tr>
                        <th>Tarih</th>
                        <th>Kullanıcı</th>
                        <th>Eylem</th>
                        <th>Modül</th>
                        <th>Kayıt ID</th>
                        <th>Detaylar</th>
                        <th>IP Adresi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($logs)): ?>
                        <tr><td colspan="7" class="text-center text-muted py-4">Henüz log kaydı bulunmuyor.</td></tr>
                    <?php else: ?>
                        <?php foreach ($logs as $log): ?>
                            <tr>
                                <td><?= date('d.m.Y H:i:s', strtotime($log['created_at'])) ?></td>
                                <td><?= htmlspecialchars($log['user_name'] ?? 'Sistem') ?></td>
                                <td><?= getActionBadge($log['action']) ?></td>
                                <td><?= htmlspecialchars(ucfirst($log['module'])) ?></td>
                                <td><?= htmlspecialchars($log['record_id'] ?? '-') ?></td>
                                <td><small><?= htmlspecialchars($log['details'] ?? '-') ?></small></td>
                                <td><?= htmlspecialchars($log['ip_address']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
$(document).ready(function() {
    $('#logsTable').DataTable({
        order: [[0, 'desc']],
        language: getDataTablesLanguage()
    });
});
</script>