<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Proje Yönetimi';
$page_subtitle = 'Müşteri projelerinizi takip edin ve yönetin.';
include 'includes/header.php';

// Müşterileri çek
$customers = $pdo->query("SELECT id, name FROM customers WHERE status = 'active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <!-- Başlıklar header.php'den geliyor -->
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#projectModal" onclick="prepareAddProject()">
        <i class="fas fa-plus me-2"></i>Yeni Proje Ekle
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-project-diagram me-2"></i>Proje Listesi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="projectsTable">
                <thead class="table-light">
                    <tr>
                        <th>Proje Adı</th>
                        <th>Müşteri</th>
                        <th>Başlangıç Tarihi</th>
                        <th>Bitiş Tarihi</th>
                        <th>Bütçe</th>
                        <th>Durum</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Proje Ekleme/Düzenleme Modal -->
<div class="modal fade" id="projectModal" tabindex="-1" aria-labelledby="projectModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="projectModalLabel">Proje</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="projectForm">
                <div class="modal-body">
                    <input type="hidden" id="projectId" name="id">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label for="projectName" class="form-label">Proje Adı <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="projectName" name="project_name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="customerId" class="form-label">Müşteri</label>
                            <select class="form-select" id="customerId" name="customer_id">
                                <option value="">Seçiniz...</option>
                                <?php foreach ($customers as $customer): ?>
                                    <option value="<?= $customer['id'] ?>"><?= htmlspecialchars($customer['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="startDate" class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" id="startDate" name="start_date">
                        </div>
                        <div class="col-md-4">
                            <label for="endDate" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="endDate" name="end_date">
                        </div>
                        <div class="col-md-4">
                            <label for="budget" class="form-label">Bütçe (₺)</label>
                            <input type="number" class="form-control" id="budget" name="budget" step="0.01">
                        </div>
                        <div class="col-md-12">
                            <label for="status" class="form-label">Durum <span class="text-danger">*</span></label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="planning" selected>Planlama</option>
                                <option value="active">Aktif</option>
                                <option value="completed">Tamamlandı</option>
                                <option value="on_hold">Beklemede</option>
                                <option value="cancelled">İptal Edildi</option>
                            </select>
                        </div>
                        <div class="col-md-12">
                            <label for="description" class="form-label">Açıklama</label>
                            <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
let projectsTable;

$(document).ready(function() {
    projectsTable = $('#projectsTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/projects_api.php?action=list',
            type: 'POST'
        },
        columns: [
            { data: 'project_name' },
            { data: 'customer_name', render: function(data) { return data || '<span class="text-muted">Belirtilmemiş</span>'; } },
            { data: 'start_date', render: function(data) { return data ? moment(data).format('DD.MM.YYYY') : '-'; } },
            { data: 'end_date', render: function(data) { return data ? moment(data).format('DD.MM.YYYY') : '-'; } },
            { data: 'budget', render: function(data) { return data ? parseFloat(data).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' }) : '-'; } },
            { data: 'status', render: function(data) {
                const statuses = {
                    'planning': { text: 'Planlama', class: 'secondary' },
                    'active': { text: 'Aktif', class: 'primary' },
                    'completed': { text: 'Tamamlandı', class: 'success' },
                    'on_hold': { text: 'Beklemede', class: 'warning' },
                    'cancelled': { text: 'İptal Edildi', class: 'danger' }
                };
                const statusInfo = statuses[data] || { text: data, class: 'dark' };
                return `<span class="badge bg-${statusInfo.class}">${statusInfo.text}</span>`;
            }},
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="btn-group btn-group-sm">
                                <a href="project_details.php?id=${row.id}" class="btn btn-info" title="Detayları Görüntüle"><i class="fas fa-eye"></i></a>
                                <button class="btn btn-warning" onclick="editProject(${row.id})"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" onclick="deleteProject(${row.id})"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[2, 'desc']],
        language: getDataTablesLanguage()
    });

    $('#projectForm').on('submit', function(e) {
        e.preventDefault();
        const id = $('#projectId').val();
        const url = id ? `../api/projects_api.php?action=update` : `../api/projects_api.php?action=create`;
        
        sendAjaxRequest({
            url: url,
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#projectModal').modal('hide');
            projectsTable.ajax.reload(null, false);
        });
    });
});

function prepareAddProject() {
    $('#projectForm')[0].reset();
    $('#projectId').val('');
    $('#projectModalLabel').text('Yeni Proje Ekle');
}

function editProject(id) {
    $.ajax({
        url: `../api/projects_api.php?action=get_project&id=${id}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                const project = response.data;
                $('#projectId').val(project.id);
                $('#projectName').val(project.project_name);
                $('#customerId').val(project.customer_id);
                $('#startDate').val(project.start_date);
                $('#endDate').val(project.end_date);
                $('#budget').val(project.budget);
                $('#status').val(project.status);
                $('#description').val(project.description);
                $('#projectModalLabel').text('Projeyi Düzenle');
                $('#projectModal').modal('show');
            } else {
                toastr.error(response.message);
            }
        }
    });
}

function deleteProject(id) {
    handleDelete('../api/projects_api.php?action=delete', id, projectsTable);
}
</script>