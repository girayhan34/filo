<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/config.php';

function log_message($message, $type = 'info') {
    $color = 'black';
    if ($type === 'success') $color = 'green';
    if ($type === 'error') $color = 'red';
    echo "<p style='color: $color;'>$message</p>";
    flush();
    ob_flush();
}

try {
    $pdo = getPDO();
    log_message("Veritabanı bağlantısı başarılı.");

    // 1. Mevcut tüm tabloları sil
    log_message("Mevcut tablolar siliniyor...");
    $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
    if (!empty($tables)) {
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 0;");
        foreach ($tables as $table) {
            $pdo->exec("DROP TABLE IF EXISTS `$table`;");
            log_message("`$table` tablosu silindi.");
        }
        $pdo->exec("SET FOREIGN_KEY_CHECKS = 1;");
        log_message("Tüm tablolar başarıyla silindi.", "success");
    } else {
        log_message("Silinecek tablo bulunamadı.");
    }

    // 2. SQL dosyasından şemayı yükle
    log_message("Veritabanı şeması oluşturuluyor...");
    $sql_file = __DIR__ . '/database/schema.sql';
    if (!file_exists($sql_file)) {
        throw new Exception("SQL şema dosyası bulunamadı: $sql_file");
    }
    $sql = file_get_contents($sql_file);
    $pdo->exec($sql);
    log_message("Veritabanı şeması başarıyla oluşturuldu.", "success");

    // 3. Varsayılan yönetici kullanıcısını ekle
    log_message("Varsayılan yönetici kullanıcısı oluşturuluyor...");
    $admin_password = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password, name, email, status) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute(['admin', $admin_password, 'Sistem Yöneticisi', 'admin@gaval.com', 'active']);
    $admin_id = $pdo->lastInsertId();
    log_message("Yönetici kullanıcısı oluşturuldu (Kullanıcı Adı: admin, Şifre: admin123).", "success");

    // Varsayılan rolleri ve admin rol atamasını ekle
    $pdo->exec("INSERT INTO roles (id, role_name, description) VALUES (1, 'Admin', 'Sistem Yöneticisi - Tam Yetki'), (2, 'User', 'Standart Kullanıcı') ON DUPLICATE KEY UPDATE role_name=VALUES(role_name);");
    $pdo->exec("INSERT INTO user_roles (user_id, role_id) VALUES ($admin_id, 1) ON DUPLICATE KEY UPDATE role_id=VALUES(role_id);");
    log_message("Varsayılan roller oluşturuldu ve yöneticiye atandı.", "success");

    // 4. Örnek verileri ekle
    log_message("Örnek veriler ekleniyor...");

    // Müşteriler
    $pdo->exec("INSERT INTO `customers` (`name`, `company_name`, `contact_person`, `email`, `phone`, `address`) VALUES
        ('ABC Lojistik', 'ABC Lojistik A.Ş.', 'Ahmet Çelik', 'ahmet.celik@abclojistik.com', '02121234567', 'İstanbul'),
        ('XYZ İnşaat', 'XYZ İnşaat Ltd. Şti.', 'Ayşe Yılmaz', 'ayse.yilmaz@xyzinşaat.com', '03129876543', 'Ankara');");
    log_message("2 örnek müşteri eklendi.");

    // Araçlar
    $pdo->exec("INSERT INTO `vehicles` (`plate`, `brand`, `model`, `year`, `type`, `status`) VALUES
        ('34 ABC 123', 'Mercedes', 'Actros', 2022, 'Kamyon', 'active'),
        ('06 DEF 456', 'Volvo', 'EC220E', 2021, 'Kepçe', 'active'),
        ('35 GHI 789', 'Ford', 'Transit', 2023, 'Kamyonet', 'maintenance');");
    log_message("3 örnek araç eklendi.");

    // Personel
    $pdo->exec("INSERT INTO `personnel` (`name`, `position`, `department`, `email`, `phone`, `hire_date`, `status`) VALUES
        ('Mehmet Demir', 'Şoför', 'Operasyon', 'mehmet.demir@gaval.com', '05321112233', '2022-01-10', 'active'),
        ('Hasan Çelik', 'Operatör', 'Operasyon', 'hasan.celik@gaval.com', '05334445566', '2021-05-20', 'active'),
        ('Ali Kaya', 'Muhasebe', 'Finans', 'ali.kaya@gaval.com', '05347778899', '2023-02-15', 'on_leave');");
    log_message("3 örnek personel eklendi.");

    // Projeler
    $pdo->exec("INSERT INTO `projects` (`project_name`, `customer_id`, `start_date`, `end_date`, `status`, `budget`) VALUES
        ('Ankara Metro İnşaatı', 2, '2024-01-01', '2025-12-31', 'active', 5000000.00),
        ('İstanbul Lojistik Merkezi', 1, '2024-03-15', '2024-09-30', 'planning', 1200000.00);");
    log_message("2 örnek proje eklendi.");

    // Görevler
    $pdo->exec("INSERT INTO `tasks` (`title`, `description`, `project_id`, `status`, `priority`, `assigned_to`) VALUES
        ('Hafriyat Kamyonu Temini', 'Metro inşaatı için 5 adet kamyon sağlanacak.', 1, 'todo', 'high', 1),
        ('Depo Alanı Planlaması', 'Lojistik merkezi için depo alanı çizimi yapılacak.', 2, 'inprogress', 'medium', 2);");
    log_message("2 örnek görev eklendi.");

    // Gelir-Gider
    $pdo->exec("INSERT INTO `income_expense` (`type`, `date`, `description`, `category`, `amount`, `project_id`) VALUES
        ('income', '2024-05-10', 'Ankara Metro Projesi Avans Ödemesi', 'Proje Geliri', 500000.00, 1),
        ('expense', '2024-05-12', 'Kamyon Yakıt Gideri', 'Yakıt', 15000.00, 1);");
    log_message("2 örnek gelir/gider kaydı eklendi.");

    echo "<hr>";
    log_message("Kurulum başarıyla tamamlandı!", "success");
    echo "<a href='login.php' class='btn btn-primary mt-3'>Giriş Sayfasına Git</a>";

} catch (Exception $e) {
    log_message("HATA: " . $e->getMessage(), "error");
}
?>