<?php
// Modül debug scripti
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once 'includes/config.php';

echo "<h2>🔍 Modül Debug Raporu</h2>";

// Veritabanı bağlantısı test
try {
    echo "<h3>✅ Veritabanı Bağlantısı: OK</h3>";
    
    // Tabloları kontrol et
    $tables = ['users', 'customers', 'vehicles', 'personnel', 'invoices', 'income_expense', 
               'personnel_shifts', 'personnel_performance', 'vehicle_maintenance', 'vehicle_fuel'];
    
    echo "<h3>📋 Tablo Kontrolü:</h3>";
    foreach ($tables as $table) {
        try {
            $stmt = $pdo->query("SELECT COUNT(*) FROM $table");
            $count = $stmt->fetchColumn();
            echo "✅ $table: $count kayıt<br>";
        } catch (Exception $e) {
            echo "❌ $table: " . $e->getMessage() . "<br>";
        }
    }
    
    // Modül dosyalarını kontrol et
    echo "<h3>📁 Modül Dosyaları:</h3>";
    $modules = ['dashboard.php', 'invoices.php', 'income_expense.php', 'vehicles.php', 
                'customers.php', 'personel.php', 'reports.php'];
    
    foreach ($modules as $module) {
        if (file_exists($module)) {
            echo "✅ $module: Mevcut<br>";
        } else {
            echo "❌ $module: Bulunamadı<br>";
        }
    }
    
    // Include dosyalarını kontrol et
    echo "<h3>📂 Include Dosyaları:</h3>";
    $includes = ['includes/config.php', 'includes/auth.php', 'includes/functions.php'];
    
    foreach ($includes as $include) {
        if (file_exists($include)) {
            echo "✅ $include: Mevcut<br>";
        } else {
            echo "❌ $include: Bulunamadı<br>";
        }
    }
    
} catch (Exception $e) {
    echo "<h3>❌ Veritabanı Hatası:</h3>";
    echo $e->getMessage();
}

echo "<br><a href='dashboard.php' class='btn btn-primary'>Dashboard'a Git</a>";
?>
<!DOCTYPE html>
<html>
<head>
    <title>Debug Raporu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container mt-3">
</body>
</html>
