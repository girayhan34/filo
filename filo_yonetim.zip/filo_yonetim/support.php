<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Destek';
$page_subtitle = 'Yardım ve destek taleplerinizi yönetin.';
include 'includes/header.php';
?>

<div class="container-fluid">
    <div class="alert alert-info">
        <i class="fas fa-info-circle"></i>
        Bu modül henüz geliştirilme aşamasındadır. Yakında kullanıma sunulacaktır.
    </div>
    
    <div class="card">
        <div class="card-body text-center py-5">
            <i class="fas fa-tools fa-3x text-muted mb-3"></i>
            <h4>Destek Modülü</h4>
            <p class="text-muted">Bu sayfa şu anda geliştirme aşamasındadır.</p>
            <a href="dashboard.php" class="btn btn-primary">Dashboard'a Dön</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>