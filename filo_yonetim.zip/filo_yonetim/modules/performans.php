<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// PDO bağlantısını al
$pdo = getPDO();

// Yetki kontrolü
if (!hasPermission('performans', 'goruntule')) {
    header('HTTP/1.0 403 Forbidden');
    die('Bu sayfaya erişim yetkiniz yok!');
}

$page_title = 'Performans Değerlendirme';
$active_menu = 'personel';

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="h3 mb-0 text-gray-800"><i class="fas fa-chart-line me-2"></i>Performans Değerlendirme</h1>
            <p class="text-muted mb-0">Personel performansını izleyin ve değerlendirin.</p>
        </div>
        <?php if (hasPermission('performans', 'olustur')): ?>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#performansEkleModal">
            <i class="fas fa-plus me-2"></i>Yeni Değerlendirme
        </button>
        <?php endif; ?>
    </div>

    <!-- Özet Kartları -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Toplam Değerlendirme</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="toplamDegerlendirme">0</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-success shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Ortalama Puan</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="ortalamaPuan">0.0</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-star fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-info shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Bu Ayki Değerlendirme</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="buAyDegerlendirme">0</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-calendar fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-warning shadow h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Bekleyen Değerlendirme</div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800" id="bekleyenDegerlendirme">0</div>
                        </div>
                        <div class="col-auto">
                            <i class="fas fa-comments fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Performans Listesi -->
    <div class="card shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-list me-2"></i>Performans Değerlendirmeleri
            </h6>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="performansTablosu" width="100%" cellspacing="0">
                    <thead class="table-light">
                        <tr>
                            <th>Personel</th>
                            <th>Değerlendirme Türü</th>
                            <th>Dönem</th>
                            <th>Puan</th>
                            <th>Değerlendiren</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- AJAX ile doldurulacak -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Performans Ekleme Modal -->
<div class="modal fade" id="performansEkleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title text-primary"><i class="fas fa-plus-circle me-2"></i>Yeni Performans Değerlendirmesi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="performansEkleForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Personel <span class="text-danger">*</span></label>
                            <select class="form-select" name="personel_id" required>
                                <option value="">Seçiniz</option>
                                <?php
                                $personeller = $pdo->query("SELECT id, CONCAT(ad, ' ', soyad) as ad_soyad FROM personel WHERE durum = 'Aktif' ORDER BY ad_soyad")->fetchAll();
                                foreach ($personeller as $personel) {
                                    echo "<option value='{$personel['id']}'>{$personel['ad_soyad']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Değerlendirme Türü <span class="text-danger">*</span></label>
                            <select class="form-select" name="tur" required>
                                <option value="">Seçiniz</option>
                                <option value="Aylık">Aylık</option>
                                <option value="Dönemsel">Dönemsel</option>
                                <option value="Yıllık">Yıllık</option>
                                <option value="Hedef">Hedef Bazlı</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Dönem <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="donem" required placeholder="Örn: Ocak 2023">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Değerlendirme Tarihi <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="tarih" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Genel Değerlendirme</label>
                            <textarea class="form-control" name="genel_degerlendirme" rows="3" placeholder="Personelin genel performansı hakkında değerlendirmenizi yazınız..."></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-1"></i>İptal
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-1"></i>Kaydet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- DataTables -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
$(document).ready(function() {
    // DataTable başlatma
    var table = $('#performansTablosu').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/performans_listesi.php',
            type: 'POST'
        },
        columns: [
            { data: 'personel_ad' },
            { data: 'tur' },
            { data: 'donem' },
            { 
                data: 'ortalama_puan',
                render: function(data, type, row) {
                    return renderPuan(data);
                }
            },
            { data: 'degerlendiren_ad' },
            { 
                data: 'durum',
                render: function(data, type, row) {
                    var durumClass = data === 'Tamamlandı' ? 'success' : 
                                    data === 'Bekliyor' ? 'warning' : 'danger';
                    return '<span class="badge bg-' + durumClass + '">' + data + '</span>';
                }
            },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    var buttons = '<div class="btn-group btn-group-sm">';
                    buttons += '<button type="button" class="btn btn-info btn-sm btn-detay" data-id="' + row.id + '" title="Detay Görüntüle"><i class="fas fa-eye"></i></button>';
                    
                    <?php if (hasPermission('performans', 'duzenle')): ?>
                    if (row.durum === 'Bekliyor') {
                        buttons += '<button type="button" class="btn btn-primary btn-sm btn-duzenle" data-id="' + row.id + '" title="Düzenle"><i class="fas fa-edit"></i></button>';
                    }
                    <?php endif; ?>
                    
                    <?php if (hasPermission('performans', 'sil')): ?>
                    if (row.durum === 'Bekliyor') {
                        buttons += '<button type="button" class="btn btn-danger btn-sm btn-sil" data-id="' + row.id + '" title="Sil"><i class="fas fa-trash"></i></button>';
                    }
                    <?php endif; ?>
                    
                    buttons += '</div>';
                    return buttons;
                }
            }
        ],
        order: [[2, 'desc']],
        language: getDataTablesLanguage(),
        dom: '<"row"<"col-md-6"B><"col-md-6"f>>rt<"row"<"col-md-6"l><"col-md-6"p>>',
        buttons: getDataTablesButtons([0, 1, 2, 3, 4, 5]),
        responsive: true,
        pageLength: 25
    });

    // Performans ekleme formu gönderimi
    $('#performansEkleForm').on('submit', function(e) {
        e.preventDefault();
        
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/performans_degerlendirme.php', // API endpoint'i kontrol edilmeli
            type: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false
        }, submitButton).then(() => {
            $('#performansEkleModal').modal('hide');
            $(this)[0].reset();
            table.ajax.reload();
            // Gerekirse istatistikleri yenile
            // yuklePerformansIstatistikleri(); 
        });
    });

    // Silme butonu için event listener
    $(document).on('click', '.btn-sil', function() {
        var performansId = $(this).data('id');
        // Not: API'niz DELETE metodu bekliyorsa, helper'ı güncellemeniz gerekebilir.
        // Şimdilik POST varsayıyoruz.
        handleDelete(
            '../api/performans_degerlendirme.php', // API endpoint'i kontrol edilmeli
            performansId, 
            table,
            'Değerlendirmeyi Sil',
            'Bu performans değerlendirmesini silmek istediğinizden emin misiniz?'
        );
    });

    // Puanı yıldızlı olarak göster
    function renderPuan(puan) {
        var yildizSayisi = Math.round(puan / 20);
        var html = '';
        
        for (var i = 0; i < 5; i++) {
            if (i < yildizSayisi) {
                html += '<i class="fas fa-star text-warning"></i>';
            } else {
                html += '<i class="far fa-star text-muted"></i>';
            }
        }
        
        html += ' <small class="text-muted">(' + puan.toFixed(1) + ')</small>';
        return html;
    }
});
</script>
