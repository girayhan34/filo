<?php
require_once __DIR__ . '/../includes/config.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';

// PDO bağlantısını al
$pdo = getPDO();

// Yetki kontrolü
if (!hasPermission('izinler', 'goruntule')) {
    header('HTTP/1.0 403 Forbidden');
    die('Bu sayfaya erişim yetkiniz yok!');
}

$page_title = 'İzin Yönetimi';
$active_menu = 'personel';

try {
    // İzin tiplerini çek
    $izin_tipleri = $pdo->query("SELECT * FROM izin_tipleri WHERE durum = 'Aktif' ORDER BY sira")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Hata durumunda boş dizi ata
    $izin_tipleri = [];
    error_log("İzin tipleri çekilirken hata: " . $e->getMessage());
}

include __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center">
        <div>
            <h1 class="h3 mb-0 text-gray-800">İzin Yönetimi</h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb mb-0">
                    <li class="breadcrumb-item"><a href="/filo_yonetim/dashboard.php">Ana Sayfa</a></li>
                    <li class="breadcrumb-item active">İzin Yönetimi</li>
                </ol>
            </nav>
        </div>
        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#izinEkleModal"><i class="fas fa-plus me-2"></i>Yeni İzin Talebi</button>
    </div>
    <!-- Özet Kartlar -->
    <div class="row mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="card bg-primary text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">Toplam İzin</h6>
                            <h3 id="toplamIzin">0</h3>
                        </div>
                        <i class="fas fa-calendar-alt fa-3x opacity-50"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#" data-filter="tum">Detay Görüntüle</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-success text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">Onay Bekleyen</h6>
                            <h3 id="onayBekleyen">0</h3>
                        </div>
                        <i class="fas fa-clock fa-3x opacity-50"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#" data-filter="onay_bekliyor">Detay Görüntüle</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-info text-white mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">Onaylanan</h6>
                            <h3 id="onaylanan">0</h3>
                        </div>
                        <i class="fas fa-check-circle fa-3x opacity-50"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-white stretched-link" href="#" data-filter="onaylandi">Detay Görüntüle</a>
                    <div class="small text-white"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="card bg-warning text-dark mb-4">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">Reddedilen</h6>
                            <h3 id="reddedilen">0</h3>
                        </div>
                        <i class="fas fa-times-circle fa-3x opacity-50"></i>
                    </div>
                </div>
                <div class="card-footer d-flex align-items-center justify-content-between">
                    <a class="small text-dark stretched-link" href="#" data-filter="reddedildi">Detay Görüntüle</a>
                    <div class="small text-dark"><i class="fas fa-angle-right"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtreleme Kartı -->
    <div class="card mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <i class="fas fa-filter me-1"></i>
                    Filtreleme
                </div>
                <button type="button" class="btn btn-sm btn-outline-secondary" id="filtreleriTemizle">
                    <i class="fas fa-eraser me-1"></i>Filtreleri Temizle
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="row g-3">
                    <div class="col-md-3">
                        <label class="form-label">İzin Türü</label>
                        <select class="form-select" id="izinTuruFilter">
                            <option value="">Tümü</option>
                            <option value="Yıllık İzin">Yıllık İzin</option>
                            <option value="Hastalık İzni">Hastalık İzni</option>
                            <option value="Doğum İzni">Doğum İzni</option>
                            <option value="Babalık İzni">Babalık İzni</option>
                            <option value="Ücretsiz İzin">Ücretsiz İzin</option>
                            <option value="Diğer">Diğer</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Durum</label>
                        <select class="form-select" id="durumFilter">
                            <option value="">Tümü</option>
                            <option value="Bekliyor">Bekliyor</option>
                            <option value="Onaylandı">Onaylandı</option>
                            <option value="Reddedildi">Reddedildi</option>
                            <option value="İptal Edildi">İptal Edildi</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Tarih Aralığı</label>
                        <input type="text" class="form-control" id="tarihAraligi" placeholder="Tarih seçin...">
                    </div>
                    <div class="col-12 text-end">
                        <button type="button" class="btn btn-light me-2" id="filtreleriTemizle">
                            <i class="fas fa-undo me-1"></i>Temizle
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-search me-1"></i>Filtrele
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- İzin Listesi -->
    <div class="card shadow-sm">
        <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center">
            <h6 class="m-0 font-weight-bold text-primary">
                <i class="fas fa-list me-2"></i>İzin Talepleri
            </h6>
            <div class="btn-group" role="group">
                <button type="button" class="btn btn-sm btn-outline-secondary" id="btnExportExcel">
                    <i class="fas fa-file-excel me-1"></i>Excel
                </button>
                <button type="button" class="btn btn-sm btn-outline-secondary" id="btnExportPdf">
                    <i class="fas fa-file-pdf me-1"></i>PDF
                </button>
                <button type="button" class="btn btn-sm btn-outline-secondary" id="btnPrint">
                    <i class="fas fa-print me-1"></i>Yazdır
                </button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover" id="izinlerTablosu" width="100%" cellspacing="0">
                    <thead class="table-light">
                        <tr>
                            <th>İzin Türü</th>
                            <th>Başlangıç</th>
                            <th>Bitiş</th>
                            <th>Süre (Gün)</th>
                            <th>Talep Tarihi</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- AJAX ile doldurulacak -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- İzin Ekleme Modal -->
<div class="modal fade" id="izinEkleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title text-primary"><i class="fas fa-plus-circle me-2"></i>Yeni İzin Talebi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="izinEkleForm">
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">İzin Türü <span class="text-danger">*</span></label>
                            <select class="form-select" name="izin_turu" required>
                                <option value="">Seçiniz</option>
                                <option value="Yıllık İzin">Yıllık İzin</option>
                                <option value="Hastalık İzni">Hastalık İzni</option>
                                <option value="Doğum İzni">Doğum İzni</option>
                                <option value="Babalık İzni">Babalık İzni</option>
                                <option value="Ücretsiz İzin">Ücretsiz İzin</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Başlangıç Tarihi <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="baslangic_tarihi" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Bitiş Tarihi <span class="text-danger">*</span></label>
                            <input type="date" class="form-control" name="bitis_tarihi" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Açıklama</label>
                            <textarea class="form-control" name="aciklama" rows="3" placeholder="İzin nedeni hakkında kısa bir açıklama..."></textarea>
                        </div>
                        <?php if (hasPermission('izinler', 'onayla')): ?>
                        <div class="col-12">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="otomatik_onay" id="otomatikOnay">
                                <label class="form-check-label" for="otomatikOnay">
                                    Otomatik olarak onayla (Yönetici onayı olmadan)
                                </label>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i>İptal</button>
                    <button type="submit" class="btn btn-primary"><i class="fas fa-save me-1"></i>Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- İzin Detay Modal -->
<div class="modal fade" id="izinDetayModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header bg-light">
                <h5 class="modal-title text-primary"><i class="fas fa-info-circle me-2"></i>İzin Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <div class="modal-body" id="izinDetaylari">
                <!-- AJAX ile doldurulacak -->
                <div class="text-center my-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Yükleniyor...</span>
                    </div>
                    <p class="mt-2">İzin detayları yükleniyor...</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i>Kapat</button>
                <div class="btn-group" id="actionButtons">
                    <!-- Duruma göre butonlar buraya eklenecek -->
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Onay/Red Modal -->
<div class="modal fade" id="onayRedModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="onayRedModalLabel">İşlem Onayı</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="onayRedForm">
                <input type="hidden" name="izin_id" id="modalIzinId">
                <input type="hidden" name="islem_tipi" id="islemTipi">
                <div class="modal-body">
                    <p id="onayRedMesaj"></p>
                    <div class="mb-3" id="aciklamaContainer">
                        <label for="aciklama" class="form-label">Açıklama</label>
                        <textarea class="form-control" id="aciklama" name="aciklama" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><i class="fas fa-times me-1"></i>İptal</button>
                    <button type="submit" class="btn" id="onayRedSubmit"></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

<script>
$(document).ready(function() {
    // İzin özet istatistiklerini yükle
    function yukleIzinIstatistikleri() {
        $.ajax({
            url: '/filo_yonetim/api/izin_istatistikleri.php',
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    $('#toplamIzin').text(response.toplam_izin);
                    $('#onayBekleyen').text(response.onay_bekleyen);
                    $('#onaylanan').text(response.onaylanan);
                    $('#reddedilen').text(response.reddedilen);
                } else {
                    console.error('İzin istatistikleri yüklenirken hata oluştu:', response.message);
                }
            },
            error: function(xhr, status, error) {
                console.error('İzin istatistikleri yüklenirken hata oluştu:', error);
            }
        });
    }

    // Sayfa yüklendiğinde istatistikleri yükle
    yukleIzinIstatistikleri();

    // Tarih aralığı seçici
    $('input[name="tarihAraligi"]').daterangepicker({
        locale: {
            format: 'DD.MM.YYYY',
            applyLabel: 'Uygula',
            cancelLabel: 'Temizle',
            fromLabel: 'Başlangıç',
            toLabel: 'Bitiş',
            customRangeLabel: 'Özel Aralık',
            daysOfWeek: ['Pz', 'Pt', 'Sa', 'Ça', 'Pe', 'Cu', 'Ct'],
            monthNames: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık'],
            firstDay: 1
        },
        autoUpdateInput: false,
        opens: 'right',
        showDropdowns: true
    });

    $('input[name="tarihAraligi"]').on('apply.daterangepicker', function(ev, picker) {
        $(this).val(picker.startDate.format('DD.MM.YYYY') + ' - ' + picker.endDate.format('DD.MM.YYYY'));
    });

    $('input[name="tarihAraligi"]').on('cancel.daterangepicker', function(ev, picker) {
        $(this).val('');
    });

    // DataTable başlatma
    var table = $('#izinlerTablosu').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '/filo_yonetim/api/izin_listesi.php',
            type: 'POST',
            data: function(d) {
                d.tarih_baslangic = $('input[name="tarihAraligi"]').data('daterangepicker').startDate.format('YYYY-MM-DD');
                d.tarih_bitis = $('input[name="tarihAraligi"]').data('daterangepicker').endDate.format('YYYY-MM-DD');
                d.izin_tipi = $('#izinTipiFilter').val();
                d.durum = $('#durumFilter').val();
            }
        },
        columns: [
            { data: 'izin_turu' },
            { 
                data: 'baslangic_tarihi',
                render: function(data, type, row) {
                    return moment(data).format('DD.MM.YYYY');
                }
            },
            { 
                data: 'bitis_tarihi',
                render: function(data, type, row) {
                    return moment(data).format('DD.MM.YYYY');
                }
            },
            { data: 'gun_sayisi' },
            { 
                data: 'created_at',
                render: function(data, type, row) {
                    return moment(data).format('DD.MM.YYYY HH:mm');
                }
            },
            { 
                data: 'durum',
                render: function(data, type, row) {
                    var durumClass = '';
                    switch(data) {
                        case 'Onaylandı':
                            durumClass = 'success';
                            break;
                        case 'Reddedildi':
                            durumClass = 'danger';
                            break;
                        case 'Bekliyor':
                            durumClass = 'warning';
                            break;
                        case 'İptal Edildi':
                            durumClass = 'secondary';
                            break;
                        default:
                            durumClass = 'info';
                    }
                    return '<span class="badge bg-' + durumClass + '">' + data + '</span>';
                }
            },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    var buttons = '<div class="btn-group btn-group-sm">';
                    buttons += '<button type="button" class="btn btn-info btn-sm btn-detay" data-id="' + row.id + '" title="Detay Görüntüle"><i class="fas fa-eye"></i></button>';
                    
                    <?php if (hasPermission('izinler', 'duzenle')): ?>
                    buttons += '<button type="button" class="btn btn-primary btn-sm btn-duzenle" data-id="' + row.id + '" title="Düzenle"><i class="fas fa-edit"></i></button>';
                    <?php endif; ?>
                    
                    <?php if (hasPermission('izinler', 'sil')): ?>
                    buttons += '<button type="button" class="btn btn-danger btn-sm btn-sil" data-id="' + row.id + '" title="Sil"><i class="fas fa-trash"></i></button>';
                    <?php endif; ?>
                    
                    buttons += '</div>';
                    return buttons;
                }
            }
        ],
        order: [[5, 'desc']],
        language: getDataTablesLanguage(),
        dom: 'Bfrtip',
        buttons: getDataTablesButtons([0, 1, 2, 3, 4, 5, 6])
    });

    // Filtreleme formu gönderildiğinde
    $('#filtreForm').on('submit', function(e) {
        e.preventDefault();
        table.ajax.reload();
    });

    // Filtreleme butonu
    $('#filtreleBtn').on('click', function() {
        table.ajax.reload();
        yukleIzinIstatistikleri();
    });

    // Özet kartlardaki filtreleme linkleri
    $('.card-footer a[data-filter]').on('click', function(e) {
        e.preventDefault();
        var filter = $(this).data('filter');
        
        // Filtreleri sıfırla
        $('#filtreForm')[0].reset();
        
        // Seçili filtreye göre ayarla
        if (filter === 'onay_bekliyor') {
            $('#durumFilter').val('Onay Bekliyor');
        } else if (filter === 'onaylandi') {
            $('#durumFilter').val('Onaylandı');
        } else if (filter === 'reddedildi') {
            $('#durumFilter').val('Reddedildi');
        }
        
        // Tarih aralığını bu ay olarak ayarla
        $('input[name="tarihAraligi"]').data('daterangepicker').setStartDate(moment().startOf('month'));
        $('input[name="tarihAraligi"]').data('daterangepicker').setEndDate(moment().endOf('month'));
        
        // Tabloyu yenile
        table.ajax.reload();
        yukleIzinIstatistikleri();
    });
    
    // Filtreleri temizle butonu
    $('#filtreleriTemizle').on('click', function() {
        $('#filtreForm')[0].reset();
        $('input[name="tarihAraligi"]').data('daterangepicker').setStartDate(moment().startOf('month'));
        $('input[name="tarihAraligi"]').data('daterangepicker').setEndDate(moment().endOf('month'));
        table.ajax.reload();
        yukleIzinIstatistikleri();
        return false;
    });

    // İzin ekleme formu gönderildiğinde
    $('#izinEkleForm').on('submit', function(e) {
        e.preventDefault();
        
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/izin_ekle.php',
            type: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false
        }, submitButton).then(() => {
            $('#izinEkleModal').modal('hide');
            table.ajax.reload();
        });
    });

    // İzin detaylarını yükle
    // İzin detaylarını göster
    function showIzinDetay(izinId) {
        var modal = new bootstrap.Modal(document.getElementById('izinDetayModal'));
        
        // Detayları yükle
        $.ajax({
            url: '/filo_yonetim/api/izin_detay.php',
            type: 'GET',
            data: { id: izinId },
            beforeSend: function() {
                $('#izinDetaylari').html(`
                    <div class="text-center my-4">
                        <div class="spinner-border text-primary" role="status">
                            <span class="visually-hidden">Yükleniyor...</span>
                        </div>
                        <p class="mt-2">İzin bilgileri yükleniyor...</p>
                    </div>
                `);
            },
                $('#izinDetaylari').html('<div class="text-center my-5"><div class="spinner-border text-primary" role="status"><span class="visually-hidden">Yükleniyor...</span></div><p class="mt-2">İzin detayları yükleniyor...</p></div>');
                $('#actionButtons').html('');
            },
            success: function(response) {
                if (response.status === 'success') {
                    var izin = response.data;
                    var html = `
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <h6 class="text-muted">Personel</h6>
                                <p>${izin.personel_ad}</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <h6 class="text-muted">İzin Türü</h6>
                                <p>${izin.izin_turu}</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <h6 class="text-muted">Başlangıç Tarihi</h6>
                                <p>${moment(izin.baslangic_tarihi).format('DD.MM.YYYY')}</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <h6 class="text-muted">Bitiş Tarihi</h6>
                                <p>${moment(izin.bitis_tarihi).format('DD.MM.YYYY')}</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <h6 class="text-muted">Süre</h6>
                                <p>${izin.toplam_gun} gün</p>
                            </div>
                            <div class="col-md-6 mb-3">
                                <h6 class="text-muted">Durum</h6>
                                <p><span class="badge bg-${izin.durum === 'Onaylandı' ? 'success' : izin.durum === 'Reddedildi' ? 'danger' : izin.durum === 'Bekliyor' ? 'warning' : 'secondary'}">${izin.durum}</span></p>
                            </div>
                            <div class="col-12 mb-3">
                                <h6 class="text-muted">Açıklama</h6>
                                <p>${izin.aciklama || '-'}</p>
                            </div>`;
                    
                    if (izin.onaylayan_ad) {
                        // Bu kısım izin_detay.php'den gelen yanıta göre düzenlenmeli.
                        // Örneğin: izin.izin_veren_adi ve izin.islem_tarihi
                        // html += `
                        //     <div class="col-md-6 mb-3">
                        //         <h6 class="text-muted">İşlemi Yapan</h6>
                        //         <p>${izin.izin_veren_adi} (${moment(izin.islem_tarihi).format('DD.MM.YYYY HH:mm')})</p>
                        //     </div>
                        // `;
                    }
                    
                    if (izin.yonetici_aciklama) {
                        html += `
                            <div class="col-12 mb-3">
                                <h6 class="text-muted">Yönetici Açıklaması</h6>
                                <p>${izin.yonetici_aciklama || '-'}</p>
                            </div>`;
                    }
                    
                    html += '</div>';
                    
                    $('#izinDetaylari').html(html);
                    
                    // İşlem butonlarını oluştur
                    var buttons = '';
                    
                    <?php if (hasPermission('izinler', 'onayla')): ?>
                    if (izin.durum === 'Bekliyor') {
                        buttons += '<button type="button" class="btn btn-success btn-sm me-2" onclick="izinIslem(\'' + izin.id + '\', \'onayla\')"><i class="fas fa-check me-1"></i>Onayla</button>';
                        buttons += '<button type="button" class="btn btn-danger btn-sm me-2" onclick="izinIslem(\'' + izin.id + '\', \'reddet\')"><i class="fas fa-times me-1"></i>Reddet</button>';
                    }
                    <?php endif; ?>
                    
                    <?php if (hasPermission('izinler', 'duzenle')): ?>
                    if (izin.durum === 'Bekliyor') {
                        buttons += '<button type="button" class="btn btn-primary btn-sm me-2 btn-izin-duzenle" data-id="' + izin.id + '"><i class="fas fa-edit me-1"></i>Düzenle</button>';
                    }
                    <?php endif; ?>
                    
                    <?php if (hasPermission('izinler', 'sil')): ?>
                    if (izin.durum === 'Bekliyor' || izin.durum === 'Onaylandı') {
                        buttons += '<button type="button" class="btn btn-danger btn-sm" onclick="izinSil(\'' + izin.id + '\')"><i class="fas fa-trash me-1"></i>Sil</button>';
                    }
                    <?php endif; ?>
                    
                    $('#actionButtons').html(buttons);
                } else {
                    $('#izinDetaylari').html('<div class="alert alert-danger">İzin detayları yüklenirken bir hata oluştu.</div>');
                }
            },
            error: function(xhr, status, error) {
                $('#izinDetaylari').html(`
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        İzin detayları yüklenirken bir hata oluştu: ${xhr.responseJSON?.message || error}
                    </div>
                `);
            }
        });
        
        modal.show();
    }
    
    // Tablodaki detay butonuna tıklandığında
    $(document).on('click', '.btn-detay', function() {
        var izinId = $(this).data('id');
        showIzinDetay(izinId);
    });
    
    // İzin düzenleme butonu
    $(document).on('click', '.btn-duzenle, .btn-izin-duzenle', function() {
        var izinId = $(this).data('id');
        // Düzenleme işlemleri burada yapılacak
        alert('Düzenleme işlemi yapılacak - İzin ID: ' + izinId);
    });
    
    // İzin silme butonu
    $(document).on('click', '.btn-sil', function() {
        var izinId = $(this).data('id');
        handleDelete('../api/izin_sil.php', izinId, table);
    });
});

// İzin silme işlemi için global handleDelete fonksiyonunu kullan
function izinSil(izinId) {
    // handleDelete(url, id, table, title, text)
    handleDelete('../api/izin_sil.php', izinId, $('#izinlerTablosu').DataTable());
}

// Tarih değiştiğinde toplam günü hesapla
$('#baslangicTarihi, #bitisTarihi').on('apply.daterangepicker', function() {
    var baslangic = moment($('#baslangicTarihi').val(), 'DD.MM.YYYY');
    var bitis = moment($('#bitisTarihi').val(), 'DD.MM.YYYY');
    
    if (baslangic.isValid() && bitis.isValid()) {
        var toplamGun = bitis.diff(baslangic, 'days') + 1;
        $('#toplamGun').text(toplamGun + ' gün');
    }
});

// İzin onaylama/reddetme işlemi
function izinIslem(izinId, islemTipi) {
    $('#modalIzinId').val(izinId);
    $('#islemTipi').val(islemTipi);
    
    if (islemTipi === 'onayla') {
        $('#onayRedModalLabel').text('İzni Onayla');
        $('#onayRedMesaj').text('Bu izin talebini onaylamak istediğinize emin misiniz?');
        $('#onayRedSubmit').html('<i class="fas fa-check me-1"></i>Onayla').removeClass('btn-danger').addClass('btn-success');
        $('#aciklamaContainer').hide();
    } else {
        $('#onayRedModalLabel').text('İzni Reddet');
        $('#onayRedMesaj').text('Bu izin talebini reddetmek istediğinize emin misiniz? Lütfen bir açıklama giriniz.');
        $('#onayRedSubmit').html('<i class="fas fa-times me-1"></i>Reddet').removeClass('btn-success').addClass('btn-danger');
        $('#aciklamaContainer').show();
    }
    
    $('#aciklama').val('');
    var modal = new bootstrap.Modal(document.getElementById('onayRedModal'));
    modal.show();
}

// Onay/Red formu gönderildiğinde
$('#onayRedForm').on('submit', function(e) {
    e.preventDefault();
    
    const submitButton = $(this).find('#onayRedSubmit');
    const islemTipi = $('#islemTipi').val();
    const url = islemTipi === 'onayla' ? '../api/izin_onayla.php' : '../api/izin_reddet.php'; // Bu satır artık gereksiz, tek bir endpoint kullanılacak.

    sendAjaxRequest({
        url: url, // Her işlem için kendi endpoint'ini kullan
        type: 'POST',
        data: $(this).serialize()
    }, submitButton).then(response => {
        $('#onayRedModal').modal('hide');
        $('#izinDetayModal').modal('hide');
        table.ajax.reload();
        yukleIzinIstatistikleri();
    });
});
</script>
