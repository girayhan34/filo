<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// İstatistikler için değişkenleri tanımla
$active_personnel = 0;
$on_leave = 0;
$inactive = 0;
$total_personnel = 0;

// İstatistikleri veritabanından çek
$stats_query = $pdo->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN durum = 'Aktif' THEN 1 ELSE 0 END) as active,
    SUM(CASE WHEN durum = 'İzinli' THEN 1 ELSE 0 END) as on_leave,
    SUM(CASE WHEN durum IN ('İşten Ayrıldı', 'İşten Çıkarıldı') THEN 1 ELSE 0 END) as inactive
FROM personel");

if ($stats_query) {
    $stats = $stats_query->fetch(PDO::FETCH_ASSOC);
    $total_personnel = $stats['total'] ?? 0;
    $active_personnel = $stats['active'] ?? 0;
    $on_leave = $stats['on_leave'] ?? 0;
    $inactive = $stats['inactive'] ?? 0;
}

// Personel listesi için değişkeni tanımla
$personnel = [];
$personel_listesi = [];

// Filtreleme parametrelerini al
$filter_department = isset($_GET['departman']) ? intval($_GET['departman']) : 0;
$filter_status = isset($_GET['durum']) ? $_GET['durum'] : '';
$search = isset($_GET['ara']) ? trim($_GET['ara']) : '';

// Sorguyu oluştur
$sql = "SELECT p.*, d.departman_adi 
        FROM personel p 
        LEFT JOIN departmanlar d ON p.departman_id = d.id 
        WHERE 1=1";
$params = [];

// Filtreleri uygula
if ($filter_department > 0) {
    $sql .= " AND p.departman_id = ?";
    $params[] = $filter_department;
}

if (!empty($filter_status)) {
    $sql .= " AND p.durum = ?";
    $params[] = $filter_status;
}

if (!empty($search)) {
    $sql .= " AND (p.ad LIKE ? OR p.soyad LIKE ? OR p.personel_no LIKE ? OR p.tc_kimlik LIKE ?)";
    $search_term = "%$search%";
    $params = array_merge($params, [$search_term, $search_term, $search_term, $search_term]);
}

// Sıralama
$order_by = 'p.ad ASC';
if (isset($_GET['sirala'])) {
    $siralama = $_GET['sirala'];
    $yon = isset($_GET['yon']) ? $_GET['yon'] : 'ASC';
    $order_by = "$siralama $yon";
}
$sql .= " ORDER BY $order_by";

// Sayfalama
$per_page = 10;
$page = isset($_GET['sayfa']) ? (int)$_GET['sayfa'] : 1;
$offset = ($page - 1) * $per_page;

// Toplam kayıt sayısını al
$count_sql = "SELECT COUNT(*) as total FROM ($sql) as count_table";
$stmt = $pdo->prepare($count_sql);
$stmt->execute($params);
$total_records = $stmt->fetch()['total'];
$total_pages = ceil($total_records / $per_page);

// Sayfalama ile verileri çek
$sql .= " LIMIT $offset, $per_page";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$personel_listesi = $stmt->fetchAll(PDO::FETCH_ASSOC);
$personnel = $personel_listesi; // Eski kodla uyumluluk için

// Departman listesini al
$departmanlar = $pdo->query("SELECT id, departman_adi FROM departmanlar WHERE durum = 1 ORDER BY departman_adi ASC")->fetchAll();

// Sayfa değişkenlerini ayarla
$page_title = 'Personel Yönetimi';
$page_subtitle = 'Personel bilgilerini yönetin';

// Filtreleme parametrelerini al
$filter_department = isset($_GET['departman']) ? $_GET['departman'] : '';
$filter_status = isset($_GET['durum']) ? $_GET['durum'] : '';
$search = isset($_GET['ara']) ? trim($_GET['ara']) : '';

// Sorgu oluştur
$sql = "SELECT p.*, d.departman_adi as departman_adi 
        FROM personel p 
        LEFT JOIN departmanlar d ON p.departman_id = d.id 
        WHERE 1=1";
$params = [];

// Filtreleri uygula
if (!empty($filter_department)) {
    $sql .= " AND p.departman_id = ?";
    $params[] = $filter_department;
}

if (!empty($filter_status)) {
    $sql .= " AND p.durum = ?";
    $params[] = $filter_status;
}

if (!empty($search)) {
    $sql .= " AND (p.ad LIKE ? OR p.soyad LIKE ? OR p.personel_no LIKE ? OR p.tc_kimlik LIKE ?)";
    $searchTerm = "%$search%";
    $params = array_merge($params, [$searchTerm, $searchTerm, $searchTerm, $searchTerm]);
}

// Sıralama
$order_by = 'p.ad ASC';
if (isset($_GET['sirala'])) {
    $siralama = $_GET['sirala'];
    $yon = isset($_GET['yon']) ? $_GET['yon'] : 'ASC';
    $order_by = "$siralama $yon";
}
$sql .= " ORDER BY $order_by";

// Sayfalama
$per_page = 10;
$page = isset($_GET['sayfa']) ? (int)$_GET['sayfa'] : 1;
$offset = ($page - 1) * $per_page;

// Toplam kayıt sayısını al
$stmt = $pdo->prepare(str_replace('p.*, d.departman_adi as departman_adi', 'COUNT(*) as total', $sql));
$stmt->execute($params);
$total_records = $stmt->fetch()['total'];
$total_pages = ceil($total_records / $per_page);

// Sayfalama ile verileri çek
$sql .= " LIMIT $offset, $per_page";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$personel_listesi = $stmt->fetchAll();

// İstatistikler için sorgular
$stats = [
    'toplam' => 0,
    'aktif' => 0,
    'izinli' => 0,
    'ayrilan' => 0
];

// Toplam personel
$stmt = $pdo->query("SELECT COUNT(*) as toplam FROM personel");
$stats['toplam'] = $stmt->fetch()['toplam'];

// Aktif personel
$stmt = $pdo->query("SELECT COUNT(*) as aktif FROM personel WHERE durum = 'Aktif'");
$stats['aktif'] = $stmt->fetch()['aktif'];

// İzinli personel
$stmt = $pdo->query("SELECT COUNT(*) as izinli FROM personel WHERE durum = 'İzinli'");
$stats['izinli'] = $stmt->fetch()['izinli'];

// Ayrılan personel
$stmt = $pdo->query("SELECT COUNT(*) as ayrilan FROM personel WHERE durum IN ('İşten Ayrıldı', 'İşten Çıkarıldı')");
// Departman listesini al
$departmanlar = $pdo->query("SELECT id, departman_adi FROM departmanlar WHERE durum = 1 ORDER BY departman_adi ASC")->fetchAll();

// Include header
include 'includes/header.php';
?>

<!-- Ana İçerik -->
<main class="main-content">
    <!-- Sayfa Başlığı ve İstatistikler -->
    <div class="page-header bg-white py-4">
        <div class="container-fluid">
            <div class="row align-items-center mb-4">
                <div class="col">
                    <h1 class="page-title mb-1"><?= $page_title ?></h1>
                    <p class="page-subtitle text-muted mb-0"><?= $page_subtitle ?></p>
                </div>
                <div class="col-auto">
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPersonnelModal">
                        <i class="fas fa-user-plus me-2"></i>Yeni Personel Ekle
                    </button>
                </div>
            </div>
            
            <!-- Filtreleme ve Arama -->
            <div class="card border-0 shadow-sm mb-4">
                <div class="card-header bg-white border-0 py-3">
                    <h5 class="mb-0">Filtreleme ve Arama</h5>
                </div>
                <div class="card-body">
                    <form action="" method="get" class="row g-3">
                        <div class="col-md-4">
                            <label for="ara" class="form-label">Ara</label>
                            <div class="input-group">
                                <input type="text" class="form-control" id="ara" name="ara" value="<?= htmlspecialchars($search) ?>" placeholder="İsim, soyisim veya sicil no ile ara...">
                                <?php if (!empty($search)): ?>
                                    <a href="?" class="btn btn-outline-secondary" type="button">
                                        <i class="fas fa-times"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <label for="departman" class="form-label">Departman</label>
                            <select class="form-select" id="departman" name="departman">
                                <option value="">Tüm Departmanlar</option>
                                <?php foreach ($departmanlar as $departman): ?>
                                    <option value="<?= $departman['id'] ?>" <?= $filter_department == $departman['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($departman['departman_adi']) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="durum" class="form-label">Durum</label>
                            <select class="form-select" id="durum" name="durum">
                                <option value="">Tüm Durumlar</option>
                                <option value="Aktif" <?= $filter_status == 'Aktif' ? 'selected' : '' ?>>Aktif</option>
                                <option value="İzinli" <?= $filter_status == 'İzinli' ? 'selected' : '' ?>>İzinli</option>
                                <option value="İşten Ayrıldı" <?= $filter_status == 'İşten Ayrıldı' ? 'selected' : '' ?>>İşten Ayrıldı</option>
                                <option value="İşten Çıkarıldı" <?= $filter_status == 'İşten Çıkarıldı' ? 'selected' : '' ?>>İşten Çıkarıldı</option>
                            </select>
                        </div>
                        <div class="col-md-2 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">
                                <i class="fas fa-filter me-2"></i>Filtrele
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Personel Listesi -->
<div class="container-fluid">
    <div class="card border-0 shadow-sm">
        <div class="card-header bg-white border-0 py-3">
            <div class="row align-items-center">
                <div class="col">
                    <h5 class="card-title mb-0">Personel Listesi</h5>
                </div>
                <div class="col-auto">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPersonnelModal">
                        <i class="fas fa-plus me-2"></i>Yeni Personel Ekle
                    </button>
                </div>
            </div>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th width="40">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="selectAll">
                                </div>
                            </th>
                            <th>Personel</th>
                            <th>Departman</th>
                            <th>Pozisyon</th>
                            <th>İşe Giriş</th>
                            <th>Durum</th>
                            <th width="100">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($personel_listesi) > 0): ?>
                            <?php foreach ($personel_listesi as $personel): 
                                $durum_class = '';
                                switch($personel['durum']) {
                                    case 'Aktif': $durum_class = 'success'; break;
                                    case 'İzinli': $durum_class = 'info'; break;
                                    case 'İşten Ayrıldı': $durum_class = 'danger'; break;
                                    case 'İşten Çıkarıldı': $durum_class = 'dark'; break;
                                    default: $durum_class = 'secondary';
                                }
                            ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input class="form-check-input select-personnel" type="checkbox" value="<?= $personel['id'] ?>">
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar avatar-sm me-3">
                                            <?php if (!empty($personel['fotograf'])): ?>
                                                <img src="<?= $personel['fotograf'] ?>" alt="<?= $personel['ad'] ?> <?= $personel['soyad'] ?>" class="rounded-circle">
                                            <?php else: ?>
                                                <div class="avatar-text bg-soft-primary text-primary">
                                                    <?= mb_substr($personel['ad'], 0, 1) . mb_substr($personel['soyad'], 0, 1) ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div>
                                            <h6 class="mb-0"><?= $personel['ad'] ?> <?= $personel['soyad'] ?></h6>
                                            <small class="text-muted"><?= $personel['personel_no'] ?></small>
                                        </div>
                                    </div>
                                </td>
                                <td><?= $personel['departman_adi'] ?? 'Belirtilmemiş' ?></td>
                                <td><?= $personel['pozisyon'] ?? 'Belirtilmemiş' ?></td>
                                <td><?= !empty($personel['ise_giris_tarihi']) ? date('d.m.Y', strtotime($personel['ise_giris_tarihi'])) : '-' ?></td>
                                <td>
                                    <span class="badge bg-<?= $durum_class ?> bg-opacity-10 text-<?= $durum_class ?>">
                                        <?= $personel['durum'] ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-light dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                            İşlemler
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a class="dropdown-item" href="personel-detay.php?id=<?= $personel['id'] ?>">
                                                    <i class="fas fa-eye me-2"></i>Görüntüle
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="#" onclick="editPersonnel(<?= $personel['id'] ?>); return false;">
                                                    <i class="fas fa-edit me-2"></i>Düzenle
                                                </a>
                                            </li>
                                            <li><hr class="dropdown-divider"></li>
                                            <li>
                                                <a class="dropdown-item text-danger" href="#" onclick="confirmDelete(<?= $personel['id'] ?>, '<?= addslashes($personel['ad'] . ' ' . $personel['soyad']) ?>'); return false;">
                                                    <i class="fas fa-trash-alt me-2"></i>Sil
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-user-slash fa-2x mb-3"></i>
                                        <p class="mb-0">Kayıtlı personel bulunamadı</p>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <!-- Sayfalama -->
            <?php if ($total_pages > 1): ?>
            <div class="card-footer bg-white border-0 py-3">
                <nav aria-label="Sayfalama">
                    <ul class="pagination justify-content-center mb-0">
                        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
                            <a class="page-link" href="?sayfa=<?= $page - 1 ?><?= !empty($filter_department) ? '&departman=' . $filter_department : '' ?><?= !empty($filter_status) ? '&durum=' . $filter_status : '' ?><?= !empty($search) ? '&ara=' . urlencode($search) : '' ?>">Önceki</a>
                        </li>
                        
                        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                            <li class="page-item <?= $i == $page ? 'active' : '' ?>">
                                <a class="page-link" href="?sayfa=<?= $i ?><?= !empty($filter_department) ? '&departman=' . $filter_department : '' ?><?= !empty($filter_status) ? '&durum=' . $filter_status : '' ?><?= !empty($search) ? '&ara=' . urlencode($search) : '' ?>">
                                    <?= $i ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <li class="page-item <?= $page >= $total_pages ? 'disabled' : '' ?>">
                            <a class="page-link" href="?sayfa=<?= $page + 1 ?><?= !empty($filter_department) ? '&departman=' . $filter_department : '' ?><?= !empty($filter_status) ? '&durum=' . $filter_status : '' ?><?= !empty($search) ? '&ara=' . urlencode($search) : '' ?>">Sonraki</a>
                        </li>
                    </ul>
                </nav>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Toplu İşlemler Toolbar -->
<div class="position-fixed bottom-0 end-0 p-3" style="z-index: 11">
    <div class="toast align-items-center text-white bg-primary border-0" role="alert" aria-live="assertive" aria-atomic="true" id="toastTopluIslem">
        <div class="d-flex">
            <div class="toast-body">
                <div class="d-flex align-items-center">
                    <div class="flex-shrink-0 me-3">
                        <i class="fas fa-users-cog fa-2x"></i>
                    </div>
                    <div class="flex-grow-1">
                        <h6 class="mb-1">Toplu İşlem</h6>
                        <span id="selectedCount">0</span> personel seçildi
                    </div>
                    <div class="ms-3">
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-sm btn-outline-light" id="btnTopluMail">
                                <i class="fas fa-envelope me-1"></i>E-posta
                            </button>
                            <button type="button" class="btn btn-sm btn-outline-light" id="btnTopluSms">
                                <i class="fas fa-sms me-1"></i>SMS
                            </button>
                            <div class="btn-group" role="group">
                                <button type="button" class="btn btn-sm btn-outline-light dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-cog me-1"></i>İşlem Yap
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li><h6 class="dropdown-header">Durum Değiştir</h6></li>
                                    <li><a class="dropdown-item" href="#" onclick="changeStatus('Aktif')">Aktif Yap</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="changeStatus('İzinli')">İzinli Yap</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="changeStatus('İşten Ayrıldı')">İşten Ayrıldı Yap</a></li>
                                    <li><a class="dropdown-item" href="#" onclick="changeStatus('İşten Çıkarıldı')">İşten Çıkarıldı Yap</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                    <li><a class="dropdown-item text-danger" href="#" id="btnTopluSil">Seçilenleri Sil</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Kapat"></button>
        </div>
    </div>
</div>
                <div class="card border-0 bg-success bg-opacity-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <h6 class="text-uppercase text-muted mb-1">Aktif Personel</h6>
                                <h3 class="mb-0"><?= $active_personnel ?></h3>
                            </div>
                            <div class="icon-shape icon-lg bg-success bg-opacity-10 text-success rounded-3">
                                <i class="fas fa-user-check"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card border-0 bg-warning bg-opacity-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <h6 class="text-uppercase text-muted mb-1">İzinli</h6>
                                <h3 class="mb-0"><?= $on_leave ?></h3>
                            </div>
                            <div class="icon-shape icon-lg bg-warning bg-opacity-10 text-warning rounded-3">
                                <i class="fas fa-umbrella-beach"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="card border-0 bg-danger bg-opacity-10">
                    <div class="card-body">
                        <div class="d-flex align-items-center">
                            <div class="flex-grow-1">
                                <h6 class="text-uppercase text-muted mb-1">Pasif Personel</h6>
                                <h3 class="mb-0"><?= $inactive ?></h3>
                            </div>
                            <div class="icon-shape icon-lg bg-danger bg-opacity-10 text-danger rounded-3">
                                <i class="fas fa-user-times"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Personel Listesi -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-header bg-white border-0 py-3">
                <div class="row align-items-center">
                    <div class="col">
                        <h5 class="card-title mb-0">Personel Listesi</h5>
                    </div>
                    <div class="col-auto">
                        <div class="input-group input-group-sm" style="max-width: 250px;">
                            <span class="input-group-text bg-transparent"><i class="fas fa-search text-muted"></i></span>
                            <input type="text" class="form-control border-start-0" id="searchInput" placeholder="Personel ara...">
                        </div>
                    </div>
                </div>
            </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle" id="personnelTable">
                                <thead class="bg-light">
                                    <tr>
                                        <th class="border-0" width="50">#</th>
                                        <th class="border-0">Ad Soyad</th>
                                        <th class="border-0">Pozisyon</th>
                                        <th class="border-0">Departman</th>
                                        <th class="border-0">İşe Giriş Tarihi</th>
                                        <th class="border-0" width="120">Durum</th>
                                        <th class="border-0 text-end" width="150">İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($personnel as $index => $person): 
                                        $status_class = '';
                                        $status_text = '';
                                        
                                        switch($person['status']) {
                                            case 'active':
                                                $status_class = 'status-active';
                                                $status_text = 'Aktif';
                                                break;
                                            case 'on_leave':
                                                $status_class = 'status-onleave';
                                                $status_text = 'İzinli';
                                                break;
                                            default:
                                                $status_class = 'status-inactive';
                                                $status_text = 'Pasif';
                                        }
                                    ?>
                                    <tr>
                                        <td><?= $index + 1 ?></td>
                                        <td>
                                            <img src="https://ui-avatars.com/api/?name=<?= urlencode($person['name']) ?>" 
                                                 alt="<?= htmlspecialchars($person['name']) ?>" 
                                                 class="personnel-avatar me-2">
                                            <?= htmlspecialchars($person['name']) ?>
                                        </td>
                                        <td><?= htmlspecialchars($person['position'] ?? '-') ?></td>
                                        <td><?= htmlspecialchars($person['department'] ?? '-') ?></td>
                                        <td><?= !empty($person['hire_date']) ? date('d.m.Y', strtotime($person['hire_date'])) : '-' ?></td>
                                        <td>
                                            <span class="status-badge <?= $status_class ?>"></span>
                                            <?= $status_text ?>
                                        </td>
                                        <td class="text-end">
                                            <div class="btn-group btn-group-sm">
                                                <button type="button" class="btn btn-outline-primary" 
                                                        onclick="viewPersonnel(<?= $person['id'] ?>)"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Görüntüle">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button type="button" class="btn btn-outline-secondary" 
                                                        onclick="editPersonnel(<?= $person['id'] ?>)"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Düzenle">
                                                    <i class="fas fa-edit"></i>
                                                </button>
                                                <button type="button" class="btn btn-outline-danger" 
                                                        onclick="deletePersonnel(<?= $person['id'] ?>, '<?= addslashes($person['name']) ?>')"
                                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Sil">
                                                    <i class="fas fa-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                    <?php if (empty($personnel)): ?>
                                    <tr>
                                        <td colspan="7" class="text-center py-4">
                                            <div class="text-muted">
                                                <i class="fas fa-user-slash fa-2x mb-2"></i>
                                                <p class="mb-0">Kayıtlı personel bulunamadı</p>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

    <!-- Personel Ekleme Modal -->
    <div class="modal fade" id="addPersonnelModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h5 class="modal-title"><i class="fas fa-user-plus me-2"></i>Yeni Personel Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>
                <form id="addPersonnelForm">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Ad Soyad <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Pozisyon</label>
                                    <input type="text" class="form-control" name="position">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Departman</label>
                                    <input type="text" class="form-control" name="department">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Telefon</label>
                            <input type="tel" class="form-control" name="phone">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">E-posta</label>
                            <input type="email" class="form-control" name="email">
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">İşe Giriş Tarihi</label>
                                    <input type="date" class="form-control" name="hire_date">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Durum</label>
                                    <select class="form-select" name="status">
                                        <option value="active">Aktif</option>
                                        <option value="on_leave">İzinli</option>
                                        <option value="inactive">Pasif</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Include SweetAlert2 for beautiful alerts -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize select2 for better select boxes
    if ($.fn.select2) {
        $('.select2').select2({
            theme: 'bootstrap-5',
            width: '100%',
            placeholder: 'Seçiniz...'
        });
    }

    // Handle select all checkbox
    $('#selectAll').on('change', function() {
        $('.select-personnel').prop('checked', $(this).prop('checked'));
        updateSelectedCount();
    });

    // Update selected count when individual checkboxes change
    $(document).on('change', '.select-personnel', function() {
        updateSelectedCount();
    });

    // Function to update the selected personnel count
    function updateSelectedCount() {
        const selectedCount = $('.select-personnel:checked').length;
        $('#selectedCount').text(selectedCount);
        
        const toast = new bootstrap.Toast(document.getElementById('toastTopluIslem'));
        
        if (selectedCount > 0) {
            toast.show();
        } else {
            toast.hide();
        }
    }

    // Export to PDF
    $('#exportPdf').on('click', function() {
        Swal.fire({
            title: 'PDF Oluşturuluyor',
            text: 'Personel listesi PDF olarak dışa aktarılıyor...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
                // Simulate PDF generation
                setTimeout(() => {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: 'Personel listesi PDF olarak dışa aktarıldı.',
                        showConfirmButton: true
                    });
                }, 1500);
            }
        });
    });

    // Export to Excel
    $('#exportExcel').on('click', function() {
        // Get filter parameters
        const params = new URLSearchParams(window.location.search);
        
        Swal.fire({
            title: 'Excel Oluşturuluyor',
            text: 'Personel listesi Excel olarak dışa aktarılıyor...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
                // AJAX call to export to Excel
                $.ajax({
                    url: 'api/export_personnel.php',
                    method: 'GET',
                    data: params,
                    xhrFields: {
                        responseType: 'blob'
                    },
                    success: function(response) {
                        const url = window.URL.createObjectURL(response);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'personel-listesi-' + new Date().toISOString().split('T')[0] + '.xlsx';
                        document.body.appendChild(a);
                        a.click();
                        window.URL.revokeObjectURL(url);
                        a.remove();
                        
                        Swal.close();
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Hata!',
                            text: 'Excel dosyası oluşturulurken bir hata oluştu.',
                            showConfirmButton: true
                        });
                    }
                });
            }
        });
    });

    // Bulk delete confirmation
    $('#btnTopluSil').on('click', function(e) {
        e.preventDefault();
        
        const selectedIds = [];
        $('.select-personnel:checked').each(function() {
            selectedIds.push($(this).val());
        });
        
        if (selectedIds.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Uyarı',
                text: 'Lütfen silmek istediğiniz personelleri seçiniz.',
                confirmButtonText: 'Tamam'
            });
            return;
        }
        
        Swal.fire({
            title: 'Emin misiniz?',
            text: `Seçilen ${selectedIds.length} personel silinecek. Bu işlem geri alınamaz!`,
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Evet, sil!',
            cancelButtonText: 'İptal'
        }).then((result) => {
            if (result.isConfirmed) {
                deletePersonnel(selectedIds);
            }
        });
    });

    // Bulk status change
    window.changeStatus = function(newStatus) {
        const selectedIds = [];
        $('.select-personnel:checked').each(function() {
            selectedIds.push($(this).val());
        });
        
        if (selectedIds.length === 0) {
            Swal.fire({
                icon: 'warning',
                title: 'Uyarı',
                text: 'Lütfen durumunu değiştirmek istediğiniz personelleri seçiniz.',
                confirmButtonText: 'Tamam'
            });
            return;
        }
        
        Swal.fire({
            title: 'Durum Güncellenecek',
            text: `Seçilen ${selectedIds.length} personelin durumu "${newStatus}" olarak güncellenecek. Emin misiniz?`,
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Evet, güncelle',
            cancelButtonText: 'İptal'
        }).then((result) => {
            if (result.isConfirmed) {
                updatePersonnelStatus(selectedIds, newStatus);
            }
        });
    };

    // Function to update personnel status
    function updatePersonnelStatus(ids, newStatus) {
        $.ajax({
            url: 'api/update_personnel_status.php',
            method: 'POST',
            data: {
                ids: ids,
                status: newStatus
            },
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        icon: 'success',
                        title: 'Başarılı!',
                        text: response.message || 'Personel durumları başarıyla güncellendi.',
                        showConfirmButton: false,
                        timer: 2000
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Hata!',
                        text: response.message || 'Bir hata oluştu. Lütfen tekrar deneyiniz.'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Hata!',
                    text: 'İşlem sırasında bir hata oluştu. Lütfen tekrar deneyiniz.'
                });
            }
        });
    }

    // Function to delete personnel
    window.deletePersonnel = function(id, name) {
        const ids = Array.isArray(id) ? id : [id];
        const isMultiple = ids.length > 1;
        
        Swal.fire({
            title: isMultiple ? 'Emin misiniz?' : `${name} isimli personeli silmek istiyor musunuz?`,
            text: isMultiple ? `Seçilen ${ids.length} personel silinecek. Bu işlem geri alınamaz!` : 'Bu işlem geri alınamaz!',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#6c757d',
            confirmButtonText: 'Evet, sil!',
            cancelButtonText: 'İptal',
            showLoaderOnConfirm: true,
            preConfirm: () => {
                return $.ajax({
                    url: 'api/delete_personnel.php',
                    method: 'POST',
                    data: { ids: ids },
                    dataType: 'json'
                }).then(response => {
                    if (!response.success) {
                        throw new Error(response.message || 'Silme işlemi başarısız oldu.');
                    }
                    return response;
                }).catch(error => {
                    Swal.showValidationMessage(
                        `İstek başarısız: ${error.statusText || 'Bilinmeyen hata'}`
                    );
                });
            },
            allowOutsideClick: () => !Swal.isLoading()
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire({
                    icon: 'success',
                    title: 'Başarılı!',
                    text: isMultiple ? 'Seçilen personeller başarıyla silindi.' : 'Personel başarıyla silindi.',
                    showConfirmButton: false,
                    timer: 1500
                }).then(() => {
                    location.reload();
                });
            }
        });
    };

    // Function to edit personnel
    window.editPersonnel = function(id) {
        // Show loading
        Swal.fire({
            title: 'Yükleniyor...',
            html: 'Personel bilgileri yükleniyor.',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
                
                // Load personnel data via AJAX
                $.ajax({
                    url: 'api/get_personnel.php',
                    method: 'GET',
                    data: { id: id },
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            // Populate the edit form
                            const personel = response.data;
                            
                            // Set form values
                            Object.keys(personel).forEach(key => {
                                $(`#editPersonnelForm [name="${key}"]`).val(personel[key]);
                            });
                            
                            // Handle select2 if exists
                            if ($.fn.select2) {
                                $('.select2').trigger('change');
                            }
                            
                            // Show the edit modal
                            $('#editPersonnelModal').modal('show');
                            
                            // Close the loading dialog
                            Swal.close();
                        } else {
                            Swal.fire({
                                icon: 'error',
                                title: 'Hata!',
                                text: response.message || 'Personel bilgileri yüklenirken bir hata oluştu.'
                            });
                        }
                    },
                    error: function() {
                        Swal.fire({
                            icon: 'error',
                            title: 'Hata!',
                            text: 'Sunucu ile bağlantı kurulurken bir hata oluştu.'
                        });
                    }
                });
            }
        });
    };

    // Initialize DataTables if available
    if ($.fn.DataTable) {
        $('.datatable').DataTable({
            responsive: true,
            language: {
                url: '//cdn.datatables.net/plug-ins/1.10.25/i18n/Turkish.json'
            },
            dom: "<'row'<'col-sm-12 col-md-6'l><'col-sm-12 col-md-6'f>>" +
                 "<'row'<'col-sm-12'tr>>" +
                 "<'row'<'col-sm-12 col-md-5'i><'col-sm-12 col-md-7'p>>",
            pageLength: 25,
            order: [[1, 'asc']]
        });
    }
});
</script>

<!-- Include Select2 CSS and JS if not already included -->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<?php include 'includes/footer.php'; ?>
</main>

<!-- Required Scripts -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
$(document).ready(function() {
    // Tooltip'leri etkinleştir
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Sidebar menü aktifleştirme
    const currentPage = 'personel2.php';
    document.querySelectorAll('.nav-link').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
            // Üst menüyü de aktif et
            const parent = link.closest('.has-submenu');
            if (parent) {
                parent.classList.add('show');
            }
        }
    });

    // Arama işlevselliği
    $('#searchInput').on('keyup', function() {
        const value = $(this).val().toLowerCase();
        $('#personnelTable tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
    });

    // Form gönderimini işle
    $('#addPersonnelForm').on('submit', function(e) {
        e.preventDefault();
        
        // Form verisini al
        const formData = new FormData(this);
        
        // AJAX isteği gönder
        $.ajax({
            url: 'api/add_personnel.php',
            type: 'POST',
            data: formData,
            processData: false,
            contentType: false,
            dataType: 'json',
            success: function(response) {
                if (response.success) {
                    Swal.fire({
                        title: 'Başarılı!',
                        text: response.message,
                        icon: 'success',
                        confirmButtonText: 'Tamam',
                        customClass: {
                            confirmButton: 'btn btn-primary'
                        },
                        buttonsStyling: false
                    }).then((result) => {
                        // Formu sıfırla
                        document.getElementById('addPersonnelForm').reset();
                        // Modalı kapat
                        const modal = bootstrap.Modal.getInstance(document.getElementById('addPersonnelModal'));
                        modal.hide();
                        // Sayfayı yenile
                        location.reload();
                    });
                } else {
                    Swal.fire({
                        title: 'Hata!',
                        text: response.message || 'Bir hata oluştu.',
                        icon: 'error',
                        confirmButtonText: 'Tamam',
                        customClass: {
                            confirmButton: 'btn btn-danger'
                        },
                        buttonsStyling: false
                    });
                }
            },
            error: function(xhr, status, error) {
                Swal.fire({
                    title: 'Hata!',
                    text: 'Sunucu hatası: ' + error,
                    icon: 'error',
                    confirmButtonText: 'Tamam',
                    customClass: {
                        confirmButton: 'btn btn-danger'
                    },
                    buttonsStyling: false
                });
            }
        });
    });

    // Personel görüntüleme fonksiyonu
    function viewPersonnel(id) {
        // Personel detay sayfasına yönlendir
        window.location.href = 'personel-detay.php?id=' + id;
    }

    // Personel düzenleme fonksiyonu
    function editPersonnel(id) {
        // Burada AJAX ile personel bilgilerini dolduracağız
        // Şimdilik sadece modalı açıyoruz
        const modal = new bootstrap.Modal(document.getElementById('addPersonnelModal'));
        const modalTitle = document.querySelector('#addPersonnelModal .modal-title');
        modalTitle.innerHTML = '<i class="fas fa-user-edit me-2"></i>Personel Düzenle';
        
        // Formu sıfırla
        const form = document.getElementById('addPersonnelForm');
        form.reset();
        
        // Burada AJAX ile personel bilgilerini getirip formu dolduracağız
        // Örnek:
        // fetch(`/api/personel/${id}`)
        //     .then(response => response.json())
        //     .then(data => {
        //         // Form alanlarını doldur
        //         Object.keys(data).forEach(key => {
        //             const input = form.querySelector(`[name="${key}"]`);
        //             if (input) input.value = data[key];
        //         });
        //     });
        
        modal.show();
    }

    // Personel silme fonksiyonu
        function deletePersonnel(id, name) {
            Swal.fire({
                title: 'Emin misiniz?',
                text: `"${name}" isimli personeli silmek istediğinize emin misiniz?`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Evet, sil',
                cancelButtonText: 'İptal',
                confirmButtonColor: '#dc3545'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Burada AJAX ile silme işlemi yapılacak
                    // Şimdilik başarılı mesajı gösteriyoruz
                    Swal.fire(
                        'Silindi!',
                        'Personel başarıyla silindi.',
                        'success'
                    ).then(() => {
                        // Sayfayı yenile
                        location.reload();
                    });
                }
            });
        }
    </script>
</body>
</html>
