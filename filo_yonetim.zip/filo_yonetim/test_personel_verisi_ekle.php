<?php
require_once 'includes/config.php';
require_once 'includes/auth.php';

// Sadece yöneticiler test verisi ekleyebilir
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
    die('Bu işlem için yetkiniz yok!');
}

// Test verileri
$test_personeller = [
    [
        'personel_no' => 'P' . rand(1000, 9999),
        'ad' => 'Ahmet',
        'soyad' => 'Yılmaz',
        'tc_kimlik' => '1' . rand(100000000, 999999999) . rand(0, 9) * 2,
        'dogum_tarihi' => '1990-01-15',
        'cinsiyet' => 'Erkek',
        'medeni_durum' => 'Bekar',
        'kan_grubu' => 'A Rh+',
        'email' => 'ahmet.yilmaz@example.com',
        'telefon' => '05' . rand(300000000, 599999999),
        'adres' => 'Örnek Mah. Test Cad. No:123',
        'il' => 'İstanbul',
        'ilce' => 'Kadıköy',
        'departman_id' => 1,
        'pozisyon' => 'Şoför',
        'durum' => 'Aktif'
    ],
    [
        'personel_no' => 'P' . rand(1000, 9999),
        'ad' => 'Ayşe',
        'soyad' => 'Demir',
        'tc_kimlik' => '2' . rand(100000000, 999999999) . rand(1, 9) * 2 + 1,
        'dogum_tarihi' => '1988-05-22',
        'cinsiyet' => 'Kadın',
        'medeni_durum' => 'Evli',
        'kan_grubu' => '0 Rh+',
        'email' => 'ayse.demir@example.com',
        'telefon' => '05' . rand(300000000, 599999999),
        'adres' => 'Deneme Mah. Örnek Sok. No:45',
        'il' => 'Ankara',
        'ilce' => 'Çankaya',
        'departman_id' => 2,
        'pozisyon' => 'Muhasebe Sorumlusu',
        'durum' => 'Aktif'
    ],
    [
        'personel_no' => 'P' . rand(1000, 9999),
        'ad' => 'Mehmet',
        'soyad' => 'Kaya',
        'tc_kimlik' => '3' . rand(100000000, 999999999) . rand(0, 9) * 2,
        'dogum_tarihi' => '1985-11-03',
        'cinsiyet' => 'Erkek',
        'medeni_durum' => 'Evli',
        'kan_grubu' => 'B Rh+',
        'email' => 'mehmet.kaya@example.com',
        'telefon' => '05' . rand(300000000, 599999999),
        'adres' => 'Test Mah. Deneme Cad. No:67',
        'il' => 'İzmir',
        'ilce' => 'Karşıyaka',
        'departman_id' => 3,
        'pozisyon' => 'Lojistik Sorumlusu',
        'durum' => 'İzinli'
    ],
    [
        'personel_no' => 'P' . rand(1000, 9999),
        'ad' => 'Zeynep',
        'soyad' => 'Şahin',
        'tc_kimlik' => '4' . rand(100000000, 999999999) . rand(1, 9) * 2 + 1,
        'dogum_tarihi' => '1992-07-18',
        'cinsiyet' => 'Kadın',
        'medeni_durum' => 'Bekar',
        'kan_grubu' => 'AB Rh-',
        'email' => 'zeynep.sahin@example.com',
        'telefon' => '05' . rand(300000000, 599999999),
        'adres' => 'Örnek Mah. Test Sok. No:89',
        'il' => 'Bursa',
        'ilce' => 'Nilüfer',
        'departman_id' => 4,
        'pozisyon' => 'İnsan Kaynakları Uzmanı',
        'durum' => 'Aktif'
    ],
    [
        'personel_no' => 'P' . rand(1000, 9999),
        'ad' => 'Mustafa',
        'soyad' => 'Yıldız',
        'tc_kimlik' => '5' . rand(100000000, 999999999) . rand(0, 9) * 2,
        'dogum_tarihi' => '1980-12-30',
        'cinsiyet' => 'Erkek',
        'medeni_durum' => 'Evli',
        'kan_grubu' => 'A Rh-',
        'email' => 'mustafa.yildiz@example.com',
        'telefon' => '05' . rand(300000000, 599999999),
        'adres' => 'Deneme Mah. Örnek Cad. No:101',
        'il' => 'Antalya',
        'ilce' => 'Muratpaşa',
        'departman_id' => 1,
        'pozisyon' => 'Şoför',
        'durum' => 'İşten Ayrıldı'
    ]
];

// Departmanları ekleyelim (eğer yoksa)
try {
    $departmanlar = [
        ['departman_adi' => 'Nakliye', 'aciklama' => 'Nakliye ve Lojistik Departmanı'],
        ['departman_adi' => 'Muhasebe', 'aciklama' => 'Muhasebe ve Finans Departmanı'],
        ['departman_adi' => 'Lojistik', 'aciklama' => 'Lojistik ve Dağıtım Departmanı'],
        ['departman_adi' => 'İnsan Kaynakları', 'aciklama' => 'İnsan Kaynakları Departmanı']
    ];

    $stmt = $pdo->query("SELECT COUNT(*) FROM departmanlar");
    if ($stmt->fetchColumn() == 0) {
        $insert_departman = $pdo->prepare("INSERT INTO departmanlar (departman_adi, aciklama) VALUES (?, ?)");
        foreach ($departmanlar as $departman) {
            $insert_departman->execute([$departman['departman_adi'], $departman['aciklama']]);
        }
        echo "Departmanlar eklendi.<br>";
    }

    // Test personellerini ekleyelim
    $eklenen = 0;
    $insert_personel = $pdo->prepare("INSERT INTO personel (
        personel_no, tc_kimlik, ad, soyad, dogum_tarihi, cinsiyet, medeni_durum, 
        kan_grubu, email, telefon, adres, il, ilce, departman_id, pozisyon, durum, created_by
    ) VALUES (
        :personel_no, :tc_kimlik, :ad, :soyad, :dogum_tarihi, :cinsiyet, :medeni_durum, 
        :kan_grubu, :email, :telefon, :adres, :il, :ilce, :departman_id, :pozisyon, :durum, :created_by
    )");

    foreach ($test_personeller as $personel) {
        try {
            $personel['created_by'] = $_SESSION['user_id'];
            $insert_personel->execute($personel);
            $eklenen++;
            echo "Personel eklendi: " . $personel['ad'] . " " . $personel['soyad'] . "<br>";
        } catch (PDOException $e) {
            // TC veya personel no zaten varsa atla
            if ($e->getCode() == '23000') {
                echo "Personel zaten mevcut: " . $personel['ad'] . " " . $personel['soyad'] . "<br>";
                continue;
            }
            throw $e;
        }
    }

    echo "<br>Toplam $eklenen yeni personel eklendi.<br>";
    echo "<a href='personel3.php'>Personel Yönetim Sayfasına Git</a>";

} catch (PDOException $e) {
    die("Hata oluştu: " . $e->getMessage());
}
