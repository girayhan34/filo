<?php
require_once 'includes/config.php';

// Hata raporlamayı etkinleştir
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Başlık ve stil
echo '<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personel Yönetim Sistemi Kurulumu</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; }
        .success { color: #155724; background-color: #d4edda; padding: 10px; border-radius: 4px; margin: 5px 0; }
        .error { color: #721c24; background-color: #f8d7da; padding: 10px; border-radius: 4px; margin: 5px 0; }
        .info { color: #0c5460; background-color: #d1ecf1; padding: 10px; border-radius: 4px; margin: 5px 0; }
        .sql-code { 
            background-color: #f8f9fa; 
            padding: 15px; 
            border-radius: 4px; 
            font-family: monospace; 
            white-space: pre-wrap; 
            margin: 10px 0; 
            border: 1px solid #dee2e6;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="my-4">Personel Yönetim Sistemi Kurulumu</h1>
        <div class="card">
            <div class="card-body">
';

try {
    // SQL dosyasını oku
    $sqlFile = __DIR__ . '/database/personel_yonetim_sistemi.sql';
    
    if (!file_exists($sqlFile)) {
        throw new Exception("SQL dosyası bulunamadı: " . $sqlFile);
    }
    
    $sql = file_get_contents($sqlFile);
    
    // SQL komutlarını ayır (noktalı virgül ile ayrılmış)
    $queries = explode(';', $sql);
    
    // Her bir sorguyu çalıştır
    $successCount = 0;
    $errorCount = 0;
    $executedQueries = [];
    
    $pdo->beginTransaction();
    
    foreach ($queries as $query) {
        $query = trim($query);
        if (empty($query)) continue;
        
        try {
            $pdo->exec($query);
            $successCount++;
            $executedQueries[] = [
                'query' => $query,
                'status' => 'success',
                'message' => 'Başarılı'
            ];
        } catch (PDOException $e) {
            $errorCount++;
            $executedQueries[] = [
                'query' => $query,
                'status' => 'error',
                'message' => $e->getMessage()
            ];
        }
    }
    
    // Tüm sorgular başarılı ise işlemi onayla
    $pdo->commit();
    
    // Sonuçları göster
    echo "<div class='alert alert-success'>Kurulum tamamlandı! Başarılı sorgu sayısı: $successCount, Hatalı sorgu sayısı: $errorCount</div>";
    
    // Çalıştırılan sorguları göster
    echo "<h4>Çalıştırılan Sorgular:</h4>";
    
    foreach ($executedQueries as $index => $item) {
        $statusClass = $item['status'] === 'success' ? 'success' : 'error';
        echo "<div class='mb-3'>";
        echo "<strong>Sorgu #" . ($index + 1) . " - Durum: <span class='$statusClass'>" . ucfirst($item['status']) . "</span></strong>";
        echo "<div class='sql-code'>" . htmlspecialchars($item['query']) . "</div>";
        
        if ($item['status'] === 'error') {
            echo "<div class='error'>Hata: " . htmlspecialchars($item['message']) . "</div>";
        }
        
        echo "</div>";
    }
    
    // Gerekli klasörleri oluştur
    $uploadDirs = [
        'uploads/personel/belgeler',
        'uploads/personel/fotograflar',
        'uploads/personel/sertifikalar'
    ];
    
    echo "<h4 class='mt-4'>Klasör Kontrolü:</h4>";
    
    foreach ($uploadDirs as $dir) {
        $fullPath = __DIR__ . '/' . $dir;
        if (!file_exists($fullPath)) {
            if (mkdir($fullPath, 0777, true)) {
                echo "<div class='success'>Klasör oluşturuldu: $dir</div>";
            } else {
                echo "<div class='error'>Klasör oluşturulamadı: $dir</div>";
            }
        } else {
            echo "<div class='info'>Klasör zaten mevcut: $dir</div>";
        }
    }
    
    echo "<div class='alert alert-success mt-4'>Kurulum başarıyla tamamlandı! <a href='personel2.php' class='btn btn-primary'>Personel Yönetimine Git</a></div>";
    
} catch (Exception $e) {
    // Hata durumunda işlemi geri al
    $pdo->rollBack();
    echo "<div class='alert alert-danger'>Hata oluştu: " . $e->getMessage() . "</div>";
}

echo '            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>';
?>
