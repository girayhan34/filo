<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Stok Yönetimi';
$page_subtitle = 'Yedek parça ve sarf malzemelerinizi yönetin.';
include 'includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <!-- Başlıklar header.php'den geliyor -->
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#stockItemModal" onclick="prepareAddItem()">
        <i class="fas fa-plus me-2"></i>Yeni Stok Kalemi Ekle
    </button>
</div>

<div class="card shadow-sm">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-warehouse me-2"></i>Stok Listesi</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="stockTable">
                <thead class="table-light">
                    <tr>
                        <th>Stok Kodu</th>
                        <th>Ürün Adı</th>
                        <th>Kategori</th>
                        <th>Miktar</th>
                        <th>Konum</th>
                        <th>Son Güncelleme</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- DataTables tarafından doldurulacak -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Stok Kalemi Ekleme/Düzenleme Modal -->
<div class="modal fade" id="stockItemModal" tabindex="-1" aria-labelledby="stockItemModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="stockItemModalLabel">Stok Kalemi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="stockItemForm">
                <div class="modal-body">
                    <input type="hidden" id="stockItemId" name="id">
                    <div class="row g-3">
                        <div class="col-md-8">
                            <label for="itemName" class="form-label">Ürün/Malzeme Adı <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="itemName" name="item_name" required>
                        </div>
                        <div class="col-md-4">
                            <label for="itemCode" class="form-label">Stok Kodu (SKU)</label>
                            <input type="text" class="form-control" id="itemCode" name="item_code">
                        </div>
                        <div class="col-md-6">
                            <label for="category" class="form-label">Kategori</label>
                            <input type="text" class="form-control" id="category" name="category" placeholder="Örn: Filtre, Yağ, Lastik">
                        </div>
                        <div class="col-md-6">
                            <label for="location" class="form-label">Depo/Konum</label>
                            <input type="text" class="form-control" id="location" name="location" placeholder="Örn: Raf A-12">
                        </div>
                        <div class="col-md-4">
                            <label for="quantity" class="form-label">Miktar <span class="text-danger">*</span></label>
                            <input type="number" class="form-control" id="quantity" name="quantity" required min="0">
                        </div>
                        <div class="col-md-4">
                            <label for="unit" class="form-label">Birim <span class="text-danger">*</span></label>
                            <select class="form-select" id="unit" name="unit" required>
                                <option value="adet" selected>Adet</option>
                                <option value="litre">Litre</option>
                                <option value="kg">Kilogram</option>
                                <option value="metre">Metre</option>
                                <option value="kutu">Kutu</option>
                                <option value="takım">Takım</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="minStockLevel" class="form-label">Minimum Stok Seviyesi</label>
                            <input type="number" class="form-control" id="minStockLevel" name="min_stock_level" min="0">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Stok Hareketi Modal -->
<div class="modal fade" id="stockMovementModal" tabindex="-1" aria-labelledby="stockMovementModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="stockMovementModalLabel">Stok Hareketi Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="stockMovementForm">
                <div class="modal-body">
                    <input type="hidden" id="movementStockItemId" name="stock_item_id">
                    <input type="hidden" id="movementType" name="movement_type">
                    <h6 class="mb-3">Ürün: <span id="movementItemName" class="fw-bold"></span></h6>
                    <div class="mb-3">
                        <label for="movementQuantity" class="form-label">Miktar <span class="text-danger">*</span></label>
                        <input type="number" class="form-control" id="movementQuantity" name="movement_quantity" required min="1">
                    </div>
                    <div class="mb-3">
                        <label for="movementNotes" class="form-label">Notlar (Opsiyonel)</label>
                        <textarea class="form-control" id="movementNotes" name="movement_notes" rows="3" placeholder="Örn: Fatura No: 12345, Proje: X İnşaatı"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Hareketi Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
let stockTable;

$(document).ready(function() {
    stockTable = $('#stockTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/stock_api.php?action=list',
            type: 'POST'
        },
        columns: [
            { data: 'item_code', render: function(data) { return data || '-'; } },
            { data: 'item_name' },
            { data: 'category' },
            { data: 'quantity', render: function(data, type, row) {
                const quantity = parseInt(data);
                const minLevel = parseInt(row.min_stock_level);
                let badgeClass = 'bg-success';
                if (quantity <= minLevel) {
                    badgeClass = 'bg-danger';
                } else if (quantity <= minLevel * 1.2) {
                    badgeClass = 'bg-warning';
                }
                return `<span class="badge ${badgeClass}">${quantity} ${row.unit}</span>`;
            }},
            { data: 'location' },
            { data: 'updated_at', render: function(data, type, row) {
                return `${moment(data).format('DD.MM.YYYY HH:mm')} <br><small class="text-muted">${row.updated_by_name || ''}</small>`;
            }},
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="btn-group btn-group-sm" role="group">
                                <button class="btn btn-success" onclick="addMovement(${row.id}, 'in', '${row.item_name}')" title="Stok Girişi"><i class="fas fa-plus"></i></button>
                                <button class="btn btn-danger" onclick="addMovement(${row.id}, 'out', '${row.item_name}')" title="Stok Çıkışı"><i class="fas fa-minus"></i></button>
                                <button class="btn btn-warning" onclick="editItem(${row.id})" title="Düzenle"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-danger" onclick="deleteItem(${row.id})"><i class="fas fa-trash"></i></button>
                            </div>`;
                }
            }
        ],
        order: [[1, 'asc']],
        language: getDataTablesLanguage()
    });

    $('#stockItemForm').on('submit', function(e) {
        e.preventDefault();
        const id = $('#stockItemId').val();
        const url = id ? `../api/stock_api.php?action=update` : `../api/stock_api.php?action=create`;
        
        sendAjaxRequest({
            url: url,
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#stockItemModal').modal('hide');
            stockTable.ajax.reload(null, false);
        });
    });

    $('#stockMovementForm').on('submit', function(e) {
        e.preventDefault();
        sendAjaxRequest({
            url: '../api/stock_api.php?action=add_movement',
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#stockMovementModal').modal('hide');
            stockTable.ajax.reload(null, false);
        });
    });
});

function prepareAddItem() {
    $('#stockItemForm')[0].reset();
    $('#stockItemId').val('');
    $('#stockItemModalLabel').text('Yeni Stok Kalemi Ekle');
}

function editItem(id) {
    $.ajax({
        url: `../api/stock_api.php?action=get_item&id=${id}`,
        type: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                const item = response.data;
                $('#stockItemId').val(item.id);
                $('#itemName').val(item.item_name);
                $('#itemCode').val(item.item_code);
                $('#category').val(item.category);
                $('#quantity').val(item.quantity);
                $('#unit').val(item.unit);
                $('#location').val(item.location);
                $('#minStockLevel').val(item.min_stock_level);
                $('#stockItemModalLabel').text('Stok Kalemini Düzenle');
                $('#stockItemModal').modal('show');
            } else {
                toastr.error(response.message);
            }
        }
    });
}

function deleteItem(id) {
    handleDelete('../api/stock_api.php?action=delete', id, stockTable);
}

function addMovement(id, type, itemName) {
    $('#stockMovementForm')[0].reset();
    $('#movementStockItemId').val(id);
    $('#movementType').val(type);
    $('#movementItemName').text(itemName);

    const modalLabel = type === 'in' ? 'Stok Girişi' : 'Stok Çıkışı';
    $('#stockMovementModalLabel').text(modalLabel);

    const movementModal = new bootstrap.Modal(document.getElementById('stockMovementModal'));
    movementModal.show();
}
</script>