<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

$page_title = 'Görev Yönetimi';
$page_subtitle = 'Görevlerinizi Kanban panosu ile yönetin.';
include 'includes/header.php';

// Kullanıcıları çek (görev ataması için)
$users = $pdo->query("SELECT id, name FROM users WHERE status = 'active' ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
// Projeleri çek (görev ataması için)
$projects = $pdo->query("SELECT id, project_name FROM projects WHERE status IN ('planning', 'active') ORDER BY project_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>

<style>
.kanban-board {
    display: flex;
    gap: 1rem;
    overflow-x: auto;
    padding-bottom: 1rem;
}
.kanban-column {
    flex: 1;
    min-width: 300px;
    max-width: 320px;
    background-color: #f4f5f7;
    border-radius: 0.5rem;
    padding: 0.5rem;
}
.kanban-column-header {
    padding: 0.5rem;
    font-weight: bold;
    margin-bottom: 1rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.kanban-tasks {
    min-height: 400px;
    padding: 0.5rem;
    border-radius: 0.25rem;
}
.kanban-task {
    background-color: white;
    border-radius: 0.25rem;
    padding: 1rem;
    margin-bottom: 1rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    cursor: grab;
    border-left: 4px solid;
}
.kanban-task:active {
    cursor: grabbing;
}
.kanban-task.priority-high { border-left-color: #e74a3b; }
.kanban-task.priority-medium { border-left-color: #f6c23e; }
.kanban-task.priority-low { border-left-color: #1cc88a; }
.kanban-task.priority-urgent { border-left-color: #dc3545; font-weight: bold; }

.kanban-task .task-title {
    font-weight: 600;
    margin-bottom: 0.5rem;
}
.kanban-task .task-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 0.8rem;
    color: #858796;
    margin-top: 1rem;
}
.dragging {
    opacity: 0.5;
}
.drag-over {
    background-color: #e9ecef;
}
</style>

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <!-- Başlıklar header.php'den geliyor -->
    </div>
    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal">
        <i class="fas fa-plus me-2"></i>Yeni Görev Ekle
    </button>
</div>

<div class="kanban-board">
    <!-- Yapılacak Sütunu -->
    <div class="kanban-column">
        <div class="kanban-column-header text-secondary">
            <span><i class="fas fa-list-ul me-2"></i>Yapılacak</span>
            <span class="badge bg-secondary" id="todo-count">0</span>
        </div>
        <div class="kanban-tasks" id="todo" data-status="todo"></div>
    </div>

    <!-- Devam Ediyor Sütunu -->
    <div class="kanban-column">
        <div class="kanban-column-header text-primary">
            <span><i class="fas fa-project-diagram me-2"></i>Devam Ediyor</span>
            <span class="badge bg-primary" id="inprogress-count">0</span>
        </div>
        <div class="kanban-tasks" id="inprogress" data-status="inprogress"></div>
    </div>

    <!-- Tamamlandı Sütunu -->
    <div class="kanban-column">
        <div class="kanban-column-header text-success">
            <span><i class="fas fa-check-circle me-2"></i>Tamamlandı</span>
            <span class="badge bg-success" id="done-count">0</span>
        </div>
        <div class="kanban-tasks" id="done" data-status="done"></div>
    </div>

    <!-- Arşivlenmiş Sütunu -->
    <div class="kanban-column">
        <div class="kanban-column-header text-muted">
            <span><i class="fas fa-archive me-2"></i>Arşivlenmiş</span>
            <span class="badge bg-light text-dark" id="archived-count">0</span>
        </div>
        <div class="kanban-tasks" id="archived" data-status="archived"></div>
    </div>

    <!-- İptal Edilmiş Sütunu -->
    <div class="kanban-column">
        <div class="kanban-column-header text-danger">
            <span><i class="fas fa-times-circle me-2"></i>İptal Edilmiş</span>
            <span class="badge bg-danger" id="cancelled-count">0</span>
        </div>
        <div class="kanban-tasks" id="cancelled" data-status="cancelled"></div>
    </div>
</div>

<!-- Yeni Görev Ekleme Modal -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addTaskModalLabel">Yeni Görev Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="addTaskForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="taskTitle" class="form-label">Başlık</label>
                        <input type="text" class="form-control" id="taskTitle" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="taskDescription" class="form-label">Açıklama</label>
                        <textarea class="form-control" id="taskDescription" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="taskProjectId" class="form-label">Proje</label>
                        <select class="form-select" id="taskProjectId" name="project_id">
                            <option value="">Proje Seçiniz (Opsiyonel)...</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['project_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="taskAssignedTo" class="form-label">Atanan Kişi</label>
                            <select class="form-select" id="taskAssignedTo" name="assigned_to">
                                <option value="">Seçiniz...</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="taskDueDate" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="taskDueDate" name="due_date">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="taskPriority" class="form-label">Öncelik</label>
                            <select class="form-select" id="taskPriority" name="priority">
                                <option value="low">Düşük</option>
                                <option value="medium" selected>Orta</option>
                                <option value="high">Yüksek</option>
                                <option value="urgent">Acil</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="taskStatus" class="form-label">Durum</label>
                            <select class="form-select" id="taskStatus" name="status">
                                <option value="todo" selected>Yapılacak</option>
                                <option value="inprogress">Devam Ediyor</option>
                                <option value="done">Tamamlandı</option>
                                <option value="archived">Arşivlendi</option>
                                <option value="cancelled">İptal Edildi</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Görevi Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Görev Detay/Düzenleme Modal -->
<div class="modal fade" id="taskDetailModal" tabindex="-1" aria-labelledby="taskDetailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="taskDetailModalLabel">Görev Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
            </div>
            <form id="editTaskForm">
                <div class="modal-body">
                    <input type="hidden" id="editTaskId" name="id">
                    <div class="mb-3">
                        <label for="editTaskTitle" class="form-label">Başlık</label>
                        <input type="text" class="form-control" id="editTaskTitle" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="editTaskDescription" class="form-label">Açıklama</label>
                        <textarea class="form-control" id="editTaskDescription" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <label for="editTaskProjectId" class="form-label">Proje</label>
                        <select class="form-select" id="editTaskProjectId" name="project_id">
                            <option value="">Proje Seçiniz (Opsiyonel)...</option>
                            <?php foreach ($projects as $project): ?>
                                <option value="<?= $project['id'] ?>"><?= htmlspecialchars($project['project_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editTaskAssignedTo" class="form-label">Atanan Kişi</label>
                            <select class="form-select" id="editTaskAssignedTo" name="assigned_to">
                                <option value="">Seçiniz...</option>
                                <?php foreach ($users as $user): ?>
                                    <option value="<?= $user['id'] ?>"><?= htmlspecialchars($user['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editTaskDueDate" class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" id="editTaskDueDate" name="due_date">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="editTaskPriority" class="form-label">Öncelik</label>
                            <select class="form-select" id="editTaskPriority" name="priority">
                                <option value="low">Düşük</option>
                                <option value="medium">Orta</option>
                                <option value="high">Yüksek</option>
                                <option value="urgent">Acil</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label for="editTaskStatus" class="form-label">Durum</label>
                            <select class="form-select" id="editTaskStatus" name="status" disabled>
                                <option value="todo">Yapılacak</option>
                                <option value="inprogress">Devam Ediyor</option>
                                <option value="done">Tamamlandı</option>
                                <option value="archived">Arşivlendi</option>
                                <option value="cancelled">İptal Edildi</option>
                            </select>
                        </div>
                    </div>
                    <hr>
                    <!-- Dosyalar Bölümü -->
                    <div class="files-section mb-3">
                        <h6><i class="fas fa-paperclip me-2"></i>Ekli Dosyalar</h6>
                        <div id="filesList" class="mb-3">
                            <!-- Dosyalar buraya yüklenecek -->
                        </div>
                        <form id="uploadFileForm" enctype="multipart/form-data">
                            <input type="hidden" id="uploadFileTaskId" name="task_id">
                            <div class="input-group">
                                <input type="file" class="form-control" name="task_file" required>
                                <button class="btn btn-outline-secondary" type="submit">Yükle</button>
                            </div>
                            <div class="form-text">İzin verilen dosya türleri: PDF, DOC, DOCX, JPG, PNG. Maksimum boyut: 5MB.</div>
                        </form>
                    </div>
                    <hr>
                    <!-- Yorumlar Bölümü -->
                    <div class="comments-section">
                        <h6><i class="fas fa-comments me-2"></i>Yorumlar</h6>
                        <div id="commentsList" class="mb-3" style="max-height: 200px; overflow-y: auto; background-color: #f8f9fa; padding: 10px; border-radius: 5px;">
                            <!-- Yorumlar buraya yüklenecek -->
                        </div>
                        <form id="addCommentForm">
                            <input type="hidden" id="commentTaskId" name="task_id">
                            <div class="input-group">
                                <input type="text" class="form-control" name="comment" placeholder="Yorum ekle..." required>
                                <button class="btn btn-outline-primary" type="submit">Gönder</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger me-auto" id="deleteTaskBtn">Görevi Sil</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Değişiklikleri Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const columns = document.querySelectorAll('.kanban-tasks');
    let draggedTask = null;

    function loadTasks() {
        // Sütunları temizle
        columns.forEach(column => column.innerHTML = '');

        // Görevleri API'den çek
        $.ajax({
            url: '../api/tasks_api.php?action=list_all', // Tüm görevleri çekecek yeni bir action
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    response.data.forEach(task => {
                        const taskElement = createTaskElement(task);
                        const columnId = task.status;
                        document.getElementById(columnId).appendChild(taskElement);
                    });
                    updateTaskCounts();
                }
            }
        });
    }

    // Sürükle-Bırak olayları
    document.addEventListener('dragstart', function(e) {
        if (e.target.classList.contains('kanban-task')) {
            draggedTask = e.target;
            setTimeout(() => {
                e.target.classList.add('dragging');
            }, 0);
        }
    });

    document.addEventListener('dragend', function(e) {
        if (e.target.classList.contains('kanban-task')) {
            e.target.classList.remove('dragging');
            draggedTask = null;
        }
    });

    columns.forEach(column => {
        column.addEventListener('dragover', function(e) {
            e.preventDefault();
            this.classList.add('drag-over');
        });

        column.addEventListener('dragleave', function() {
            this.classList.remove('drag-over');
        });

        column.addEventListener('drop', function(e) {
            e.preventDefault();
            this.classList.remove('drag-over');
            if (draggedTask) {
                this.appendChild(draggedTask);
                const taskId = draggedTask.dataset.id;
                const newStatus = this.dataset.status;
                updateTaskStatus(taskId, newStatus);
            }
        });
    });

    function createTaskElement(task) {
        const div = document.createElement('div');
        div.classList.add('kanban-task', `priority-${task.priority}`);
        // Arşivlenmiş ve iptal edilmiş görevler sürüklenemez
        if (task.status !== 'archived' && task.status !== 'cancelled') {
            div.setAttribute('draggable', 'true');
        }
        div.dataset.id = task.id;

        const assignedUser = task.assigned_to_name ? `<i class="fas fa-user me-1"></i> ${task.assigned_to_name}` : '<i class="fas fa-user-slash me-1"></i> Atanmamış';
        const dueDate = task.due_date ? `<i class="fas fa-calendar-alt me-1"></i> ${moment(task.due_date).format('DD.MM.YYYY')}` : '';

        div.innerHTML = `
            <div class="task-title">${task.title}</div>
            <div class="task-description small">${task.description || ''}</div>
            <div class="task-footer mt-3">
                <span>${assignedUser}</span>
                <span>${dueDate}</span>
            </div>
        `;

        // Görev kartına tıklama olayı
        div.addEventListener('click', function(e) {
            e.preventDefault();
            viewTaskDetails(task.id);
        });
        return div;
    }

    function updateTaskCounts() {
        document.getElementById('todo-count').textContent = document.querySelectorAll('#todo .kanban-task').length;
        document.getElementById('inprogress-count').textContent = document.querySelectorAll('#inprogress .kanban-task').length;
        document.getElementById('done-count').textContent = document.querySelectorAll('#done .kanban-task').length;
        document.getElementById('archived-count').textContent = document.querySelectorAll('#archived .kanban-task').length;
        document.getElementById('cancelled-count').textContent = document.querySelectorAll('#cancelled .kanban-task').length;
    }

    function updateTaskStatus(taskId, newStatus) {
        $.ajax({
            url: '../api/tasks_api.php?action=update_status',
            type: 'POST',
            data: { id: taskId, status: newStatus },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    toastr.success(`Görev #${taskId} durumu güncellendi.`);
                    updateTaskCounts();
                }
            }
        });
    }

    // Görev ekleme formu
    $('#addTaskForm').on('submit', function(e) {
        e.preventDefault();
        sendAjaxRequest({
            url: '../api/tasks_api.php?action=create',
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#addTaskModal').modal('hide');
            this.reset();
            loadTasks();
        });
    });

    // Görev düzenleme formu
    $('#editTaskForm').on('submit', function(e) {
        e.preventDefault();
        sendAjaxRequest({
            url: '../api/tasks_api.php?action=update_task',
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#taskDetailModal').modal('hide');
            loadTasks();
        });
    });

    // Dosya yükleme formu
    $('#uploadFileForm').on('submit', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/tasks_api.php?action=upload_file',
            type: 'POST',
            data: new FormData(this),
            processData: false,
            contentType: false
        }, submitButton).then(() => {
            this.reset();
            viewTaskDetails($('#uploadFileTaskId').val()); // Dosya listesini yenile
        });
    });

    // Yorum ekleme formu
    $('#addCommentForm').on('submit', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        sendAjaxRequest({
            url: '../api/tasks_api.php?action=add_comment',
            type: 'POST',
            data: $(this).serialize()
        }, submitButton).then(() => {
            this.reset();
            viewTaskDetails($('#commentTaskId').val()); // Yorum listesini yenile
        });
    });

    // Görev silme butonu
    $('#deleteTaskBtn').on('click', function() {
        const taskId = $('#editTaskId').val();
        if (taskId) {
            handleDelete('../api/tasks_api.php?action=delete_task', taskId, null, 'Görevi Sil', 'Bu görevi kalıcı olarak silmek istediğinizden emin misiniz?')
                .then(() => {
                    $('#taskDetailModal').modal('hide');
                    loadTasks();
                });
        }
    });

    // Görev detaylarını görüntüleme
    function viewTaskDetails(taskId) {
        $.ajax({
            url: `../api/tasks_api.php?action=get_task&id=${taskId}`,
            type: 'GET',
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    const task = response.data;
                    $('#editTaskId').val(task.id);
                    $('#editTaskTitle').val(task.title);
                    $('#editTaskProjectId').val(task.project_id);
                    $('#editTaskDescription').val(task.description);
                    $('#editTaskAssignedTo').val(task.assigned_to);
                    $('#editTaskDueDate').val(task.due_date);
                    $('#editTaskPriority').val(task.priority);
                    $('#editTaskStatus').val(task.status);
                    
                    $('#taskDetailModal').modal('show');
                } else {
                    toastr.error(response.message || 'Görev detayları alınamadı.');
                }
            }
        });
    }

    // Global scope'a fonksiyonu ekle
    window.deleteTaskFile = function(fileId, taskId) {
        handleDelete('../api/tasks_api.php?action=delete_file', fileId, null, 'Dosyayı Sil', 'Bu dosyayı kalıcı olarak silmek istediğinizden emin misiniz?')
            .then(() => {
                viewTaskDetails(taskId); // Dosya listesini yenile
            });
    }

    loadTasks();
});
</script>
            </div>
        `;
        return div;
    }

    function updateTaskCounts() {
        document.getElementById('todo-count').textContent = document.querySelectorAll('#todo .kanban-task').length;
        document.getElementById('inprogress-count').textContent = document.querySelectorAll('#inprogress .kanban-task').length;
        document.getElementById('done-count').textContent = document.querySelectorAll('#done .kanban-task').length;
    }

    function updateTaskStatus(taskId, newStatus) {
        $.ajax({
            url: '../api/tasks_api.php?action=update_status',
            type: 'POST',
            data: { id: taskId, status: newStatus },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    toastr.success(`Görev #${taskId} durumu güncellendi.`);
                    updateTaskCounts();
                }
            }
        });
    }

    // Görev ekleme formu
    $('#addTaskForm').on('submit', function(e) {
        e.preventDefault();
        sendAjaxRequest({
            url: '../api/tasks_api.php?action=create',
            type: 'POST',
            data: $(this).serialize()
        }, $(this).find('button[type="submit"]')).then(() => {
            $('#addTaskModal').modal('hide');
            this.reset();
            loadTasks();
        });
    });

    loadTasks();
});
</script>