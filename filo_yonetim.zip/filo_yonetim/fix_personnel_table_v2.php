<?php
require_once 'includes/config.php';

try {
    // 1. Önce department sütununu ekleyelim
    $pdo->exec("ALTER TABLE `personnel` ADD COLUMN IF NOT EXISTS `department` VARCHAR(100) DEFAULT NULL AFTER `position`");
    
    // 2. Diğer eksik sütunları ekleyelim
    $alterQueries = [
        "ALTER TABLE `personnel` 
         ADD COLUMN IF NOT EXISTS `surname` VARCHAR(100) DEFAULT NULL AFTER `name`",
        
        "ALTER TABLE `personnel`
         ADD COLUMN IF NOT EXISTS `hire_date` DATE DEFAULT NULL AFTER `department`",
         
        "ALTER TABLE `personnel`
         MODIFY COLUMN `status` ENUM('active', 'on_leave', 'inactive', 'deleted') DEFAULT 'active'",
         
        "ALTER TABLE `personnel`
         ADD COLUMN IF NOT EXISTS `created_by` INT DEFAULT NULL AFTER `status`"
    ];
    
    echo "<h2>Tablo Yapısı Güncelleniyor</h2>";
    
    foreach ($alterQueries as $query) {
        echo "<p>Çalıştırılıyor: <code>" . htmlspecialchars($query) . "</code></p>";
        try {
            $pdo->exec($query);
            echo "<p style='color: green;'>Başarılı!</p>";
        } catch (PDOException $e) {
            echo "<p style='color: red;'>Hata: " . htmlspecialchars($e->getMessage()) . "</p>";
        }
    }
    
    echo "<h2>Güncel Tablo Yapısı</h2>";
    
    // Güncel tablo yapısını göster
    $stmt = $pdo->query("DESCRIBE personnel");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "<table border='1' cellpadding='5' cellspacing='0'>";
    echo "<tr><th>Alan</th><th>Tip</th><th>Boş Geçilebilir</th><th>Anahtar</th><th>Varsayılan</th><th>Ekstra</th></tr>";
    
    foreach ($columns as $column) {
        echo "<tr>";
        echo "<td>" . htmlspecialchars($column['Field']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Type']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Null']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Key']) . "</td>";
        echo "<td>" . htmlspecialchars($column['Default'] ?? 'NULL') . "</td>";
        echo "<td>" . htmlspecialchars($column['Extra'] ?? '') . "</td>";
        echo "</tr>";
    }
    
    echo "</table>";
    
    echo "<h3 style='color: green;'>Tablo yapısı başarıyla güncellendi!</h3>";
    
} catch (PDOException $e) {
    die("<p style='color: red;'>Hata oluştu: " . htmlspecialchars($e->getMessage()) . "</p>");
}
?>
