<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Set page variables for header
$page_title = 'Araç Yönetimi';
$page_subtitle = 'Araçlarınızı yönetin ve takip edin';

// Araçları listeleme ve istatistikler
try {
    $stmt = $pdo->query("SELECT v.*, 
        vm_last.maintenance_date as last_maintenance,
        vm_next.next_maintenance_date as next_maintenance,
        vf_last.fuel_date as last_fuel_date,
        vf_last.km_reading as current_km
    FROM vehicles v
    LEFT JOIN (SELECT vehicle_id, MAX(maintenance_date) as maintenance_date 
               FROM vehicle_maintenance WHERE status = 'completed' GROUP BY vehicle_id) vm_last 
               ON v.id = vm_last.vehicle_id
    LEFT JOIN (SELECT vehicle_id, MIN(next_maintenance_date) as next_maintenance_date 
               FROM vehicle_maintenance WHERE next_maintenance_date > CURDATE() GROUP BY vehicle_id) vm_next 
               ON v.id = vm_next.vehicle_id
    LEFT JOIN (SELECT vehicle_id, fuel_date, km_reading, ROW_NUMBER() OVER (PARTITION BY vehicle_id ORDER BY fuel_date DESC) as rn 
               FROM vehicle_fuel) vf_last ON v.id = vf_last.vehicle_id AND vf_last.rn = 1
    WHERE v.status != 'deleted'
    ORDER BY v.created_at DESC");
    $vehicles = $stmt->fetchAll();
    
    // Dashboard istatistikleri
    $stats = [
        'total' => count($vehicles),
        'active' => count(array_filter($vehicles, fn($v) => $v['status'] == 'active')),
        'maintenance' => count(array_filter($vehicles, fn($v) => $v['status'] == 'maintenance')),
        'inactive' => count(array_filter($vehicles, fn($v) => $v['status'] == 'inactive'))
    ];
} catch (Exception $e) {
    $vehicles = [];
    $stats = ['total' => 0, 'active' => 0, 'maintenance' => 0, 'inactive' => 0];
}

// Araç silme
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("UPDATE vehicles SET status = 'deleted' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: vehicles.php?success=deleted");
    exit();
}

// Include modern header
include 'includes/header.php';
?>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#addVehicleModal">
                            <i class="fas fa-plus-circle mb-1"></i>
                            <small>Yeni Araç</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-success w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#maintenanceModal">
                            <i class="fas fa-tools mb-1"></i>
                            <small>Bakım Ekle</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-info w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#fuelModal">
                            <i class="fas fa-gas-pump mb-1"></i>
                            <small>Yakıt Ekle</small>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- İstatistik Kartları -->
<div class="row mb-4">
    <div class="col-md-3 mb-3">
        <div class="card stats-card">
            <i class="fas fa-truck"></i>
            <h2><?= $stats['total'] ?></h2>
            <p>Toplam Araç</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stats-card">
            <i class="fas fa-check-circle text-success"></i>
            <h2><?= $stats['active'] ?></h2>
            <p>Aktif Araçlar</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stats-card">
            <i class="fas fa-tools text-warning"></i>
            <h2><?= $stats['maintenance'] ?></h2>
            <p>Bakımda</p>
        </div>
    </div>
    <div class="col-md-3 mb-3">
        <div class="card stats-card">
            <i class="fas fa-pause-circle text-secondary"></i>
            <h2><?= $stats['inactive'] ?></h2>
            <p>Pasif Araçlar</p>
        </div>
    </div>
</div>

<!-- Arama ve Filtre -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-search"></i></span>
            <input type="text" class="form-control" id="searchInput" placeholder="Araç ara (plaka, marka, model)...">
        </div>
    </div>
    <div class="col-md-6">
        <select class="form-select" id="statusFilter" onchange="filterVehicles(this.value)">
            <option value="all">Tüm Araçlar</option>
            <option value="active">Aktif Araçlar</option>
            <option value="maintenance">Bakımda</option>
            <option value="inactive">Pasif Araçlar</option>
        </select>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php
    switch ($_GET['success']) {
        case 'added': echo "Araç başarıyla eklendi!"; break;
        case 'updated': echo "Araç başarıyla güncellendi!"; break;
        case 'deleted': echo "Araç başarıyla silindi!"; break;
    }
    ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<div class="card mb-4">
    <div class="card-header">
        <h5 class="mb-0"><i class="fas fa-truck me-2"></i>Araç Listesi</h5>
    </div>
    <div class="card-body">
        <div class="row" id="vehiclesList">
            <?php if (empty($vehicles)): ?>
                <div class="col-12">
                    <div class="text-center py-5">
                        <i class="fas fa-truck fa-3x text-muted mb-3"></i>
                        <h5>Henüz araç kaydı bulunmuyor</h5>
                        <p class="text-muted">İlk aracınızı eklemek için "Yeni Araç" butonunu kullanın.</p>
                    </div>
                </div>
            <?php else: ?>
                <?php foreach ($vehicles as $vehicle): ?>
                <div class="col-xl-3 col-lg-4 col-md-6 mb-4 vehicle-item" data-status="<?= $vehicle['status'] ?>">
                    <div class="card h-100 <?php 
                        echo $vehicle['status'] == 'maintenance' ? 'border-warning' : 
                             ($vehicle['status'] == 'inactive' ? 'border-secondary' : 'border-success'); 
                    ?>">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-start mb-3">
                                <h5 class="card-title mb-0"><?= htmlspecialchars($vehicle['plate_number'] ?? $vehicle['plate']) ?></h5>
                                <span class="badge bg-<?php 
                                    echo $vehicle['status'] == 'active' ? 'success' : 
                                         ($vehicle['status'] == 'maintenance' ? 'warning' : 'secondary'); 
                                ?>">
                                    <?php 
                                    echo $vehicle['status'] == 'active' ? 'Aktif' : 
                                         ($vehicle['status'] == 'maintenance' ? 'Bakımda' : 'Pasif'); 
                                    ?>
                                </span>
                            </div>
                            
                            <div class="mb-3">
                                <small class="text-muted d-block">
                                    <i class="fas fa-car me-1"></i><?= htmlspecialchars($vehicle['brand']) ?> <?= htmlspecialchars($vehicle['model']) ?> (<?= $vehicle['year'] ?>)
                                </small>
                                <small class="text-muted d-block">
                                    <i class="fas fa-cogs me-1"></i><?= htmlspecialchars($vehicle['type']) ?>
                                </small>
                                <?php if ($vehicle['current_km']): ?>
                                <small class="text-muted d-block">
                                    <i class="fas fa-tachometer-alt me-1"></i><?= number_format($vehicle['current_km']) ?> km
                                </small>
                                <?php endif; ?>
                            </div>
                            
                            <?php if ($vehicle['next_maintenance'] && $vehicle['next_maintenance'] <= date('Y-m-d', strtotime('+30 days'))): ?>
                            <div class="alert alert-warning py-1 px-2 mb-2">
                                <i class="fas fa-exclamation-triangle me-1"></i>
                                <small>Bakım: <?= date('d.m.Y', strtotime($vehicle['next_maintenance'])) ?></small>
                            </div>
                            <?php endif; ?>
                            
                            <div class="d-flex gap-1 mt-auto">
                                <button class="btn btn-outline-primary btn-sm" onclick="viewVehicle(<?= $vehicle['id'] ?>)" title="Detay">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-outline-warning btn-sm" onclick="editVehicle(<?= $vehicle['id'] ?>)" title="Düzenle">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-outline-success btn-sm" onclick="addMaintenance(<?= $vehicle['id'] ?>)" title="Bakım">
                                    <i class="fas fa-tools"></i>
                                </button>
                                <button class="btn btn-outline-info btn-sm" onclick="addFuel(<?= $vehicle['id'] ?>)" title="Yakıt">
                                    <i class="fas fa-gas-pump"></i>
                                </button>
                                <button class="btn btn-outline-danger btn-sm" onclick="deleteVehicle(<?= $vehicle['id'] ?>)" title="Sil">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Yeni Araç Modal -->
<div class="modal fade" id="addVehicleModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yeni Araç Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addVehicleForm">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Plaka *</label>
                            <input type="text" class="form-control" name="plate" placeholder="34 ABC 123" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Araç Türü *</label>
                            <select class="form-select" name="type" required>
                                <option value="">Tür seçin</option>
                                <option value="Kamyon">Kamyon</option>
                                <option value="Kamyonet">Kamyonet</option>
                                <option value="Vinç">Vinç</option>
                                <option value="Kepçe">Kepçe</option>
                                <option value="Forklift">Forklift</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Marka</label>
                            <input type="text" class="form-control" name="brand" placeholder="Mercedes">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Model</label>
                            <input type="text" class="form-control" name="model" placeholder="Actros">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Yıl</label>
                            <input type="number" class="form-control" name="year" placeholder="2020" min="1900" max="2099">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Kilometre</label>
                            <input type="number" class="form-control" name="km_reading" placeholder="125000">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Yakıt Kapasitesi (L)</label>
                            <input type="number" class="form-control" name="fuel_capacity" placeholder="300">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Durum</label>
                            <select class="form-select" name="status">
                                <option value="active" selected>Aktif</option>
                                <option value="maintenance">Bakımda</option>
                                <option value="inactive">Pasif</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Sigorta Bitiş Tarihi</label>
                            <input type="date" class="form-control" name="insurance_expiry">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Muayene Bitiş Tarihi</label>
                            <input type="date" class="form-control" name="inspection_expiry">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Araç Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Bakım Ekleme Modal -->
<div class="modal fade" id="maintenanceModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Bakım Kaydı Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="maintenanceForm">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Araç Seçin *</label>
                            <select class="form-select" name="vehicle_id" required>
                                <option value="">Araç seçin</option>
                                <?php foreach ($vehicles as $vehicle): ?>
                                <option value="<?= $vehicle['id'] ?>"><?= htmlspecialchars($vehicle['plate']) ?> - <?= htmlspecialchars($vehicle['brand']) ?> <?= htmlspecialchars($vehicle['model']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Bakım Türü *</label>
                            <select class="form-select" name="maintenance_type" required>
                                <option value="">Bakım türü seçin</option>
                                <option value="Periyodik Bakım">Periyodik Bakım</option>
                                <option value="Motor Bakımı">Motor Bakımı</option>
                                <option value="Fren Sistemi">Fren Sistemi</option>
                                <option value="Lastik Değişimi">Lastik Değişimi</option>
                                <option value="Elektrik Sistemi">Elektrik Sistemi</option>
                                <option value="Hidrolik Sistem">Hidrolik Sistem</option>
                                <option value="Arıza Onarımı">Arıza Onarımı</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Bakım Tarihi *</label>
                            <input type="date" class="form-control" name="maintenance_date" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Sonraki Bakım Tarihi</label>
                            <input type="date" class="form-control" name="next_maintenance_date">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Kilometre</label>
                            <input type="number" class="form-control" name="km_reading" placeholder="Mevcut kilometre">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Maliyet (₺)</label>
                            <input type="number" step="0.01" class="form-control" name="cost" placeholder="0.00">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Servis Sağlayıcı</label>
                            <input type="text" class="form-control" name="service_provider" placeholder="Servis adı">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Durum</label>
                            <select class="form-select" name="status">
                                <option value="completed" selected>Tamamlandı</option>
                                <option value="scheduled">Planlandı</option>
                                <option value="overdue">Gecikmiş</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Açıklama</label>
                        <textarea class="form-control" name="description" rows="3" placeholder="Yapılan işlemler..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notlar</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="Ek notlar..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-success">Bakım Kaydı Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Yakıt Ekleme Modal -->
<div class="modal fade" id="fuelModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yakıt Kaydı Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="fuelForm">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Araç Seçin *</label>
                            <select class="form-select" name="vehicle_id" required>
                                <option value="">Araç seçin</option>
                                <?php foreach ($vehicles as $vehicle): ?>
                                <option value="<?= $vehicle['id'] ?>"><?= htmlspecialchars($vehicle['plate']) ?> - <?= htmlspecialchars($vehicle['brand']) ?> <?= htmlspecialchars($vehicle['model']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Yakıt Tarihi *</label>
                            <input type="date" class="form-control" name="fuel_date" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Litre *</label>
                            <input type="number" step="0.01" class="form-control" name="liters" placeholder="0.00" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Tutar (₺) *</label>
                            <input type="number" step="0.01" class="form-control" name="cost" placeholder="0.00" required>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Kilometre</label>
                            <input type="number" class="form-control" name="km_reading" placeholder="Mevcut kilometre">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Yakıt Türü</label>
                            <select class="form-select" name="fuel_type">
                                <option value="dizel" selected>Dizel</option>
                                <option value="benzin">Benzin</option>
                                <option value="lpg">LPG</option>
                                <option value="elektrik">Elektrik</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">İstasyon Adı</label>
                        <input type="text" class="form-control" name="station_name" placeholder="Shell, BP, Petrol Ofisi...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notlar</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="Ek notlar..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-info">Yakıt Kaydı Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Araç Detay Modal -->
<div class="modal fade" id="vehicleDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Araç Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="vehicleDetailContent">
                <!-- Dinamik içerik buraya yüklenecek -->
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Bugünün tarihini default olarak set et
    const today = new Date().toISOString().split('T')[0];
    document.querySelectorAll('input[type="date"]').forEach(input => {
        if (!input.value) input.value = today;
    });

    // Araç ekleme formu
    document.getElementById('addVehicleForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        // Form verilerini konsola yazdır (geliştirme amaçlı)
        console.log('Araç verisi:', Object.fromEntries(formData));
        
        // Başarı mesajı göster
        alert('Araç başarıyla eklendi! (Demo - Backend entegrasyonu gerekli)');
        bootstrap.Modal.getInstance(document.getElementById('addVehicleModal')).hide();
        this.reset();
    });

    // Bakım ekleme formu
    document.getElementById('maintenanceForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        console.log('Bakım verisi:', Object.fromEntries(formData));
        
        alert('Bakım kaydı başarıyla eklendi! (Demo - Backend entegrasyonu gerekli)');
        bootstrap.Modal.getInstance(document.getElementById('maintenanceModal')).hide();
        this.reset();
    });

    // Yakıt ekleme formu
    document.getElementById('fuelForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        console.log('Yakıt verisi:', Object.fromEntries(formData));
        
        alert('Yakıt kaydı başarıyla eklendi! (Demo - Backend entegrasyonu gerekli)');
        bootstrap.Modal.getInstance(document.getElementById('fuelModal')).hide();
        this.reset();
    });

    // Araç detay görüntüleme
    document.querySelectorAll('.view-vehicle').forEach(button => {
        button.addEventListener('click', function() {
            const vehicleId = this.dataset.id;
            
            // Modal içeriğini yükle
            document.getElementById('vehicleDetailContent').innerHTML = `
                <div class="text-center py-4">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Yükleniyor...</span>
                    </div>
                    <p class="mt-2">Araç detayları yükleniyor...</p>
                </div>
            `;
            
            // Modal'ı göster
            new bootstrap.Modal(document.getElementById('vehicleDetailModal')).show();
            
            // Simüle edilmiş detay yükleme (gerçek uygulamada AJAX ile)
            setTimeout(() => {
                document.getElementById('vehicleDetailContent').innerHTML = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Araç Bilgileri</h6>
                            <p><strong>Plaka:</strong> 34 ABC 123</p>
                            <p><strong>Marka/Model:</strong> Mercedes Actros</p>
                            <p><strong>Yıl:</strong> 2020</p>
                            <p><strong>Durum:</strong> <span class="badge bg-success">Aktif</span></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Son Bakım</h6>
                            <p><strong>Tarih:</strong> 15.08.2024</p>
                            <p><strong>Tür:</strong> Periyodik Bakım</p>
                            <p><strong>Sonraki:</strong> 15.11.2024</p>
                        </div>
                    </div>
                    <hr>
                    <p class="text-muted">Detaylı araç bilgileri için backend entegrasyonu gereklidir.</p>
                `;
            }, 1000);
        });
    });

    // Araç filtreleme fonksiyonları
    function filterVehicles(status) {
        const vehicles = document.querySelectorAll('.vehicle-item');
        vehicles.forEach(vehicle => {
            if (status === 'all') {
                vehicle.style.display = '';
            } else {
                const vehicleStatus = vehicle.getAttribute('data-status');
                vehicle.style.display = vehicleStatus === status ? '' : 'none';
            }
        });
    }

    // Araç işlem fonksiyonları
    function viewVehicle(id) {
        console.log('Araç görüntüleniyor:', id);
    }

    function editVehicle(id) {
        console.log('Araç düzenleniyor:', id);
    }

    function addMaintenance(id) {
        console.log('Bakım ekleniyor:', id);
    }

    function addFuel(id) {
        console.log('Yakıt ekleniyor:', id);
    }

    function deleteVehicle(id) {
        if (confirm('Bu aracı silmek istediğinizden emin misiniz?')) {
            window.location.href = 'vehicles.php?delete=' + id;
        }
    }

    function exportVehicles() {
        alert('Dışa aktarma özelliği yakında eklenecek');
    }

    function printVehicles() {
        window.print();
    }

    // Arama fonksiyonu
    document.addEventListener('DOMContentLoaded', function() {
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const vehicleItems = document.querySelectorAll('.vehicle-item');
                
                vehicleItems.forEach(item => {
                    const vehicleName = item.querySelector('.vehicle-name').textContent.toLowerCase();
                    const vehiclePlate = item.querySelector('.vehicle-plate').textContent.toLowerCase();
                    
                    if (vehicleName.includes(searchTerm) || vehiclePlate.includes(searchTerm)) {
                        item.style.display = '';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        }
    });

    // Araç silme onayı
    document.querySelectorAll('.delete-vehicle').forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Bu aracı silmek istediğinize emin misiniz?')) {
                e.preventDefault();
            }
        });
    });
});
</script>

<?php include 'includes/footer.php'; ?>