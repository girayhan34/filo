<?php
session_start();
// Güvenlik kontrolü için oturum yönetimini dahil et
require_once 'includes/auth.php';
// Veritabanı ve genel fonksiyonları dahil et
require_once 'includes/config.php';
require_once 'includes/functions.php';

$page_title = "Filo Yönetim Sistemi | Dashboard";
include 'includes/header.php';

// Dashboard verilerini çekme
try {
    // Toplam Araç Sayısı
    $stmt_vehicles = $pdo->query("SELECT COUNT(*) FROM vehicles WHERE status = 'active'");
    $total_vehicles = $stmt_vehicles->fetchColumn();

    // Toplam Müşteri Sayısı
    $stmt_customers = $pdo->query("SELECT COUNT(*) FROM customers WHERE status = 'active'");
    $total_customers = $stmt_customers->fetchColumn();

    // Toplam Fatura Sayısı
    $stmt_invoices = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status = 'pending'");
    $total_invoices_pending = $stmt_invoices->fetchColumn();

    // Toplam Görev Sayısı
    $stmt_tasks = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'in-progress' OR status = 'pending'");
    $total_tasks = $stmt_tasks->fetchColumn();
    
    // Son 5 Görev
    $stmt_recent_tasks = $pdo->query("SELECT * FROM tasks ORDER BY created_at DESC LIMIT 5");
    $recent_tasks = $stmt_recent_tasks->fetchAll();

} catch (PDOException $e) {
    echo "Veritabanı hatası: " . $e->getMessage();
    $total_vehicles = 0;
    $total_customers = 0;
    $total_invoices_pending = 0;
    $total_tasks = 0;
    $recent_tasks = [];
}
?>

<!-- Sidebar Menü (Eksiksiz, sadece ikinci menü) -->
<div class="sidebar">
    <div class="sidebar-logo text-center py-3 border-bottom">
        <img src="https://via.placeholder.com/80/2c3e50/ffffff?text=GYS" alt="Logo">
        <h5 class="mt-2 mb-0">Gaval Yönetim Sistemi</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a class="nav-link active" href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Pano</a></li>
        <li class="nav-item"><a class="nav-link" href="invoices.php"><i class="fas fa-file-invoice"></i> Faturalar</a></li>
        <li class="nav-item"><a class="nav-link" href="income_expense.php"><i class="fas fa-money-bill-wave"></i> Gelir-Gider</a></li>
        <li class="nav-item"><a class="nav-link" href="payments.php"><i class="fas fa-credit-card"></i> Ödemeler</a></li>
        <li class="nav-item"><a class="nav-link" href="collections.php"><i class="fas fa-cash-register"></i> Tahsilat</a></li>
        <li class="nav-item"><a class="nav-link" href="customers.php"><i class="fas fa-users"></i> Müşteriler</a></li>
        <li class="nav-item"><a class="nav-link" href="reports.php"><i class="fas fa-chart-bar"></i> Rapor</a></li>
        <li class="nav-item"><a class="nav-link" href="vehicles.php"><i class="fas fa-truck"></i> Araçlar</a></li>
        <li class="nav-item"><a class="nav-link" href="personnel.php"><i class="fas fa-user-tie"></i> Personel</a></li>
        <li class="nav-item"><a class="nav-link" href="receipts.php"><i class="fas fa-receipt"></i> Fişler</a></li>
        <li class="nav-item"><a class="nav-link" href="tasks.php"><i class="fas fa-tasks"></i> Görevler</a></li>
        <li class="nav-item"><a class="nav-link" href="todo.php"><i class="fas fa-clipboard-list"></i> Yapılacaklar</a></li>
        <li class="nav-item"><a class="nav-link" href="stock.php"><i class="fas fa-warehouse"></i> Stok Yönetimi</a></li>
        <li class="nav-item"><a class="nav-link" href="projects.php"><i class="fas fa-project-diagram"></i> Proje Yönetimi</a></li>
        <li class="nav-item"><a class="nav-link" href="contracts.php"><i class="fas fa-file-contract"></i> Sözleşmeler</a></li>
        <li class="nav-item"><a class="nav-link" href="maintenance.php"><i class="fas fa-tools"></i> Araç Bakım</a></li>
        <li class="nav-item"><a class="nav-link" href="dispatches.php"><i class="fas fa-truck-loading"></i> İrsaliyeler</a></li>
        <li class="nav-item"><a class="nav-link" href="cash.php"><i class="fas fa-cash-register"></i> Kasa</a></li>
        <li class="nav-item"><a class="nav-link" href="route_optimization.php"><i class="fas fa-route"></i> Rota Optimizasyonu</a></li>
        <li class="nav-item"><a class="nav-link" href="vehicle_tracking.php"><i class="fas fa-map-marker-alt"></i> Araç Takip</a></li>
        <li class="nav-item"><a class="nav-link" href="documents.php"><i class="fas fa-folder"></i> Doküman Yönetimi</a></li>
        <li class="nav-item"><a class="nav-link" href="notifications.php"><i class="fas fa-bell"></i> Bildirimler</a></li>
        <li class="nav-item"><a class="nav-link" href="settings.php"><i class="fas fa-cogs"></i> Ayarlar</a></li>
        <li class="nav-item mt-4"><a class="nav-link" href="logout.php"><i class="fas fa-sign-out-alt"></i> Çıkış</a></li>
    </ul>
</div>

<div class="content-section active" id="dashboardSection">
    <div class="container-fluid">
    </div>
</div>

<!-- Yeni Görev Ekleme Modalı -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
    </div>
</div>

<?php include 'includes/footer.php'; ?>
