<?php
session_start();
// Veritabanı bağlantısı
require_once 'includes/config.php';
require_once 'includes/functions.php';

$page_title = "Pano";

// İstatistikleri veritabanından al
try {
    $total_customers = $pdo->query("SELECT COUNT(*) FROM customers WHERE status = 'active'")->fetchColumn();
    $total_vehicles = $pdo->query("SELECT COUNT(*) FROM vehicles WHERE status = 'active'")->fetchColumn();
    $active_vehicles = $pdo->query("SELECT COUNT(*) FROM vehicles WHERE status = 'active' AND availability = 'available'")->fetchColumn();
    
    // Son faturalar
    $stmt = $pdo->query("SELECT i.*, c.name as customer_name 
                         FROM invoices i 
                         LEFT JOIN customers c ON i.customer_id = c.id 
                         ORDER BY i.created_at DESC 
                         LIMIT 5");
    $recent_invoices = $stmt->fetchAll();
    
    // Yaklaşan ödemeler
    $stmt = $pdo->query("SELECT * FROM payments 
                         WHERE status = 'pending' AND due_date <= DATE_ADD(CURDATE(), INTERVAL 7 DAY)
                         ORDER BY due_date ASC 
                         LIMIT 5");
    $upcoming_payments = $stmt->fetchAll();
} catch (Exception $e) {
    // Veritabanı hatası durumunda varsayılan değerler
    $total_customers = 0;
    $total_vehicles = 0;
    $active_vehicles = 0;
    $recent_invoices = [];
    $upcoming_payments = [];
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> | Filo Yönetim Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Ana Uygulama -->
    <div id="appScreen">
        <!-- Sidebar - Orijinal menü yapısı -->
        <div class="sidebar">
            <div class="position-sticky">
                <div class="text-center mb-4">
                    <h5 class="text-white">Filo Yönetim Sistemi</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php" data-section="dashboard">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Pano</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="invoices.php" data-section="invoices">
                            <i class="fas fa-file-invoice"></i>
                            <span>Faturalar</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="income_expense.php" data-section="incomeExpense">
                            <i class="fas fa-money-bill-wave"></i>
                            <span>Gelir-Gider</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payments.php" data-section="payments">
                            <i class="fas fa-credit-card"></i>
                            <span>Ödemeler</span>
                            <span class="notification-badge">3</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="collections.php" data-section="collections">
                            <i class="fas fa-cash-register"></i>
                            <span>Tahsilat</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="customers.php" data-section="customers">
                            <i class="fas fa-users"></i>
                            <span>Müşteriler</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php" data-section="reports">
                            <i class="fas fa-chart-bar"></i>
                            <span>Rapor</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="vehicles.php" data-section="vehicles">
                            <i class="fas fa-truck"></i>
                            <span>Araçlar</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="personnel.php" data-section="personnel">
                            <i class="fas fa-user-tie"></i>
                            <span>Personel</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="receipts.php" data-section="receipts">
                            <i class="fas fa-receipt"></i>
                            <span>Fişler</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="tasks.php" data-section="tasks">
                            <i class="fas fa-tasks"></i>
                            <span>Görevler</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="todo.php" data-section="todo">
                            <i class="fas fa-clipboard-list"></i>
                            <span>Yapılacaklar</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="settings.php" data-section="settings">
                            <i class="fas fa-cogs"></i>
                            <span>Ayarlar</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <button class="btn btn-sm btn-light mobile-menu-btn" id="mobileMenuToggle" style="display: none;">
                    <i class="fas fa-bars"></i>
                </button>
                
                <button class="btn btn-sm btn-light" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="d-flex align-items-center ms-auto">
                    <div class="search-container me-3" style="max-width: 300px;">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-sm" placeholder="Ara..." id="globalSearch">
                            <button class="btn btn-primary btn-sm" id="searchButton">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button class="btn btn-sm btn-light d-lg-none" id="mobileSearchToggle">
                        <i class="fas fa-search"></i>
                    </button>
                    
                    <div class="dropdown ms-3">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="assets/images/user.png" alt="Kullanıcı" width="40" height="40" class="rounded-circle me-2">
                            <span class="d-none d-md-inline">Misafir Kullanıcı</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser">
                            <li><a class="dropdown-item" href="#" id="highContrastToggle">Yüksek Kontrast</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="main-content">
            <!-- Pano Section -->
            <div class="content-section active" id="dashboardSection">
                <div class="container-fluid">
                    <div class="row mb-4">
                        <div class="col-12">
                            <h1 class="h4">Pano</h1>
                            <p class="text-muted">Firma performans özeti ve önemli istatistikler</p>
                        </div>
                    </div>
                    
                    <!-- İstatistik Kartları -->
                    <div class="row">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-money-bill-wave"></i>
                                <h2>142.850₺</h2>
                                <p>Aylık Gelir</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-credit-card"></i>
                                <h2>87.300₺</h2>
                                <p>Aylık Gider</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-file-invoice"></i>
                                <h2>48</h2>
                                <p>Bekleyen Faturalar</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-truck"></i>
                                <h2><?php echo $active_vehicles . '/' . $total_vehicles; ?></h2>
                                <p>Aktif Araçlar</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Gelir-Gider ve Tahsilat Kartları -->
                    <div class="row">
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-cash-register"></i>
                                <h2>68.500₺</h2>
                                <p>Aylık Tahsilat</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-hand-holding-usd"></i>
                                <h2>55.550₺</h2>
                                <p>Net Kâr</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-chart-pie"></i>
                                <h2>62%</h2>
                                <p>Kâr Marjı</p>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card stats-card">
                                <i class="fas fa-exclamation-triangle"></i>
                                <h2>7</h2>
                                <p>Gecikmiş Ödemeler</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Grafik ve Tablolar -->
                    <div class="row">
                        <div class="col-xl-8 col-lg-7">
                            <div class="card mb-4">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="fas fa-chart-line me-2"></i>
                                        Aylık Gelir-Gider Analizi
                                    </div>
                                    <div>
                                        <select class="form-select form-select-sm" id="financeChartRange">
                                            <option>Son 6 Ay</option>
                                            <option>Son 1 Yıl</option>
                                            <option>Son 2 Yıl</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="chart-container">
                                        <canvas id="financeChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-xl-4 col-lg-5">
                            <div class="card mb-4">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="fas fa-exclamation-circle me-2"></i>
                                        Yaklaşan Ödemeler
                                    </div>
                                    <div>
                                        <a href="payments.php" class="btn btn-sm btn-outline-primary">Tümü</a>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <ul class="list-group list-group-flush">
                                        <?php if (count($upcoming_payments) > 0): ?>
                                            <?php foreach ($upcoming_payments as $payment): ?>
                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                <div>
                                                    <h6 class="mb-0"><?php echo $payment['payment_no']; ?></h6>
                                                    <small class="text-muted"><?php echo $payment['creditor']; ?></small>
                                                </div>
                                                <div class="text-end">
                                                    <div class="fw-bold"><?php echo number_format($payment['amount'], 2, ',', '.'); ?>₺</div>
                                                    <span class="badge bg-warning">
                                                        <?php 
                                                        $due_date = new DateTime($payment['due_date']);
                                                        $today = new DateTime();
                                                        $diff = $today->diff($due_date);
                                                        echo $diff->days == 0 ? 'Bugün' : $diff->days . ' Gün';
                                                        ?>
                                                    </span>
                                                </div>
                                            </li>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <li class="list-group-item text-center text-muted">
                                                Yaklaşan ödeme bulunmamaktadır.
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                            
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-truck me-2"></i>
                                    Araç Durumu
                                </div>
                                <div class="card-body">
                                    <div class="d-flex justify-content-between mb-3">
                                        <div class="text-center">
                                            <h4 class="mb-0">8</h4>
                                            <small class="text-muted">Vinç</small>
                                        </div>
                                        <div class="text-center">
                                            <h4 class="mb-0">6</h4>
                                            <small class="text-muted">Kepçe</small>
                                        </div>
                                        <div class="text-center">
                                            <h4 class="mb-0">10</h4>
                                            <small class="text-muted">Nakliye</small>
                                        </div>
                                        <div class="text-center">
                                            <h4 class="mb-0">8</h4>
                                            <small class="text-muted">Forklift</small>
                                        </div>
                                    </div>
                                    <div class="progress mb-2">
                                        <div class="progress-bar bg-success" role="progressbar" style="width: 75%" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100"></div>
                                    </div>
                                    <p class="text-muted small mb-0">32 araçtan 24'ü aktif (%75)</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Bakım Takip ve Konum -->
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-tools me-2"></i>
                                    Bakım Takvimi
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="mb-0">34 ABC 123 - Vinç</h6>
                                            <span class="badge bg-warning">Bakım Gerekli</span>
                                        </div>
                                        <div class="progress maintenance-progress mb-3">
                                            <div class="progress-bar bg-warning" role="progressbar" style="width: 85%" aria-valuenow="85" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="mb-0">35 DEF 456 - Kepçe</h6>
                                            <span class="badge bg-success">İyi Durumda</span>
                                        </div>
                                        <div class="progress maintenance-progress mb-3">
                                            <div class="progress-bar bg-success" role="progressbar" style="width: 35%" aria-valuenow="35" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="mb-0">34 GHI 789 - Forklift</h6>
                                            <span class="badge bg-danger">Acil Bakım</span>
                                        </div>
                                        <div class="progress maintenance-progress mb-3">
                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 95%" aria-valuenow="95" aria-valuemin="0" aria-valuemax="100"></div>
                                        </div>
                                    </div>
                                    
                                    <a href="vehicles.php" class="btn btn-sm btn-outline-primary w-100">Tüm Bakım Kayıtları</a>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-lg-6">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-map-marker-alt me-2"></i>
                                    Araç Konumları
                                </div>
                                <div class="card-body">
                                    <div class="map-container mb-3">
                                        <!-- Harita görüntüsü simülasyonu -->
                                        <div style="width:100%; height:100%; background:#e9ecef; display:flex; align-items:center; justify-content:center; color:#6c757d;">
                                            <i class="fas fa-map-marked-alt fa-3x"></i>
                                        </div>
                                    </div>
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h6 class="mb-0">Aktif Araçlar: <span class="text-success">24</span></h6>
                                            <small class="text-muted">Şu anda hareket halinde</small>
                                        </div>
                                        <div>
                                            <h6 class="mb-0">Park Halinde: <span class="text-warning">8</span></h6>
                                            <small class="text-muted">Beklemede</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Görev Takip -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card mb-4">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <div>
                                        <i class="fas fa-tasks me-2"></i>
                                        Görev Listesi
                                    </div>
                                    <div>
                                        <button class="btn btn-sm btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                                            <i class="fas fa-plus me-1"></i> Yeni Görev
                                        </button>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="task-item urgent">
                                                <h6>34 ABC 123 Bakımı</h6>
                                                <p class="small mb-1">Vinç bakımı için randevu oluşturulması gerekiyor</p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-danger">Acil</span>
                                                    <small class="text-muted">Bugün</small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="task-item">
                                                <h6>Müşteri Ziyareti</h6>
                                                <p class="small mb-1">ABC İnşaat için yeni teklif hazırlanması</p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-primary">Orta</span>
                                                    <small class="text-muted">2 Gün</small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="task-item completed">
                                                <h6>Fatura Tahsilatı</h6>
                                                <p class="small mb-1">Demirtaş Nakliyat faturasının tahsilatı</p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-success">Tamamlandı</span>
                                                    <small class="text-muted">Dün</small>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="task-item">
                                                <h6>Yakıt Alımı</h6>
                                                <p class="small mb-1">Tüm araçlar için yakıt alımı yapılacak</p>
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <span class="badge bg-warning">Düşük</span>
                                                    <small class="text-muted">3 Gün</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal'lar -->
    <!-- Yeni Görev Modal -->
    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Yeni Görev Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addTaskForm">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Görev Başlığı</label>
                                <input type="text" class="form-control" placeholder="Görev başlığı" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Öncelik</label>
                                <select class="form-select" required>
                                    <option value="low">Düşük</option>
                                    <option value="medium" selected>Orta</option>
                                    <option value="high">Yüksek</option>
                                    <option value="urgent">Acil</option>
                                </select>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Başlangıç Tarihi</label>
                                <input type="date" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Bitiş Tarihi</label>
                                <input type="date" class="form-control" required>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Açıklama</label>
                            <textarea class="form-control" rows="3" required></textarea>
                        </div>
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label class="form-label">Atanan Personel</label>
                                <select class="form-select" required>
                                    <option value="">Personel seçin</option>
                                    <option value="1">Mehmet Kaya</option>
                                    <option value="2">Ayşe Demir</option>
                                    <option value="3">Ali Yıldız</option>
                                    <option value="4">Zeynep Çelik</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Durum</label>
                                <select class="form-select" required>
                                    <option value="pending">Beklemede</option>
                                    <option value="in-progress">Devam Ediyor</option>
                                    <option value="completed">Tamamlandı</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="button" class="btn btn-primary">Görev Oluştur</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="assets/js/script.js"></script>
    <script>
        // Finans grafiği
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('financeChart').getContext('2d');
            var financeChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: ['Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim'],
                    datasets: [{
                        label: 'Gelir',
                        data: [120000, 125000, 130000, 118000, 135000, 142000, 150000, 145000, 138000, 142850],
                        backgroundColor: 'rgba(52, 152, 219, 0.7)',
                        borderColor: 'rgba(52, 152, 219, 1)',
                        borderWidth: 1
                    },
                    {
                        label: 'Gider',
                        data: [85000, 88000, 92000, 95000, 89000, 93000, 102000, 98000, 91000, 87300],
                        backgroundColor: 'rgba(231, 76, 60, 0.7)',
                        borderColor: 'rgba(231, 76, 60, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: function(value) {
                                    return value.toLocaleString('tr-TR') + '₺';
                                }
                            }
                        }
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: function(context) {
                                    return context.dataset.label + ': ' + context.raw.toLocaleString('tr-TR') + '₺';
                                }
                            }
                        }
                    }
                }
            });
        });
    </script>
</body>
</html>