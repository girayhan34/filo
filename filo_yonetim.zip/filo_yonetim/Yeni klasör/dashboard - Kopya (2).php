<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filo Yönetim Sistemi | Kiralama ve Nakliye Hizmetleri</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c3e50;
            --secondary: #3498db;
            --accent: #e74c3c;
            --light: #ecf0f1;
            --dark: #2c3e50;
            --success: #2ecc71;
            --warning: #f39c12;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            color: #333;
        }

        .sidebar {
            background-color: var(--primary);
            color: white;
            height: 100vh;
            position: fixed;
            padding-top: 60px;
            overflow-y: auto;
            width: 250px;
            z-index: 1000;
            transition: width 0.3s ease;
        }
        .sidebar-item {
            padding: 15px 20px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .sidebar-item:hover, .sidebar-item.active {
            background-color: #34495e;
            color: #ecf0f1;
        }
        .sidebar-item a {
            color: white;
            text-decoration: none;
            display: block;
        }
        .sidebar-item i {
            margin-right: 15px;
            font-size: 1.2em;
        }
        .sidebar-header {
            text-align: center;
            padding: 20px 0;
            font-size: 1.5em;
            font-weight: bold;
            color: #f1c40f;
        }

        #content-wrapper {
            margin-left: 250px;
            padding: 20px;
            transition: margin-left 0.3s ease;
        }

        body.sidebar-collapsed .sidebar {
            width: 70px;
        }
        body.sidebar-collapsed #content-wrapper {
            margin-left: 70px;
        }
        .sidebar-collapsed .sidebar-item span, .sidebar-collapsed .sidebar-header {
            display: none;
        }
        .sidebar-collapsed .sidebar-item i {
            margin-right: 0;
            text-align: center;
            width: 100%;
        }

        .navbar {
            background-color: white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            position: fixed;
            width: 100%;
            z-index: 999;
            top: 0;
            left: 0;
        }
        .navbar .container-fluid {
            padding-left: 270px;
            transition: padding-left 0.3s ease;
        }
        .sidebar-collapsed .navbar .container-fluid {
            padding-left: 90px;
        }
        .search-bar input {
            border-radius: 20px;
            padding-left: 35px;
            background-color: #f1f3f4;
            border: none;
        }
        .search-bar .fa-search {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
        }

        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        .card-header {
            background-color: var(--primary);
            color: white;
            border-top-left-radius: 10px;
            border-top-right-radius: 10px;
            border-bottom: none;
        }
        .stat-card {
            background-color: #fff;
            color: var(--primary);
            text-align: center;
            padding: 20px;
        }
        .stat-card .stat-icon {
            font-size: 2.5em;
            margin-bottom: 10px;
            color: var(--secondary);
        }
        .stat-card .stat-value {
            font-size: 2em;
            font-weight: bold;
        }
        .stat-card .stat-label {
            font-size: 1em;
            color: #777;
        }

        /* Responsive */
        @media (max-width: 991.98px) {
            .sidebar {
                left: -250px;
                transition: left 0.3s ease;
            }
            .sidebar.mobile-visible {
                left: 0;
            }
            #content-wrapper {
                margin-left: 0;
            }
            .navbar .container-fluid {
                padding-left: 15px;
            }
            .sidebar-collapsed .navbar .container-fluid {
                padding-left: 15px;
            }
            .navbar-brand, .user-profile {
                display: none;
            }
            .mobile-menu-toggle {
                display: block !important;
            }
            .search-bar {
                display: none;
                position: absolute;
                top: 60px;
                left: 0;
                width: 100%;
                background-color: white;
                padding: 10px;
                box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .navbar.mobile-search-visible .search-bar {
                display: block;
            }
        }
        @media (min-width: 992px) {
            .mobile-menu-toggle {
                display: none !important;
            }
        }
        .table .action-btns .btn {
            padding: 5px 10px;
            font-size: 0.9em;
        }
        .table-responsive {
            overflow-x: auto;
        }
    </style>
</head>
<body>

    <div class="sidebar d-flex flex-column" id="sidebar">
        <div class="sidebar-header">
            Filo Yönetimi
        </div>
        <ul class="nav flex-column flex-grow-1">
            <li class="nav-item sidebar-item active" data-target="dashboard">
                <a class="nav-link" href="#"><i class="fas fa-home"></i> <span>Dashboard</span></a>
            </li>
            <li class="nav-item sidebar-item" data-target="vehicles">
                <a class="nav-link" href="#"><i class="fas fa-car"></i> <span>Araçlar</span></a>
            </li>
            <li class="nav-item sidebar-item" data-target="rentals">
                <a class="nav-link" href="#"><i class="fas fa-clipboard-list"></i> <span>Kiralamalar</span></a>
            </li>
            <li class="nav-item sidebar-item" data-target="tasks">
                <a class="nav-link" href="#"><i class="fas fa-tasks"></i> <span>Görevler</span></a>
            </li>
            <li class="nav-item sidebar-item" data-target="reports">
                <a class="nav-link" href="#"><i class="fas fa-chart-line"></i> <span>Raporlar</span></a>
            </li>
            <li class="nav-item sidebar-item" data-target="settings">
                <a class="nav-link" href="#"><i class="fas fa-cogs"></i> <span>Ayarlar</span></a>
            </li>
        </ul>
        <div class="mt-auto p-3">
            <a href="#" class="btn btn-danger w-100"><i class="fas fa-sign-out-alt"></i> Çıkış</a>
        </div>
    </div>

    <nav class="navbar navbar-expand-lg">
        <div class="container-fluid">
            <a class="navbar-brand d-none d-lg-block" href="#">
                <img src="https://via.placeholder.com/150x50" alt="Logo" height="30">
            </a>
            <button class="btn btn-link d-none d-lg-block" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <button class="btn btn-link d-lg-none mobile-menu-toggle" id="mobileMenuToggle">
                <i class="fas fa-bars"></i>
            </button>
            <div class="flex-grow-1 ms-3">
                <div class="position-relative search-bar d-none d-md-block">
                    <i class="fas fa-search position-absolute"></i>
                    <input class="form-control me-2" type="search" placeholder="Ara..." aria-label="Search">
                </div>
            </div>
            <div class="d-flex align-items-center">
                <button class="btn btn-link d-lg-none" id="mobileSearchToggle">
                    <i class="fas fa-search"></i>
                </button>
                <button class="btn btn-link mx-2">
                    <i class="fas fa-bell"></i>
                </button>
                <div class="dropdown">
                    <a href="#" class="d-block link-body-emphasis text-decoration-none" data-bs-toggle="dropdown" aria-expanded="false">
                        <img src="https://github.com/mdo.png" alt="mdo" width="32" height="32" class="rounded-circle">
                    </a>
                    <ul class="dropdown-menu text-small shadow">
                        <li><a class="dropdown-item" href="#">Yeni Proje...</a></li>
                        <li><a class="dropdown-item" href="#">Ayarlar</a></li>
                        <li><a class="dropdown-item" href="#">Profil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#">Çıkış Yap</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <div id="content-wrapper">
        <div id="page-content" data-page="dashboard" class="content-section active">
            <div class="container-fluid">
                <h1 class="mt-4">Dashboard</h1>
                <hr>
                <div class="row">
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="stat-icon"><i class="fas fa-car-side"></i></div>
                                <div class="stat-value">124</div>
                                <div class="stat-label">Aktif Araç</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="stat-icon"><i class="fas fa-road"></i></div>
                                <div class="stat-value">45</div>
                                <div class="stat-label">Devam Eden Sefer</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                                <div class="stat-value">550,000 TL</div>
                                <div class="stat-label">Aylık Gelir</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card stat-card">
                            <div class="card-body">
                                <div class="stat-icon"><i class="fas fa-user-friends"></i></div>
                                <div class="stat-value">32</div>
                                <div class="stat-label">Yeni Müşteri</div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                Son Faaliyetler
                            </div>
                            <div class="card-body">
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Araç (34 ABC 123) için bakım görevi oluşturuldu.
                                        <span class="badge bg-primary">Bugün</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Yeni araç (34 XYZ 456) filoya eklendi.
                                        <span class="badge bg-success">Dün</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Ahmet Yılmaz'a yeni kiralama yapıldı.
                                        <span class="badge bg-secondary">2 gün önce</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between align-items-center">
                                        Yakıt takibi yapıldı (34 ABC 123).
                                        <span class="badge bg-info">1 hafta önce</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                Yaklaşan Görevler
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th scope="col">Görev</th>
                                                <th scope="col">Atanan</th>
                                                <th scope="col">Son Tarih</th>
                                                <th scope="col">Durum</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <th scope="row">1</th>
                                                <td>Motor Bakımı</td>
                                                <td>Mehmet Can</td>
                                                <td>15.09.2023</td>
                                                <td><span class="badge bg-warning">Bekliyor</span></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">2</th>
                                                <td>Lastik Değişimi</td>
                                                <td>Ayşe Demir</td>
                                                <td>20.09.2023</td>
                                                <td><span class="badge bg-warning">Bekliyor</span></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">3</th>
                                                <td>Rutin Kontrol</td>
                                                <td>Ali Veli</td>
                                                <td>25.09.2023</td>
                                                <td><span class="badge bg-success">Tamamlandı</span></td>
                                            </tr>
                                            <tr>
                                                <th scope="row">4</th>
                                                <td>Kaza Raporu</td>
                                                <td>Mehmet Can</td>
                                                <td>30.09.2023</td>
                                                <td><span class="badge bg-danger">Geçmiş</span></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <div id="page-content" data-page="vehicles" class="content-section d-none">
            <div class="container-fluid">
                <h1 class="mt-4">Araç Listesi</h1>
                <hr>
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Yeni Araç Ekle</button>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Plaka</th>
                                        <th>Marka/Model</th>
                                        <th>Yıl</th>
                                        <th>Durum</th>
                                        <th>Kilometre</th>
                                        <th>Son Bakım</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>34 ABC 123</td>
                                        <td>Mercedes Actros</td>
                                        <td>2021</td>
                                        <td><span class="badge bg-success">Uygun</span></td>
                                        <td>155,000 km</td>
                                        <td>20.08.2023</td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-eye"></i></button>
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>06 DEF 456</td>
                                        <td>Ford Transit</td>
                                        <td>2018</td>
                                        <td><span class="badge bg-danger">Arızalı</span></td>
                                        <td>210,500 km</td>
                                        <td>10.05.2023</td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-eye"></i></button>
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>42 GHI 789</td>
                                        <td>Renault Master</td>
                                        <td>2023</td>
                                        <td><span class="badge bg-primary">Seferde</span></td>
                                        <td>15,000 km</td>
                                        <td>Yeni</td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-eye"></i></button>
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>27 JKL 012</td>
                                        <td>Volvo FH</td>
                                        <td>2020</td>
                                        <td><span class="badge bg-success">Uygun</span></td>
                                        <td>320,000 km</td>
                                        <td>01.07.2023</td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-eye"></i></button>
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-edit"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="page-content" data-page="rentals" class="content-section d-none">
            <div class="container-fluid">
                <h1 class="mt-4">Kiralama ve Nakliye İşlemleri</h1>
                <hr>
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Yeni İşlem Başlat</button>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>İşlem No</th>
                                        <th>Müşteri</th>
                                        <th>Araç Plaka</th>
                                        <th>Başlangıç Tarihi</th>
                                        <th>Bitiş Tarihi</th>
                                        <th>Toplam Tutar</th>
                                        <th>Durum</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>RNT-00125</td>
                                        <td>Ahmet Yılmaz</td>
                                        <td>34 ABC 123</td>
                                        <td>01.09.2023</td>
                                        <td>15.09.2023</td>
                                        <td>12,500 TL</td>
                                        <td><span class="badge bg-primary">Devam Ediyor</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-file-alt"></i> Detay</button>
                                            <button class="btn btn-success btn-sm"><i class="fas fa-check"></i> Sonlandır</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>TRN-00045</td>
                                        <td>Büyük Nakliyat A.Ş.</td>
                                        <td>42 GHI 789</td>
                                        <td>05.09.2023</td>
                                        <td>08.09.2023</td>
                                        <td>8,200 TL</td>
                                        <td><span class="badge bg-primary">Devam Ediyor</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-file-alt"></i> Detay</button>
                                            <button class="btn btn-success btn-sm"><i class="fas fa-check"></i> Sonlandır</button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>RNT-00124</td>
                                        <td>Can Demir</td>
                                        <td>27 JKL 012</td>
                                        <td>25.08.2023</td>
                                        <td>30.08.2023</td>
                                        <td>5,000 TL</td>
                                        <td><span class="badge bg-success">Tamamlandı</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-info btn-sm"><i class="fas fa-file-alt"></i> Detay</button>
                                            <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-check"></i> Sonlandır</button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="page-content" data-page="tasks" class="content-section d-none">
            <div class="container-fluid">
                <h1 class="mt-4">Filo Görev Yönetimi</h1>
                <hr>
                <div class="d-flex justify-content-end mb-3">
                    <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addTaskModal"><i class="fas fa-plus"></i> Yeni Görev Ekle</button>
                </div>
                <div class="card">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Görev Tanımı</th>
                                        <th scope="col">Araç Plaka</th>
                                        <th scope="col">Atanan Kişi</th>
                                        <th scope="col">Son Tarih</th>
                                        <th scope="col">Durum</th>
                                        <th scope="col">İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>T-0015</td>
                                        <td>150.000 KM Ağır Bakım</td>
                                        <td>34 ABC 123</td>
                                        <td>Mehmet Can</td>
                                        <td>15.09.2023</td>
                                        <td><span class="badge bg-warning">Bekliyor</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-success btn-sm"><i class="fas fa-check"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>T-0016</td>
                                        <td>Ön Lastik Değişimi</td>
                                        <td>06 DEF 456</td>
                                        <td>Ayşe Demir</td>
                                        <td>20.09.2023</td>
                                        <td><span class="badge bg-warning">Bekliyor</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-success btn-sm"><i class="fas fa-check"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>T-0014</td>
                                        <td>Gps Cihazı Kurulumu</td>
                                        <td>42 GHI 789</td>
                                        <td>Ali Veli</td>
                                        <td>25.09.2023</td>
                                        <td><span class="badge bg-success">Tamamlandı</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-check"></i></button>
                                            <button class="btn btn-secondary btn-sm" disabled><i class="fas fa-times"></i></button>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>T-0013</td>
                                        <td>Sigorta Yenileme</td>
                                        <td>27 JKL 012</td>
                                        <td>Deniz Aksoy</td>
                                        <td>30.08.2023</td>
                                        <td><span class="badge bg-danger">Geçmiş</span></td>
                                        <td class="action-btns">
                                            <button class="btn btn-warning btn-sm"><i class="fas fa-redo"></i></button>
                                            <button class="btn btn-danger btn-sm"><i class="fas fa-times"></i></button>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div id="page-content" data-page="reports" class="content-section d-none">
            <div class="container-fluid">
                <h1 class="mt-4">Filo Raporları</h1>
                <hr>
                <div class="row">
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-chart-bar"></i> Aylık Gelir Grafiği
                            </div>
                            <div class="card-body">
                                <p>Buraya bir chart.js grafiği gelecektir. (HTML görünümü için metin)</p>
                                <img src="https://via.placeholder.com/500x300/f8f9fa/333?text=Aylik+Gelir+Grafigi" class="img-fluid" alt="Aylık Gelir Grafiği">
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 mb-4">
                        <div class="card">
                            <div class="card-header">
                                <i class="fas fa-oil-can"></i> Yakıt Tüketim Raporu (Son 30 Gün)
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-sm table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Plaka</th>
                                                <th>Tüketim (Lt)</th>
                                                <th>Kat Edilen (Km)</th>
                                                <th>Ortalama (Lt/100km)</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr><td>34 ABC 123</td><td>1500</td><td>15000</td><td>10.00</td></tr>
                                            <tr><td>06 DEF 456</td><td>1800</td><td>14500</td><td>12.41</td></tr>
                                            <tr><td>42 GHI 789</td><td>1200</td><td>18000</td><td>6.67</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div id="page-content" data-page="settings" class="content-section d-none">
            <div class="container-fluid">
                <h1 class="mt-4">Ayarlar</h1>
                <hr>
                <div class="card">
                    <div class="card-body">
                        <form>
                            <div class="mb-3">
                                <h5>Genel Ayarlar</h5>
                            </div>
                            <div class="mb-3">
                                <label for="companyName" class="form-label">Firma Adı</label>
                                <input type="text" class="form-control" id="companyName" value="Filo Yönetim A.Ş.">
                            </div>
                            <div class="mb-3">
                                <label for="defaultCurrency" class="form-label">Varsayılan Para Birimi</label>
                                <select class="form-select" id="defaultCurrency">
                                    <option selected>TL (Türk Lirası)</option>
                                    <option>USD (Amerikan Doları)</option>
                                    <option>EUR (Euro)</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Ayarları Kaydet</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addTaskModalLabel">Yeni Görev Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="addTaskForm">
                        <div class="mb-3">
                            <label for="taskName" class="form-label">Görev Adı</label>
                            <input type="text" class="form-control" id="taskName" required>
                        </div>
                        <div class="mb-3">
                            <label for="taskAssigned" class="form-label">Atanan Kişi</label>
                            <input type="text" class="form-control" id="taskAssigned" required>
                        </div>
                        <div class="mb-3">
                            <label for="taskVehicle" class="form-label">İlgili Araç Plaka</label>
                            <input type="text" class="form-control" id="taskVehicle">
                        </div>
                        <div class="mb-3">
                            <label for="taskDueDate" class="form-label">Son Tarih</label>
                            <input type="date" class="form-control" id="taskDueDate" required>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Kapat</button>
                    <button type="button" class="btn btn-primary" onclick="saveTask()">Görev Ekle</button>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {

            checkResponsive();
            $(window).resize(checkResponsive);

            // Sidebar ve İçerik Kontrolü
            const sidebarToggle = document.getElementById('sidebarToggle');
            const mobileMenuToggle = document.getElementById('mobileMenuToggle');
            const mobileSearchToggle = document.getElementById('mobileSearchToggle');

            sidebarToggle.addEventListener('click', function() {
                $('body').toggleClass('sidebar-collapsed');
            });

            mobileMenuToggle.addEventListener('click', function() {
                $('.sidebar').toggleClass('mobile-visible');
            });

            mobileSearchToggle.addEventListener('click', function() {
                $('.navbar').toggleClass('mobile-search-visible');
            });

            // Sayfa içeriği değiştirme
            $('.sidebar-item').on('click', function() {
                const targetPage = $(this).data('target');
                $('.content-section').removeClass('active').addClass('d-none');
                $(`[data-page="${targetPage}"]`).removeClass('d-none').addClass('active');
                $('.sidebar-item').removeClass('active');
                $(this).addClass('active');
                
                // Mobil görünümde menüyü kapat
                if (window.innerWidth < 992) {
                    $('.sidebar').removeClass('mobile-visible');
                }
            });
            
            // Görev kaydetme (Modal)
            window.saveTask = function() {
                const form = document.getElementById('addTaskForm');
                if (form.checkValidity()) {
                    alert('Görev başarıyla oluşturuldu!');
                    $('#addTaskModal').modal('hide');
                    form.reset();
                } else {
                    form.reportValidity();
                }
            }
            
            // Responsive kontrol fonksiyonu
            function checkResponsive() {
                if (window.innerWidth < 992) {
                    document.getElementById('mobileMenuToggle').style.display = 'block';
                    // sidebarToggle'ın null kontrolü
                    if (document.getElementById('sidebarToggle')) {
                        document.getElementById('sidebarToggle').style.display = 'none';
                    }
                    document.body.classList.remove('sidebar-collapsed');
                } else {
                    document.getElementById('mobileMenuToggle').style.display = 'none';
                    if (document.getElementById('sidebarToggle')) {
                        document.getElementById('sidebarToggle').style.display = 'block';
                    }
                    document.querySelector('.sidebar').classList.remove('mobile-visible');
                    document.querySelector('.navbar').classList.remove('mobile-search-visible');
                }
            }
            
            // İlk açılışta dashboard'u aktif et
            $('[data-target="dashboard"]').click();
        });
    </script>
</body>
</html>