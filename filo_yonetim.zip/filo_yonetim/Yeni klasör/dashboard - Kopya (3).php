<?php
session_start();
// Güvenlik kontrolü için oturum yönetimini dahil et
require_once 'includes/auth.php';
// Veritabanı ve genel fonksiyonları dahil et
require_once 'includes/config.php';
require_once 'includes/functions.php';

$page_title = "Filo Yönetim Sistemi | Dashboard";
include 'includes/header.php';

// Dashboard verilerini çekme
try {
    // Toplam Araç Sayısı
    $stmt_vehicles = $pdo->query("SELECT COUNT(*) FROM vehicles WHERE status = 'active'");
    $total_vehicles = $stmt_vehicles->fetchColumn();

    // Toplam Müşteri Sayısı
    $stmt_customers = $pdo->query("SELECT COUNT(*) FROM customers WHERE status = 'active'");
    $total_customers = $stmt_customers->fetchColumn();

    // Toplam Fatura Sayısı
    $stmt_invoices = $pdo->query("SELECT COUNT(*) FROM invoices WHERE status = 'pending'");
    $total_invoices_pending = $stmt_invoices->fetchColumn();

    // Toplam Görev Sayısı
    $stmt_tasks = $pdo->query("SELECT COUNT(*) FROM tasks WHERE status = 'in-progress' OR status = 'pending'");
    $total_tasks = $stmt_tasks->fetchColumn();
    
    // Son 5 Görev
    $stmt_recent_tasks = $pdo->query("SELECT * FROM tasks ORDER BY created_at DESC LIMIT 5");
    $recent_tasks = $stmt_recent_tasks->fetchAll();

} catch (PDOException $e) {
    echo "Veritabanı hatası: " . $e->getMessage();
    $total_vehicles = 0;
    $total_customers = 0;
    $total_invoices_pending = 0;
    $total_tasks = 0;
    $recent_tasks = [];
}

?>

<div class="content-section active" id="dashboardSection">
    <div class="container-fluid">
        <div class="row mb-4">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <h1 class="h4">Dashboard</h1>
                        <p class="text-muted">Güncel durum özeti</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Hızlı Rapor Kartları -->
        <div class="row mb-4">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <p class="text-muted fw-bold text-uppercase mb-1 small">Toplam Araç</p>
                            <h5 class="mb-0 fw-bold"><?= htmlspecialchars($total_vehicles) ?></h5>
                        </div>
                        <i class="fas fa-truck-moving fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <p class="text-muted fw-bold text-uppercase mb-1 small">Aktif Müşteri</p>
                            <h5 class="mb-0 fw-bold"><?= htmlspecialchars($total_customers) ?></h5>
                        </div>
                        <i class="fas fa-users fa-2x text-success"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <p class="text-muted fw-bold text-uppercase mb-1 small">Bekleyen Fatura</p>
                            <h5 class="mb-0 fw-bold"><?= htmlspecialchars($total_invoices_pending) ?></h5>
                        </div>
                        <i class="fas fa-file-invoice-dollar fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-body d-flex align-items-center justify-content-between">
                        <div>
                            <p class="text-muted fw-bold text-uppercase mb-1 small">Devam Eden Görev</p>
                            <h5 class="mb-0 fw-bold"><?= htmlspecialchars($total_tasks) ?></h5>
                        </div>
                        <i class="fas fa-clipboard-list fa-2x text-info"></i>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Ana İçerik Alanı -->
        <div class="row">
            <!-- Görevler ve Bakım Takibi -->
            <div class="col-lg-8 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">
                        Son Eklenen Görevler
                        <button class="btn btn-sm btn-primary float-end" data-bs-toggle="modal" data-bs-target="#addTaskModal">
                            <i class="fas fa-plus"></i> Görev Ekle
                        </button>
                    </div>
                    <div class="card-body">
                        <?php if (count($recent_tasks) > 0): ?>
                        <ul class="list-group list-group-flush">
                            <?php foreach ($recent_tasks as $task): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1"><?= htmlspecialchars($task['title']) ?></h6>
                                    <small class="text-muted"><?= htmlspecialchars($task['description']) ?></small>
                                </div>
                                <div>
                                    <span class="badge bg-<?= get_status_color($task['status']) ?>"><?= ucfirst(htmlspecialchars(get_turkish_status($task['status']))) ?></span>
                                    <small class="text-muted ms-2"><?= htmlspecialchars(formatDate($task['end_date'])) ?></small>
                                </div>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php else: ?>
                        <div class="alert alert-info">Henüz bir görev bulunmuyor.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Hızlı Eylemler ve Diğer İstatistikler -->
            <div class="col-lg-4 mb-4">
                <div class="card shadow-sm border-0">
                    <div class="card-header bg-white fw-bold">Hızlı Eylemler</div>
                    <div class="list-group list-group-flush">
                        <a href="invoices.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Fatura Oluştur <i class="fas fa-chevron-right"></i>
                        </a>
                        <a href="vehicles.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Yeni Araç Ekle <i class="fas fa-chevron-right"></i>
                        </a>
                        <a href="customers.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center">
                            Yeni Müşteri Ekle <i class="fas fa-chevron-right"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Yeni Görev Ekleme Modalı -->
<div class="modal fade" id="addTaskModal" tabindex="-1" aria-labelledby="addTaskModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="addTaskModalLabel">Yeni Görev Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="#" method="post" id="addTaskForm">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="taskTitle" class="form-label">Görev Başlığı</label>
                        <input type="text" class="form-control" id="taskTitle" name="title" required>
                    </div>
                    <div class="mb-3">
                        <label for="taskDescription" class="form-label">Açıklama</label>
                        <textarea class="form-control" id="taskDescription" name="description" rows="3"></textarea>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="taskPriority" class="form-label">Öncelik</label>
                            <select class="form-select" id="taskPriority" name="priority">
                                <option value="low">Düşük</option>
                                <option value="medium" selected>Orta</option>
                                <option value="high">Yüksek</option>
                                <option value="urgent">Acil</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="taskStatus" class="form-label">Durum</label>
                            <select class="form-select" id="taskStatus" name="status">
                                <option value="pending" selected>Beklemede</option>
                                <option value="in-progress">Devam Ediyor</option>
                                <option value="completed">Tamamlandı</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="taskEndDate" class="form-label">Bitiş Tarihi</label>
                        <input type="date" class="form-control" id="taskEndDate" name="end_date">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
