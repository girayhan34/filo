<?php
session_start();
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Sayfa başlık ve alt başlık ayarları
$page_title = 'Müşteri Yönetimi';
$page_subtitle = 'Müşteri bilgilerinizi yönetin ve takip edin';

try {
    // Veritabanından müşteri verilerini çek
    $stmt = $pdo->query("SELECT * FROM customers WHERE status != 'deleted' ORDER BY created_at DESC");
    $customer_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // İstatistiksel verileri hesapla
    $stats = [
        'total' => count($customer_data),
        'active' => count(array_filter($customer_data, fn($c) => $c['status'] == 'active')),
        'pending' => count(array_filter($customer_data, fn($c) => $c['status'] == 'pending')),
        'inactive' => count(array_filter($customer_data, fn($c) => $c['status'] == 'inactive'))
    ];
    
} catch (Exception $e) {
    $customer_data = [];
    $stats = ['total' => 0, 'active' => 0, 'pending' => 0, 'inactive' => 0];
}

// Müşteri silme işlemi
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $stmt = $pdo->prepare("UPDATE customers SET status = 'deleted' WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: customers.php?success=silindi");
    exit();
}

// Header dosyasını dahil et
include 'includes/header.php';
?>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card border-0 shadow-sm">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#addCustomerModal">
                            <i class="fas fa-plus-circle me-1"></i>
                            <span class="d-none d-sm-inline">Yeni Müşteri</span>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-success w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#communicationModal">
                            <i class="fas fa-comment-alt me-1"></i>
                            <span class="d-none d-sm-inline">İletişim Ekle</span>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-info w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#projectModal">
                            <i class="fas fa-project-diagram me-1"></i>
                            <span class="d-none d-sm-inline">Proje Ekle</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Hızlı İşlem Butonları -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card">
            <div class="card-body py-2">
                <div class="row g-2">
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-primary w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#addCustomerModal">
                            <i class="fas fa-plus-circle mb-1"></i>
                            <small>Yeni Müşteri Ekle</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-success w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#communicationModal">
                            <i class="fas fa-comment-alt mb-1"></i>
                            <small>İletişim Ekle</small>
                        </button>
                    </div>
                    <div class="col-xl-1 col-md-2 col-sm-3 col-4">
                        <button type="button" class="btn btn-info w-100 quick-action-btn" data-bs-toggle="modal" data-bs-target="#projectModal">
                            <i class="fas fa-project-diagram mb-1"></i>
                            <small>Proje Ekle</small>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- İstatistik Kartları -->
<div class="row g-3 mb-4">
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 bg-primary bg-opacity-10">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="bg-primary bg-opacity-25 p-3 rounded-3 me-3">
                        <i class="fas fa-users text-primary fs-4"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 text-muted">Toplam Müşteri</h6>
                        <h3 class="mb-0 fw-bold"><?= $stats['total'] ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 bg-success bg-opacity-10">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="bg-success bg-opacity-25 p-3 rounded-3 me-3">
                        <i class="fas fa-check-circle text-success fs-4"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 text-muted">Aktif Müşteriler</h6>
                        <h3 class="mb-0 fw-bold"><?= $stats['active'] ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 bg-warning bg-opacity-10">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="bg-warning bg-opacity-25 p-3 rounded-3 me-3">
                        <i class="fas fa-clock text-warning fs-4"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 text-muted">Bekleyenler</h6>
                        <h3 class="mb-0 fw-bold"><?= $stats['pending'] ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-md-6">
        <div class="card border-0 bg-secondary bg-opacity-10">
            <div class="card-body">
                <div class="d-flex align-items-center">
                    <div class="bg-secondary bg-opacity-25 p-3 rounded-3 me-3">
                        <i class="fas fa-pause-circle text-secondary fs-4"></i>
                    </div>
                    <div>
                        <h6 class="mb-0 text-muted">Pasif Müşteriler</h6>
                        <h3 class="mb-0 fw-bold"><?= $stats['inactive'] ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Arama ve Filtre -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="input-group">
            <span class="input-group-text"><i class="fas fa-search"></i></span>
            <input type="text" class="form-control" id="searchInput" placeholder="Müşteri ara (isim, iletişim, vergi no...)">
        </div>
    </div>
    <div class="col-md-6">
        <select class="form-select" id="statusFilter" onchange="filterCustomers(this.value)">
            <option value="all">Tüm Müşteriler</option>
            <option value="active">Aktif Müşteriler</option>
            <option value="pending">Bekleyenler</option>
            <option value="inactive">Pasif Müşteriler</option>
        </select>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <?php
    switch ($_GET['success']) {
        case 'added': echo "Müşteri başarıyla eklendi!"; break;
        case 'updated': echo "Müşteri başarıyla güncellendi!"; break;
        case 'deleted': echo "Müşteri başarıyla silindi!"; break;
    }
    ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<!-- Müşteri Listesi -->
<div class="card mb-4">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0"><i class="fas fa-users me-2"></i>Müşteri Listesi</h5>
            <div>
                <button class="btn btn-sm btn-outline-secondary me-2" onclick="exportCustomers()">
                    <i class="fas fa-file-export me-1"></i>Dışa Aktar
                </button>
                <button class="btn btn-sm btn-outline-secondary" onclick="window.print()">
                    <i class="fas fa-print me-1"></i>Yazdır
                </button>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover" id="customersTable">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Müşteri Adı</th>
                        <th>Yetkili Kişi</th>
                        <th>Telefon</th>
                        <th>E-posta</th>
                        <th>Durum</th>
                        <th>Toplam Fatura</th>
                        <th>Son Fatura</th>
                        <th>İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($customer_data)): ?>
                    <tr>
                        <td colspan="9" class="text-center py-4">
                            <i class="fas fa-users fa-3x text-muted mb-3"></i>
                            <h5>Henüz müşteri kaydı bulunmuyor</h5>
                            <p class="text-muted">İlk müşterinizi eklemek için "Yeni Müşteri" butonunu kullanın.</p>
                        </td>
                    </tr>
                    <?php else: ?>
                        <?php foreach ($customer_data as $customer): ?>
                        <tr class="customer-item" data-status="<?= $customer['status'] ?>">
                            <td><?= $customer['id'] ?></td>
                            <td>
                                <a href="#" onclick="viewCustomer(<?= $customer['id'] ?>); return false;" 
                                   data-bs-toggle="tooltip" data-bs-title="Detayları Görüntüle">
                                    <?= htmlspecialchars($customer['name']) ?>
                                </a>
                            </td>
                            <td><?= htmlspecialchars($customer['contact_person'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($customer['phone'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($customer['email'] ?? '-') ?></td>
                            <td>
                                <span class="badge bg-<?= 
                                    $customer['status'] == 'active' ? 'success' : 
                                    ($customer['status'] == 'pending' ? 'warning' : 'secondary') 
                                ?>">
                                    <?= 
                                        $customer['status'] == 'active' ? 'Aktif' : 
                                        ($customer['status'] == 'pending' ? 'Beklemede' : 'Pasif') 
                                    ?>
                                </span>
                            </td>
                            <td><?= number_format($customer['total_revenue'] ?? 0, 2, ',', '.') ?> ₺</td>
                            <td><?= !empty($customer['last_invoice_date']) ? date('d.m.Y', strtotime($customer['last_invoice_date'])) : '-' ?></td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button type="button" class="btn btn-outline-primary" 
                                            onclick="viewCustomer(<?= $customer['id'] ?>)" 
                                            data-bs-toggle="tooltip" data-bs-title="Görüntüle">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <button type="button" class="btn btn-outline-warning" 
                                            onclick="editCustomer(<?= $customer['id'] ?>)" 
                                            data-bs-toggle="tooltip" data-bs-title="Düzenle">
                                        <i class="fas fa-edit"></i>
                                    </button>
                                    <a href="customers.php?delete=<?= $customer['id'] ?>" 
                                       class="btn btn-outline-danger delete-customer"
                                       data-bs-toggle="tooltip" data-bs-title="Sil">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Yeni Müşteri Modal -->
<div class="modal fade" id="addCustomerModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Yeni Müşteri Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="addCustomerForm">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Müşteri Adı *</label>
                            <input type="text" class="form-control" name="name" placeholder="Şirket/Kişi adı" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Müşteri Tipi *</label>
                            <select class="form-select" name="type" required>
                                <option value="corporate" selected>Kurumsal</option>
                                <option value="individual">Bireysel</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Telefon *</label>
                            <input type="tel" class="form-control" name="phone" placeholder="0212 555 0000" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">E-posta</label>
                            <input type="email" class="form-control" name="email" placeholder="info@sirket.com">
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Vergi Dairesi</label>
                            <input type="text" class="form-control" name="tax_office" placeholder="Beşiktaş VD">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Vergi/TC No</label>
                            <input type="text" class="form-control" name="tax_number" placeholder="1234567890">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Adres *</label>
                        <textarea class="form-control" name="address" rows="3" placeholder="Tam adres bilgisi" required></textarea>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Sektör</label>
                            <select class="form-select" name="industry">
                                <option value="">Sektör seçin</option>
                                <option value="İnşaat">İnşaat</option>
                                <option value="Nakliyat">Nakliyat</option>
                                <option value="Madencilik">Madencilik</option>
                                <option value="Üretim">Üretim</option>
                                <option value="Lojistik">Lojistik</option>
                                <option value="Enerji">Enerji</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Durum</label>
                            <select class="form-select" name="status">
                                <option value="active" selected>Aktif</option>
                                <option value="pending">Beklemede</option>
                                <option value="passive">Pasif</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notlar</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="Müşteri hakkında notlar..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-primary">Müşteri Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- İletişim Ekleme Modal -->
<div class="modal fade" id="communicationModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">İletişim Kaydı Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="communicationForm">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Müşteri Seçin *</label>
                            <select class="form-select" name="customer_id" required>
                                <option value="">Müşteri seçin</option>
                                <?php foreach ($customer_data as $customer): ?>
                                <option value="<?= $customer['id'] ?>"><?= htmlspecialchars($customer['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">İletişim Türü *</label>
                            <select class="form-select" name="communication_type" required>
                                <option value="">Tür seçin</option>
                                <option value="phone">Telefon Görüşmesi</option>
                                <option value="email">E-posta</option>
                                <option value="meeting">Toplantı/Ziyaret</option>
                                <option value="note">Not</option>
                                <option value="complaint">Şikayet</option>
                                <option value="request">Talep</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Tarih/Saat *</label>
                            <input type="datetime-local" class="form-control" name="communication_date" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Öncelik</label>
                            <select class="form-select" name="priority">
                                <option value="low">Düşük</option>
                                <option value="medium" selected>Orta</option>
                                <option value="high">Yüksek</option>
                                <option value="urgent">Acil</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Konu</label>
                        <input type="text" class="form-control" name="subject" placeholder="İletişim konusu">
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Açıklama *</label>
                        <textarea class="form-control" name="description" rows="4" placeholder="Detaylı açıklama..." required></textarea>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Takip Tarihi</label>
                            <input type="date" class="form-control" name="follow_up_date">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Durum</label>
                            <select class="form-select" name="status">
                                <option value="open" selected>Açık</option>
                                <option value="in_progress">İşlemde</option>
                                <option value="resolved">Çözüldü</option>
                                <option value="closed">Kapatıldı</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-success">İletişim Kaydı Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Proje Ekleme Modal -->
<div class="modal fade" id="projectModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Proje Kaydı Ekle</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="projectForm">
                <div class="modal-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label class="form-label">Müşteri Seçin *</label>
                            <select class="form-select" name="customer_id" required>
                                <option value="">Müşteri seçin</option>
                                <?php foreach ($customer_data as $customer): ?>
                                <option value="<?= $customer['id'] ?>"><?= htmlspecialchars($customer['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Proje Türü</label>
                            <select class="form-select" name="project_type">
                                <option value="">Tür seçin</option>
                                <option value="İnşaat">İnşaat</option>
                                <option value="Lojistik">Lojistik</option>
                                <option value="Endüstriyel">Endüstriyel</option>
                                <option value="Nakliyat">Nakliyat</option>
                                <option value="Diğer">Diğer</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Proje Adı *</label>
                        <input type="text" class="form-control" name="project_name" placeholder="Proje adı" required>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-4">
                            <label class="form-label">Başlangıç Tarihi</label>
                            <input type="date" class="form-control" name="start_date">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Bitiş Tarihi</label>
                            <input type="date" class="form-control" name="end_date">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label">Proje Değeri (₺)</label>
                            <input type="number" step="0.01" class="form-control" name="project_value" placeholder="0.00">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Durum</label>
                        <select class="form-select" name="status">
                            <option value="planning" selected>Planlama</option>
                            <option value="active">Aktif</option>
                            <option value="completed">Tamamlandı</option>
                            <option value="cancelled">İptal Edildi</option>
                            <option value="on_hold">Beklemede</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Proje Açıklaması</label>
                        <textarea class="form-control" name="description" rows="3" placeholder="Proje detayları..."></textarea>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Notlar</label>
                        <textarea class="form-control" name="notes" rows="2" placeholder="Ek notlar..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                    <button type="submit" class="btn btn-info">Proje Kaydı Kaydet</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Müşteri Detay Modal -->
<div class="modal fade" id="customerDetailModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Müşteri Detayları</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="customerDetailContent">
                <!-- Dinamik içerik buraya yüklenecek -->
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Varsayılan olarak bugünün tarihini ayarla
    const today = new Date();
    const todayString = today.toISOString().split('T')[0];
    const nowString = today.toISOString().slice(0, 16);
    
    // Tarih alanlarına bugünün tarihini otomatik olarak doldur
    document.querySelectorAll('input[type="date"]').forEach(input => {
        if (!input.value) input.value = todayString;
    });
    
    // Zaman alanlarına şu anki zamanı otomatik olarak doldur
    document.querySelectorAll('input[type="datetime-local"]').forEach(input => {
        if (!input.value) input.value = nowString;
    });
    
    // Yeni müşteri ekleme formunu göster
    document.getElementById('addCustomerForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        console.log('Müşteri verisi:', Object.fromEntries(formData));
        
        alert('Müşteri başarıyla eklendi! (Demo - Backend entegrasyonu gerekli)');
        bootstrap.Modal.getInstance(document.getElementById('addCustomerModal')).hide();
        this.reset();
    });

    // İletişim ekleme formunu göster
    document.getElementById('communicationForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        console.log('İletişim verisi:', Object.fromEntries(formData));
        
        alert('İletişim kaydı başarıyla eklendi! (Demo - Backend entegrasyonu gerekli)');
        bootstrap.Modal.getInstance(document.getElementById('communicationModal')).hide();
        this.reset();
    });

    // Proje ekleme formunu göster
    document.getElementById('projectForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const formData = new FormData(this);
        
        console.log('Proje verisi:', Object.fromEntries(formData));
        
        alert('Proje kaydı başarıyla eklendi! (Demo - Backend entegrasyonu gerekli)');
        bootstrap.Modal.getInstance(document.getElementById('projectModal')).hide();
        this.reset();
    });

    // Silme işlemi için onay iste
    document.querySelectorAll('.delete-customer').forEach(button => {
        button.addEventListener('click', function(e) {
            if (confirm('Bu müşteriyi silmek istediğinize emin misiniz? Bu işlem geri alınamaz!')) {
                // Silme işlemi başarılı olduğunda sayfayı yenile
                window.location.href = this.getAttribute('href');
            }
            e.preventDefault();
        });
    });

    // Müşteri detay görüntüleme
    document.querySelectorAll('.view-customer').forEach(button => {
        button.addEventListener('click', function() {
            const customerId = this.dataset.id;
            
            document.getElementById('customerDetailContent').innerHTML = `
                <div class="text-center py-4">
                    <div class="spinner-border" role="status">
                        <span class="visually-hidden">Yükleniyor...</span>
                    </div>
                    <p class="mt-2">Müşteri detayları yükleniyor...</p>
                </div>
            `;
            
            new bootstrap.Modal(document.getElementById('customerDetailModal')).show();
            
            // Simüle edilmiş detay yükleme
            setTimeout(() => {
                document.getElementById('customerDetailContent').innerHTML = `
                    <div class="row">
                        <div class="col-md-6">
                            <h6><i class="fas fa-user me-2"></i>Müşteri Bilgileri</h6>
                            <div class="card">
                                <div class="card-body">
                                    <p><strong>Müşteri ID:</strong> ${customerId}</p>
                                    <p><strong>Ad:</strong> ABC Nakliyat Ltd.</p>
                                    <p><strong>Telefon:</strong> 0212 555 0001</p>
                                    <p><strong>E-posta:</strong> info@abcnakliyat.com</p>
                                    <p><strong>Durum:</strong> <span class="badge bg-success">Aktif</span></p>
                                    <p><strong>Kayıt Tarihi:</strong> 15.08.2024</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <h6><i class="fas fa-chart-bar me-2"></i>İş Özeti</h6>
                            <div class="card">
                                <div class="card-body">
                                    <p><strong>Toplam Fatura:</strong> 15 adet</p>
                                    <p><strong>Toplam Ciro:</strong> 450.000₺</p>
                                    <p><strong>Aktif Projeler:</strong> 2 adet</p>
                                    <p><strong>Son İletişim:</strong> 3 gün önce</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <h6><i class="fas fa-comments me-2"></i>Son İletişimler</h6>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead class="table-light">
                                <tr><th>Tarih</th><th>Tür</th><th>Konu</th><th>Durum</th></tr>
                            </thead>
                            <tbody>
                                <tr><td>01.09.2024</td><td><i class="fas fa-phone text-primary"></i> Telefon</td><td>Fiyat Teklifi</td><td><span class="badge bg-success">Çözüldü</span></td></tr>
                                <tr><td>03.09.2024</td><td><i class="fas fa-users text-info"></i> Toplantı</td><td>Proje Görüşmesi</td><td><span class="badge bg-secondary">Kapatıldı</span></td></tr>
                            </tbody>
                        </table>
                    </div>
                    <div class="alert alert-info mt-3">
                        <i class="fas fa-info-circle me-2"></i>
                        Detaylı müşteri bilgileri için backend entegrasyonu gereklidir.
                    </div>
                `;
            }, 1000);
        });
    });

    // Müşteri düzenleme fonksiyonu
    function editCustomer(customerId) {
        alert(`Müşteri düzenleme sayfası açılacak (ID: ${customerId})\n\nBackend entegrasyonu gereklidir.`);
    }

    // Proje ekleme fonksiyonu
    function addProject(customerId) {
        const modal = new bootstrap.Modal(document.getElementById('projectModal'));
        modal.show();
        
        setTimeout(() => {
            document.querySelector('#projectModal select[name="customer_id"]').value = customerId;
        }, 100);
    }
    
    // İletişim ekleme fonksiyonu
    function addCommunication(customerId) {
        const modal = new bootstrap.Modal(document.getElementById('communicationModal'));
        modal.show();
        
        setTimeout(() => {
            document.querySelector('#communicationModal select[name="customer_id"]').value = customerId;
        }, 100);
    }

    // Dışa aktarma fonksiyonu
    function exportCustomers() {
        const customers = [
            ['ID', 'Müşteri Adı', 'Yetkili Kişi', 'Telefon', 'E-posta', 'Durum', 'Toplam Fatura', 'Son Fatura Tarihi']
        ];
        
        document.querySelectorAll('.customer-item').forEach(row => {
            if (row.style.display !== 'none') {
                const cells = row.querySelectorAll('td');
                const customer = [
                    cells[0].textContent.trim(),
                    cells[1].textContent.trim(),
                    cells[2].textContent.trim(),
                    cells[3].textContent.trim(),
                    cells[4].textContent.trim(),
                    cells[5].querySelector('.badge').textContent.trim(),
                    cells[6].textContent.trim(),
                    cells[7].textContent.trim()
                ];
                customers.push(customer);
            }
        });
        
        console.log('Dışa aktarılacak müşteriler:', customers);
        alert(`${customers.length} müşteri dışa aktarılacak.\n\nExcel/CSV dışa aktarma işlemi için backend entegrasyonu gereklidir.`);
    }

    // Yazdırma fonksiyonu
    function printCustomers() {
        const printWindow = window.open('', '_blank');
        const customersTable = document.getElementById('customersTable').outerHTML;
        
        printWindow.document.write(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Müşteri Listesi</title>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
                <style>
                    @media print {
                        .btn-group { display: none !important; }
                        body { font-size: 12px; }
                    }
                </style>
            </head>
            <body>
                <div class="container-fluid">
                    <h2 class="mb-4">Müşteri Listesi</h2>
                    <p>Yazdırma Tarihi: ${new Date().toLocaleDateString('tr-TR')}</p>
                    ${customersTable}
                </div>
            </body>
            </html>
        `);
        
        printWindow.document.close();
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 500);
    }
});
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html>
        <head>
            <title>Müşteri Listesi</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <style>
                @media print {
                    .btn-group { display: none !important; }
                    body { font-size: 12px; }
                }
            </style>
        </head>
        <body>
            <div class="container-fluid">
                <h2 class="mb-4">Müşteri Listesi</h2>
                <p>Yazdırma Tarihi: ${new Date().toLocaleDateString('tr-TR')}</p>
                ${customersTable}
            </div>
        </body>
        </html>
    `);
    
    printWindow.document.close();
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 500);
}
</script>
</body>
</html>