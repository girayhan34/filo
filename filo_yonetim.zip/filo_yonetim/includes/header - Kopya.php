<?php
if (!isset($page_title)) {
    $page_title = "Filo Yönetim Sistemi";
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?> | Filo Yönetim Sistemi</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Ana Uygulama -->
    <div id="appScreen">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="position-sticky">
                <div class="text-center mb-4">
                    <h5 class="text-white">Filo Yönetim Sistemi</h5>
                </div>
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php" data-section="dashboard">
                            <i class="fas fa-tachometer-alt"></i>
                            <span>Pano</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="invoices.php" data-section="invoices">
                            <i class="fas fa-file-invoice"></i>
                            <span>Faturalar</span>
                        </a>
                    </li>
                    <!-- Diğer menü öğeleri -->
                    <li class="nav-item mt-4">
                        <a class="nav-link" href="../logout.php">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Çıkış</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Navbar -->
        <nav class="navbar navbar-expand-lg navbar-light">
            <div class="container-fluid">
                <button class="btn btn-sm btn-light mobile-menu-btn" id="mobileMenuToggle" style="display: none;">
                    <i class="fas fa-bars"></i>
                </button>
                
                <button class="btn btn-sm btn-light" id="sidebarToggle">
                    <i class="fas fa-bars"></i>
                </button>
                
                <div class="d-flex align-items-center ms-auto">
                    <div class="search-container me-3" style="max-width: 300px;">
                        <div class="input-group">
                            <input type="text" class="form-control form-control-sm" placeholder="Ara..." id="globalSearch">
                            <button class="btn btn-primary btn-sm" id="searchButton">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </div>
                    
                    <button class="btn btn-sm btn-light d-lg-none" id="mobileSearchToggle">
                        <i class="fas fa-search"></i>
                    </button>
                    
                    <div class="dropdown ms-3">
                        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle" id="dropdownUser" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="../assets/images/user.png" alt="Kullanıcı" width="40" height="40" class="rounded-circle me-2">
                            <span class="d-none d-md-inline"><?php echo $_SESSION['user_name']; ?></span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser">
                            <li><a class="dropdown-item" href="profile.php">Profil</a></li>
                            <li><a class="dropdown-item" href="settings.php">Ayarlar</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="#" id="highContrastToggle">Yüksek Kontrast</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Çıkış</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="main-content">