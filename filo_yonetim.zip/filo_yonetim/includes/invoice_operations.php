<?php
require_once 'config.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    exit(0);
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'create_invoice':
            createInvoice();
            break;
        case 'get_invoices':
            getInvoices();
            break;
        case 'delete_invoice':
            deleteInvoice();
            break;
        case 'get_customers':
            getCustomers();
            break;
        case 'create_customer':
            createCustomer();
            break;
        case 'get_vehicles':
            getVehicles();
            break;
        case 'get_personnel':
            getPersonnel();
            break;
        case 'get_next_receipt_no':
            getNextReceiptNo();
            break;
        case 'get_invoice_details':
            getInvoiceDetails();
            break;
        case 'update_invoice':
            updateInvoice();
            break;
        case 'add_payment':
            addPayment();
            break;
        case 'get_payments':
            getPayments();
            break;
        default:
            throw new Exception('Geçersiz işlem');
    }
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

function createInvoice() {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        // Son fiş numarasını al ve güncelle
        $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'last_receipt_no'");
        $stmt->execute();
        $lastReceiptNo = (int)$stmt->fetchColumn();
        $newReceiptNo = $lastReceiptNo + 1;
        
        // Fiş numarasını güncelle
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = 'last_receipt_no'");
        $stmt->execute([$newReceiptNo]);
    
    // Müşteri ID'sini al veya oluştur
    $customerName = $_POST['customer'];
    $stmt = $pdo->prepare("SELECT id FROM customers WHERE name = ?");
    $stmt->execute([$customerName]);
    $customerId = $stmt->fetchColumn();
    
    if (!$customerId) {
        // Yeni müşteri oluştur
        $stmt = $pdo->prepare("INSERT INTO customers (name) VALUES (?)");
        $stmt->execute([$customerName]);
        $customerId = $pdo->lastInsertId();
    }
    
    // Araç ID'sini al
    $vehiclePlate = $_POST['vehicle'];
    $stmt = $pdo->prepare("SELECT id FROM vehicles WHERE plate = ?");
    $stmt->execute([$vehiclePlate]);
    $vehicleId = $stmt->fetchColumn();
    
    // Şoför ID'si
    $driverId = $_POST['driver'];
    
    // Tutarları hesapla
    $unitPrice = (float)$_POST['unit_price'];
    $quantity = (int)$_POST['quantity'];
    $taxRate = (float)$_POST['tax_rate'];
    
    $amount = $unitPrice * $quantity;
    $taxAmount = $amount * ($taxRate / 100);
    $totalAmount = $amount + $taxAmount;
    
    // Faturayı kaydet
    $stmt = $pdo->prepare("
        INSERT INTO invoices (
            invoice_no, receipt_no, customer_id, vehicle_id, driver_id,
            invoice_date, payment_date, due_date, service_type, payment_method,
            unit_price, quantity, amount, tax_rate, tax_amount, total_amount,
            description, status
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $result = $stmt->execute([
        $_POST['invoice_no'],
        $newReceiptNo,
        $customerId,
        $vehicleId,
        $driverId,
        $_POST['date'],
        $_POST['payment_date'] ?? null,
        $_POST['due_date'] ?? null,
        $_POST['service'],
        $_POST['payment_method'],
        $unitPrice,
        $quantity,
        $amount,
        $taxRate,
        $taxAmount,
        $totalAmount,
        $_POST['description'] ?? '',
        $_POST['status']
    ]);
    
        if ($result) {
            $pdo->commit();
            echo json_encode([
                'success' => true, 
                'message' => 'Fatura başarıyla oluşturuldu',
                'invoice_id' => $pdo->lastInsertId(),
                'receipt_no' => $newReceiptNo
            ]);
        } else {
            $pdo->rollback();
            throw new Exception('Fatura kaydedilemedi');
        }
    } catch (Exception $e) {
        $pdo->rollback();
        throw $e;
    }
}

function getInvoices() {
    global $pdo;
    
    // Filtre parametrelerini al
    $invoiceNo = $_GET['invoice_no'] ?? '';
    $receiptNo = $_GET['receipt_no'] ?? '';
    $status = $_GET['status'] ?? '';
    $customer = $_GET['customer'] ?? '';
    $vehicle = $_GET['vehicle'] ?? '';
    $vehicleCategory = $_GET['vehicle_category'] ?? '';
    $startDate = $_GET['start_date'] ?? '';
    $endDate = $_GET['end_date'] ?? '';
    
    // Base query
    $query = "
        SELECT 
            i.*,
            c.name as customer_name,
            v.plate as vehicle_plate,
            v.type as vehicle_type,
            p.name as driver_name
        FROM invoices i
        LEFT JOIN customers c ON i.customer_id = c.id
        LEFT JOIN vehicles v ON i.vehicle_id = v.id
        LEFT JOIN personnel p ON i.driver_id = p.id
        WHERE 1=1
    ";
    
    $params = [];
    
    // Filtre koşullarını ekle
    if (!empty($invoiceNo)) {
        $query .= " AND i.invoice_no LIKE ?";
        $params[] = '%' . $invoiceNo . '%';
    }
    
    if (!empty($receiptNo)) {
        $query .= " AND i.receipt_no = ?";
        $params[] = $receiptNo;
    }
    
    if (!empty($status)) {
        $query .= " AND i.status = ?";
        $params[] = $status;
    }
    
    if (!empty($customer)) {
        $query .= " AND c.name LIKE ?";
        $params[] = '%' . $customer . '%';
    }
    
    if (!empty($vehicle)) {
        $query .= " AND v.plate = ?";
        $params[] = $vehicle;
    }
    
    if (!empty($vehicleCategory)) {
        $query .= " AND v.type = ?";
        $params[] = $vehicleCategory;
    }
    
    if (!empty($startDate)) {
        $query .= " AND i.invoice_date >= ?";
        $params[] = $startDate;
    }
    
    if (!empty($endDate)) {
        $query .= " AND i.invoice_date <= ?";
        $params[] = $endDate;
    }
    
    $query .= " ORDER BY i.created_at DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $invoices = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'data' => $invoices]);
}

function deleteInvoice() {
    global $pdo;
    
    $invoiceId = (int)$_POST['invoice_id'];
    
    $stmt = $pdo->prepare("DELETE FROM invoices WHERE id = ?");
    $result = $stmt->execute([$invoiceId]);
    
    if ($result) {
        echo json_encode(['success' => true, 'message' => 'Fatura silindi']);
    } else {
        throw new Exception('Fatura silinemedi');
    }
}

function getCustomers() {
    global $pdo;
    
    $search = $_GET['search'] ?? '';
    
    if ($search) {
        $stmt = $pdo->prepare("SELECT * FROM customers WHERE name LIKE ? AND status = 'active' ORDER BY name");
        $stmt->execute(['%' . $search . '%']);
    } else {
        $stmt = $pdo->query("SELECT * FROM customers WHERE status = 'active' ORDER BY name");
    }
    
    $customers = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'data' => $customers]);
}

function createCustomer() {
    global $pdo;
    
    $stmt = $pdo->prepare("
        INSERT INTO customers (name, phone, email, address, tax_office, tax_number)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    
    $result = $stmt->execute([
        $_POST['customer_name'],
        $_POST['phone'] ?? '',
        $_POST['email'] ?? '',
        $_POST['address'] ?? '',
        $_POST['tax_office'] ?? '',
        $_POST['tax_number'] ?? ''
    ]);
    
    if ($result) {
        echo json_encode([
            'success' => true, 
            'message' => 'Müşteri başarıyla eklendi',
            'customer_id' => $pdo->lastInsertId()
        ]);
    } else {
        throw new Exception('Müşteri kaydedilemedi');
    }
}

function getVehicles() {
    global $pdo;
    
    $stmt = $pdo->query("SELECT * FROM vehicles WHERE status = 'active' ORDER BY plate");
    $vehicles = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'data' => $vehicles]);
}

function getPersonnel() {
    global $pdo;
    
    $stmt = $pdo->query("SELECT * FROM personnel WHERE status = 'active' ORDER BY name");
    $personnel = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'data' => $personnel]);
}

function getNextReceiptNo() {
    global $pdo;
    
    $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = 'last_receipt_no'");
    $stmt->execute();
    $lastReceiptNo = (int)$stmt->fetchColumn();
    $nextReceiptNo = $lastReceiptNo + 1;
    
    echo json_encode(['success' => true, 'next_receipt_no' => $nextReceiptNo]);
}

function getInvoiceDetails() {
    global $pdo;
    
    $invoiceId = (int)($_GET['invoice_id'] ?? 0);
    
    if (!$invoiceId) {
        throw new Exception('Fatura ID gerekli');
    }
    
    $stmt = $pdo->prepare("
        SELECT 
            i.*,
            c.name as customer_name,
            c.phone as customer_phone,
            c.email as customer_email,
            c.address as customer_address,
            v.plate as vehicle_plate,
            v.type as vehicle_type,
            p.name as driver_name
        FROM invoices i
        LEFT JOIN customers c ON i.customer_id = c.id
        LEFT JOIN vehicles v ON i.vehicle_id = v.id
        LEFT JOIN personnel p ON i.driver_id = p.id
        WHERE i.id = ?
    ");
    
    $stmt->execute([$invoiceId]);
    $invoice = $stmt->fetch();
    
    if (!$invoice) {
        throw new Exception('Fatura bulunamadı');
    }
    
    // Tahsilat kayıtlarını al
    $stmt = $pdo->prepare("
        SELECT * FROM payments 
        WHERE invoice_id = ? 
        ORDER BY payment_date DESC
    ");
    $stmt->execute([$invoiceId]);
    $payments = $stmt->fetchAll();
    
    $totalPaid = array_sum(array_column($payments, 'amount'));
    $remainingAmount = $invoice['total_amount'] - $totalPaid;
    
    echo json_encode([
        'success' => true, 
        'invoice' => $invoice,
        'payments' => $payments,
        'total_paid' => $totalPaid,
        'remaining_amount' => $remainingAmount
    ]);
}

function updateInvoice() {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $invoiceId = (int)$_POST['invoice_id'];
        $customerId = (int)$_POST['customer_id'];
        $vehicleId = (int)$_POST['vehicle_id'];
        $driverId = (int)$_POST['driver_id'];
        
        // Tutarları hesapla
        $unitPrice = (float)$_POST['unit_price'];
        $quantity = (int)$_POST['quantity'];
        $taxRate = (float)$_POST['tax_rate'];
        
        $amount = $unitPrice * $quantity;
        $taxAmount = $amount * ($taxRate / 100);
        $totalAmount = $amount + $taxAmount;
        
        $stmt = $pdo->prepare("
            UPDATE invoices SET
                customer_id = ?, vehicle_id = ?, driver_id = ?,
                invoice_date = ?, payment_date = ?, due_date = ?,
                service_type = ?, payment_method = ?,
                unit_price = ?, quantity = ?, amount = ?,
                tax_rate = ?, tax_amount = ?, total_amount = ?,
                description = ?, status = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        
        $result = $stmt->execute([
            $customerId, $vehicleId, $driverId,
            $_POST['invoice_date'], $_POST['payment_date'] ?? null, $_POST['due_date'] ?? null,
            $_POST['service_type'], $_POST['payment_method'],
            $unitPrice, $quantity, $amount,
            $taxRate, $taxAmount, $totalAmount,
            $_POST['description'] ?? '', $_POST['status'],
            $invoiceId
        ]);
        
        if ($result) {
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => 'Fatura başarıyla güncellendi']);
        } else {
            $pdo->rollback();
            throw new Exception('Fatura güncellenemedi');
        }
    } catch (Exception $e) {
        $pdo->rollback();
        throw $e;
    }
}

function addPayment() {
    global $pdo;
    
    try {
        $pdo->beginTransaction();
        
        $invoiceId = (int)$_POST['invoice_id'];
        $amount = (float)$_POST['amount'];
        
        // Fatura toplam tutarını kontrol et
        $stmt = $pdo->prepare("SELECT total_amount FROM invoices WHERE id = ?");
        $stmt->execute([$invoiceId]);
        $totalAmount = (float)$stmt->fetchColumn();
        
        // Mevcut ödemeleri kontrol et
        $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) as total_paid FROM payments WHERE invoice_id = ?");
        $stmt->execute([$invoiceId]);
        $totalPaid = (float)$stmt->fetchColumn();
        
        $remainingAmount = $totalAmount - $totalPaid;
        
        if ($amount > $remainingAmount) {
            throw new Exception('Ödeme tutarı kalan tutardan fazla olamaz. Kalan: ' . number_format($remainingAmount, 2) . '₺');
        }
        
        // Ödeme kaydını ekle
        $stmt = $pdo->prepare("
            INSERT INTO payments (invoice_id, payment_date, amount, payment_method, reference_no, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $result = $stmt->execute([
            $invoiceId,
            $_POST['payment_date'],
            $amount,
            $_POST['payment_method'],
            $_POST['reference_no'] ?? '',
            $_POST['notes'] ?? '',
            'Admin' // Gerçek uygulamada session'dan alınacak
        ]);
        
        if ($result) {
            // Fatura durumunu güncelle
            $newTotalPaid = $totalPaid + $amount;
            $newStatus = ($newTotalPaid >= $totalAmount) ? 'paid' : 'pending';
            
            $stmt = $pdo->prepare("UPDATE invoices SET status = ? WHERE id = ?");
            $stmt->execute([$newStatus, $invoiceId]);
            
            $pdo->commit();
            echo json_encode([
                'success' => true, 
                'message' => 'Tahsilat başarıyla kaydedildi',
                'new_status' => $newStatus,
                'remaining_amount' => $totalAmount - $newTotalPaid
            ]);
        } else {
            $pdo->rollback();
            throw new Exception('Tahsilat kaydedilemedi');
        }
    } catch (Exception $e) {
        $pdo->rollback();
        throw $e;
    }
}

function getPayments() {
    global $pdo;
    
    $invoiceId = (int)($_GET['invoice_id'] ?? 0);
    
    if (!$invoiceId) {
        throw new Exception('Fatura ID gerekli');
    }
    
    $stmt = $pdo->prepare("
        SELECT * FROM payments 
        WHERE invoice_id = ? 
        ORDER BY payment_date DESC, created_at DESC
    ");
    
    $stmt->execute([$invoiceId]);
    $payments = $stmt->fetchAll();
    
    echo json_encode(['success' => true, 'payments' => $payments]);
}
?>
