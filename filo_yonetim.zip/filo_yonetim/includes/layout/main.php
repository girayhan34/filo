<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<!DOCTYPE html>
<html lang="tr" x-data="{ mobileMenuOpen: false }">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'Filo Yönetim Sistemi' ?></title>
    
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?= base_url('asset/media/logos/favicon.ico') ?>">
    
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Alpine.js -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= base_url('asset/css/metronic-tailwind.css') ?>">
    
    <!-- Page-specific CSS -->
    <?php if(isset($page_css)): ?>
        <?php foreach((array)$page_css as $css): ?>
            <link rel="stylesheet" href="<?= base_url('asset/css/' . $css) ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body class="bg-gray-50">
    <div class="app-container">
        <!-- Header -->
        <?php $this->load->view('layout/header'); ?>
        
        <!-- Sidebar -->
        <?php $this->load->view('layout/sidebar'); ?>
        
        <!-- Mobile menu button -->
        <div class="md:hidden fixed bottom-4 right-4 z-40">
            <button @click="mobileMenuOpen = !mobileMenuOpen" class="p-3 bg-primary text-white rounded-full shadow-lg">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
                </svg>
            </button>
        </div>
        
        <!-- Main Content -->
        <main class="app-main">
            <!-- Page Header -->
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <div>
                    <h1 class="text-2xl font-bold text-gray-900"><?= $page_title ?? 'Hoş Geldiniz' ?></h1>
                    <?php if(isset($page_subtitle)): ?>
                        <p class="mt-1 text-sm text-gray-500"><?= $page_subtitle ?></p>
                    <?php endif; ?>
                </div>
                <div class="mt-4 md:mt-0">
                    <?= $page_actions ?? '' ?>
                </div>
            </div>
            
            <!-- Page Content -->
            <?php $this->load->view($content_view); ?>
            
            <!-- Footer -->
            <footer class="mt-12 py-6 border-t border-gray-200">
                <div class="container mx-auto px-4">
                    <div class="flex flex-col md:flex-row justify-between items-center">
                        <p class="text-sm text-gray-500">© <?= date('Y') ?> Filo Yönetim Sistemi. Tüm hakları saklıdır.</p>
                        <div class="flex space-x-6 mt-4 md:mt-0">
                            <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Gizlilik Politikası</a>
                            <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Kullanım Şartları</a>
                            <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Yardım</a>
                        </div>
                    </div>
                </div>
            </footer>
        </main>
    </div>
    
    <!-- Page-specific JS -->
    <?php if(isset($page_js)): ?>
        <?php foreach((array)$page_js as $js): ?>
            <script src="<?= base_url('asset/js/' . $js) ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
    
    <!-- Initialize Alpine.js -->
    <script>
        document.addEventListener('alpine:init', () => {
            // Alpine.js initializations can go here
        });
    </script>
</body>
</html>
