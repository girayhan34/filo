<?php
// Oturum kontrolü
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

// Kullanıcı yetki kontrolü
function has_permission($role) {
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === $role) {
        return true;
    }
    return false;
}

// Güvenli çıktı için HTML temizleme
function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)), ENT_QUOTES, 'UTF-8');
}

// Tarih formatı düzenleme
function format_date($date, $format = 'd.m.Y') {
    if (empty($date)) return '';
    $datetime = new DateTime($date);
    return $datetime->format($format);
}

// Para formatı düzenleme
function format_currency($amount) {
    return number_format($amount, 2, ',', '.') . '₺';
}

// Yönlendirme fonksiyonu
function redirect($url) {
    header("Location: $url");
    exit();
}
?>