<?php
// Ornek.html uyumlu sidebar navigation
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar">
    <div class="position-sticky">
        <div class="sidebar-logo">
            <img src="https://via.placeholder.com/80/2c3e50/ffffff?text=FYS" alt="Filo Yönetim Sistemi Logo">
            <h5>Filo Yönetim Sistemi</h5>
        </div>
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'dashboard.php' ? 'active' : '' ?>" href="dashboard.php">
                    <i class="fas fa-tachometer-alt"></i>
                    <span>Pano</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'invoices.php' ? 'active' : '' ?>" href="invoices.php">
                    <i class="fas fa-file-invoice"></i>
                    <span>Faturalar</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'income_expense.php' ? 'active' : '' ?>" href="income_expense.php">
                    <i class="fas fa-money-bill-wave"></i>
                    <span>Gelir-Gider</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'customers.php' ? 'active' : '' ?>" href="customers.php">
                    <i class="fas fa-users"></i>
                    <span>Müşteriler</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= in_array($current_page, ['reports2.php', 'reports_z.php']) ? 'active' : '' ?>" href="reports_z.php">
                    <i class="fas fa-chart-bar"></i>
                    <span>Raporlar</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'vehicles.php' ? 'active' : '' ?>" href="vehicles.php">
                    <i class="fas fa-truck"></i>
                    <span>Araçlar</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'personel3.php' ? 'active' : '' ?>" href="personel3.php">
                    <i class="fas fa-user-tie"></i>
                    <span>Personel</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'receipts.php' ? 'active' : '' ?>" href="receipts.php">
                    <i class="fas fa-receipt"></i>
                    <span>Fişler</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'tasks.php' ? 'active' : '' ?>" href="tasks.php">
                    <i class="fas fa-tasks"></i>
                    <span>Görevler</span>
                </a>
            </li>
            <li class="nav-item has-submenu">
                <a class="nav-link <?= in_array($current_page, ['stock.php', 'stock_movements.php']) ? 'active' : '' ?>" href="#" data-bs-toggle="collapse" data-bs-target="#stock-submenu" aria-expanded="false">
                    <i class="fas fa-warehouse"></i>
                    <span>Stok Yönetimi <i class="fas fa-chevron-down float-end"></i></span>
                </a>
                <ul class="collapse list-unstyled" id="stock-submenu">
                    <li><a class="nav-link sub-link" href="stock.php">Stok Listesi</a></li>
                    <li><a class="nav-link sub-link" href="stock_movements.php">Stok Hareketleri</a></li>
                </ul>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'projects.php' ? 'active' : '' ?>" href="projects.php">
                    <i class="fas fa-project-diagram"></i>
                    <span>Proje Yönetimi</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'contracts.php' ? 'active' : '' ?>" href="contracts.php">
                    <i class="fas fa-file-contract"></i>
                    <span>Sözleşmeler</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'maintenance.php' ? 'active' : '' ?>" href="maintenance.php">
                    <i class="fas fa-tools"></i>
                    <span>Araç Bakım</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'dispatches.php' ? 'active' : '' ?>" href="dispatches.php">
                    <i class="fas fa-truck-loading"></i>
                    <span>İrsaliyeler</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'cash.php' ? 'active' : '' ?>" href="cash.php">
                    <i class="fas fa-cash-register"></i>
                    <span>Kasa</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'route_optimization.php' ? 'active' : '' ?>" href="route_optimization.php">
                    <i class="fas fa-route"></i>
                    <span>Rota Optimizasyonu</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'vehicle_tracking.php' ? 'active' : '' ?>" href="vehicle_tracking.php">
                    <i class="fas fa-map-marker-alt"></i>
                    <span>Araç Takip</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'notifications.php' ? 'active' : '' ?>" href="notifications.php">
                    <i class="fas fa-bell"></i>
                    <span>Bildirimler</span>
                    <span class="notification-badge">5</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'support.php' ? 'active' : '' ?>" href="support.php">
                    <i class="fas fa-life-ring"></i>
                    <span>Destek</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'settings.php' ? 'active' : '' ?>" href="settings.php">
                    <i class="fas fa-cogs"></i>
                    <span>Ayarlar</span>
                </a>
            </li>
            <?php if ($_SESSION['user_role'] === 'admin'): ?>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'roles.php' ? 'active' : '' ?>" href="roles.php">
                    <i class="fas fa-user-shield"></i>
                    <span>Rol Yönetimi</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'users.php' ? 'active' : '' ?>" href="users.php">
                    <i class="fas fa-users-cog"></i>
                    <span>Kullanıcılar</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?= $current_page == 'activity_log.php' ? 'active' : '' ?>" href="activity_log.php">
                    <i class="fas fa-history"></i>
                    <span>Aktivite Geçmişi</span>
                </a>
            </li>
            <?php endif; ?>
            <li class="nav-item mt-4">
                <a class="nav-link" href="logout.php">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Çıkış</span>
                </a>
            </li>
        </ul>
    </div>
</div>
