<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini veritabanından al
require_once 'config.php';
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || $user['status'] != 'active') {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini session'da güncelle
$_SESSION['user_name'] = $user['name'];
$_SESSION['user_role'] = $user['role'];
?>