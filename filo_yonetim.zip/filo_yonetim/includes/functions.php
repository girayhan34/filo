<?php
/**
 * Kullanıcının oturum açıp açmadığını kontrol eder.
 *
 * @return bool True eğer oturum açıksa, aksi halde false.
 */
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

/**
 * Durum metninin Türkçe karşılığını döndürür.
 *
 * @param string $status Durum metni (ingilizce).
 * @return string Türkçe karşılığı.
 */
function get_turkish_status($status) {
    $turkish_statuses = [
        'pending' => 'Beklemede',
        'in-progress' => 'Devam Ediyor',
        'completed' => 'Tamamlandı',
        'paid' => 'Ödendi',
        'overdue' => 'Gecikmiş',
        'active' => 'Aktif',
        'passive' => 'Pasif',
        'inactive' => 'Pasif',
        'available' => 'Müsait',
        'busy' => 'Meşgul',
        'unavailable' => 'Müsait Değil',
    ];
    return $turkish_statuses[$status] ?? $status;
}

/**
 * Duruma göre Bootstrap renk sınıfını döndürür.
 *
 * @param string $status Durum metni.
 * @return string Bootstrap renk sınıfı.
 */
function get_status_color($status) {
    $colors = [
        'pending' => 'warning',
        'in-progress' => 'info',
        'completed' => 'success',
        'paid' => 'success',
        'overdue' => 'danger',
        'active' => 'success',
        'passive' => 'secondary',
        'inactive' => 'secondary',
        'available' => 'success',
        'busy' => 'warning',
        'unavailable' => 'danger',
    ];
    return $colors[$status] ?? 'secondary';
}

/**
 * Tarih formatını dd.mm.yyyy formatına dönüştürür.
 *
 * @param string $dateString Tarih metni.
 * @return string Formatlanmış tarih metni.
 */
function formatDate($dateString) {
    $date = new DateTime($dateString);
    return $date->format('d.m.Y');
}

/**
 * Sisteme bir log kaydı ekler.
 *
 * @param PDO $pdo Veritabanı bağlantısı.
 * @param string $action Yapılan işlem (örn: 'create', 'update', 'delete', 'login_success').
 * @param string $module İşlemin yapıldığı modül (örn: 'invoices', 'users').
 * @param int|null $record_id İşlem yapılan kaydın ID'si.
 * @param array|null $details İşlemle ilgili ek detaylar (JSON olarak saklanacak).
 * @return void
 */
function add_log(PDO $pdo, string $action, string $module, ?int $record_id = null, ?array $details = null) {
    $sql = "INSERT INTO system_logs (user_id, action, module, record_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $_SESSION['user_id'] ?? null,
        $action,
        $module,
        $record_id,
        $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
        $_SERVER['REMOTE_ADDR'] ?? 'UNKNOWN'
    ]);
}
?>
