<?php
// Modern header component for Fleet Management System
$page_title = $page_title ?? 'Filo Yönetim Sistemi';
$page_subtitle = $page_subtitle ?? '';

// Yaklaşan Bakım Bildirimleri
$upcoming_maintenance_days = 15; // Kaç gün öncesinden uyarı verileceği
$maintenance_notifications = [];
$upcoming_contract_days = 30; // Sözleşme bitiş/yenileme uyarısı için gün sayısı
$contract_notifications = [];
$notification_count = 0; // Toplam bildirim sayısı

if (isset($pdo)) {
    // Bakım bildirimleri
    $maintenance_stmt = $pdo->prepare("
        SELECT v.id, v.plate, vm.next_maintenance_date 
        FROM vehicle_maintenance vm
        JOIN vehicles v ON vm.vehicle_id = v.id
        WHERE vm.next_maintenance_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :days DAY)
        ORDER BY vm.next_maintenance_date ASC
    ");
    $maintenance_stmt->execute([':days' => $upcoming_maintenance_days]);
    $maintenance_notifications = $maintenance_stmt->fetchAll(PDO::FETCH_ASSOC);
    // Sözleşme bildirimleri
    $contract_stmt = $pdo->prepare("SELECT id, contract_no, title, end_date, renewal_date FROM contracts
        WHERE status = 'active' AND (end_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :end_days DAY) OR renewal_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL :renewal_days DAY))
        ORDER BY end_date ASC, renewal_date ASC
    ");
    $contract_stmt->execute([':end_days' => $upcoming_contract_days, ':renewal_days' => $upcoming_contract_days]);
    $contract_notifications = $contract_stmt->fetchAll(PDO::FETCH_ASSOC);

    $notification_count = count($maintenance_notifications) + count($contract_notifications);
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($page_title) ?> | Filo Yönetim Sistemi</title>
    
    <!-- External CSS Libraries -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link rel="stylesheet" href="/filo_yonetim/asset/css/style.css">
</head>
<body>
    <!-- Sidebar -->
    <?php include __DIR__ . '/sidebar.php'; ?>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light">
        <div class="container-fluid">
            <button class="btn btn-sm btn-light mobile-menu-btn" id="mobileMenuToggle" style="display: none;">
                <i class="fas fa-bars"></i>
            </button>
            
            <button class="btn btn-sm btn-light" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            
            <div class="d-flex align-items-center ms-auto">
                <div class="search-container me-3" style="max-width: 300px;">
                    <div class="input-group">
                        <input type="text" class="form-control form-control-sm" placeholder="Ara..." id="globalSearch">
                        <button class="btn btn-primary btn-sm" id="searchButton">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>
                
                <button class="btn btn-sm btn-light d-lg-none" id="mobileSearchToggle">
                    <i class="fas fa-search"></i>
                </button>

                <div class="dropdown ms-2">
                    <a href="#" class="btn btn-sm btn-light position-relative" id="notificationDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                        <?php if ($notification_count > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                                <?= $notification_count ?>
                                <span class="visually-hidden">okunmamış bildirim</span>
                            </span>
                        <?php endif; ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="notificationDropdown" style="width: 350px;">
                        <li class="dropdown-header">Bildirimler</li>
                        <?php if (!empty($maintenance_notifications)): ?>
                            <li class="dropdown-header bg-light">Yaklaşan Bakımlar</li>
                            <?php foreach ($maintenance_notifications as $notification): ?>
                                <li><a class="dropdown-item" href="maintenance.php"> 
                                    <small class="d-block text-muted">Tarih: <?= date('d.m.Y', strtotime($notification['next_maintenance_date'])) ?></small>
                                </a></li>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <?php if (!empty($contract_notifications)): ?>
                            <li class="dropdown-header bg-light">Sözleşme Hatırlatmaları</li>
                            <?php foreach ($contract_notifications as $notification): ?>
                                <li><a class="dropdown-item" href="contracts.php">
                                    <i class="fas fa-file-contract text-info me-2"></i>
                                    <strong><?= htmlspecialchars($notification['contract_no']) ?></strong> sözleşmesi yakında sona eriyor/yenilenecek.
                                    <small class="d-block text-muted">Bitiş/Yenileme: <?= date('d.m.Y', strtotime($notification['end_date'] ?? $notification['renewal_date'])) ?></small>
                                </a></li>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <li><p class="dropdown-item text-muted text-center my-2">Yeni bildirim bulunmuyor.</p></li>
                        <?php endif; ?>
                    </ul>
                </div>
                
                <div class="dropdown ms-3">
                    <a href="#" class-circle me-2">
                        <span class="d-none d-md-inline"><?= htmlspecialchars($_SESSION['user_name'] ?? 'Admin') ?></span>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="dropdownUser">
                        <li><a class="dropdown-item" href="#" data-section="profile">Profil</a></li>
                        <li><a class="dropdown-item" href="settings.php">Ayarlar</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="#" id="highContrastToggle">Yüksek Kontrast</a></li>
                        <li><a class="dropdown-item" href="#" id="darkModeToggle">Koyu Mod</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="logout.php">Çıkış</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <div class="row mb-4">
                <div class="col-12">
                    <h1 class="h4"><?= htmlspecialchars($page_title) ?></h1>
                    <?php if (!empty($page_subtitle)): ?>
                        <p class="text-muted"><?= htmlspecialchars($page_subtitle) ?></p>
                    <?php endif; ?>
                </div>
            </div>
