<?php
require_once 'config.php';

// TCPDF kütüphanesini kullanmak için composer ile yüklemek gerekir
// Alternatif olarak basit HTML to PDF çözümü kullanıyoruz

class InvoicePDFGenerator {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function generateInvoicePDF($invoiceId) {
        // Fatura detaylarını al
        $stmt = $this->pdo->prepare("
            SELECT i.*, 
                   c.name as customer_name, c.phone as customer_phone, 
                   c.email as customer_email, c.address as customer_address,
                   c.tax_office, c.tax_number,
                   v.plate as vehicle_plate, v.type as vehicle_type, v.model as vehicle_model,
                   p.name as driver_name
            FROM invoices i
            LEFT JOIN customers c ON i.customer_id = c.id
            LEFT JOIN vehicles v ON i.vehicle_id = v.id
            LEFT JOIN personnel p ON i.driver_id = p.id
            WHERE i.id = ?
        ");
        $stmt->execute([$invoiceId]);
        $invoice = $stmt->fetch();
        
        if (!$invoice) {
            throw new Exception("Fatura bulunamadı!");
        }
        
        // Tahsilat bilgilerini al
        $stmt = $this->pdo->prepare("
            SELECT * FROM payments 
            WHERE invoice_id = ? 
            ORDER BY payment_date DESC
        ");
        $stmt->execute([$invoiceId]);
        $payments = $stmt->fetchAll();
        
        $totalPaid = array_sum(array_column($payments, 'amount'));
        $remainingAmount = $invoice['total_amount'] - $totalPaid;
        
        // HTML fatura şablonu oluştur
        $html = $this->generateInvoiceHTML($invoice, $payments, $totalPaid, $remainingAmount);
        
        // PDF başlıkları ayarla
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="Fatura_' . $invoice['invoice_no'] . '.pdf"');
        
        // HTML'yi PDF'e çevir (basit yöntem - production'da TCPDF kullanılmalı)
        $this->htmlToPDF($html, $invoice['invoice_no']);
    }
    
    private function generateInvoiceHTML($invoice, $payments, $totalPaid, $remainingAmount) {
        $statusText = $invoice['status'] === 'paid' ? 'ÖDENDİ' : 
                     ($invoice['status'] === 'overdue' ? 'GECİKMİŞ' : 'BEKLEMEDE');
        
        $paymentsHtml = '';
        if (!empty($payments)) {
            $paymentsHtml = '<h4>Tahsilat Geçmişi</h4><table border="1" style="width:100%; border-collapse:collapse;">';
            $paymentsHtml .= '<tr><th>Tarih</th><th>Tutar</th><th>Yöntem</th><th>Referans</th></tr>';
            foreach ($payments as $payment) {
                $paymentsHtml .= '<tr>';
                $paymentsHtml .= '<td>' . date('d.m.Y', strtotime($payment['payment_date'])) . '</td>';
                $paymentsHtml .= '<td>' . number_format($payment['amount'], 2, ',', '.') . '₺</td>';
                $paymentsHtml .= '<td>' . $payment['payment_method'] . '</td>';
                $paymentsHtml .= '<td>' . ($payment['reference_no'] ?: '-') . '</td>';
                $paymentsHtml .= '</tr>';
            }
            $paymentsHtml .= '</table><br>';
        }
        
        return '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Fatura - ' . $invoice['invoice_no'] . '</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 20px; }
                .header { text-align: center; border-bottom: 2px solid #333; padding-bottom: 20px; margin-bottom: 30px; }
                .company-info { text-align: center; margin-bottom: 20px; }
                .invoice-info { display: flex; justify-content: space-between; margin-bottom: 30px; }
                .customer-info, .invoice-details { width: 48%; }
                .invoice-table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                .invoice-table th, .invoice-table td { border: 1px solid #ddd; padding: 10px; text-align: left; }
                .invoice-table th { background-color: #f5f5f5; }
                .total-row { font-weight: bold; background-color: #f9f9f9; }
                .status { padding: 5px 10px; border-radius: 3px; color: white; }
                .status.paid { background-color: #28a745; }
                .status.pending { background-color: #ffc107; color: #000; }
                .status.overdue { background-color: #dc3545; }
                .footer { margin-top: 50px; text-align: center; font-size: 12px; color: #666; }
            </style>
        </head>
        <body>
            <div class="header">
                <div class="company-info">
                    <h1>GAVAL YÖNETİM SİSTEMİ</h1>
                    <p>Filo Yönetim ve Nakliye Hizmetleri</p>
                </div>
            </div>
            
            <div class="invoice-info">
                <div class="customer-info">
                    <h3>MÜŞTERİ BİLGİLERİ</h3>
                    <p><strong>Firma:</strong> ' . $invoice['customer_name'] . '</p>
                    <p><strong>Telefon:</strong> ' . ($invoice['customer_phone'] ?: '-') . '</p>
                    <p><strong>E-posta:</strong> ' . ($invoice['customer_email'] ?: '-') . '</p>
                    <p><strong>Adres:</strong> ' . ($invoice['customer_address'] ?: '-') . '</p>
                    <p><strong>Vergi Dairesi:</strong> ' . ($invoice['tax_office'] ?: '-') . '</p>
                    <p><strong>Vergi No:</strong> ' . ($invoice['tax_number'] ?: '-') . '</p>
                </div>
                
                <div class="invoice-details">
                    <h3>FATURA BİLGİLERİ</h3>
                    <p><strong>Fatura No:</strong> ' . $invoice['invoice_no'] . '</p>
                    <p><strong>Fiş No:</strong> ' . $invoice['receipt_no'] . '</p>
                    <p><strong>Tarih:</strong> ' . date('d.m.Y', strtotime($invoice['invoice_date'])) . '</p>
                    <p><strong>Vade Tarihi:</strong> ' . ($invoice['due_date'] ? date('d.m.Y', strtotime($invoice['due_date'])) : '-') . '</p>
                    <p><strong>Durum:</strong> <span class="status ' . $invoice['status'] . '">' . $statusText . '</span></p>
                    <p><strong>Araç:</strong> ' . $invoice['vehicle_plate'] . ' (' . $invoice['vehicle_type'] . ')</p>
                    <p><strong>Şoför:</strong> ' . ($invoice['driver_name'] ?: '-') . '</p>
                </div>
            </div>
            
            <table class="invoice-table">
                <thead>
                    <tr>
                        <th>Hizmet Türü</th>
                        <th>Birim Fiyat</th>
                        <th>Miktar</th>
                        <th>Tutar</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>' . $invoice['service_type'] . '</td>
                        <td>' . number_format($invoice['unit_price'], 2, ',', '.') . '₺</td>
                        <td>' . $invoice['quantity'] . '</td>
                        <td>' . number_format($invoice['amount'], 2, ',', '.') . '₺</td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: right;"><strong>Ara Toplam:</strong></td>
                        <td><strong>' . number_format($invoice['amount'], 2, ',', '.') . '₺</strong></td>
                    </tr>
                    <tr>
                        <td colspan="3" style="text-align: right;"><strong>KDV (%' . $invoice['tax_rate'] . '):</strong></td>
                        <td><strong>' . number_format($invoice['tax_amount'], 2, ',', '.') . '₺</strong></td>
                    </tr>
                    <tr class="total-row">
                        <td colspan="3" style="text-align: right;"><strong>GENEL TOPLAM:</strong></td>
                        <td><strong>' . number_format($invoice['total_amount'], 2, ',', '.') . '₺</strong></td>
                    </tr>
                </tbody>
            </table>
            
            ' . ($invoice['description'] ? '<p><strong>Açıklama:</strong> ' . $invoice['description'] . '</p>' : '') . '
            
            <div style="margin-top: 30px;">
                <h4>ÖDEME BİLGİLERİ</h4>
                <p><strong>Ödeme Yöntemi:</strong> ' . $invoice['payment_method'] . '</p>
                <p><strong>Toplam Tutar:</strong> ' . number_format($invoice['total_amount'], 2, ',', '.') . '₺</p>
                <p><strong>Ödenen Tutar:</strong> ' . number_format($totalPaid, 2, ',', '.') . '₺</p>
                <p><strong>Kalan Tutar:</strong> ' . number_format($remainingAmount, 2, ',', '.') . '₺</p>
            </div>
            
            ' . $paymentsHtml . '
            
            <div class="footer">
                <p>Bu fatura elektronik ortamda oluşturulmuş olup, yasal geçerliliği vardır.</p>
                <p>Fatura tarihi: ' . date('d.m.Y H:i') . '</p>
            </div>
        </body>
        </html>';
    }
    
    private function htmlToPDF($html, $filename) {
        // Basit HTML çıktısı (gerçek PDF için TCPDF/MPDF gerekir)
        // Şimdilik HTML olarak indirme yapıyoruz
        header('Content-Type: text/html; charset=UTF-8');
        header('Content-Disposition: attachment; filename="Fatura_' . $filename . '.html"');
        echo $html;
    }
}

// API endpoint
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'generate_pdf') {
    try {
        $invoiceId = $_GET['invoice_id'] ?? null;
        
        if (!$invoiceId) {
            throw new Exception("Fatura ID gerekli!");
        }
        
        $generator = new InvoicePDFGenerator($pdo);
        $generator->generateInvoicePDF($invoiceId);
        
    } catch (Exception $e) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
}
?>
