<?php
require_once 'config.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        // Yeni müşteri ekleme
        $code = sanitize_input($_POST['code']);
        $type = sanitize_input($_POST['type']);
        $name = sanitize_input($_POST['name']);
        $tax_number = sanitize_input($_POST['tax_number']);
        $phone = sanitize_input($_POST['phone']);
        $email = sanitize_input($_POST['email']);
        $address = sanitize_input($_POST['address']);
        $industry = sanitize_input($_POST['industry']);
        $status = sanitize_input($_POST['status']);
        
        $stmt = $pdo->prepare("INSERT INTO customers (code, type, name, tax_number, phone, email, address, industry, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$code, $type, $name, $tax_number, $phone, $email, $address, $industry, $status]);
        
        header("Location: ../customers.php?success=added");
        exit();
    }
}
?>