<?php
// Hata raporlama
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Define database constants
define('DB_HOST', 'localhost');
define('DB_NAME', 'filo_yonetim');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

// Application constants
define('SITE_URL', 'http://' . $_SERVER['HTTP_HOST'] . '/filo_yonetim');
define('UPLOAD_DIR', __DIR__ . '/../uploads');

// Create uploads directory if it doesn't exist
if (!file_exists(UPLOAD_DIR)) {
    mkdir(UPLOAD_DIR, 0755, true);
}

/**
 * Get PDO database connection
 * @return PDO
 */
function getPDO() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_PERSISTENT => false
            ];
            
            $pdo = new PDO($dsn, DB_USER, DB_PASSWORD, $options);
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception("Veritabanı bağlantı hatası. Lütfen daha sonra tekrar deneyiniz.");
        }
    }
    
    return $pdo;
}

// Set timezone
date_default_timezone_set('Europe/Istanbul');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}

/**
 * Load user permissions from database and store in session
 */
function loadUserPermissions() {
    if (!isLoggedIn()) {
        $_SESSION['permissions'] = [];
        return;
    }
    
    try {
        $pdo = getPDO();
        
        // Get role-based permissions
        $stmt = $pdo->prepare("
            SELECT DISTINCT CONCAT(LOWER(p.module), '_', LOWER(p.name)) as permission
            FROM role_permissions rp
            JOIN permissions p ON rp.permission_id = p.id
            JOIN user_roles ur ON ur.role_id = rp.role_id
            WHERE ur.user_id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $rolePermissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Get user-specific permissions (overrides)
        $stmt = $pdo->prepare("
            SELECT DISTINCT CONCAT(LOWER(p.module), '_', LOWER(p.name)) as permission
            FROM user_permissions up
            JOIN permissions p ON up.permission_id = p.id
            WHERE up.user_id = ?
        ");
        $stmt->execute([$_SESSION['user_id']]);
        $userPermissions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Combine and store in session
        $_SESSION['permissions'] = array_unique(array_merge($rolePermissions, $userPermissions));
        
    } catch (PDOException $e) {
        error_log("Permission loading error: " . $e->getMessage());
        $_SESSION['permissions'] = [];
    }
}

/**
 * Check if user has permission to perform an action on a module
 * @param string $module The module to check permissions for
 * @param string $action The action to check (view, create, edit, delete, etc.)
 * @return bool True if user has permission, false otherwise
 */
function hasPermission($module, $action = 'view') {
    // Admin has all permissions
    if (isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin') {
        return true;
    }
    
    // If user is not logged in, no permissions
    if (!isLoggedIn()) {
        return false;
    }
    
    // Load user permissions if not already loaded
    if (!isset($_SESSION['permissions'])) {
        loadUserPermissions();
    }
    
    // Check if the specific permission exists
    $permissionString = strtolower($module . '_' . $action);
    return in_array($permissionString, $_SESSION['permissions'] ?? []);
}

// Function to redirect
function redirect($url) {
    header("Location: " . $url);
    exit();
}

// Function to sanitize input
function sanitize($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Generate a full URL for the given path
 * @param string $path The path to append to the base URL
 * @return string The full URL
 */
function base_url($path = '') {
    $base = rtrim(SITE_URL, '/');
    $path = ltrim($path, '/');
    return $base . ($path ? '/' . $path : '');
}

// CSRF Token oluşturma
function generate_csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF Token doğrulama
function verify_csrf_token($token) {
    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        die('CSRF token doğrulaması başarısız!');
    }
    return true;
}

// Şifre hashleme
function hash_password($password) {
    return password_hash($password, PASSWORD_BCRYPT, ['cost' => 12]);
}

// Şifre doğrulama
function verify_password($password, $hash) {
    return password_verify($password, $hash);
}

// Güçlü şifre kontrolü
function is_strong_password($password) {
    $uppercase = preg_match('@[A-Z]@', $password);
    $lowercase = preg_match('@[a-z]@', $password);
    $number    = preg_match('@[0-9]@', $password);
    $special   = preg_match('@[^\w]@', $password);
    
    return ($uppercase && $lowercase && $number && $special && strlen($password) >= 8);
}

// Auto-load classes
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/../classes/' . $class . '.php';
    if (file_exists($file)) {
        require $file;
    }
});