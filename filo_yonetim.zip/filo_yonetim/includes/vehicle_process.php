<?php
require_once 'config.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        // Yeni araç ekleme
        $plate = sanitize_input($_POST['plate']);
        $type = sanitize_input($_POST['type']);
        $model = sanitize_input($_POST['model']);
        $year = sanitize_input($_POST['year']);
        $status = sanitize_input($_POST['status']);
        $availability = sanitize_input($_POST['availability']);
        $last_maintenance = !empty($_POST['last_maintenance']) ? $_POST['last_maintenance'] : null;
        $next_maintenance = !empty($_POST['next_maintenance']) ? $_POST['next_maintenance'] : null;
        
        // Plakanın benzersiz olup olmadığını kontrol et
        $stmt = $pdo->prepare("SELECT id FROM vehicles WHERE plate = ?");
        $stmt->execute([$plate]);
        if ($stmt->rowCount() > 0) {
            header("Location: ../vehicles.php?error=plate_exists");
            exit();
        }
        
        $stmt = $pdo->prepare("INSERT INTO vehicles (plate, type, model, year, status, availability, last_maintenance, next_maintenance) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$plate, $type, $model, $year, $status, $availability, $last_maintenance, $next_maintenance]);
        
        header("Location: ../vehicles.php?success=added");
        exit();
    }
}
?>