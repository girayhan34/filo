<?php
// session_start() burada zaten başlamış olabileceğinden kaldırıldı.

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini veritabanından al
require_once 'config.php';
$pdo = getPDO(); // PDO bağlantısını başlat
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("
    SELECT u.*, r.role_name 
    FROM users u
    LEFT JOIN user_roles ur ON u.id = ur.user_id
    LEFT JOIN roles r ON ur.role_id = r.id
    WHERE u.id = ?
");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if (!$user || $user['status'] !== 'active') {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini session'da güncelle
$_SESSION['user_name'] = $user['name'];
$_SESSION['user_role'] = $user['role_name'] ?? 'User'; // Rol bulunamazsa varsayılan olarak 'User' ata

/**
 * Kullanıcının belirtilen yetkiye sahip olup olmadığını kontrol eder
 * @param string $izin Kullanıcının sahip olması gereken yetki kodu
 * @return bool Yetki varsa true, yoksa false döndürür
 */
function yetki_kontrol($izin) {
    // Mevcut hasPermission fonksiyonunu kullan
    // İzin kodunu module.action formatına çeviriyoruz
    $parts = explode('_', $izin, 2);
    $module = $parts[0] ?? '';
    $action = $parts[1] ?? 'view'; // Varsayılan aksiyon 'view' olarak ayarlandı
    
    return hasPermission($module, $action);
}

// loadUserPermissions function is now defined in config.php

// isLoggedIn() function is defined in config.php
?>
