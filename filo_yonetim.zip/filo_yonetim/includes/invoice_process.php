<?php
require_once 'config.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    
    if ($action == 'add') {
        // Yeni fatura ekleme
        $invoice_no = sanitize_input($_POST['invoice_no']);
        $receipt_no = sanitize_input($_POST['receipt_no']);
        $customer_id = intval($_POST['customer_id']);
        $service_type = sanitize_input($_POST['service_type']);
        $date = sanitize_input($_POST['date']);
        $unit_price = floatval($_POST['unit_price']);
        $quantity = intval($_POST['quantity']);
        $tax_rate = floatval($_POST['tax_rate']);
        $description = sanitize_input($_POST['description']);
        $payment_method = sanitize_input($_POST['payment_method']);
        $status = sanitize_input($_POST['status']);
        
        // Hesaplamalar
        $amount = $unit_price * $quantity;
        $tax_amount = $amount * ($tax_rate / 100);
        $total_amount = $amount + $tax_amount;
        
        // Fatura numarasının benzersiz olup olmadığını kontrol et
        $stmt = $pdo->prepare("SELECT id FROM invoices WHERE invoice_no = ?");
        $stmt->execute([$invoice_no]);
        if ($stmt->rowCount() > 0) {
            header("Location: ../invoices.php?error=invoice_exists");
            exit();
        }
        
        $stmt = $pdo->prepare("INSERT INTO invoices (invoice_no, receipt_no, customer_id, service_type, date, unit_price, quantity, amount, tax_rate, tax_amount, total_amount, description, payment_method, status) 
                              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$invoice_no, $receipt_no, $customer_id, $service_type, $date, $unit_price, $quantity, $amount, $tax_rate, $tax_amount, $total_amount, $description, $payment_method, $status]);
        
        header("Location: ../invoices.php?success=added");
        exit();
    }
}
?>