<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Filtreler için pozisyonları ve departmanları çek
$positions = $pdo->query("SELECT DISTINCT position FROM personnel WHERE position IS NOT NULL AND position != '' ORDER BY position ASC")->fetchAll(PDO::FETCH_COLUMN);
$departments = $pdo->query("SELECT DISTINCT department FROM personnel WHERE department IS NOT NULL AND department != '' ORDER BY department ASC")->fetchAll(PDO::FETCH_COLUMN);
?>
<?php
$page_title = 'Personel Yönetimi';
$page_subtitle = 'Personel kayıtlarını, vardiyaları ve performansları yönetin.';
include 'includes/header.php';
?>
                <!-- Arama ve Filtreleme -->
                <div class="card border-0 shadow-sm mb-4">
                    <div class="card-body p-3">
                        <div class="row g-3 align-items-end">
                            <div class="col-md-4">
                                <label for="statusFilter" class="form-label">Durum</label>
                                <select class="form-select form-select-sm" id="statusFilter">
                                    <option value="">Tüm Durumlar</option>
                                    <option value="active">Aktif</option>
                                    <option value="on_leave">İzinli</option>
                                    <option value="inactive">Pasif</option>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="departmentFilter" class="form-label">Departman</label>
                                <select class="form-select form-select-sm" id="departmentFilter">
                                    <option value="">Tüm Departmanlar</option>
                                    <?php foreach ($departments as $department): ?>
                                        <option value="<?= htmlspecialchars($department) ?>"><?= htmlspecialchars($department) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4">
                                <label for="positionFilter" class="form-label">Pozisyon</label>
                                <select class="form-select form-select-sm" id="positionFilter">
                                    <option value="">Tüm Pozisyonlar</option>
                                    <?php foreach ($positions as $position): ?>
                                        <option value="<?= htmlspecialchars($position) ?>"><?= htmlspecialchars($position) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Personel Listesi -->
                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white border-0 py-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><i class="fas fa-users me-2 text-primary"></i>Personel Listesi</h5>
                            <div class="d-flex">
                                <button class="btn btn-sm btn-outline-secondary me-2" onclick="exportPersonnel()">
                                    <i class="fas fa-download me-1"></i> Dışa Aktar
                                </button>
                                <button class="btn btn-sm btn-outline-secondary" onclick="printPersonnel()">
                                    <i class="fas fa-print me-1"></i> Yazdır
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="card-body p-0">
                        <div class="table-responsive">
                            <table class="table table-hover align-middle mb-0" id="personnelTable">
                                <thead class="table-light">
                                    <tr>
                                        <th>Ad Soyad</th>
                                        <th>Pozisyon</th>
                                        <th>Telefon</th>
                                        <th>Durum</th>
                                        <th>Son Vardiya</th>
                                        <th>Performans</th>
                                        <th>Belgeler</th>
                                        <th>İşlemler</th>
                                    </tr>
                                </thead>
                                <tbody class="border-top-0">
                                    <!-- DataTables tarafından sunucu taraflı olarak doldurulacak -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
<!-- DataTables CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.bootstrap5.min.css">

<?php include 'includes/footer.php'; ?>

<!-- DataTables JS -->
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.11.5/js/dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.bootstrap5.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
<script src="/filo_yonetim/asset/js/crud-datatable-helper.js"></script>

<script>
// Global Değişkenler
let personnelTable;
let currentPersonnelId = null;

// Personel silme onayı
function confirmDelete(id, name) {
    Swal.fire({
        title: 'Emin misiniz?',
        text: `"${name}" isimli personeli silmek istediğinize emin misiniz? Bu işlem geri alınamaz!`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Evet, sil!',
        cancelButtonText: 'İptal',
        backdrop: 'rgba(0,0,0,0.4)'
    }).then((result) => {
        if (result.isConfirmed) {
            // Silme işlemi AJAX ile yapılacak
            fetch(`/filo_yonetim/api/personnel/${id}`, {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    Swal.fire(
                        'Silindi!',
                        'Personel başarıyla silindi.',
                        'success'
                    ).then(() => {
                        window.location.reload();
                    });
                } else {
                    throw new Error(data.message || 'Silme işlemi başarısız oldu.');
                }
            })
            .catch(error => {
                console.error('Hata:', error);
                Swal.fire(
                    'Hata!',
                    'Personel silinirken bir hata oluştu: ' + error.message,
                    'error'
                );
            });
        }
    });
}

function viewPersonnelDetails(personnelId) {
    currentPersonnelId = personnelId;
    const modal = new bootstrap.Modal(document.getElementById('personnelDetailModal'));
    const content = document.getElementById('personnelDetailContent');

    // Yükleme göstergesi
    content.innerHTML = `
        <div class="text-center py-5">
            <div class="spinner-border text-primary" role="status">
                <span class="visually-hidden">Yükleniyor...</span>
            </div>
            <p class="mt-2 text-muted">Personel detayları yükleniyor...</p>
        </div>
    `;
    modal.show();

    // API'den verileri çek
    fetch(`../api/personel_api.php?action=get_details&id=${personnelId}`)
        .then(response => response.json())
        .then(response => {
            if (response.status === 'success') {
                const data = response.data;
                const p = data.details;
                
                let leavesHtml = '';
                if (data.leaves.length > 0) {
                    data.leaves.forEach(leave => {
                        const durumClass = leave.durum === 'Onaylandı' ? 'success' : (leave.durum === 'Reddedildi' ? 'danger' : 'warning');
                        leavesHtml += `
                            <tr>
                                <td>${moment(leave.baslangic_tarihi).format('DD.MM.YYYY')}</td>
                                <td>${leave.izin_tipi}</td>
                                <td>${leave.toplam_gun} gün</td>
                                <td><span class="badge bg-${durumClass}">${leave.durum}</span></td>
                            </tr>
                        `;
                    });
                } else {
                    leavesHtml = '<tr><td colspan="4" class="text-center text-muted">İzin kaydı bulunamadı.</td></tr>';
                }

                let documentsHtml = '';
                if (data.documents.length > 0) {
                    data.documents.forEach(doc => {
                        documentsHtml += `
                            <tr>
                                <td><i class="fas fa-file-alt me-2 text-info"></i>${doc.document_type}</td>
                                <td>${doc.file_name}</td>
                                <td>${moment(doc.uploaded_at).format('DD.MM.YYYY')}</td>
                                <td><a href="../${doc.file_path}" target="_blank" class="btn btn-sm btn-outline-primary"><i class="fas fa-download"></i></a></td>
                            </tr>
                        `;
                    });
                } else {
                    documentsHtml = '<tr><td colspan="4" class="text-center text-muted">Belge kaydı bulunamadı.</td></tr>';
                }

                let shiftsHtml = '';
                if (data.shifts.length > 0) {
                    data.shifts.forEach(shift => {
                        const durumClass = shift.status === 'completed' ? 'success' : (shift.status === 'active' ? 'primary' : 'secondary');
                        shiftsHtml += `
                            <tr>
                                <td>${moment(shift.shift_date).format('DD.MM.YYYY')}</td>
                                <td>${moment(shift.start_time, 'HH:mm:ss').format('HH:mm')} - ${moment(shift.end_time, 'HH:mm:ss').format('HH:mm')}</td>
                                <td>${shift.shift_type}</td>
                                <td>${shift.plate_number || '-'}</td>
                                <td><span class="badge bg-${durumClass}">${shift.status}</span></td>
                            </tr>
                        `;
                    });
                } else {
                    shiftsHtml = '<tr><td colspan="5" class="text-center text-muted">Vardiya kaydı bulunamadı.</td></tr>';
                }

                let performancesHtml = '';
                if (data.performances.length > 0) {
                    data.performances.forEach(perf => {
                        const puanClass = perf.puan_toplam >= 40 ? 'success' : (perf.puan_toplam >= 25 ? 'warning' : 'danger');
                        performancesHtml += `
                            <tr>
                                <td>${moment(perf.degerlendirme_tarihi).format('DD.MM.YYYY')}</td>
                                <td>${perf.degerlendiren_adi || 'Bilinmiyor'}</td>
                                <td><span class="badge bg-${puanClass}">${(perf.puan_toplam / 5).toFixed(1)} / 10</span></td>
                            </tr>
                        `;
                    });
                } else {
                    performancesHtml = '<tr><td colspan="3" class="text-center text-muted">Performans kaydı bulunamadı.</td></tr>';
                }

                let salariesHtml = '';
                if (data.salaries.length > 0) {
                    const monthNames = ["", "Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];
                    data.salaries.forEach(salary => {
                        const durumClass = salary.odeme_durumu === 'Ödendi' ? 'success' : (salary.odeme_durumu === 'Gecikmiş' ? 'danger' : 'warning');
                        salariesHtml += `
                            <tr>
                                <td>${monthNames[salary.donem_ay]} ${salary.donem_yil}</td>
                                <td class="text-end">${parseFloat(salary.brut_ucret).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}</td>
                                <td class="text-end text-danger">-${parseFloat(salary.kesintiler_toplami).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}</td>
                                <td class="text-end fw-bold">${parseFloat(salary.net_ucret).toLocaleString('tr-TR', { style: 'currency', currency: 'TRY' })}</td>
                                <td><span class="badge bg-${durumClass}">${salary.odeme_durumu}</span></td>
                            </tr>
                        `;
                    });
                } else {
                    salariesHtml = '<tr><td colspan="5" class="text-center text-muted">Maaş/Bordro kaydı bulunamadı.</td></tr>';
                }

                const editContactFormHtml = `
                    <form id="editContactForm">
                        <input type="hidden" name="id" value="${p.id}">
                        <div class="mb-3">
                            <label for="editEmail" class="form-label">E-posta Adresi</label>
                            <input type="email" class="form-control" id="editEmail" name="email" value="${p.email || ''}">
                        </div>
                        <div class="mb-3">
                            <label for="editPhone" class="form-label">Telefon Numarası</label>
                            <input type="tel" class="form-control" id="editPhone" name="phone" value="${p.phone || ''}">
                        </div>
                        <div class="mb-3">
                            <label for="editAddress" class="form-label">Adres</label>
                            <textarea class="form-control" id="editAddress" name="address" rows="3">${p.address || ''}</textarea>
                        </div>
                        <div class="text-end">
                            <button type="submit" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Değişiklikleri Kaydet
                            </button>
                        </div>
                    </form>
                `;

                content.innerHTML = `
                    <div class="row g-4">
                        <div class="col-lg-4 text-center border-end">
                            <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(p.name)}&background=random&size=128" class="rounded-circle mb-3 shadow-sm">
                            <h4 class="mb-1">${p.name || ''}</h4>
                            <p class="text-muted mb-2">${p.position || '-'}</p>
                            <hr>
                            <div class="text-start">
                                <p><i class="fas fa-envelope fa-fw me-2 text-muted"></i>${p.email || '-'}</p>
                                <p><i class="fas fa-phone fa-fw me-2 text-muted"></i>${p.phone || '-'}</p>
                                <p><i class="fas fa-building fa-fw me-2 text-muted"></i>${p.department || '-'}</p>
                                <p><i class="fas fa-calendar-alt fa-fw me-2 text-muted"></i>İşe Giriş: ${p.hire_date ? moment(p.hire_date).format('DD.MM.YYYY') : '-'}</p>
                            </div>
                        </div>
                        <div class="col-lg-8">
                            <ul class="nav nav-tabs nav-fill mb-3" id="personnelDetailTabs" role="tablist">
                                <li class="nav-item" role="presentation"><button class="nav-link active" id="shifts-tab" data-bs-toggle="tab" data-bs-target="#shifts" type="button" role="tab">Vardiyalar</button></li>
                                <li class="nav-item" role="presentation"><button class="nav-link" id="leaves-tab" data-bs-toggle="tab" data-bs-target="#leaves" type="button" role="tab">İzinler</button></li>
                                <li class="nav-item" role="presentation"><button class="nav-link" id="salary-tab" data-bs-toggle="tab" data-bs-target="#salary" type="button" role="tab">Maaş</button></li>
                                <li class="nav-item" role="presentation"><button class="nav-link" id="performance-tab" data-bs-toggle="tab" data-bs-target="#performance" type="button" role="tab">Performans</button></li>
                                <li class="nav-item" role="presentation"><button class="nav-link" id="edit-contact-tab" data-bs-toggle="tab" data-bs-target="#edit-contact" type="button" role="tab"><i class="fas fa-edit"></i></button></li>
                                <li class="nav-item" role="presentation"><button class="nav-link" id="documents-tab" data-bs-toggle="tab" data-bs-target="#documents" type="button" role="tab">Belgeler</button></li>
                            </ul>
                            <div class="tab-content" id="personnelDetailTabsContent">
                                <div class="tab-pane fade show active" id="shifts" role="tabpanel">
                                    <h5 class="mb-3">Son Vardiyalar</h5>
                                    <div class="table-responsive"><table class="table table-sm table-striped table-hover">
                                        <thead class="table-light"><tr><th>Tarih</th><th>Saatler</th><th>Tür</th><th>Araç</th><th>Durum</th></tr></thead>
                                        <tbody>${shiftsHtml}</tbody>
                                    </table></div>
                                </div>
                                <div class="tab-pane fade" id="leaves" role="tabpanel">
                                    <h5 class="mb-3">Son İzin Talepleri</h5>
                                    <div class="table-responsive"><table class="table table-sm table-striped table-hover">
                                        <thead class="table-light"><tr><th>Tarih</th><th>Tür</th><th>Süre</th><th>Durum</th></tr></thead>
                                        <tbody>${leavesHtml}</tbody>
                                    </table></div>
                                </div>
                                <div class="tab-pane fade" id="salary" role="tabpanel">
                                    <h5 class="mb-3">Son Bordrolar</h5>
                                    <div class="table-responsive"><table class="table table-sm table-striped table-hover">
                                        <thead class="table-light"><tr><th>Dönem</th><th class="text-end">Brüt Ücret</th><th class="text-end">Kesintiler</th><th class="text-end">Net Ücret</th><th>Durum</th></tr></thead>
                                        <tbody>${salariesHtml}</tbody>
                                    </table></div>
                                </div>
                                <div class="tab-pane fade" id="performance" role="tabpanel">
                                    <h5 class="mb-3">Son Performans Değerlendirmeleri</h5>
                                    <div class="table-responsive"><table class="table table-sm table-striped table-hover">
                                        <thead class="table-light"><tr><th>Tarih</th><th>Değerlendiren</th><th>Puan</th></tr></thead>
                                        <tbody>${performancesHtml}</tbody>
                                    </table></div>
                                </div>
                                <div class="tab-pane fade" id="documents" role="tabpanel">
                                    <h5 class="mb-3">Son Yüklenen Belgeler</h5>
                                    <div class="table-responsive"><table class="table table-sm table-striped table-hover">
                                        <thead class="table-light"><tr><th>Tür</th><th>Dosya Adı</th><th>Yüklenme Tarihi</th><th>İndir</th></tr></thead>
                                        <tbody>${documentsHtml}</tbody>
                                    </table></div>
                                </div>
                                <div class="tab-pane fade" id="edit-contact" role="tabpanel">
                                    <h5 class="mb-3">İletişim Bilgilerini Düzenle</h5>
                                    ${editContactFormHtml}
                                    </table></div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            } else {
                content.innerHTML = `<div class="alert alert-danger">${response.message}</div>`;
            }
        })
        .catch(error => {
            console.error('Hata:', error);
            content.innerHTML = `<div class="alert alert-danger">Detaylar yüklenirken bir hata oluştu.</div>`;
        });
}

// Personel düzenleme fonksiyonu
function editPersonnel(id) {
    // Örnek veri yükleme
    fetch(`/filo_yonetim/api/personnel/${id}`)
        .then(response => response.json())
        .then(personnel => {
            // Form alanlarını doldur
            const form = document.getElementById('addPersonnelForm');
            form.querySelector('input[name="name"]').value = personnel.name || '';
            form.querySelector('input[name="position"]').value = personnel.position || '';
            // Diğer alanları da doldur...

            // Modal başlığını güncelle
            document.querySelector('#addPersonnelModal .modal-title').innerHTML = 
                `<i class="fas fa-user-edit me-2"></i>Personel Düzenle`;

            // Form submit işleyicisini güncelle
            form.onsubmit = function(e) {
                e.preventDefault();
                // Güncelleme işlemi
                console.log('Güncelleniyor:', id, Object.fromEntries(new FormData(form)));
                // Başarılı olduğunda kullanıcıya bildir ve sayfayı yenile
                Swal.fire(
                    'Başarılı!',
                    'Personel bilgileri güncellendi.',
                    'success'
                ).then(() => {
                    window.location.reload();
                });
            };

            // Modalı aç
            const modal = new bootstrap.Modal(document.getElementById('addPersonnelModal'));
            modal.show();
        })
        .catch(error => {
            console.error('Hata:', error);
            Swal.fire(
                'Hata!',
                'Personel bilgileri yüklenirken bir hata oluştu.',
                'error'
            );
        });
}

// Vardiya ekleme fonksiyonu
function addShift(personnelId) {
    // Personel bilgilerini yükle
    fetch(`/filo_yonetim/api/personnel/${personnelId}`)
        .then(response => response.json())
        .then(personnel => {
            // Vardiya ekleme formunu doldur
            document.querySelector('#addShiftModal [name="personnel_id"]').value = personnel.id;
            document.querySelector('#addShiftModal #personnelName').textContent = personnel.name;
            
            // Varsayılan değerleri ayarla
            const now = new Date();
            const startDate = now.toISOString().slice(0, 16);
            const endDate = new Date(now.getTime() + 8 * 60 * 60 * 1000).toISOString().slice(0, 16);

            document.querySelector('#addShiftModal [name="start_date"]').value = startDate;
            document.querySelector('#addShiftModal [name="end_date"]').value = endDate;

            // Modalı aç
            const modal = new bootstrap.Modal(document.getElementById('addShiftModal'));
            modal.show();
        });
}

$(document).ready(function() {
    personnelTable = $('#personnelTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: {
            url: '../api/personel_api.php?action=list',
            type: 'POST',
            data: function(d) {
                d.status = $('#statusFilter').val();
                d.department = $('#departmentFilter').val();
                d.position = $('#positionFilter').val();
            }
        },
        columns: [
            { 
                data: 'name',
                render: function(data, type, row) {
                    const status_class = row.status === 'active' ? 'success' : (row.status === 'on_leave' ? 'warning' : 'secondary');
                    const initial = data ? data.charAt(0).toUpperCase() : '?';
                    return `
                        <div class="d-flex align-items-center">
                            <div class="avatar avatar-sm me-3">
                                <span class="avatar-initial rounded-circle bg-soft-${status_class} text-${status_class}">${initial}</span>
                            </div>
                            <div>
                                <h6 class="mb-0">${row.name || ''}</h6>
                                <small class="text-muted">${row.email || ''}</small>
                            </div>
                        </div>`;
                }
            },
            { 
                data: 'position',
                render: function(data, type, row) {
                    return `<span class="d-block">${data || '-'}</span>
                            <small class="text-muted">${row.department || 'Departman yok'}</small>`;
                }
            },
            { data: 'phone' },
            { 
                data: 'status',
                render: function(data, type, row) {
                    const status_map = {
                        'active': { text: 'Aktif', class: 'success' },
                        'on_leave': { text: 'İzinli', class: 'warning' },
                        'inactive': { text: 'Pasif', class: 'secondary' }
                    };
                    const status_info = status_map[data] || { text: 'Bilinmiyor', class: 'secondary' };
                    return `<span class="badge bg-soft-${status_info.class} text-${status_info.class} d-inline-flex align-items-center">
                                <span class="dot bg-${status_info.class} me-1"></span>
                                ${status_info.text}
                            </span>`;
                }
            },
            { 
                data: 'last_shift_date',
                render: function(data, type, row) {
                    if (!data) return '<span class="text-muted">Kayıt yok</span>';
                    return `<div class="d-flex flex-column">
                                <span class="text-dark">${moment(data).format('DD MMM YYYY')}</span>
                                <small class="text-muted">${moment(data).format('HH:mm')}</small>
                            </div>`;
                }
            },
            { 
                data: 'avg_performance',
                render: function(data, type, row) {
                    const score = parseFloat(data) || 0;
                    if (score === 0) return '<span class="badge bg-soft-secondary text-secondary">Değerlendirme yok</span>';
                    const perf_class = score > 7 ? 'success' : (score > 5 ? 'warning' : 'danger');
                    return `<div class="d-flex align-items-center">
                                <div class="progress flex-grow-1 me-2" style="height: 6px;">
                                    <div class="progress-bar bg-${perf_class}" role="progressbar" style="width: ${score * 10}%"></div>
                                </div>
                                <span class="fw-medium text-${perf_class}" style="min-width: 45px;">${score.toFixed(1)}/10</span>
                            </div>`;
                }
            },
            { 
                data: 'document_count',
                render: function(data, type, row) {
                    const count = parseInt(data) || 0;
                    if (count === 0) return '<span class="badge bg-soft-secondary text-secondary"><i class="fas fa-times-circle me-1"></i> Yok</span>';
                    return `<span class="badge bg-soft-info text-info d-inline-flex align-items-center"><i class="fas fa-file-alt me-1"></i> ${count}</span>`;
                }
            },
            {
                data: null,
                orderable: false,
                render: function(data, type, row) {
                    return `<div class="dropdown">
                                <button class="btn btn-sm btn-icon btn-light rounded-circle shadow-sm" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    <i class="fas fa-ellipsis-v text-muted"></i>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end border-0 shadow-sm" style="min-width: 180px;">
                                    <li><a class="dropdown-item d-flex align-items-center py-2" href="#" onclick="viewPersonnelDetails(${row.id})"><i class="fas fa-eye me-2 text-primary"></i> Detaylar</a></li>
                                    <li><a class="dropdown-item d-flex align-items-center py-2" href="#" onclick="editPersonnel(${row.id})"><i class="fas fa-edit me-2 text-success"></i> Düzenle</a></li>
                                    <li><a class="dropdown-item d-flex align-items-center py-2" href="#" onclick="addShift(${row.id})"><i class="fas fa-calendar-plus me-2 text-info"></i> Vardiya Ekle</a></li>
                                    <li><hr class="dropdown-divider my-2"></li>
                                    <li><a class="dropdown-item d-flex align-items-center py-2 text-danger" href="#" onclick="confirmDelete(${row.id}, '${row.name.replace(/'/g, "\\'")}')"><i class="fas fa-trash-alt me-2"></i> Sil</a></li>
                                </ul>
                            </div>`;
                }
            }
        ],
        order: [[0, 'asc']],
        language: getDataTablesLanguage(),
        dom: '<"row"<"col-md-6"l><"col-md-6"f>>rt<"row"<"col-md-6"i><"col-md-6"p>>',
        responsive: true
    });

    // Filtreler değiştiğinde tabloyu yeniden yükle
    $('#statusFilter, #departmentFilter, #positionFilter').on('change', function() {
        personnelTable.ajax.reload();
    });

    // Dinamik olarak oluşturulan iletişim formu için submit event'i
    $(document).on('submit', '#editContactForm', function(e) {
        e.preventDefault();
        const submitButton = $(this).find('button[type="submit"]');
        
        sendAjaxRequest({
            url: '../api/personel_api.php?action=update_contact',
            type: 'POST',
            data: $(this).serialize()
        }, submitButton).then(response => {
            // Başarılı olunca tabloyu ve detayları yenile
            personnelTable.ajax.reload(null, false); // Sayfalama sıfırlanmasın
        });
    });
});
    </script>

    <!-- Personel Detay Modal -->
    <div class="modal fade" id="personnelDetailModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header bg-light">
                    <h5 class="modal-title"><i class="fas fa-user-tie me-2"></i>Personel Detayları</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>
                <div class="modal-body" id="personnelDetailContent">
                    <!-- Dinamik içerik buraya yüklenecek -->
                </div>
            </div>
        </div>
    </div>

    <!-- Yeni Personel Modal -->
    <div class="modal fade" id="addPersonnelModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content border-0 shadow">
                <div class="modal-header bg-light">
                    <h5 class="modal-title text-primary"><i class="fas fa-user-plus me-2"></i>Yeni Personel Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Kapat"></button>
                </div>
                <form id="addPersonnelForm">
                    <div class="modal-body p-4">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label fw-medium">Ad Soyad <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-user text-muted"></i></span>
                                    <input type="text" class="form-control" name="name" placeholder="Personel adı giriniz" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium">Pozisyon <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-briefcase text-muted"></i></span>
                                    <input type="text" class="form-control" name="position" placeholder="Örn: Şoför, Operatör" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium">Telefon</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-phone text-muted"></i></span>
                                    <input type="tel" class="form-control" name="phone" placeholder="(5__) ___ __ __">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium">E-posta</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-envelope text-muted"></i></span>
                                    <input type="email" class="form-control" name="email" placeholder="ornek@firma.com">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium">Departman</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-building text-muted"></i></span>
                                    <select class="form-select" name="department">
                                        <option value="">Seçiniz</option>
                                        <option value="Sürüş">Sürüş</option>
                                        <option value="Lojistik">Lojistik</option>
                                        <option value="Yönetim">Yönetim</option>
                                        <option value="İdari İşler">İdari İşler</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-medium">Durum <span class="text-danger">*</span></label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light"><i class="fas fa-info-circle text-muted"></i></span>
                                    <select class="form-select" name="status" required>
                                        <option value="active">Aktif</option>
                                        <option value="inactive">Pasif</option>
                                        <option value="on_leave">İzinli</option>
                                    <label class="form-label">Maaş</label>
                                    <input type="number" class="form-control" name="salary" step="0.01">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Adres</label>
                            <textarea class="form-control" name="address" rows="2"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Vardiya Ekleme Modal -->
    <div class="modal fade" id="addShiftModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-calendar-plus"></i> Vardiya Ekle</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="addShiftForm">
                    <div class="modal-body">
                        <input type="hidden" id="shift_personnel_id" name="personnel_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Vardiya Tarihi *</label>
                                    <input type="date" class="form-control" name="shift_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Vardiya Türü *</label>
                                    <select class="form-select" name="shift_type" required>
                                        <option value="normal">Normal</option>
                                        <option value="overtime">Fazla Mesai</option>
                                        <option value="night">Gece</option>
                                        <option value="weekend">Hafta Sonu</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Başlangıç Saati *</label>
                                    <input type="time" class="form-control" name="start_time" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Bitiş Saati *</label>
                                    <input type="time" class="form-control" name="end_time" required>
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Araç</label>
                            <select class="form-select" name="vehicle_id">
                                <option value="">Araç seçiniz</option>
                                <?php
                                $vehicle_stmt = $pdo->prepare("SELECT id, plate_number, brand, model FROM vehicles WHERE status = 'active'");
                                $vehicle_stmt->execute();
                                $vehicles = $vehicle_stmt->fetchAll();
                                foreach ($vehicles as $vehicle):
                                ?>
                                    <option value="<?= $vehicle['id'] ?>"><?= htmlspecialchars($vehicle['plate_number']) ?> - <?= htmlspecialchars($vehicle['brand'] . ' ' . $vehicle['model']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Notlar</label>
                            <textarea class="form-control" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Performans Değerlendirme Modal -->
    <div class="modal fade" id="addPerformanceModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-star"></i> Performans Değerlendirmesi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form id="addPerformanceForm">
                    <div class="modal-body">
                        <input type="hidden" id="performance_personnel_id" name="personnel_id">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Değerlendirme Tarihi *</label>
                                    <input type="date" class="form-control" name="evaluation_date" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Değerlendiren</label>
                                    <input type="text" class="form-control" name="evaluated_by" value="<?= htmlspecialchars($_SESSION['username']) ?>">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Genel Performans (0-10) *</label>
                                    <input type="number" class="form-control" name="performance_score" min="0" max="10" step="0.1" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Dakiklik (0-10) *</label>
                                    <input type="number" class="form-control" name="punctuality_score" min="0" max="10" step="0.1" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Güvenlik (0-10) *</label>
                                    <input type="number" class="form-control" name="safety_score" min="0" max="10" step="0.1" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label class="form-label">Müşteri Memnuniyeti (0-10) *</label>
                                    <input type="number" class="form-control" name="customer_feedback_score" min="0" max="10" step="0.1" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Toplam Çalışma Saati</label>
                                    <input type="number" class="form-control" name="total_hours_worked" min="0">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Fazla Mesai Saati</label>
                                    <input type="number" class="form-control" name="overtime_hours" min="0">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label">Olay Sayısı</label>
                                    <input type="number" class="form-control" name="incidents_count" min="0" value="0">
                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Yorumlar</label>
                            <textarea class="form-control" name="comments" rows="4"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">İptal</button>
                        <button type="submit" class="btn btn-primary">Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Personel Detay Modal -->
    <div class="modal fade" id="personnelDetailModal" tabindex="-1">
        <div class="modal-dialog modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="fas fa-user"></i> Personel Detayları</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="personnelDetailContent">
                        <div class="text-center py-5">
                            <div class="spinner-border text-primary" role="status">
                                <span class="visually-hidden">Yükleniyor...</span>
                            </div>
                            <p class="mt-2">Personel bilgileri yükleniyor...</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Custom CSS for Personnel Page -->
    <style>
        :root {
            --primary: #4e73df;
            --secondary: #858796;
            --success: #1cc88a;
            --info: #36b9cc;
            --warning: #f6c23e;
            --danger: #e74a3b;
            --light: #f8f9fc;
            --dark: #5a5c69;
        }
        
        .bg-soft-primary { background-color: rgba(78, 115, 223, 0.1) !important; }
        .bg-soft-success { background-color: rgba(28, 200, 138, 0.1) !important; }
        .bg-soft-info { background-color: rgba(54, 185, 204, 0.1) !important; }
        .bg-soft-warning { background-color: rgba(246, 194, 62, 0.1) !important; }
        .bg-soft-danger { background-color: rgba(231, 74, 59, 0.1) !important; }
        .bg-soft-secondary { background-color: rgba(133, 135, 150, 0.1) !important; }
        
        .text-soft-primary { color: rgba(78, 115, 223, 0.8) !important; }
        .text-soft-success { color: rgba(28, 200, 138, 0.8) !important; }
        .text-soft-info { color: rgba(54, 185, 204, 0.8) !important; }
        .text-soft-warning { color: rgba(246, 194, 62, 0.8) !important; }
        .text-soft-danger { color: rgba(231, 74, 59, 0.8) !important; }
        .text-soft-secondary { color: rgba(133, 135, 150, 0.8) !important; }
        /* Avatar Styles */
        .avatar {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        .avatar-sm {
            width: 36px;
            height: 36px;
            font-size: 0.875rem;
        }
        .avatar-initial {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            font-weight: 600;
        }
        
        /* Status Dot */
        .dot {
            height: 8px;
            width: 8px;
            border-radius: 50%;
            display: inline-block;
        }
        
        /* Card Styles */
        .card {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            background-color: #f8f9fc;
            border-bottom: 1px solid #e3e6f0;
        }
        
        .card-title {
            color: #4e73df;
            font-weight: 600;
        }
        
        /* Table Styles */
        .table > :not(:first-child) {
            border-top: 0;
        }
        .table > :not(caption) > * > * {
            padding: 1rem 1.25rem;
            border-bottom-width: 1px;
        }
        .table-hover > tbody > tr:hover {
            background-color: rgba(0, 0, 0, 0.02);
        }
        
        /* Badge Styles */
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
            font-size: 0.75em;
        }
        
        /* Buttons */
        .btn {
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 0.35rem;
            transition: all 0.2s;
        }
        
        .btn-icon {
            width: 2rem;
            height: 2rem;
            padding: 0;
            display: inline-flex;
            align-items: center;
            justify-content: center;
        }
        
        /* Quick Action Buttons */
        .quick-action-btn {
            white-space: nowrap;
            padding: 0.4rem 0.75rem;
            font-size: 0.8rem;
            border-radius: 0.375rem;
            transition: all 0.2s;
        }
        .quick-action-btn i {
            font-size: 0.9em;
        }
        
        /* Stats Cards */
        .stats-card {
            border: none;
            border-radius: 0.5rem;
            overflow: hidden;
            transition: transform 0.2s, box-shadow 0.2s;
        }
        .stats-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.05);
        }
        
        /* Form Controls */
        .form-control, .form-select {
            border: 1px solid #d1d3e2;
            border-radius: 0.35rem;
            padding: 0.5rem 0.75rem;
            font-size: 0.85rem;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: #bac8f3;
            box-shadow: 0 0 0 0.2rem rgba(78, 115, 223, 0.25);
        }
        
        .input-group-text {
            background-color: #f8f9fc;
            border: 1px solid #d1d3e2;
        }
        
        /* Badge Styles */
        .badge {
            font-weight: 500;
            padding: 0.35em 0.65em;
            font-size: 0.75em;
            border-radius: 0.25rem;
        }
        
        /* Avatar */
        .avatar {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
        }
        
        .avatar-sm {
            width: 2.5rem;
            height: 2.5rem;
            font-size: 1rem;
        }
        
        .avatar-initial {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 100%;
            height: 100%;
            font-weight: 600;
            color: #fff;
        }
        
        /* Status Indicator */
        .status-indicator {
            display: inline-block;
            width: 0.75rem;
            height: 0.75rem;
            border-radius: 50%;
            margin-right: 0.5rem;
        }
        
        .status-active { background-color: #1cc88a; }
        .status-inactive { background-color: #e74a3b; }
        .status-pending { background-color: #f6c23e; }
        
        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .table-responsive {
                border-radius: 0.5rem;
                border: 1px solid #dee2e6;
            }
            .table > :not(caption) > * > * {
                padding: 0.75rem 0.5rem;
            }
        }
    </style>
    
    <!-- Core JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons/dist/feather.min.js"></script>
    <script>
        // CSRF Token for AJAX requests
        const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
        
        // Initialize plugins when document is ready
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize Select2
            $('.select2').select2({
                theme: 'bootstrap-5',
                width: '100%',
                dropdownAutoWidth: true,
                language: 'tr',
                placeholder: 'Seçiniz...'
            });
            
            // Initialize date pickers
            flatpickr('.datepicker', {
                dateFormat: 'd.m.Y',
                locale: 'tr',
                allowInput: true
            });
            
            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
            
            // Initialize charts if any
            initCharts();
        });
        
        // Initialize charts
        function initCharts() {
            // Performance chart
            const ctx = document.getElementById('performanceChart');
            if (ctx) {
                new Chart(ctx, {
                    type: 'radar',
                    data: {
                        labels: ['Puanlama', 'Vardiya Tamamlama', 'Ekip Çalışması', 'Müşteri Memnuniyeti', 'Araç Bakımı'],
                        datasets: [{
                            label: 'Ortalama Performans',
                            data: [85, 90, 78, 92, 80],
                            fill: true,
                            backgroundColor: 'rgba(78, 115, 223, 0.2)',
                            borderColor: 'rgb(78, 115, 223)',
                            pointBackgroundColor: 'rgb(78, 115, 223)',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: 'rgb(78, 115, 223)'
                        }]
                    },
                    options: {
                        scales: {
                            r: {
                                angleLines: { display: true },
                                suggestedMin: 0,
                                suggestedMax: 100
                            }
                        }
                    }
                });
            }
        }
        
        // Personel ekleme formu
        document.getElementById('addPersonnelForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const submitBtn = this.querySelector('button[type="submit"]');
            const originalBtnText = submitBtn.innerHTML;
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Kaydediliyor...';
            
            // Simulate API call
            setTimeout(() => {
                // In a real app, you would use fetch/axios to submit the form
                console.log('Personel ekleme:', Object.fromEntries(formData));
                
                // Show success message
                Swal.fire({
                    icon: 'success',
                    title: 'Başarılı!',
                    text: 'Personel başarıyla eklendi.',
                    confirmButtonText: 'Tamam',
                    customClass: {
                        confirmButton: 'btn btn-primary'
                    },
                    buttonsStyling: false
                }).then(() => {
                    // Reset form and close modal
                    this.reset();
                    const modal = bootstrap.Modal.getInstance(document.getElementById('addPersonnelModal'));
                    modal.hide();
                    
                    // Refresh the page or update the table
                    window.location.reload();
                });
                
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            }, 1000);
        });
        
        // Delete personnel
        function deletePersonnel(id, name) {
            Swal.fire({
                title: 'Emin misiniz?',
                text: `"${name}" isimli personeli silmek istediğinizden emin misiniz? Bu işlem geri alınamaz!`,
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Evet, sil!',
                cancelButtonText: 'İptal',
                customClass: {
                    confirmButton: 'btn btn-danger me-2',
                    cancelButton: 'btn btn-secondary'
                },
                buttonsStyling: false
            }).then((result) => {
                if (result.isConfirmed) {
                    // Show loading
                    Swal.fire({
                        title: 'Siliniyor...',
                        text: 'Lütfen bekleyin...',
                        allowOutsideClick: false,
                        didOpen: () => {
                            Swal.showLoading();
                        }
                    });
                    
                    // Simulate API call
                    setTimeout(() => {
                        // In a real app, you would use fetch/axios to delete the personnel
                        console.log('Personel siliniyor:', id);
                        
                        // Show success message
                        Swal.fire({
                            icon: 'success',
                            title: 'Silindi!',
                            text: 'Personel başarıyla silindi.',
                            confirmButtonText: 'Tamam',
                            customClass: {
                                confirmButton: 'btn btn-primary'
                            },
                            buttonsStyling: false
                        }).then(() => {
                            // Remove the row from the table
                            const row = document.querySelector(`tr[data-personnel-id="${id}"]`);
                            if (row) {
                                row.remove();
                                updatePersonnelStats();
                            }
                        });
                    }, 1000);
                }
            });
        }
        
        // Update personnel stats
        function updatePersonnelStats() {
            const totalPersonnel = document.querySelectorAll('table tbody tr').length;
            const activePersonnel = document.querySelectorAll('table tbody tr .badge.bg-success').length;
            const onLeavePersonnel = document.querySelectorAll('table tbody tr .badge.bg-warning').length;
            
            document.getElementById('totalPersonnel').textContent = totalPersonnel;
            document.getElementById('activePersonnel').textContent = activePersonnel;
            document.getElementById('onLeavePersonnel').textContent = onLeavePersonnel;
        }
        
        // Filter table
        function filterTable() {
            const searchInput = document.getElementById('searchInput').value.toLowerCase();
            const statusFilter = document.getElementById('statusFilter').value;
            const rows = document.querySelectorAll('table tbody tr');
            
            rows.forEach(row => {
                const name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const position = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                const status = row.querySelector('td:nth-child(5) .badge').textContent.toLowerCase();
                const statusMatch = statusFilter === 'all' || status.includes(statusFilter);
                const searchMatch = name.includes(searchInput) || position.includes(searchInput);
                
                if (statusMatch && searchMatch) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
            
            updatePersonnelStats();
        }
        
        // Export to Excel
        function exportToExcel() {
            // In a real app, this would generate an Excel file
            Swal.fire({
                icon: 'info',
                title: 'Dışa Aktar',
                text: 'Personel listesi Excel formatında dışa aktarılıyor...',
                showConfirmButton: false,
                timer: 2000
            });
            
            // Simulate download
            setTimeout(() => {
                const table = document.createElement('table');
                const thead = document.createElement('thead');
                const tbody = document.createElement('tbody');
                
                // Add headers
                const headerRow = document.createElement('tr');
                document.querySelectorAll('table thead th').forEach(th => {
                    const cell = document.createElement('th');
                    cell.textContent = th.textContent;
                    headerRow.appendChild(cell);
                });
                thead.appendChild(headerRow);
                table.appendChild(thead);
                
                // Add rows
                document.querySelectorAll('table tbody tr:not([style*="display: none"])').forEach(tr => {
                    const row = document.createElement('tr');
                    tr.querySelectorAll('td').forEach(td => {
                        const cell = document.createElement('td');
                        // Remove any buttons or icons from the cell content
                        const cellContent = td.cloneNode(true);
                        const buttons = cellContent.querySelectorAll('button, .btn, .dropdown, .dropdown-menu, .dropdown-toggle');
                        buttons.forEach(btn => btn.remove());
                        cell.textContent = cellContent.textContent.trim();
                        row.appendChild(cell);
                    });
                    tbody.appendChild(row);
                });
                table.appendChild(tbody);
                
                // Create a download link
                const html = table.outerHTML;
                const blob = new Blob([html], { type: 'application/vnd.ms-excel' });
                const url = URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'personel-listesi.xls';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 500);
        }
        
        // Print table
        function printTable() {
            const printWindow = window.open('', '_blank');
            const table = document.querySelector('table').cloneNode(true);
            
            // Remove action buttons
            const actionColumns = table.querySelectorAll('th:last-child, td:last-child');
            actionColumns.forEach(cell => cell.remove());
            
            // Create print content
            const printContent = `
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Personel Listesi - Yazdır</title>
                    <style>
                        body { font-family: Arial, sans-serif; font-size: 12px; }
                        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                        th { background-color: #f5f5f5; font-weight: bold; }
                        .text-center { text-align: center; }
                        .badge { padding: 3px 8px; border-radius: 4px; font-weight: normal; }
                        .bg-success { background-color: #d4edda !important; color: #155724 !important; }
                        .bg-warning { background-color: #fff3cd !important; color: #856404 !important; }
                        .bg-danger { background-color: #f8d7da !important; color: #721c24 !important; }
                        .print-header { margin-bottom: 20px; text-align: center; }
                        .print-title { font-size: 20px; font-weight: bold; margin-bottom: 10px; }
                        .print-date { margin-bottom: 15px; color: #666; }
                    </style>
                </head>
                <body>
                    <div class="print-header">
                        <div class="print-title">Personel Listesi</div>
                        <div class="print-date">${new Date().toLocaleString('tr-TR')}</div>
                    </div>
                    ${table.outerHTML}
                    <script>
                        window.onload = function() {
                            window.print();
                            setTimeout(function() { window.close(); }, 100);
                        };
                    <\/script>
                </body>
                </html>
            `;
            
            printWindow.document.open();
            printWindow.document.write(printContent);
            printWindow.document.close();
        }
        
        // View personnel details
        function viewPersonnelDetails(id) {
            // In a real app, this would fetch personnel details via AJAX
            console.log('Viewing personnel details:', id);
            
            // Show loading
            Swal.fire({
                title: 'Yükleniyor...',
                text: 'Personel bilgileri yükleniyor, lütfen bekleyiniz.',
                allowOutsideClick: false,
                didOpen: () => {
                    Swal.showLoading();
                }
            });
            
            // Simulate API call
            setTimeout(() => {
                // Sample data - in a real app, this would come from the server
                const personnelData = {
                    id: id,
                    name: 'Ahmet Yılmaz',
                    position: 'Şoför',
                    department: 'Lojistik',
                    email: 'ahmet.yilmaz@example.com',
                    phone: '+90 555 123 4567',
                    hireDate: '15.05.2020',
                    status: 'Aktif',
                    statusClass: 'success',
                    address: 'Örnek Mah. Demo Sokak No:123/4 İstanbul',
                    emergencyContact: 'Ayşe Yılmaz (Eş) - +90 555 987 6543',
                    licenseNumber: 'A123456789',
                    licenseExpiry: '31.12.2025',
                    performance: 92,
                    shiftsThisMonth: 18,
                    totalShifts: 245,
                    documents: [
                        { name: 'Sürücü Belgesi', expiry: '31.12.2025', status: 'Geçerli' },
                        { name: 'Psikoteknik Raporu', expiry: '15.08.2024', status: 'Geçerli' },
                        { name: 'Sağlık Raporu', expiry: '30.06.2024', status: 'Yakında Yenilenecek' }
                    ]
                };
                
                // Create HTML for documents
                let documentsHtml = '';
                personnelData.documents.forEach(doc => {
                    let statusClass = 'text-success';
                    if (doc.status !== 'Geçerli') {
                        statusClass = 'text-warning';
                    }
                    documentsHtml += `
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <i class="fas fa-file-alt me-2"></i>
                                <span>${doc.name}</span>
                            </div>
                            <div>
                                <small class="text-muted me-3">Son Geçerlilik: ${doc.expiry}</small>
                                <span class="badge bg-soft-${doc.status === 'Geçerli' ? 'success' : 'warning'} text-${doc.status === 'Geçerli' ? 'success' : 'warning'} p-1">
                                    ${doc.status}
                                </span>
                            </div>
                        </div>
                    `;
                });
                
                // Show details in a modal
                Swal.fire({
                    title: 'Personel Detayları',
                    html: `
                        <div class="container-fluid">
                            <div class="row mb-4">
                                <div class="col-md-3 text-center">
                                    <div class="avatar avatar-xxl mb-3">
                                        <div class="avatar-initial bg-primary text-white rounded-circle">
                                            ${personnelData.name.split(' ').map(n => n[0]).join('')}
                                        </div>
                                    </div>
                                    <h5 class="mb-1">${personnelData.name}</h5>
                                    <p class="text-muted mb-2">${personnelData.position}</p>
                                    <span class="badge bg-${personnelData.statusClass} mb-3">${personnelData.status}</span>
                                </div>
                                <div class="col-md-9">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <p><strong>Departman:</strong> ${personnelData.department}</p>
                                            <p><strong>İşe Giriş Tarihi:</strong> ${personnelData.hireDate}</p>
                                            <p><strong>E-posta:</strong> ${personnelData.email}</p>
                                            <p><strong>Telefon:</strong> ${personnelData.phone}</p>
                                        </div>
                                        <div class="col-md-6">
                                            <p><strong>Adres:</strong> ${personnelData.address}</p>
                                            <p><strong>Acil Durum İletişimi:</strong> ${personnelData.emergencyContact}</p>
                                            <p><strong>Sürücü Belge No:</strong> ${personnelData.licenseNumber}</p>
                                            <p><strong>Belge Geçerlilik:</strong> ${personnelData.licenseExpiry}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card shadow-sm mb-4">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Performans İstatistikleri</h6>
                                        </div>
                                        <div class="card-body">
                                            <div class="mb-3">
                                                <div class="d-flex justify-content-between mb-1">
                                                    <span>Genel Performans</span>
                                                    <strong>${personnelData.performance}%</strong>
                                                </div>
                                                <div class="progress" style="height: 10px;">
                                                    <div class="progress-bar bg-success" role="progressbar" style="width: ${personnelData.performance}%" 
                                                         aria-valuenow="${personnelData.performance}" aria-valuemin="0" aria-valuemax="100"></div>
                                                </div>
                                            </div>
                                            <div class="row text-center">
                                                <div class="col-6">
                                                    <div class="border rounded p-2 mb-2">
                                                        <div class="text-muted small">Bu Ayki Vardiya</div>
                                                        <div class="h5 mb-0">${personnelData.shiftsThisMonth}</div>
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="border rounded p-2 mb-2">
                                                        <div class="text-muted small">Toplam Vardiya</div>
                                                        <div class="h5 mb-0">${personnelData.totalShifts}</div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card shadow-sm">
                                        <div class="card-header py-3">
                                            <h6 class="m-0 font-weight-bold text-primary">Belgeler</h6>
                                        </div>
                                        <div class="card-body">
                                            ${documentsHtml || '<p class="text-muted">Kayıtlı belge bulunamadı.</p>'}
                                            <button class="btn btn-sm btn-outline-primary mt-2">
                                                <i class="fas fa-plus me-1"></i> Yeni Belge Ekle
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    `,
                    width: '900px',
                    showCloseButton: true,
                    showConfirmButton: false,
                    customClass: {
                        container: 'personnel-detail-modal',
                        popup: 'p-0',
                        htmlContainer: 'p-0'
                    },
                    didOpen: () => {
                        // Initialize tooltips in the modal
                        var tooltipTriggerList = [].slice.call(document.querySelectorAll('.personnel-detail-modal [data-bs-toggle="tooltip"]'));
                        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                            return new bootstrap.Tooltip(tooltipTriggerEl);
                        });
                    }
                });
            }, 800);
        }
        
        // Edit personnel
        function editPersonnel(id) {
            // In a real app, this would fetch personnel data and open an edit form
            console.log('Editing personnel:', id);
            
            // For demo, just show a message
            Swal.fire({
                icon: 'info',
                title: 'Düzenleme Modu',
                text: 'Personel düzenleme işlemi için hazırlık yapılıyor...',
                showConfirmButton: false,
                timer: 1500
            });
            
            // In a real app, you would open a modal with the form pre-filled with personnel data
            // For now, we'll just show the add personnel modal
            setTimeout(() => {
                const addPersonnelModal = new bootstrap.Modal(document.getElementById('addPersonnelModal'));
                const modalTitle = document.querySelector('#addPersonnelModal .modal-title');
                const submitBtn = document.querySelector('#addPersonnelForm button[type="submit"]');
                
                // Update modal for editing
                modalTitle.textContent = 'Personel Düzenle';
                submitBtn.textContent = 'Güncelle';
                submitBtn.classList.remove('btn-primary');
                submitBtn.classList.add('btn-warning');
                
                // In a real app, you would populate the form with existing data here
                
                // Show the modal
                addPersonnelModal.show();
            }, 500);
        }
        
        // Add shift
        function addShift() {
            // In a real app, this would open a modal to add a new shift
            console.log('Adding new shift');
            
            // For demo, just show a message
            Swal.fire({
                icon: 'info',
                title: 'Vardiya Ekle',
                text: 'Yeni vardiya ekleme formu açılıyor...',
                showConfirmButton: false,
                timer: 1500
            });
            
            // In a real app, you would open a modal with the shift form
            setTimeout(() => {
                const modal = new bootstrap.Modal(document.getElementById('addShiftModal'));
                modal.show();
            }, 500);
        }
        
        // Save shift form
        document.getElementById('saveShiftBtn').addEventListener('click', function() {
            const form = document.getElementById('shiftForm');
            const formData = new FormData(form);
            const submitBtn = this;
            const originalBtnText = submitBtn.innerHTML;
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Kaydediliyor...';
            
            // Simulate API call
            setTimeout(() => {
                // In a real app, you would submit the form data to the server
                console.log('Vardiya kaydediliyor:', Object.fromEntries(formData));
                
                // Show success message
                Swal.fire({
                    icon: 'success',
                    title: 'Başarılı!',
                    text: 'Vardiya başarıyla eklendi.',
                    confirmButtonText: 'Tamam',
                    customClass: {
                        confirmButton: 'btn btn-primary'
                    },
                    buttonsStyling: false
                }).then(() => {
                    // Close the modal
                    const modal = bootstrap.Modal.getInstance(document.getElementById('addShiftModal'));
                    modal.hide();
                    
                    // Reset the form
                    form.reset();
                    
                    // In a real app, you would refresh the shifts list
                });
                
                // Reset button state
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalBtnText;
            }, 1000);
        });
        
        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            // Update stats on page load
            updatePersonnelStats();
            
            // Add event listeners for filter inputs
            document.getElementById('searchInput').addEventListener('keyup', filterTable);
            document.getElementById('statusFilter').addEventListener('change', filterTable);
            
            // Initialize tooltips
            var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
            var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
                return new bootstrap.Tooltip(tooltipTriggerEl);
            });
        });
        
            const modal = bootstrap.Modal.getInstance(document.getElementById('addPersonnelModal'));
            modal.hide();
            this.reset();
        });

        // Personel detayları görüntüleme
        function viewPersonnelDetails(personnelId) {
            console.log('Personel detayları görüntüleniyor:', personnelId);
            alert('Personel detayları yükleniyor... (Demo)');
        }

        // Vardiya ekleme
        function addShift(personnelId) {
            document.getElementById('shift_personnel_id').value = personnelId;
            const modal = new bootstrap.Modal(document.getElementById('addShiftModal'));
            modal.show();
        }

        // Performans değerlendirmesi ekleme
        function addPerformance(personnelId) {
            document.getElementById('performance_personnel_id').value = personnelId;
            const modal = new bootstrap.Modal(document.getElementById('addPerformanceModal'));
            modal.show();
        }

        // Vardiya ekleme formu
        document.getElementById('addShiftForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            console.log('Vardiya ekleme:', Object.fromEntries(formData));
            
            alert('Vardiya başarıyla eklendi! (Demo)');
            
            const modal = bootstrap.Modal.getInstance(document.getElementById('addShiftModal'));
            modal.hide();
            this.reset();
        });

        // Performans değerlendirme formu
        document.getElementById('addPerformanceForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            console.log('Performans değerlendirmesi:', Object.fromEntries(formData));
            
            alert('Performans değerlendirmesi başarıyla kaydedildi! (Demo)');
            
            const modal = bootstrap.Modal.getInstance(document.getElementById('addPerformanceModal'));
            modal.hide();
            this.reset();
        });

        // Personel detayları
        function viewPersonnelDetails(personnelId) {
            const modal = new bootstrap.Modal(document.getElementById('personnelDetailModal'));
            modal.show();
            
            // Simulated loading
            setTimeout(() => {
                document.getElementById('personnelDetailContent').innerHTML = `
                    <div class="row">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-user"></i> Kişisel Bilgiler</h6>
                                </div>
                                <div class="card-body">
                                    <p><strong>Ad Soyad:</strong> Ahmet Yılmaz</p>
                                    <p><strong>Pozisyon:</strong> Şoför</p>
                                    <p><strong>Telefon:</strong> 0532 123 4567</p>
                                    <p><strong>E-posta:</strong> ahmet@example.com</p>
                                    <p><strong>İşe Başlama:</strong> 15.03.2022</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-chart-line"></i> Performans Özeti</h6>
                                </div>
                                <div class="card-body">
                                    <p><strong>Genel Performans:</strong> <span class="badge bg-success">8.5/10</span></p>
                                    <p><strong>Dakiklik:</strong> <span class="badge bg-success">9.0/10</span></p>
                                    <p><strong>Güvenlik:</strong> <span class="badge bg-warning">8.0/10</span></p>
                                    <p><strong>Müşteri Memnuniyeti:</strong> <span class="badge bg-success">9.5/10</span></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-calendar"></i> Vardiya Bilgileri</h6>
                                </div>
                                <div class="card-body">
                                    <p><strong>Bu Ay Vardiya:</strong> 22 gün</p>
                                    <p><strong>Fazla Mesai:</strong> 15 saat</p>
                                    <p><strong>Son Vardiya:</strong> 07.09.2024</p>
                                    <p><strong>Toplam Saat:</strong> 180 saat</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h6 class="mb-0"><i class="fas fa-file-alt"></i> Belgeler ve Sertifikalar</h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Belge Türü</th>
                                                    <th>Belge Adı</th>
                                                    <th>Geçerlilik</th>
                                                    <th>Durum</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Ehliyet</td>
                                                    <td>CE Sınıfı Ehliyet</td>
                                                    <td>15.03.2030</td>
                                                    <td><span class="badge bg-success">Aktif</span></td>
                                                </tr>
                                                <tr>
                                                    <td>Sertifika</td>
                                                    <td>Mesleki Yeterlilik</td>
                                                    <td>10.01.2029</td>
                                                    <td><span class="badge bg-success">Aktif</span></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            }, 1000);
        }
    </script>
