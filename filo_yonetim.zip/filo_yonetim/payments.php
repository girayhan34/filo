<?php
require_once 'includes/auth.php';
require_once 'includes/config.php';

// Örnek ödeme verileri - gerçek uygulamada veritabanından gelecek
$payment_data = [
    [
        'id' => 1,
        'payment_date' => '2024-01-15',
        'invoice_number' => 'FAT-001',
        'customer' => 'ABC Lojistik Ltd.',
        'amount' => 2500.00,
        'payment_method' => 'Havale/EFT',
        'reference_no' => 'REF123456',
        'status' => 'completed',
        'notes' => 'Zamanında ödeme alındı'
    ],
    [
        'id' => 2,
        'payment_date' => '2024-01-14',
        'invoice_number' => 'FAT-002',
        'customer' => 'XYZ Nakliyat A.Ş.',
        'amount' => 1800.00,
        'payment_method' => 'Kredi Kartı',
        'reference_no' => 'CC789012',
        'status' => 'completed',
        'notes' => ''
    ],
    [
        'id' => 3,
        'payment_date' => '2024-01-13',
        'invoice_number' => 'FAT-003',
        'customer' => 'DEF Kargo',
        'amount' => 3200.00,
        'payment_method' => 'Nakit',
        'reference_no' => '',
        'status' => 'pending',
        'notes' => 'Kısmi ödeme alındı'
    ],
    [
        'id' => 4,
        'payment_date' => '2024-01-12',
        'invoice_number' => 'FAT-004',
        'customer' => 'GHI Taşımacılık',
        'amount' => 4500.00,
        'payment_method' => 'Çek',
        'reference_no' => 'CHK345678',
        'status' => 'completed',
        'notes' => 'Çek tahsil edildi'
    ]
];

// İstatistikler
$total_payments = count($payment_data);
$completed_payments = count(array_filter($payment_data, fn($p) => $p['status'] === 'completed'));
$pending_payments = count(array_filter($payment_data, fn($p) => $p['status'] === 'pending'));
$total_amount = array_sum(array_column($payment_data, 'amount'));
?>
<?php
$page_title = 'Ödeme Yönetimi';
$page_subtitle = 'Yapılan ve bekleyen ödemeleri takip edin.';
include 'includes/header.php';
?>
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h1 class="h3 mb-0"><i class="fas fa-credit-card me-2"></i>Ödeme Yönetimi</h1>
                    </div>

                    <!-- Hızlı İşlem Butonları -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="quick-actions">
                                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPaymentModal">
                                    <i class="fas fa-plus"></i> Yeni Ödeme
                                </button>
                                <button class="btn btn-success" onclick="filterPayments('completed')">
                                    <i class="fas fa-check-circle"></i> Tamamlanan
                                </button>
                                <button class="btn btn-warning" onclick="filterPayments('pending')">
                                    <i class="fas fa-clock"></i> Bekleyen
                                </button>
                                <button class="btn btn-info" onclick="exportPayments()">
                                    <i class="fas fa-file-export"></i> Dışa Aktar
                                </button>
                                <button class="btn btn-secondary" onclick="printPayments()">
                                    <i class="fas fa-print"></i> Yazdır
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- İstatistik Kartları -->
                    <div class="row mb-4">
                        <div class="col-md-3 mb-3">
                            <div class="card stats-card">
                                <i class="fas fa-credit-card"></i>
                                <h2><?= $total_payments ?></h2>
                                <p>Toplam Ödeme</p>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card stats-card">
                                <i class="fas fa-check-circle text-success"></i>
                                <h2><?= $completed_payments ?></h2>
                                <p>Tamamlanan</p>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card stats-card">
                                <i class="fas fa-clock text-warning"></i>
                                <h2><?= $pending_payments ?></h2>
                                <p>Bekleyen</p>
                            </div>
                        </div>
                        <div class="col-md-3 mb-3">
                            <div class="card stats-card">
                                <i class="fas fa-money-bill-wave text-info"></i>
                                <h2><?= number_format($total_amount, 0, ',', '.') ?>₺</h2>
                                <p>Toplam Tutar</p>
                            </div>
                        </div>
                    </div>

                    <!-- Arama ve Filtre -->
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-search"></i></span>
                                <input type="text" class="form-control" id="searchInput" placeholder="Ödeme ara...">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <select class="form-select" id="statusFilter" onchange="filterPayments(this.value)">
                                <option value="all">Tüm Ödemeler</option>
                                <option value="completed">Tamamlanan</option>
                                <option value="pending">Bekleyen</option>
                            </select>
                        </div>
                    </div>

                    <!-- Ödeme Listesi -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0"><i class="fas fa-list me-2"></i>Ödeme Listesi</h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover" id="paymentsTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Tarih</th>
                                            <th>Fatura No</th>
                                            <th>Müşteri</th>
                                            <th>Tutar</th>
                                            <th>Ödeme Yöntemi</th>
                                            <th>Referans</th>
                                            <th>Durum</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($payment_data as $payment): ?>
                                        <tr>
                                            <td><?= date('d.m.Y', strtotime($payment['payment_date'])) ?></td>
                                            <td><strong><?= htmlspecialchars($payment['invoice_number']) ?></strong></td>
                                            <td><?= htmlspecialchars($payment['customer']) ?></td>
                                            <td><strong><?= number_format($payment['amount'], 2, ',', '.') ?>₺</strong></td>
                                            <td>
                                                <?php
                                                $method_icons = [
                                                    'Nakit' => '<i class="fas fa-money-bill"></i>',
                                                    'Kredi Kartı' => '<i class="fas fa-credit-card"></i>',
                                                    'Havale/EFT' => '<i class="fas fa-university"></i>',
                                                    'Çek' => '<i class="fas fa-file-invoice"></i>'
                                                ];
                                                echo ($method_icons[$payment['payment_method']] ?? '') . ' ' . htmlspecialchars($payment['payment_method']);
                                                ?>
                                            </td>
                                            <td><?= htmlspecialchars($payment['reference_no'] ?: '-') ?></td>
                                            <td>
                                                <?php if ($payment['status'] === 'completed'): ?>
                                                    <span class="badge bg-success">Tamamlandı</span>
                                                <?php elseif ($payment['status'] === 'pending'): ?>
                                                    <span class="badge bg-warning">Bekliyor</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <div class="btn-group" role="group">
                                                    <button class="btn btn-outline-primary btn-sm" onclick="viewPayment(<?= $payment['id'] ?>)" title="Görüntüle">
                                                        <i class="fas fa-eye"></i>
                                                    </button>
                                                    <button class="btn btn-outline-warning btn-sm" onclick="editPayment(<?= $payment['id'] ?>)" title="Düzenle">
                                                        <i class="fas fa-edit"></i>
                                                    </button>
                                                    <button class="btn btn-outline-info btn-sm" onclick="printPayment(<?= $payment['id'] ?>)" title="Yazdır">
                                                        <i class="fas fa-print"></i>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                </div>
<?php include 'includes/footer.php'; ?>

<script>
// Ödeme filtreleme fonksiyonları
function filterPayments(status) {
    const rows = document.querySelectorAll('#paymentsTable tbody tr');
    rows.forEach(row => {
        if (status === 'all') {
            row.style.display = '';
        } else {
            const statusBadge = row.querySelector('.badge');
            const rowStatus = statusBadge ? statusBadge.textContent.toLowerCase() : '';
            
            let shouldShow = false;
            if (status === 'completed' && rowStatus.includes('tamamlandı')) shouldShow = true;
            if (status === 'pending' && rowStatus.includes('bekliyor')) shouldShow = true;
            
            row.style.display = shouldShow ? '' : 'none';
        }
    });
}

// Ödeme işlem fonksiyonları
function viewPayment(id) {
    console.log('Ödeme görüntüleniyor:', id);
}

function editPayment(id) {
    console.log('Ödeme düzenleniyor:', id);
}

function printPayment(id) {
    window.print();
}

function exportPayments() {
    alert('Dışa aktarma özelliği yakında eklenecek');
}

function printPayments() {
    window.print();
}

// Arama fonksiyonu
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = document.querySelectorAll('#paymentsTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchTerm) ? '' : 'none';
            });
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>